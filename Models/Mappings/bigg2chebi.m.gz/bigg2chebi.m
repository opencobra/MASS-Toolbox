(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
{metabolite["2pg", _] -> ChEBI["17835"], metabolite["fdp", _] -> 
  ChEBI["16905"], metabolite["atp", _] -> ChEBI["15422"], 
 metabolite["acald", _] -> ChEBI["15343"], metabolite["asp-L", _] -> 
  ChEBI["17053"], metabolite["ala-D", _] -> ChEBI["15570"], 
 metabolite["5mdr1p", _] -> ChEBI["27859"], metabolite["5mta", _] -> 
  ChEBI["17509"], metabolite["acglu", _] -> ChEBI["17533"], 
 metabolite["3c2hmp", _] -> ChEBI["35121"], metabolite["3mop", _] -> 
  ChEBI["15614"], metabolite["3c3hmp", _] -> ChEBI["1178"], 
 metabolite["3dhq", _] -> ChEBI["17947"], metabolite["aps", _] -> 
  ChEBI["17709"], metabolite["paps", _] -> ChEBI["17980"], 
 metabolite["aspsa", _] -> ChEBI["13086"], metabolite["lys-L", _] -> 
  ChEBI["18019"], metabolite["dad-2", _] -> ChEBI["17256"], 
 metabolite["ins", _] -> ChEBI["17596"], metabolite["dgdp", _] -> 
  ChEBI["28862"], metabolite["dttp", _] -> ChEBI["18077"], 
 metabolite["dgtp", _] -> ChEBI["16497"], metabolite["din", _] -> 
  ChEBI["28997"], metabolite["5pmev", _] -> ChEBI["17436"], 
 metabolite["4ampm", _] -> ChEBI["18032"], metabolite["2mahmp", _] -> 
  ChEBI["16629"], metabolite["dpcoa", _] -> ChEBI["15468"], 
 metabolite["23dhb", _] -> ChEBI["18026"], metabolite["ru5p-L", _] -> 
  ChEBI["17666"], metabolite["tre", _] -> ChEBI["16551"], 
 metabolite["fru", _] -> ChEBI["15824"], metabolite["udcpp", _] -> 
  ChEBI["16141"], metabolite["ugmda", _] -> ChEBI["18199"], 
 metabolite["glu-D", _] -> ChEBI["15966"], metabolite["hemeO", _] -> 
  ChEBI["24480"], metabolite["leutrna", _] -> ChEBI["16624"], 
 metabolite["trnacys", _] -> ChEBI["29167"], metabolite["histrna", _] -> 
  ChEBI["29155"], metabolite["metsox-S-L", _] -> ChEBI["17016"], 
 metabolite["ppp9", _] -> ChEBI["15430"], metabolite["fcl-L", _] -> 
  ChEBI["17617"], metabolite["itp", _] -> ChEBI["16039"], 
 metabolite["Lfmkynr", _] -> ChEBI["30249"], metabolite["n4abutn", _] -> 
  ChEBI["7386"], metabolite["5aop", _] -> ChEBI["17549"], 
 metabolite["trnathr", _] -> ChEBI["29180"], metabolite["ttdca", _] -> 
  ChEBI["28875"], metabolite["ocdca", _] -> ChEBI["25629"], 
 metabolite["dcacoa", _] -> ChEBI["28493"], metabolite["fuc-L", _] -> 
  ChEBI["2181"], metabolite["glcr", _] -> ChEBI["16002"], 
 metabolite["seln", _] -> ChEBI["16503"], metabolite["gbbtn", _] -> 
  ChEBI["1941"], metabolite["apoACP", _] -> ChEBI["16139"], 
 metabolite["btamp", _] -> ChEBI["3110"], metabolite["mg2", _] -> 
  ChEBI["18420"], metabolite["pre6b", _] -> ChEBI["27858"], 
 metabolite["ppcoa", _] -> ChEBI["15539"], metabolite["minohp", _] -> 
  ChEBI["17401"], metabolite["cholcoads", _] -> ChEBI["27505"], 
 metabolite["carn", _] -> ChEBI["15727"], metabolite["chlstol", _] -> 
  ChEBI["16290"], metabolite["11docrtsl", _] -> ChEBI["28324"], 
 metabolite["prostgf2", _] -> ChEBI["15553"], metabolite["bildglcur", _] -> 
  ChEBI["18392"], metabolite["1pipdn2c", _] -> ChEBI["30912"], 
 metabolite["so2", _] -> ChEBI["18422"], metabolite["pg161", _] -> 
  ChEBI["17517"], metabolite["pe141", _] -> ChEBI["16038"], 
 metabolite["pa120", _] -> ChEBI["16337"], metabolite["12ppd-R", _] -> 
  ChEBI["28972"], metabolite["forcoa", _] -> ChEBI["15522"], 
 metabolite["mthgxl", _] -> ChEBI["17158"], metabolite["thdp", _] -> 
  ChEBI["864"], metabolite["dhpt", _] -> ChEBI["4581"], 
 metabolite["mn2", _] -> ChEBI["18291"], metabolite["uacgam", _] -> 
  ChEBI["16264"], metabolite["2maacoa", _] -> ChEBI["15476"], 
 metabolite["f6p", _] -> ChEBI["15946"], metabolite["q8", _] -> 
  ChEBI["16389"], metabolite["acnam", _] -> ChEBI["17012"], 
 metabolite["dxyl", _] -> ChEBI["28354"], metabolite["4per", _] -> 
  ChEBI["49003"], metabolite["4abutn", _] -> ChEBI["17769"], 
 metabolite["cyst-L", _] -> ChEBI["17482"], metabolite["odecoa", _] -> 
  ChEBI["15534"], metabolite["2pglyc", _] -> ChEBI["17150"], 
 metabolite["adocbip", _] -> ChEBI["2481"], metabolite["fuc1p-L", _] -> 
  ChEBI["28319"], metabolite["methf", _] -> ChEBI["15638"], 
 metabolite["frmd", _] -> ChEBI["16397"], metabolite["dgmp", _] -> 
  ChEBI["16192"], metabolite["6ax", _] -> ChEBI["16586"], 
 metabolite["pre2", _] -> ChEBI["50602"], metabolite["ca2", _] -> 
  ChEBI["29108"], metabolite["dmpp", _] -> ChEBI["16057"], 
 metabolite["3hmp", _] -> ChEBI["11805"], metabolite["rbl-D", _] -> 
  ChEBI["17173"], metabolite["dhcholoylcoa", _] -> ChEBI["27393"], 
 metabolite["cdpdtdecg", _] -> ChEBI["17962"], 
 metabolite["npthl", _] -> ChEBI["16482"], metabolite["clpn180", _] -> 
  ChEBI["28494"], metabolite["msh", _] -> ChEBI["16768"], 
 metabolite["andrstandn", _] -> ChEBI["16985"], 
 metabolite["5aptn", _] -> ChEBI["15887"], metabolite["met-L", _] -> 
  ChEBI["16643"], metabolite["56dthm", _] -> ChEBI["27468"], 
 metabolite["lgt-S", _] -> ChEBI["15694"], metabolite["s17bp", _] -> 
  ChEBI["17969"], metabolite["lipidX", _] -> ChEBI["16942"], 
 metabolite["dhpmp", _] -> ChEBI["48954"], metabolite["pydx", _] -> 
  ChEBI["17310"], metabolite["gdpmann", _] -> ChEBI["15820"], 
 metabolite["35cimp", _] -> ChEBI["27541"], metabolite["hqn", _] -> 
  ChEBI["17594"], metabolite["NPmehis", _] -> ChEBI["27596"], 
 metabolite["hxdcal", _] -> ChEBI["17600"], metabolite["arachd", _] -> 
  ChEBI["15843"], metabolite["bhb", _] -> ChEBI["10983"], 
 metabolite["copre3", _] -> ChEBI["3791"], metabolite["xylu-L", _] -> 
  ChEBI["17399"], metabolite["zymstnl", _] -> ChEBI["16608"], 
 metabolite["11docrtstrn", _] -> ChEBI["16973"], 
 metabolite["prostgi2", _] -> ChEBI["15552"], 
 metabolite["crtsl", _] -> ChEBI["17650"], metabolite["o2s", _] -> 
  ChEBI["18421"], metabolite["5fthf", _] -> ChEBI["15640"], 
 metabolite["adfdRD", _] -> ChEBI["16906"], metabolite["dh4mchc", _] -> 
  ChEBI["17095"], metabolite["tagur", _] -> ChEBI["17886"], 
 metabolite["f26bp", _] -> ChEBI["28602"], metabolite["pgp_EC", _] -> 
  ChEBI["37393"], metabolite["scl", _] -> ChEBI["18023"], 
 metabolite["malt6p", _] -> ChEBI["15703"], metabolite["adprbp", _] -> 
  ChEBI["37463"], metabolite["citmcoa-L", _] -> ChEBI["36882"], 
 metabolite["saccrp-L", _] -> ChEBI["16927"], 
 metabolite["dad-5", _] -> ChEBI["17319"], metabolite["dhcholestanate", _] -> 
  ChEBI["16577"], metabolite["pg181", _] -> ChEBI["17517"], 
 metabolite["perillyl", _] -> ChEBI["10782"], 
 metabolite["vanlt", _] -> ChEBI["30816"], metabolite["26dap-LL", _] -> 
  ChEBI["16026"], metabolite["uAgl", _] -> ChEBI["9837"], 
 metabolite["amuco", _] -> ChEBI["16886"], metabolite["3dsphgn", _] -> 
  ChEBI["17862"], metabolite["xu5p-L", _] -> ChEBI["16593"], 
 metabolite["3hanthrn", _] -> ChEBI["15793"], 
 metabolite["malm", _] -> ChEBI["29045"], metabolite["cysam", _] -> 
  ChEBI["17141"], metabolite["34dhmald", _] -> ChEBI["27852"], 
 metabolite["15HPET", _] -> ChEBI["15628"], metabolite["4tmeabutn", _] -> 
  ChEBI["1941"], metabolite["arach", _] -> ChEBI["28822"], 
 metabolite["Nacasp", _] -> ChEBI["16953"], metabolite["confrl", _] -> 
  ChEBI["17745"], metabolite["rml1p", _] -> ChEBI["17892"], 
 metabolite["raffin", _] -> ChEBI["16634"], metabolite["pc_EC", _] -> 
  ChEBI["16110"], metabolite["hicit", _] -> ChEBI["15404"], 
 metabolite["hgbyr", _] -> ChEBI["17926"], metabolite["mi3p-D", _] -> 
  ChEBI["18169"], metabolite["dhcholestancoa", _] -> ChEBI["15494"], 
 metabolite["12dgr181", _] -> ChEBI["17815"], metabolite["bz12diol", _] -> 
  ChEBI["18340"], metabolite["cytcc", _] -> ChEBI["18070"], 
 metabolite["C04051", _] -> ChEBI["2030"], metabolite["2c25dho", _] -> 
  ChEBI["16993"], metabolite["nformanth", _] -> ChEBI["36575"], 
 metabolite["lpp", _] -> ChEBI["6495"], metabolite["hexdp", _] -> 
  ChEBI["17528"], metabolite["focytcc553", _] -> ChEBI["15856"], 
 metabolite["nal2a6o", _] -> ChEBI["17355"], metabolite["acetol", _] -> 
  ChEBI["27957"], metabolite["h", _] -> ChEBI["15378"], 
 metabolite["pyr", _] -> ChEBI["32816"], metabolite["r5p", _] -> 
  ChEBI["17797"], metabolite["cit", _] -> ChEBI["30769"], 
 metabolite["ppi", _] -> ChEBI["18361"], metabolite["utp", _] -> 
  ChEBI["15713"], metabolite["ala-L", _] -> ChEBI["16977"], 
 metabolite["5mdru1p", _] -> ChEBI["28096"], metabolite["urea", _] -> 
  ChEBI["16199"], metabolite["ptrc", _] -> ChEBI["17148"], 
 metabolite["glu5p", _] -> ChEBI["17798"], metabolite["ile-L", _] -> 
  ChEBI["17191"], metabolite["2dda7p", _] -> ChEBI["18150"], 
 metabolite["3php", _] -> ChEBI["30933"], metabolite["pser-L", _] -> 
  ChEBI["15811"], metabolite["h2s", _] -> ChEBI["16136"], 
 metabolite["imp", _] -> ChEBI["17202"], metabolite["dudp", _] -> 
  ChEBI["28850"], metabolite["4ahmmp", _] -> ChEBI["16892"], 
 metabolite["pnto-R", _] -> ChEBI["29032"], metabolite["3uib", _] -> 
  ChEBI["1670"], metabolite["gly", _] -> ChEBI["15428"], 
 metabolite["pro-L", _] -> ChEBI["17203"], metabolite["sucr", _] -> 
  ChEBI["17992"], metabolite["glutrna", _] -> ChEBI["29157"], 
 metabolite["arg-L", _] -> ChEBI["16467"], metabolite["hxan", _] -> 
  ChEBI["17368"], metabolite["leu-L", _] -> ChEBI["15603"], 
 metabolite["no3", _] -> ChEBI["48107"], metabolite["air", _] -> 
  ChEBI["28843"], metabolite["gthox", _] -> ChEBI["17858"], 
 metabolite["pydx5p", _] -> ChEBI["18405"], metabolite["4hthr", _] -> 
  ChEBI["28330"], metabolite["cdpea", _] -> ChEBI["16732"], 
 metabolite["sphgn", _] -> ChEBI["16566"], metabolite["sql", _] -> 
  ChEBI["15440"], metabolite["aacald", _] -> ChEBI["17628"], 
 metabolite["5dglcn", _] -> ChEBI["17426"], metabolite["glcn", _] -> 
  ChEBI["33198"], metabolite["udpgalfur", _] -> ChEBI["18251"], 
 metabolite["ap4a", _] -> ChEBI["17422"], metabolite["acon-T", _] -> 
  ChEBI["32806"], metabolite["dmbzid", _] -> ChEBI["15890"], 
 metabolite["glyclt", _] -> ChEBI["17497"], metabolite["galur", _] -> 
  ChEBI["12952"], metabolite["cynt", _] -> ChEBI["28024"], 
 metabolite["tsul", _] -> ChEBI["33541"], metabolite["fmnh2", _] -> 
  ChEBI["16048"], metabolite["1pyr5c", _] -> ChEBI["371"], 
 metabolite["hatrz", _] -> ChEBI["18316"], metabolite["dma", _] -> 
  ChEBI["17170"], metabolite["meoh", _] -> ChEBI["17790"], 
 metabolite["pheme", _] -> ChEBI["17627"], metabolite["2ppoh", _] -> 
  ChEBI["17824"], metabolite["f430", _] -> ChEBI["28265"], 
 metabolite["fe3hox", _] -> ChEBI["28163"], metabolite["nmthsrtn", _] -> 
  ChEBI["48294"], metabolite["txa2", _] -> ChEBI["15627"], 
 metabolite["1p2cbxl", _] -> ChEBI["36761"], metabolite["tmlys", _] -> 
  ChEBI["17311"], metabolite["prostge1", _] -> ChEBI["15544"], 
 metabolite["xol7ah3", _] -> ChEBI["28540"], metabolite["xol7ah2", _] -> 
  ChEBI["28047"], metabolite["sl-L", _] -> ChEBI["16712"], 
 metabolite["pgp160", _] -> ChEBI["37393"], metabolite["pe160", _] -> 
  ChEBI["16038"], metabolite["cdpdddecg", _] -> ChEBI["17962"], 
 metabolite["aldstrn", _] -> ChEBI["27584"], metabolite["pgp161", _] -> 
  ChEBI["37393"], metabolite["pprdn", _] -> ChEBI["47858"], 
 metabolite["tol", _] -> ChEBI["17578"], metabolite["hisp", _] -> 
  ChEBI["16996"], metabolite["mmcoa-R", _] -> ChEBI["15465"], 
 metabolite["2aobut", _] -> ChEBI["16944"], metabolite["pppi", _] -> 
  ChEBI["18036"], metabolite["5dpmev", _] -> ChEBI["15899"], 
 metabolite["2shchc", _] -> ChEBI["39564"], metabolite["2dmmq8", _] -> 
  ChEBI["28192"], metabolite["ni2", _] -> ChEBI["28112"], 
 metabolite["13BDglcn", _] -> ChEBI["37671"], metabolite["uaaGgla", _] -> 
  ChEBI["27692"], metabolite["iletrna", _] -> ChEBI["29160"], 
 metabolite["actn-R", _] -> ChEBI["15686"], metabolite["3c4mop", _] -> 
  ChEBI["1467"], metabolite["no2", _] -> ChEBI["16301"], 
 metabolite["fc1p", _] -> ChEBI["6220"], metabolite["acoa", _] -> 
  ChEBI["17984"], metabolite["galt", _] -> ChEBI["16813"], 
 metabolite["lpam", _] -> ChEBI["17460"], metabolite["psd5p", _] -> 
  ChEBI["18116"], metabolite["malACP", _] -> ChEBI["17330"], 
 metabolite["gdpfuc", _] -> ChEBI["17009"], metabolite["ind3ac", _] -> 
  ChEBI["16411"], metabolite["fecrm", _] -> ChEBI["5019"], 
 metabolite["5hoxnfkyn", _] -> ChEBI["2065"], metabolite["lnlncgcoa", _] -> 
  ChEBI["15508"], metabolite["lnlncg", _] -> ChEBI["28661"], 
 metabolite["dopaqn", _] -> ChEBI["16852"], metabolite["sphings", _] -> 
  ChEBI["16393"], metabolite["gal-bD", _] -> ChEBI["28260"], 
 metabolite["23cump", _] -> ChEBI["28637"], metabolite["3cmp", _] -> 
  ChEBI["53013"], metabolite["bz", _] -> ChEBI["30746"], 
 metabolite["ps161", _] -> ChEBI["11750"], metabolite["12dgr161", _] -> 
  ChEBI["17815"], metabolite["clpn161", _] -> ChEBI["28494"], 
 metabolite["dh3mchc", _] -> ChEBI["17641"], metabolite["mnl", _] -> 
  ChEBI["16899"], metabolite["trnaser", _] -> ChEBI["29179"], 
 metabolite["inost", _] -> ChEBI["17268"], metabolite["2ins", _] -> 
  ChEBI["17811"], metabolite["4hglusa", _] -> ChEBI["27809"], 
 metabolite["pepd", _] -> ChEBI["16670"], metabolite["zymst", _] -> 
  ChEBI["18252"], metabolite["pre5", _] -> ChEBI["27630"], 
 metabolite["cobya", _] -> ChEBI["33907"], metabolite["octa", _] -> 
  ChEBI["28837"], metabolite["tma", _] -> ChEBI["18139"], 
 metabolite["34dhoxmand", _] -> ChEBI["27637"], 
 metabolite["thyox-L", _] -> ChEBI["18332"], metabolite["2hyoxplac", _] -> 
  ChEBI["28478"], metabolite["kynate", _] -> ChEBI["18344"], 
 metabolite["cys-D", _] -> ChEBI["16375"], metabolite["dcaACP", _] -> 
  ChEBI["4349"], metabolite["pa181", _] -> ChEBI["16337"], 
 metabolite["dopasf", _] -> ChEBI["37946"], metabolite["dc2coa", _] -> 
  ChEBI["10723"], metabolite["dxyl5p", _] -> ChEBI["16493"], 
 metabolite["ps_EC", _] -> ChEBI["11750"], metabolite["melt", _] -> 
  ChEBI["27527"], metabolite["cmpacna", _] -> ChEBI["16556"], 
 metabolite["estrone", _] -> ChEBI["17263"], metabolite["prostgh2", _] -> 
  ChEBI["15554"], metabolite["sphs1p", _] -> ChEBI["37550"], 
 metabolite["nrpphr", _] -> ChEBI["18357"], metabolite["acmalt", _] -> 
  ChEBI["2411"], metabolite["acanth", _] -> ChEBI["16803"], 
 metabolite["tagat-D", _] -> ChEBI["4249"], metabolite["6p2dhglcn", _] -> 
  ChEBI["2229"], metabolite["e4p", _] -> ChEBI["48153"], 
 metabolite["rml", _] -> ChEBI["17897"], metabolite["glutar", _] -> 
  ChEBI["17859"], metabolite["b124tc", _] -> ChEBI["17516"], 
 metabolite["sprm", _] -> ChEBI["15746"], metabolite["pre4", _] -> 
  ChEBI["16430"], metabolite["all-D", _] -> ChEBI["4093"], 
 metabolite["oh1", _] -> ChEBI["16234"], metabolite["dna", _] -> 
  ChEBI["16991"], metabolite["oxalc", _] -> ChEBI["32808"], 
 metabolite["Dara14lac", _] -> ChEBI["16292"], 
 metabolite["cmusa", _] -> ChEBI["995"], metabolite["all6p", _] -> 
  ChEBI["17942"], metabolite["seasmet", _] -> ChEBI["9066"], 
 metabolite["limnen", _] -> ChEBI["15384"], metabolite["4cmcoa", _] -> 
  ChEBI["15499"], metabolite["oxadpcoa", _] -> ChEBI["15490"], 
 metabolite["xol7ah", _] -> ChEBI["2290"], metabolite["aso4", _] -> 
  ChEBI["18231"], metabolite["ps141", _] -> ChEBI["11750"], 
 metabolite["scys-L", _] -> ChEBI["27891"], metabolite["pqqh2", _] -> 
  ChEBI["18356"], metabolite["thglu", _] -> ChEBI["17420"], 
 metabolite["3hacoa", _] -> ChEBI["15455"], metabolite["2omph", _] -> 
  ChEBI["1235"], metabolite["man6pglyc", _] -> ChEBI["61001"], 
 metabolite["mmtsa", _] -> ChEBI["27821"], metabolite["pg140", _] -> 
  ChEBI["17517"], metabolite["3mcat", _] -> ChEBI["18404"], 
 metabolite["dhap", _] -> ChEBI["16108"], metabolite["g6p", _] -> 
  ChEBI["4170"], metabolite["nadh", _] -> ChEBI["16908"], 
 metabolite["co2", _] -> ChEBI["16526"], metabolite["6pgl", _] -> 
  ChEBI["16938"], metabolite["akg", _] -> ChEBI["30915"], 
 metabolite["succ", _] -> ChEBI["15741"], metabolite["trdrd", _] -> 
  ChEBI["15967"], metabolite["trdox", _] -> ChEBI["18191"], 
 metabolite["agm", _] -> ChEBI["17431"], metabolite["imacp", _] -> 
  ChEBI["16426"], metabolite["adn", _] -> ChEBI["16335"], 
 metabolite["thf", _] -> ChEBI["15635"], metabolite["cytd", _] -> 
  ChEBI["17562"], metabolite["gtp", _] -> ChEBI["15996"], 
 metabolite["2dr1p", _] -> ChEBI["28542"], metabolite["grdp", _] -> 
  ChEBI["17211"], metabolite["frdp", _] -> ChEBI["17407"], 
 metabolite["2ahhmd", _] -> ChEBI["15998"], metabolite["o2", _] -> 
  ChEBI["15379"], metabolite["ala-B", _] -> ChEBI["16958"], 
 metabolite["hx2coa", _] -> ChEBI["28706"], metabolite["sdhlam", _] -> 
  ChEBI["17432"], metabolite["glx", _] -> ChEBI["16891"], 
 metabolite["fe3", _] -> ChEBI["29034"], metabolite["sertrna", _] -> 
  ChEBI["29162"], metabolite["sbt-D", _] -> ChEBI["17924"], 
 metabolite["glu1sa", _] -> ChEBI["15757"], metabolite["glycogen", _] -> 
  ChEBI["28087"], metabolite["ac", _] -> ChEBI["15366"], 
 metabolite["3ophb", _] -> ChEBI["1617"], metabolite["ara5p", _] -> 
  ChEBI["16241"], metabolite["5caiz", _] -> ChEBI["48000"], 
 metabolite["25aics", _] -> ChEBI["18319"], metabolite["aacoa", _] -> 
  ChEBI["15345"], metabolite["na1", _] -> ChEBI["29101"], 
 metabolite["tyrtrna", _] -> ChEBI["29161"], metabolite["chitos", _] -> 
  ChEBI["16261"], metabolite["13dampp", _] -> ChEBI["15725"], 
 metabolite["stcoa", _] -> ChEBI["15541"], metabolite["pmtcoa", _] -> 
  ChEBI["15525"], metabolite["lcts", _] -> ChEBI["17716"], 
 metabolite["ddcacoa", _] -> ChEBI["15521"], metabolite["2dhguln", _] -> 
  ChEBI["27469"], metabolite["etha", _] -> ChEBI["16000"], 
 metabolite["ddca", _] -> ChEBI["30805"], metabolite["sucarg", _] -> 
  ChEBI["17705"], metabolite["gtspmd", _] -> ChEBI["16613"], 
 metabolite["pram", _] -> ChEBI["37737"], metabolite["acryl", _] -> 
  ChEBI["18308"], metabolite["co1dam", _] -> ChEBI["28531"], 
 metabolite["adcobdam", _] -> ChEBI["2482"], metabolite["ascb-L", _] -> 
  ChEBI["29073"], metabolite["fol", _] -> ChEBI["27470"], 
 metabolite["mobd", _] -> ChEBI["36264"], metabolite["thbpt", _] -> 
  ChEBI["15372"], metabolite["xtp", _] -> ChEBI["10049"], 
 metabolite["bdg2hc", _] -> ChEBI["62223"], metabolite["asp-D", _] -> 
  ChEBI["17364"], metabolite["fald", _] -> ChEBI["16842"], 
 metabolite["srtn", _] -> ChEBI["28790"], metabolite["gchola", _] -> 
  ChEBI["17687"], metabolite["sulfac", _] -> ChEBI["50519"], 
 metabolite["thcholstoic", _] -> ChEBI["18402"], 
 metabolite["1hdecg3p", _] -> ChEBI["16975"], metabolite["cdpdhdec9eg", _] -> 
  ChEBI["17962"], metabolite["cdpdodec11eg", _] -> ChEBI["17962"], 
 metabolite["nad", _] -> ChEBI["15846"], metabolite["qh2", _] -> 
  ChEBI["17976"], metabolite["spmd", _] -> ChEBI["16610"], 
 metabolite["dcamp", _] -> ChEBI["15919"], metabolite["dhf", _] -> 
  ChEBI["15633"], metabolite["uppg1", _] -> ChEBI["28766"], 
 metabolite["trnaval", _] -> ChEBI["29183"], metabolite["trnagly", _] -> 
  ChEBI["29176"], metabolite["lac-L", _] -> ChEBI["422"], 
 metabolite["lipidAds", _] -> ChEBI["18380"], 
 metabolite["pmcoa", _] -> ChEBI["15504"], metabolite["4mzym", _] -> 
  ChEBI["1949"], metabolite["4h2opntn", _] -> ChEBI["17655"], 
 metabolite["met-D", _] -> ChEBI["16867"], metabolite["h2mb4p", _] -> 
  ChEBI["15664"], metabolite["tcynt", _] -> ChEBI["29200"], 
 metabolite["6ax6ax", _] -> ChEBI["16780"], metabolite["copre6", _] -> 
  ChEBI["3794"], metabolite["n2", _] -> ChEBI["17997"], 
 metabolite["prpncoa", _] -> ChEBI["15513"], metabolite["estradiol", _] -> 
  ChEBI["16469"], metabolite["camp", _] -> ChEBI["17489"], 
 metabolite["2coum", _] -> ChEBI["28873"], metabolite["g3pe", _] -> 
  ChEBI["16929"], metabolite["23cgmp", _] -> ChEBI["28181"], 
 metabolite["dlnlcg", _] -> ChEBI["53486"], metabolite["n2o", _] -> 
  ChEBI["17045"], metabolite["xoltriol", _] -> ChEBI["16496"], 
 metabolite["formcoa", _] -> ChEBI["15522"], metabolite["12dgr140", _] -> 
  ChEBI["17815"], metabolite["hxa", _] -> ChEBI["30776"], 
 metabolite["actp", _] -> ChEBI["15350"], metabolite["op4en", _] -> 
  ChEBI["1113"], metabolite["glyc-R", _] -> ChEBI["32398"], 
 metabolite["malthx", _] -> ChEBI["27445"], metabolite["gmhep17bp", _] -> 
  ChEBI["4188"], metabolite["thmpp", _] -> ChEBI["9532"], 
 metabolite["3hhdcoa", _] -> ChEBI["27402"], metabolite["feenter", _] -> 
  ChEBI["28199"], metabolite["xoldioloneh", _] -> ChEBI["2288"], 
 metabolite["didp", _] -> ChEBI["28823"], metabolite["pa180", _] -> 
  ChEBI["16337"], metabolite["p-xyl", _] -> ChEBI["27417"], 
 metabolite["argsuc", _] -> ChEBI["15682"], metabolite["kdolipid4", _] -> 
  ChEBI["27439"], metabolite["cdpchol", _] -> ChEBI["16436"], 
 metabolite["23dhba", _] -> ChEBI["15572"], metabolite["hkntd", _] -> 
  ChEBI["31082"], metabolite["adrnl", _] -> ChEBI["28918"], 
 metabolite["cholate", _] -> ChEBI["16359"], 
 metabolite["ha", _] -> ChEBI["16336"], metabolite["pg141", _] -> 
  ChEBI["17517"], metabolite["oxalcoa", _] -> ChEBI["15535"], 
 metabolite["conialdh", _] -> ChEBI["16547"], 
 metabolite["3mgcoa", _] -> ChEBI["15488"], metabolite["glutcoa", _] -> 
  ChEBI["15524"], metabolite["L-dpchrm", _] -> ChEBI["15772"], 
 metabolite["ergst", _] -> ChEBI["16933"], metabolite["ptth", _] -> 
  ChEBI["16753"], metabolite["hphaccoa", _] -> ChEBI["28773"], 
 metabolite["34dhphe", _] -> ChEBI["15765"], metabolite["xol7a", _] -> 
  ChEBI["17500"], metabolite["xoltetrol", _] -> ChEBI["28533"], 
 metabolite["selcyst", _] -> ChEBI["27760"], metabolite["hista", _] -> 
  ChEBI["18295"], metabolite["5dh4dglc", _] -> ChEBI["16369"], 
 metabolite["3AStmyn", _] -> ChEBI["29076"], metabolite["mcom", _] -> 
  ChEBI["17827"], metabolite["gg4abut", _] -> ChEBI["49260"], 
 metabolite["5htrp", _] -> ChEBI["17780"], metabolite["3ump", _] -> 
  ChEBI["28895"], metabolite["2mb2coa", _] -> ChEBI["15478"], 
 metabolite["4gudbutn", _] -> ChEBI["15728"], 
 metabolite["bzalc", _] -> ChEBI["17987"], metabolite["rbflvrd", _] -> 
  ChEBI["17607"], metabolite["2oph", _] -> ChEBI["40407"], 
 metabolite["octp", _] -> ChEBI["15805"], metabolite["scl2", _] -> 
  ChEBI["18023"], metabolite["mercplac", _] -> ChEBI["28580"], 
 metabolite["omaenol", _] -> ChEBI["16321"], metabolite["3hpp", _] -> 
  ChEBI["33404"], metabolite["mescoa", _] -> ChEBI["27969"], 
 metabolite["3gmp", _] -> ChEBI["28072"], metabolite["nicrns", _] -> 
  ChEBI["27748"], metabolite["acglc-D", _] -> ChEBI["17901"], 
 metabolite["pqq", _] -> ChEBI["18315"], metabolite["3pg", _] -> 
  ChEBI["17794"], metabolite["3dhsk", _] -> ChEBI["30918"], 
 metabolite["3psme", _] -> ChEBI["16257"], metabolite["prpp", _] -> 
  ChEBI["17111"], metabolite["ser-L", _] -> ChEBI["17115"], 
 metabolite["cys-L", _] -> ChEBI["17561"], metabolite["pap", _] -> 
  ChEBI["17985"], metabolite["so3", _] -> ChEBI["48854"], 
 metabolite["26dap-M", _] -> ChEBI["16488"], metabolite["sl26da", _] -> 
  ChEBI["17279"], metabolite["xmp", _] -> ChEBI["15652"], 
 metabolite["gmp", _] -> ChEBI["17345"], metabolite["cdp", _] -> 
  ChEBI["17239"], metabolite["dctp", _] -> ChEBI["16311"], 
 metabolite["glc-D", _] -> ChEBI["4167"], metabolite["h2o", _] -> 
  ChEBI["15377"], metabolite["4mhetz", _] -> ChEBI["17957"], 
 metabolite["2mop", _] -> ChEBI["16256"], metabolite["chol", _] -> 
  ChEBI["15354"], metabolite["nadph", _] -> ChEBI["16474"], 
 metabolite["mal-L", _] -> ChEBI["30797"], metabolite["dcyt", _] -> 
  ChEBI["15698"], metabolite["ura", _] -> ChEBI["17568"], 
 metabolite["etoh", _] -> ChEBI["16236"], metabolite["lystrna", _] -> 
  ChEBI["16047"], metabolite["trnahis", _] -> ChEBI["29178"], 
 metabolite["alatrna", _] -> ChEBI["17732"], metabolite["glytrna", _] -> 
  ChEBI["29156"], metabolite["asn-L", _] -> ChEBI["17196"], 
 metabolite["orn", _] -> ChEBI["18257"], metabolite["focytc", _] -> 
  ChEBI["16928"], metabolite["hcit", _] -> ChEBI["17852"], 
 metabolite["ggl", _] -> ChEBI["15754"], metabolite["thm", _] -> 
  ChEBI["18385"], metabolite["trnaarg", _] -> ChEBI["29171"], 
 metabolite["8aonn", _] -> ChEBI["12266"], metabolite["chitin", _] -> 
  ChEBI["17029"], metabolite["mmcoa-S", _] -> ChEBI["15466"], 
 metabolite["5mthf", _] -> ChEBI["15641"], metabolite["25dkglcn", _] -> 
  ChEBI["18281"], metabolite["dtdp4addg", _] -> ChEBI["15952"], 
 metabolite["uacmam", _] -> ChEBI["16287"], metabolite["maltttr", _] -> 
  ChEBI["28460"], metabolite["pac", _] -> ChEBI["30745"], 
 metabolite["acACP", _] -> ChEBI["17093"], metabolite["thmtp", _] -> 
  ChEBI["9534"], metabolite["tmao", _] -> ChEBI["15724"], 
 metabolite["cmaphis", _] -> ChEBI["16475"], metabolite["macchitppdol", _] -> 
  ChEBI["18396"], metabolite["25dhpp", _] -> ChEBI["29114"], 
 metabolite["sheme", _] -> ChEBI["28599"], metabolite["btcoa", _] -> 
  ChEBI["15517"], metabolite["2ombz", _] -> ChEBI["28423"], 
 metabolite["cbi", _] -> ChEBI["28956"], metabolite["4abut", _] -> 
  ChEBI["16865"], metabolite["creat", _] -> ChEBI["16919"], 
 metabolite["urate", _] -> ChEBI["17775"], metabolite["retinol", _] -> 
  ChEBI["17336"], metabolite["pa160", _] -> ChEBI["16337"], 
 metabolite["pe181", _] -> ChEBI["16038"], metabolite["ppal", _] -> 
  ChEBI["17153"], metabolite["5mtr", _] -> ChEBI["16895"], 
 metabolite["glu5sa", _] -> ChEBI["17232"], metabolite["pphn", _] -> 
  ChEBI["16666"], metabolite["3ig3p", _] -> ChEBI["18299"], 
 metabolite["sucbz", _] -> ChEBI["18325"], metabolite["2mecdp", _] -> 
  ChEBI["18425"], metabolite["uamr", _] -> ChEBI["17882"], 
 metabolite["trnaleu", _] -> ChEBI["29169"], metabolite["trnalys", _] -> 
  ChEBI["29185"], metabolite["pyam5p", _] -> ChEBI["18335"], 
 metabolite["sucorn", _] -> ChEBI["27574"], metabolite["lpro", _] -> 
  ChEBI["15804"], metabolite["lanost", _] -> ChEBI["16521"], 
 metabolite["fgam", _] -> ChEBI["18272"], metabolite["q10", _] -> 
  ChEBI["16389"], metabolite["cu2", _] -> ChEBI["28694"], 
 metabolite["pre3a", _] -> ChEBI["28307"], metabolite["mppp9", _] -> 
  ChEBI["15431"], metabolite["r15bp", _] -> ChEBI["17994"], 
 metabolite["5forthf", _] -> ChEBI["15639"], metabolite["male", _] -> 
  ChEBI["18300"], metabolite["35diotyr", _] -> ChEBI["15768"], 
 metabolite["3ityr-L", _] -> ChEBI["27847"], metabolite["2ameph", _] -> 
  ChEBI["15573"], metabolite["mi1346p", _] -> ChEBI["16155"], 
 metabolite["lipa", _] -> ChEBI["27963"], metabolite["pg120", _] -> 
  ChEBI["17517"], metabolite["sbt6p", _] -> ChEBI["17044"], 
 metabolite["trnatyr", _] -> ChEBI["29182"], metabolite["3otdcoa", _] -> 
  ChEBI["28726"], metabolite["mannan", _] -> ChEBI["28808"], 
 metabolite["unaga", _] -> ChEBI["16511"], metabolite["g3pi", _] -> 
  ChEBI["18321"], metabolite["arbt6p", _] -> ChEBI["2807"], 
 metabolite["indpyr", _] -> ChEBI["29750"], metabolite["pacald", _] -> 
  ChEBI["16424"], metabolite["adocbi", _] -> ChEBI["2480"], 
 metabolite["5hoxindoa", _] -> ChEBI["27823"], 
 metabolite["ditp", _] -> ChEBI["28807"], metabolite["leuktrA4", _] -> 
  ChEBI["15651"], metabolite["selcys", _] -> ChEBI["9093"], 
 metabolite["sel", _] -> ChEBI["18170"], metabolite["ach", _] -> 
  ChEBI["15355"], metabolite["elaid", _] -> ChEBI["27997"], 
 metabolite["1odecg3p", _] -> ChEBI["16975"], 
 metabolite["ps160", _] -> ChEBI["11750"], metabolite["pe120", _] -> 
  ChEBI["16038"], metabolite["pe140", _] -> ChEBI["16038"], 
 metabolite["clpn140", _] -> ChEBI["28494"], metabolite["aprgstrn", _] -> 
  ChEBI["28453"], metabolite["aprut", _] -> ChEBI["17768"], 
 metabolite["sbt-L", _] -> ChEBI["28789"], metabolite["ppap", _] -> 
  ChEBI["8478"], metabolite["cinnm", _] -> ChEBI["35697"], 
 metabolite["2dh3dgal", _] -> ChEBI["17028"], 
 metabolite["dhptd", _] -> ChEBI["29484"], metabolite["prostgd2", _] -> 
  ChEBI["15555"], metabolite["lnlnca", _] -> ChEBI["27432"], 
 metabolite["arbtn", _] -> ChEBI["18157"], metabolite["5a2opntn", _] -> 
  ChEBI["17572"], metabolite["2mp2coa", _] -> ChEBI["27754"], 
 metabolite["mi145p", _] -> ChEBI["16595"], metabolite["clpn120", _] -> 
  ChEBI["28494"], metabolite["p-tol", _] -> ChEBI["36635"], 
 metabolite["tagdp-D", _] -> ChEBI["4250"], metabolite["1Dgali", _] -> 
  ChEBI["17505"], metabolite["N1sprm", _] -> ChEBI["17312"], 
 metabolite["selnp", _] -> ChEBI["16144"], metabolite["adphep-LD", _] -> 
  ChEBI["15915"], metabolite["clpn_SC", _] -> ChEBI["28494"], 
 metabolite["hkndd", _] -> ChEBI["17367"], metabolite["hsfd", _] -> 
  ChEBI["18209"], metabolite["mi3456p", _] -> ChEBI["15844"], 
 metabolite["acgpail_hs", _] -> ChEBI["12194"], 
 metabolite["dcholcoa", _] -> ChEBI["28701"], 
 metabolite["bzal", _] -> ChEBI["17169"], metabolite["3oacoa", _] -> 
  ChEBI["15489"], metabolite["ppt", _] -> ChEBI["16215"], 
 metabolite["3mox4hoxm", _] -> ChEBI["20106"], 
 metabolite["dttOX", _] -> ChEBI["16912"], metabolite["coke", _] -> 
  ChEBI["27958"], metabolite["retn", _] -> ChEBI["15367"], 
 metabolite["dgal6p", _] -> ChEBI["4141"], metabolite["n6all26d", _] -> 
  ChEBI["18317"], metabolite["homoval", _] -> ChEBI["545959"], 
 metabolite["cholcoaone", _] -> ChEBI["27379"], 
 metabolite["ggbutal", _] -> ChEBI["61521"], metabolite["acnamp", _] -> 
  ChEBI["27438"], metabolite["retinal", _] -> ChEBI["17898"], 
 metabolite["12dgr180", _] -> ChEBI["17815"], 
 metabolite["mndn", _] -> ChEBI["28869"], metabolite["m1macchitppdol", _] -> 
  ChEBI["28067"], metabolite["46dhoxquin", _] -> ChEBI["28799"], 
 metabolite["lthstrl", _] -> ChEBI["17168"], metabolite["2hmc", _] -> 
  ChEBI["28080"], metabolite["4mcat", _] -> ChEBI["17254"], 
 metabolite["pi", _] -> ChEBI["18367"], metabolite["6pgc", _] -> 
  ChEBI["48928"], metabolite["lac-D", _] -> ChEBI["42111"], 
 metabolite["udpgal", _] -> ChEBI["18307"], metabolite["glyc3p", _] -> 
  ChEBI["15978"], metabolite["acorn", _] -> ChEBI["16543"], 
 metabolite["cbp", _] -> ChEBI["17672"], metabolite["acg5p", _] -> 
  ChEBI["16878"], metabolite["23dhmb", _] -> ChEBI["15684"], 
 metabolite["2obut", _] -> ChEBI["30831"], metabolite["2cpr5p", _] -> 
  ChEBI["29112"], metabolite["so4", _] -> ChEBI["16189"], 
 metabolite["10fthf", _] -> ChEBI["15637"], metabolite["dgsn", _] -> 
  ChEBI["17172"], metabolite["gdp", _] -> ChEBI["17552"], 
 metabolite["for", _] -> ChEBI["30751"], metabolite["dmlz", _] -> 
  ChEBI["17601"], metabolite["ahdt", _] -> ChEBI["18372"], 
 metabolite["cala", _] -> ChEBI["18261"], metabolite["dhna", _] -> 
  ChEBI["18094"], metabolite["rnam", _] -> ChEBI["15927"], 
 metabolite["36dahx", _] -> ChEBI["15613"], metabolite["cpppg3", _] -> 
  ChEBI["15439"], metabolite["3ohcoa", _] -> ChEBI["27648"], 
 metabolite["gln-L", _] -> ChEBI["18050"], metabolite["uaagmda", _] -> 
  ChEBI["28138"], metabolite["uaccg", _] -> ChEBI["16435"], 
 metabolite["trnamet", _] -> ChEBI["29173"], metabolite["cystrna", _] -> 
  ChEBI["29152"], metabolite["glntrna", _] -> ChEBI["29166"], 
 metabolite["thrtrna", _] -> ChEBI["29163"], metabolite["asptrna", _] -> 
  ChEBI["29158"], metabolite["gcald", _] -> ChEBI["17071"], 
 metabolite["adp", _] -> ChEBI["16761"], metabolite["4pasp", _] -> 
  ChEBI["15836"], metabolite["amob", _] -> ChEBI["8944"], 
 metabolite["pdx5p", _] -> ChEBI["28803"], metabolite["btn", _] -> 
  ChEBI["15956"], metabolite["g6p-B", _] -> ChEBI["17719"], 
 metabolite["3oddcoa", _] -> ChEBI["27868"], metabolite["Ssq23epx", _] -> 
  ChEBI["15441"], metabolite["mql8", _] -> ChEBI["18151"], 
 metabolite["35ccmp", _] -> ChEBI["17065"], metabolite["acac", _] -> 
  ChEBI["13705"], metabolite["malttr", _] -> ChEBI["27931"], 
 metabolite["aconm", _] -> ChEBI["15663"], metabolite["rdmbzi", _] -> 
  ChEBI["10329"], metabolite["acmanap", _] -> ChEBI["28273"], 
 metabolite["but", _] -> ChEBI["30772"], metabolite["palmACP", _] -> 
  ChEBI["5697"], metabolite["uama", _] -> ChEBI["16932"], 
 metabolite["dca", _] -> ChEBI["30813"], metabolite["glyb", _] -> 
  ChEBI["17750"], metabolite["im4ac", _] -> ChEBI["16974"], 
 metabolite["prgstrn", _] -> ChEBI["17026"], metabolite["ibcoa", _] -> 
  ChEBI["15479"], metabolite["cholp", _] -> ChEBI["18132"], 
 metabolite["metsox-R-L", _] -> ChEBI["49032"], 
 metabolite["dheas", _] -> ChEBI["16814"], metabolite["udpLa4o", _] -> 
  ChEBI["47028"], metabolite["aso3", _] -> ChEBI["29866"], 
 metabolite["3snpyr", _] -> ChEBI["1665"], metabolite["3opalmACP", _] -> 
  ChEBI["1639"], metabolite["pgp140", _] -> ChEBI["37393"], 
 metabolite["bilglcur", _] -> ChEBI["16427"], 
 metabolite["ppa", _] -> ChEBI["30768"], metabolite["34dhbz", _] -> 
  ChEBI["36062"], metabolite["amet", _] -> ChEBI["15414"], 
 metabolite["2ippm", _] -> ChEBI["17275"], metabolite["histd", _] -> 
  ChEBI["16255"], metabolite["acser", _] -> ChEBI["17981"], 
 metabolite["56dura", _] -> ChEBI["15901"], metabolite["2p4c2me", _] -> 
  ChEBI["16840"], metabolite["altrn", _] -> ChEBI["17360"], 
 metabolite["trnaala", _] -> ChEBI["29170"], metabolite["actACP", _] -> 
  ChEBI["2393"], metabolite["q8h2", _] -> ChEBI["17976"], 
 metabolite["lald-L", _] -> ChEBI["18041"], metabolite["12ppd-S", _] -> 
  ChEBI["29002"], metabolite["arab-D", _] -> ChEBI["17108"], 
 metabolite["hdcoa", _] -> ChEBI["28935"], metabolite["udpglcur", _] -> 
  ChEBI["17200"], metabolite["dms", _] -> ChEBI["17437"], 
 metabolite["urdglyc", _] -> ChEBI["15412"], metabolite["fpram", _] -> 
  ChEBI["18413"], metabolite["4adcho", _] -> ChEBI["18198"], 
 metabolite["cd2", _] -> ChEBI["48775"], metabolite["enter", _] -> 
  ChEBI["28855"], metabolite["codhpre6", _] -> ChEBI["3789"], 
 metabolite["cholcoa", _] -> ChEBI["15519"], metabolite["dimp", _] -> 
  ChEBI["28806"], metabolite["fruur", _] -> ChEBI["4126"], 
 metabolite["guln", _] -> ChEBI["13115"], metabolite["pylald", _] -> 
  ChEBI["15421"], metabolite["gpail_hs", _] -> ChEBI["17049"], 
 metabolite["tchola", _] -> ChEBI["28865"], metabolite["andrstrn", _] -> 
  ChEBI["16032"], metabolite["2mcit", _] -> ChEBI["10860"], 
 metabolite["CCbuttc", _] -> ChEBI["15749"], metabolite["4mbzalc", _] -> 
  ChEBI["1895"], metabolite["pep", _] -> ChEBI["18021"], 
 metabolite["nh4oh", _] -> ChEBI["18219"], metabolite["quln", _] -> 
  ChEBI["16675"], metabolite["3htdcoa", _] -> ChEBI["27466"], 
 metabolite["gam", _] -> ChEBI["47977"], metabolite["trnatrp", _] -> 
  ChEBI["29181"], metabolite["e4hglu", _] -> ChEBI["6331"], 
 metabolite["pydam", _] -> ChEBI["16410"], metabolite["fecost", _] -> 
  ChEBI["17038"], metabolite["tartr-L", _] -> ChEBI["15671"], 
 metabolite["dtdp4d6dm", _] -> ChEBI["15744"], 
 metabolite["uacmamu", _] -> ChEBI["28581"], metabolite["hLkynr", _] -> 
  ChEBI["17380"], metabolite["idon-L", _] -> ChEBI["17796"], 
 metabolite["itacon", _] -> ChEBI["30838"], metabolite["ind3acnl", _] -> 
  ChEBI["17566"], metabolite["com", _] -> ChEBI["17905"], 
 metabolite["ptp", _] -> ChEBI["929"], metabolite["cob", _] -> 
  ChEBI["28890"], metabolite["acmum", _] -> ChEBI["21615"], 
 metabolite["mi134p", _] -> ChEBI["18228"], metabolite["4pyrdx", _] -> 
  ChEBI["17405"], metabolite["pg180", _] -> ChEBI["17517"], 
 metabolite["ps181", _] -> ChEBI["11750"], metabolite["ficytc", _] -> 
  ChEBI["15991"], metabolite["2me4p", _] -> ChEBI["17764"], 
 metabolite["sucgsa", _] -> ChEBI["27657"], metabolite["3dhguln", _] -> 
  ChEBI["16142"], metabolite["3pop", _] -> ChEBI["30935"], 
 metabolite["hspmd", _] -> ChEBI["16554"], metabolite["4nph", _] -> 
  ChEBI["16836"], metabolite["i", _] -> ChEBI["16382"], 
 metabolite["acetone", _] -> ChEBI["15347"], metabolite["thcholoylcoa", _] -> 
  ChEBI["27403"], metabolite["dhocholoylcoa", _] -> ChEBI["17278"], 
 metabolite["ag", _] -> ChEBI["9141"], metabolite["12dgr160", _] -> 
  ChEBI["17815"], metabolite["clpn160", _] -> ChEBI["28494"], 
 metabolite["salc", _] -> ChEBI["16914"], metabolite["ferulcoa", _] -> 
  ChEBI["15511"], metabolite["caffcoa", _] -> ChEBI["15518"], 
 metabolite["dd2coa", _] -> ChEBI["15471"], metabolite["1agly3p_SC", _] -> 
  ChEBI["15835"], metabolite["myrsACP", _] -> ChEBI["50651"], 
 metabolite["oxur", _] -> ChEBI["16582"], metabolite["pg_EC", _] -> 
  ChEBI["17517"], metabolite["f420-2", _] -> ChEBI["16848"], 
 metabolite["copre4", _] -> ChEBI["3792"], metabolite["4hphac", _] -> 
  ChEBI["18101"], metabolite["frulysp", _] -> ChEBI["61437"], 
 metabolite["1mpyr", _] -> ChEBI["27435"], metabolite["pg160", _] -> 
  ChEBI["17517"], metabolite["chols", _] -> ChEBI["16822"], 
 metabolite["galt1p", _] -> ChEBI["28663"], metabolite["ch4", _] -> 
  ChEBI["16183"], metabolite["pgp181", _] -> ChEBI["37393"], 
 metabolite["gdbtal", _] -> ChEBI["16671"], metabolite["2hmcnsad", _] -> 
  ChEBI["17236"], metabolite["vanln", _] -> ChEBI["18346"], 
 metabolite["pser-D", _] -> ChEBI["37713"], metabolite["glp", _] -> 
  ChEBI["16462"], metabolite["2h3oppan", _] -> ChEBI["16992"], 
 metabolite["caphis", _] -> ChEBI["17144"], metabolite["manglyc", _] -> 
  ChEBI["15847"], metabolite["3hibutcoa", _] -> ChEBI["28259"], 
 metabolite["5g2oxpt", _] -> ChEBI["28116"], metabolite["udpLa4fn", _] -> 
  ChEBI["47027"], metabolite["4mptnl", _] -> ChEBI["17998"], 
 metabolite["adhlam", _] -> ChEBI["16807"], metabolite["s7p", _] -> 
  ChEBI["15721"], metabolite["oaa", _] -> ChEBI["30744"], 
 metabolite["xylu-D", _] -> ChEBI["17140"], metabolite["glu-L", _] -> 
  ChEBI["16015"], metabolite["fum", _] -> ChEBI["18012"], 
 metabolite["hom-L", _] -> ChEBI["15699"], metabolite["4izp", _] -> 
  ChEBI["27384"], metabolite["fprica", _] -> ChEBI["18381"], 
 metabolite["orot5p", _] -> ChEBI["15842"], metabolite["orot", _] -> 
  ChEBI["16742"], metabolite["gsn", _] -> ChEBI["16750"], 
 metabolite["ade", _] -> ChEBI["16708"], metabolite["damp", _] -> 
  ChEBI["17713"], metabolite["dtdp", _] -> ChEBI["18075"], 
 metabolite["datp", _] -> ChEBI["16284"], metabolite["gua", _] -> 
  ChEBI["16235"], metabolite["xan", _] -> ChEBI["17712"], 
 metabolite["mlthf", _] -> ChEBI["1989"], metabolite["fmn", _] -> 
  ChEBI["17621"], metabolite["4r5au", _] -> ChEBI["15934"], 
 metabolite["pime", _] -> ChEBI["30531"], metabolite["thmmp", _] -> 
  ChEBI["9533"], metabolite["pant-R", _] -> ChEBI["14737"], 
 metabolite["4ppcys", _] -> ChEBI["15769"], metabolite["dnad", _] -> 
  ChEBI["18304"], metabolite["fadh2", _] -> ChEBI["17877"], 
 metabolite["alltn", _] -> ChEBI["15676"], metabolite["gdptp", _] -> 
  ChEBI["16690"], metabolite["hmbil", _] -> ChEBI["16645"], 
 metabolite["3ohdcoa", _] -> ChEBI["15491"], metabolite["rib-D", _] -> 
  ChEBI["47013"], metabolite["crn", _] -> ChEBI["16347"], 
 metabolite["trptrna", _] -> ChEBI["29159"], metabolite["protrna", _] -> 
  ChEBI["29154"], metabolite["zn2", _] -> ChEBI["29105"], 
 metabolite["4hbz", _] -> ChEBI["30763"], metabolite["acmana", _] -> 
  ChEBI["17122"], metabolite["tag6p-D", _] -> ChEBI["4251"], 
 metabolite["melib", _] -> ChEBI["28053"], metabolite["34hpp", _] -> 
  ChEBI["15999"], metabolite["oxag", _] -> ChEBI["7814"], 
 metabolite["nac", _] -> ChEBI["15940"], metabolite["pppg9", _] -> 
  ChEBI["15435"], metabolite["dtbt", _] -> ChEBI["16691"], 
 metabolite["4h2oglt", _] -> ChEBI["30923"], metabolite["mettrna", _] -> 
  ChEBI["16635"], metabolite["2ahhmp", _] -> ChEBI["17083"], 
 metabolite["3hddcoa", _] -> ChEBI["27668"], metabolite["hdca", _] -> 
  ChEBI["15756"], metabolite["15dap", _] -> ChEBI["18127"], 
 metabolite["dtdpglu", _] -> ChEBI["15700"], metabolite["gp4g", _] -> 
  ChEBI["15883"], metabolite["mi1p-D", _] -> ChEBI["18297"], 
 metabolite["4mlacac", _] -> ChEBI["47904"], metabolite["betald", _] -> 
  ChEBI["15710"], metabolite["cbl1", _] -> ChEBI["15982"], 
 metabolite["pppn", _] -> ChEBI["28631"], metabolite["mmet", _] -> 
  ChEBI["17728"], metabolite["ddcaACP", _] -> ChEBI["16759"], 
 metabolite["ocdcea", _] -> ChEBI["16196"], metabolite["glucys", _] -> 
  ChEBI["17515"], metabolite["citr-L", _] -> ChEBI["16349"], 
 metabolite["pre8", _] -> ChEBI["28629"], metabolite["succoa", _] -> 
  ChEBI["15380"], metabolite["mma", _] -> ChEBI["16830"], 
 metabolite["6pthp", _] -> ChEBI["17804"], metabolite["udpacgal", _] -> 
  ChEBI["16650"], metabolite["malt", _] -> ChEBI["17306"], 
 metabolite["xoltri27", _] -> ChEBI["18431"], metabolite["48dhoxquin", _] -> 
  ChEBI["28883"], metabolite["adprib", _] -> ChEBI["16960"], 
 metabolite["prgnlone", _] -> ChEBI["16581"], metabolite["selmeth", _] -> 
  ChEBI["27585"], metabolite["acgal", _] -> ChEBI["28037"], 
 metabolite["lnlc", _] -> ChEBI["17351"], metabolite["cmp", _] -> 
  ChEBI["17361"], metabolite["dtmp", _] -> ChEBI["17013"], 
 metabolite["3sala", _] -> ChEBI["16345"], metabolite["cdpdodecg", _] -> 
  ChEBI["17962"], metabolite["1ddecg3p", _] -> ChEBI["16975"], 
 metabolite["pgp180", _] -> ChEBI["37393"], metabolite["5adtststerone", _] -> 
  ChEBI["16330"], metabolite["s", _] -> ChEBI["17909"], 
 metabolite["thp2c", _] -> ChEBI["49014"], metabolite["fer", _] -> 
  ChEBI["17620"], metabolite["4hbald", _] -> ChEBI["17597"], 
 metabolite["g3p", _] -> ChEBI["29052"], metabolite["adpglc", _] -> 
  ChEBI["15751"], metabolite["nadp", _] -> ChEBI["18009"], 
 metabolite["acg5sa", _] -> ChEBI["16319"], metabolite["2ahbut", _] -> 
  ChEBI["27681"], metabolite["phe-L", _] -> ChEBI["17295"], 
 metabolite["thym", _] -> ChEBI["17821"], metabolite["ipdp", _] -> 
  ChEBI["16584"], metabolite["hepdp", _] -> ChEBI["17613"], 
 metabolite["5apru", _] -> ChEBI["18337"], metabolite["4mpetz", _] -> 
  ChEBI["17857"], metabolite["oc2coa", _] -> ChEBI["27537"], 
 metabolite["salc6p", _] -> ChEBI["9003"], metabolite["tre6p", _] -> 
  ChEBI["18283"], metabolite["23dhmp", _] -> ChEBI["27512"], 
 metabolite["prlp", _] -> ChEBI["27735"], metabolite["alltt", _] -> 
  ChEBI["30837"], metabolite["4hpro-LT", _] -> ChEBI["18095"], 
 metabolite["td2coa", _] -> ChEBI["27721"], metabolite["dhcinnm", _] -> 
  ChEBI["32356"], metabolite["23doguln", _] -> ChEBI["15622"], 
 metabolite["ap5a", _] -> ChEBI["28898"], metabolite["cyan", _] -> 
  ChEBI["18407"], metabolite["thfglu", _] -> ChEBI["27650"], 
 metabolite["iasp", _] -> ChEBI["50616"], metabolite["3mbdhl", _] -> 
  ChEBI["27462"], metabolite["copre5", _] -> ChEBI["3793"], 
 metabolite["adcobhex", _] -> ChEBI["2483"], metabolite["phaccoa", _] -> 
  ChEBI["15537"], metabolite["triodthy", _] -> ChEBI["18258"], 
 metabolite["lald-D", _] -> ChEBI["17167"], metabolite["cholcoar", _] -> 
  ChEBI["15493"], metabolite["phyQ", _] -> ChEBI["18067"], 
 metabolite["3hmbcoa", _] -> ChEBI["15449"], metabolite["thcys", _] -> 
  ChEBI["28839"], metabolite["3aib", _] -> ChEBI["18188"], 
 metabolite["glcur1p", _] -> ChEBI["28547"], metabolite["pgp120", _] -> 
  ChEBI["37393"], metabolite["mal-D", _] -> ChEBI["30796"], 
 metabolite["cl", _] -> ChEBI["17996"], metabolite["lys-D", _] -> 
  ChEBI["16855"], metabolite["ccmuac", _] -> ChEBI["16508"], 
 metabolite["skm5p", _] -> ChEBI["17052"], metabolite["23ddhb", _] -> 
  ChEBI["15941"], metabolite["uGgl", _] -> ChEBI["16329"], 
 metabolite["dolp", _] -> ChEBI["16214"], metabolite["hpyr", _] -> 
  ChEBI["30841"], metabolite["gmhep1p", _] -> ChEBI["28137"], 
 metabolite["applp", _] -> ChEBI["28390"], metabolite["24dab", _] -> 
  ChEBI["48950"], metabolite["nmptrc", _] -> ChEBI["17166"], 
 metabolite["pcollg5hlys", _] -> ChEBI["51807"], 
 metabolite["Sfglutth", _] -> ChEBI["16225"], 
 metabolite["tyrp", _] -> ChEBI["37788"], metabolite["eandrstrn", _] -> 
  ChEBI["27771"], metabolite["mucl", _] -> ChEBI["18080"], 
 metabolite["ppbng", _] -> ChEBI["17381"], metabolite["trnaasp", _] -> 
  ChEBI["29186"], metabolite["dolmanp", _] -> ChEBI["15809"], 
 metabolite["35cgmp", _] -> ChEBI["16356"], metabolite["23dpg", _] -> 
  ChEBI["17720"], metabolite["m4macchitppdol", _] -> ChEBI["37633"], 
 metabolite["acmama", _] -> ChEBI["28920"], metabolite["pre3b", _] -> 
  ChEBI["27711"], metabolite["hgbam", _] -> ChEBI["27914"], 
 metabolite["mso3", _] -> ChEBI["27376"], metabolite["6a2ohxnt", _] -> 
  ChEBI["17534"], metabolite["pa161", _] -> ChEBI["16337"], 
 metabolite["clpn141", _] -> ChEBI["28494"], metabolite["5apentam", _] -> 
  ChEBI["18120"], metabolite["uGgla", _] -> ChEBI["16574"], 
 metabolite["4aabutn", _] -> ChEBI["11951"], metabolite["3hodcoa", _] -> 
  ChEBI["50583"], metabolite["ctbt", _] -> ChEBI["1774"], 
 metabolite["thcholst", _] -> ChEBI["16466"], metabolite["cdpdtdec7eg", _] -> 
  ChEBI["17962"], metabolite["3oocoa", _] -> ChEBI["28264"], 
 metabolite["S2hglut", _] -> ChEBI["32797"], metabolite["trypta", _] -> 
  ChEBI["16765"], metabolite["2amac", _] -> ChEBI["17123"], 
 metabolite["hyptaur", _] -> ChEBI["16668"], metabolite["xylnt", _] -> 
  ChEBI["48092"], metabolite["ggptrc", _] -> ChEBI["48005"], 
 metabolite["arg-D", _] -> ChEBI["15816"], metabolite["cortsn", _] -> 
  ChEBI["16962"], metabolite["pa141", _] -> ChEBI["16337"], 
 metabolite["Nforglu", _] -> ChEBI["48309"], metabolite["dhpyr", _] -> 
  ChEBI["16364"], metabolite["4hoxoh", _] -> ChEBI["27530"], 
 metabolite["iodine", _] -> ChEBI["17606"], metabolite["6hnac", _] -> 
  ChEBI["16168"], metabolite["13dpg", _] -> ChEBI["16001"], 
 metabolite["xu5p-D", _] -> ChEBI["16332"], metabolite["accoa", _] -> 
  ChEBI["15351"], metabolite["hco3", _] -> ChEBI["17544"], 
 metabolite["gal", _] -> ChEBI["4139"], metabolite["gal1p", _] -> 
  ChEBI["17973"], metabolite["gam6p", _] -> ChEBI["15873"], 
 metabolite["rbl-L", _] -> ChEBI["16880"], metabolite["ametam", _] -> 
  ChEBI["15625"], metabolite["val-L", _] -> ChEBI["16414"], 
 metabolite["thr-L", _] -> ChEBI["16857"], metabolite["anth", _] -> 
  ChEBI["30754"], metabolite["chor", _] -> ChEBI["17333"], 
 metabolite["phpyr", _] -> ChEBI["30851"], metabolite["indole", _] -> 
  ChEBI["16881"], metabolite["prfp", _] -> ChEBI["18302"], 
 metabolite["hcys-L", _] -> ChEBI["17588"], metabolite["dump", _] -> 
  ChEBI["17622"], metabolite["thymd", _] -> ChEBI["17748"], 
 metabolite["dadp", _] -> ChEBI["16174"], metabolite["nicrnt", _] -> 
  ChEBI["15763"], metabolite["2dhp", _] -> ChEBI["11561"], 
 metabolite["4mop", _] -> ChEBI["48430"], metabolite["b2coa", _] -> 
  ChEBI["15473"], metabolite["4c2me", _] -> ChEBI["16578"], 
 metabolite["mana", _] -> ChEBI["17767"], metabolite["fe2", _] -> 
  ChEBI["18248"], metabolite["arab-L", _] -> ChEBI["17535"], 
 metabolite["udcpdp", _] -> ChEBI["18197"], metabolite["amp", _] -> 
  ChEBI["16027"], metabolite["gam1p", _] -> ChEBI["27625"], 
 metabolite["valtrna", _] -> ChEBI["29164"], metabolite["trnaasn", _] -> 
  ChEBI["29172"], metabolite["k", _] -> ChEBI["29103"], 
 metabolite["glyald", _] -> ChEBI["17378"], metabolite["malcoa", _] -> 
  ChEBI["15531"], metabolite["idp", _] -> ChEBI["17808"], 
 metabolite["ch4s", _] -> ChEBI["16007"], metabolite["3mob", _] -> 
  ChEBI["11851"], metabolite["dann", _] -> ChEBI["2247"], 
 metabolite["id3acald", _] -> ChEBI["18086"], metabolite["trnaphe", _] -> 
  ChEBI["29184"], metabolite["tdcoa", _] -> ChEBI["15532"], 
 metabolite["3odcoa", _] -> ChEBI["28528"], metabolite["hdcea", _] -> 
  ChEBI["28716"], metabolite["drib", _] -> ChEBI["28816"], 
 metabolite["g3pg", _] -> ChEBI["5457"], metabolite["2oxoadp", _] -> 
  ChEBI["15753"], metabolite["L2aadp", _] -> ChEBI["37023"], 
 metabolite["4fumacac", _] -> ChEBI["30907"], 
 metabolite["Lkynr", _] -> ChEBI["16946"], metabolite["man6p", _] -> 
  ChEBI["17369"], metabolite["ACP", _] -> ChEBI["18359"], 
 metabolite["oxam", _] -> ChEBI["18058"], metabolite["dha", _] -> 
  ChEBI["16016"], metabolite["rb15bp", _] -> ChEBI["16710"], 
 metabolite["occoa", _] -> ChEBI["15533"], metabolite["glyc1p", _] -> 
  ChEBI["16221"], metabolite["man", _] -> ChEBI["4208"], 
 metabolite["alac-S", _] -> ChEBI["18409"], metabolite["fad", _] -> 
  ChEBI["16238"], metabolite["dtt", _] -> ChEBI["18320"], 
 metabolite["biocyt", _] -> ChEBI["27870"], metabolite["2mbcoa", _] -> 
  ChEBI["15477"], metabolite["Lcystin", _] -> ChEBI["16283"], 
 metabolite["peamn", _] -> ChEBI["18397"], metabolite["dcmp", _] -> 
  ChEBI["15918"], metabolite["xolest_hs", _] -> ChEBI["17002"], 
 metabolite["gthrd", _] -> ChEBI["16856"], metabolite["12dgr120", _] -> 
  ChEBI["17815"], metabolite["ru5p-D", _] -> ChEBI["17363"], 
 metabolite["appnn", _] -> ChEBI["28261"], metabolite["kdo2lipid4", _] -> 
  ChEBI["28526"], metabolite["Lpipecol", _] -> ChEBI["30633"], 
 metabolite["ga", _] -> ChEBI["30778"], metabolite["2ddg6p", _] -> 
  ChEBI["15925"], metabolite["prbatp", _] -> ChEBI["18263"], 
 metabolite["sl2a6o", _] -> ChEBI["35266"], metabolite["db4p", _] -> 
  ChEBI["50606"], metabolite["pan4p", _] -> ChEBI["16858"], 
 metabolite["octdp", _] -> ChEBI["16275"], metabolite["nmn", _] -> 
  ChEBI["16171"], metabolite["3hocoa", _] -> ChEBI["28632"], 
 metabolite["suc6p", _] -> ChEBI["16308"], metabolite["kdo8p", _] -> 
  ChEBI["18069"], metabolite["kdo", _] -> ChEBI["32817"], 
 metabolite["u23ga", _] -> ChEBI["17787"], metabolite["acrn", _] -> 
  ChEBI["15960"], metabolite["sucglu", _] -> ChEBI["48957"], 
 metabolite["galctn-D", _] -> ChEBI["12931"], 
 metabolite["micit", _] -> ChEBI["15607"], metabolite["ethamp", _] -> 
  ChEBI["17553"], metabolite["5prdmbz", _] -> ChEBI["16837"], 
 metabolite["itaccoa", _] -> ChEBI["15528"], metabolite["N1aspmd", _] -> 
  ChEBI["17927"], metabolite["gar", _] -> ChEBI["18349"], 
 metabolite["cgly", _] -> ChEBI["4047"], metabolite["no", _] -> 
  ChEBI["16480"], metabolite["acgam", _] -> ChEBI["506227"], 
 metabolite["2ommb", _] -> ChEBI["28636"], metabolite["bgly", _] -> 
  ChEBI["18089"], metabolite["copre8", _] -> ChEBI["3795"], 
 metabolite["co", _] -> ChEBI["17245"], metabolite["xol7aone", _] -> 
  ChEBI["17899"], metabolite["g1p", _] -> ChEBI["16077"], 
 metabolite["3hpcoa", _] -> ChEBI["27762"], metabolite["mercppyr", _] -> 
  ChEBI["16208"], metabolite["mi13456p", _] -> ChEBI["16322"], 
 metabolite["mi1345p", _] -> ChEBI["16783"], metabolite["coumarin", _] -> 
  ChEBI["28794"], metabolite["prostge2", _] -> ChEBI["15551"], 
 metabolite["tym", _] -> ChEBI["15760"], metabolite["4hoxpacd", _] -> 
  ChEBI["15621"], metabolite["chsterol", _] -> ChEBI["16113"], 
 metabolite["udpxyl", _] -> ChEBI["16082"], metabolite["14glucan", _] -> 
  ChEBI["28102"], metabolite["xol7ah2al", _] -> ChEBI["27428"], 
 metabolite["alaala", _] -> ChEBI["16576"], metabolite["ps180", _] -> 
  ChEBI["11750"], metabolite["rbt", _] -> ChEBI["15963"], 
 metabolite["crtstrn", _] -> ChEBI["16827"], metabolite["nh3", _] -> 
  ChEBI["16134"], metabolite["oxptn", _] -> ChEBI["39153"], 
 metabolite["suchms", _] -> ChEBI["16160"], metabolite["urcan", _] -> 
  ChEBI["30817"], metabolite["ctp", _] -> ChEBI["17677"], 
 metabolite["salcn", _] -> ChEBI["17814"], metabolite["mhpglu", _] -> 
  ChEBI["17614"], metabolite["taur", _] -> ChEBI["15891"], 
 metabolite["3hpppn", _] -> ChEBI["1427"], metabolite["u3hga", _] -> 
  ChEBI["27392"], metabolite["udcp", _] -> ChEBI["16591"], 
 metabolite["seramp", _] -> ChEBI["61645"], metabolite["2mbdhl", _] -> 
  ChEBI["28692"], metabolite["melatn", _] -> ChEBI["16796"], 
 metabolite["Lcyst", _] -> ChEBI["17285"], metabolite["pro-D", _] -> 
  ChEBI["16313"], metabolite["5HPET", _] -> ChEBI["15632"], 
 metabolite["crtn", _] -> ChEBI["16737"], metabolite["pail345p_hs", _] -> 
  ChEBI["16618"], metabolite["carveol", _] -> ChEBI["15389"], 
 metabolite["trnagln", _] -> ChEBI["29168"], metabolite["pa_EC", _] -> 
  ChEBI["16337"], metabolite["pe_EC", _] -> ChEBI["16038"], 
 metabolite["xylt", _] -> ChEBI["17151"], metabolite["g3pc", _] -> 
  ChEBI["16870"], metabolite["2ddglcn", _] -> ChEBI["17032"], 
 metabolite["fmettrna", _] -> ChEBI["17119"], 
 metabolite["nop", _] -> ChEBI["17249"], metabolite["im4act", _] -> 
  ChEBI["27398"], metabolite["msa", _] -> ChEBI["17960"], 
 metabolite["mi4p-D", _] -> ChEBI["18384"], metabolite["crmp_hs", _] -> 
  ChEBI["16197"], metabolite["pa140", _] -> ChEBI["16337"], 
 metabolite["ichor", _] -> ChEBI["17582"], metabolite["3ddgc", _] -> 
  ChEBI["16622"], metabolite["u3aga", _] -> ChEBI["28131"], 
 metabolite["3mldz", _] -> ChEBI["28104"], metabolite["5hoxindact", _] -> 
  ChEBI["50157"], metabolite["ntm2amep", _] -> ChEBI["7347"], 
 metabolite["tststerone", _] -> ChEBI["17347"], 
 metabolite["mi13p", _] -> ChEBI["18225"], metabolite["12dgr141", _] -> 
  ChEBI["17815"], metabolite["dhlam", _] -> ChEBI["17694"], 
 metabolite["4gudbd", _] -> ChEBI["18062"], metabolite["hxcoa", _] -> 
  ChEBI["27540"], metabolite["cdpglyc", _] -> ChEBI["17885"], 
 metabolite["mi34p", _] -> ChEBI["28858"], metabolite["S-gtrdhdlp", _] -> 
  ChEBI["28391"], metabolite["pre6a", _] -> ChEBI["27513"], 
 metabolite["copre2", _] -> ChEBI["3790"], metabolite["mhista", _] -> 
  ChEBI["29009"], metabolite["17ahprgnlone", _] -> ChEBI["28750"], 
 metabolite["hmgth", _] -> ChEBI["48926"], metabolite["3amp", _] -> 
  ChEBI["28931"], metabolite["allphn", _] -> ChEBI["9889"], 
 metabolite["4aphdob", _] -> ChEBI["17442"], metabolite["5hxkynam", _] -> 
  ChEBI["28715"], metabolite["ahandrostan", _] -> ChEBI["28195"], 
 metabolite["estriol", _] -> ChEBI["27974"], metabolite["Nmtrp", _] -> 
  ChEBI["15334"], metabolite["ps140", _] -> ChEBI["11750"], 
 metabolite["5mthglu", _] -> ChEBI["17614"], metabolite["icit", _] -> 
  ChEBI["30887"], metabolite["udpg", _] -> ChEBI["18066"], 
 metabolite["man1p", _] -> ChEBI["35374"], metabolite["2dr5p", _] -> 
  ChEBI["16132"], metabolite["pran", _] -> ChEBI["7091"], 
 metabolite["tyr-L", _] -> ChEBI["17895"], metabolite["trp-L", _] -> 
  ChEBI["16828"], metabolite["his-L", _] -> ChEBI["15971"], 
 metabolite["eig3p", _] -> ChEBI["17805"], metabolite["phom", _] -> 
  ChEBI["15961"], metabolite["ahcys", _] -> ChEBI["16680"], 
 metabolite["aicar", _] -> ChEBI["18406"], metabolite["dhor-S", _] -> 
  ChEBI["17025"], metabolite["cbasp", _] -> ChEBI["15859"], 
 metabolite["ump", _] -> ChEBI["16695"], metabolite["xtsn", _] -> 
  ChEBI["18107"], metabolite["udp", _] -> ChEBI["17659"], 
 metabolite["dutp", _] -> ChEBI["17625"], metabolite["ribflv", _] -> 
  ChEBI["17015"], metabolite["4abz", _] -> ChEBI["30753"], 
 metabolite["4ppan", _] -> ChEBI["15905"], metabolite["ncam", _] -> 
  ChEBI["17154"], metabolite["uppg3", _] -> ChEBI["15437"], 
 metabolite["3hdcoa", _] -> ChEBI["28325"], metabolite["btal", _] -> 
  ChEBI["15743"], metabolite["coa", _] -> ChEBI["15346"], 
 metabolite["xyl-D", _] -> ChEBI["15936"], metabolite["acgam6p", _] -> 
  ChEBI["15784"], metabolite["csn", _] -> ChEBI["16040"], 
 metabolite["duri", _] -> ChEBI["16450"], metabolite["acgam1p", _] -> 
  ChEBI["7125"], metabolite["trnaile", _] -> ChEBI["29174"], 
 metabolite["ivcoa", _] -> ChEBI["15487"], metabolite["nh4", _] -> 
  ChEBI["28938"], metabolite["h2o2", _] -> ChEBI["16240"], 
 metabolite["h2", _] -> ChEBI["18276"], metabolite["cdpdag_EC", _] -> 
  ChEBI["17962"], metabolite["5aizc", _] -> ChEBI["28413"], 
 metabolite["argtrna", _] -> ChEBI["18366"], metabolite["clpn_EC", _] -> 
  ChEBI["28494"], metabolite["2ohph", _] -> ChEBI["1233"], 
 metabolite["dhnpt", _] -> ChEBI["17001"], metabolite["dscl", _] -> 
  ChEBI["50602"], metabolite["ohpb", _] -> ChEBI["27951"], 
 metabolite["pydxn", _] -> ChEBI["16709"], metabolite["dkmpp", _] -> 
  ChEBI["50604"], metabolite["hdd2coa", _] -> ChEBI["28935"], 
 metabolite["abt", _] -> ChEBI["18403"], metabolite["gdpddman", _] -> 
  ChEBI["16955"], metabolite["dtdprmn", _] -> ChEBI["15774"], 
 metabolite["3dhgulnp", _] -> ChEBI["49039"], metabolite["L2aadp6sa", _] -> 
  ChEBI["17917"], metabolite["hgentis", _] -> ChEBI["44747"], 
 metabolite["agdpcbi", _] -> ChEBI["2479"], metabolite["adocbl", _] -> 
  ChEBI["18408"], metabolite["glcur", _] -> ChEBI["4178"], 
 metabolite["uamag", _] -> ChEBI["16970"], metabolite["alpro", _] -> 
  ChEBI["16882"], metabolite["fdxox", _] -> ChEBI["17908"], 
 metabolite["thrp", _] -> ChEBI["37525"], metabolite["lipoate", _] -> 
  ChEBI["30314"], metabolite["3hbcoa", _] -> ChEBI["15453"], 
 metabolite["Nacsertn", _] -> ChEBI["17697"], 
 metabolite["sarcs", _] -> ChEBI["15611"], metabolite["mev-R", _] -> 
  ChEBI["17710"], metabolite["7dhchsterol", _] -> ChEBI["17759"], 
 metabolite["uri", _] -> ChEBI["16704"], metabolite["23dappa", _] -> 
  ChEBI["18383"], metabolite["mi14p", _] -> ChEBI["17816"], 
 metabolite["isetac", _] -> ChEBI["1157"], metabolite["23ccmp", _] -> 
  ChEBI["27652"], metabolite["2amsa", _] -> ChEBI["37012"], 
 metabolite["gdchola", _] -> ChEBI["36274"], metabolite["T4hcinnm", _] -> 
  ChEBI["32374"], metabolite["pheacgln", _] -> ChEBI["17884"], 
 metabolite["cbl2", _] -> ChEBI["16304"], metabolite["pe161", _] -> 
  ChEBI["16038"], metabolite["prbamp", _] -> ChEBI["18374"], 
 metabolite["23dhdp", _] -> ChEBI["18042"], metabolite["ser-D", _] -> 
  ChEBI["16523"], metabolite["cpppg1", _] -> ChEBI["28607"], 
 metabolite["3hhcoa", _] -> ChEBI["28276"], metabolite["glyc", _] -> 
  ChEBI["17754"], metabolite["hpglu", _] -> ChEBI["17420"], 
 metabolite["achms", _] -> ChEBI["16288"], metabolite["25drapp", _] -> 
  ChEBI["29114"], metabolite["rmn", _] -> ChEBI["16055"], 
 metabolite["asntrna", _] -> ChEBI["29265"], metabolite["phthr", _] -> 
  ChEBI["18336"], metabolite["44mzym", _] -> ChEBI["18364"], 
 metabolite["ergtetrol", _] -> ChEBI["18249"], 
 metabolite["hmgcoa", _] -> ChEBI["15467"], metabolite["2dh3dgal6p", _] -> 
  ChEBI["17860"], metabolite["2mcacn", _] -> ChEBI["16717"], 
 metabolite["sph1p", _] -> ChEBI["16893"], metabolite["adphep-DD", _] -> 
  ChEBI["16693"], metabolite["ugmd", _] -> ChEBI["28639"], 
 metabolite["pad", _] -> ChEBI["16562"], metabolite["Stmyn", _] -> 
  ChEBI["17076"], metabolite["atrz", _] -> ChEBI["15930"], 
 metabolite["aa", _] -> ChEBI["28619"], metabolite["forglu", _] -> 
  ChEBI["7274"], metabolite["lyx-L", _] -> ChEBI["28480"], 
 metabolite["dmso", _] -> ChEBI["28262"], metabolite["34dhpha", _] -> 
  ChEBI["41941"], metabolite["2hb", _] -> ChEBI["1148"], 
 metabolite["3htmelys", _] -> ChEBI["15786"], metabolite["estrones", _] -> 
  ChEBI["17474"], metabolite["phyt", _] -> ChEBI["16285"], 
 metabolite["aqcobal", _] -> ChEBI["15852"], metabolite["ocACP", _] -> 
  ChEBI["7725"], metabolite["clpn181", _] -> ChEBI["28494"], 
 metabolite["acon-C", _] -> ChEBI["32805"], metabolite["mnl1p", _] -> 
  ChEBI["16298"], metabolite["skm", _] -> ChEBI["16119"], 
 metabolite["sucsal", _] -> ChEBI["16265"], metabolite["ggdp", _] -> 
  ChEBI["48861"], metabolite["5aprbu", _] -> ChEBI["18247"], 
 metabolite["sbzcoa", _] -> ChEBI["15509"], metabolite["2dglcn", _] -> 
  ChEBI["16138"], metabolite["trnaglu", _] -> ChEBI["29175"], 
 metabolite["phetrna", _] -> ChEBI["29153"], metabolite["tglp", _] -> 
  ChEBI["17739"], metabolite["f6p-B", _] -> ChEBI["16084"], 
 metabolite["dolichol", _] -> ChEBI["16091"], 
 metabolite["srb-L", _] -> ChEBI["48649"], metabolite["dhpppn", _] -> 
  ChEBI["18136"], metabolite["35cdamp", _] -> ChEBI["28074"], 
 metabolite["gmhep7p", _] -> ChEBI["28723"], metabolite["kdo2lipid4L", _] -> 
  ChEBI["27422"], metabolite["n8aspmd", _] -> ChEBI["27911"], 
 metabolite["biliverd", _] -> ChEBI["17033"], metabolite["cobalt2", _] -> 
  ChEBI["27638"], metabolite["2mpdhl", _] -> ChEBI["17577"], 
 metabolite["oxa", _] -> ChEBI["16995"], metabolite["eryth", _] -> 
  ChEBI["27913"], metabolite["od2coa", _] -> ChEBI["50570"], 
 metabolite["3mb2coa", _] -> ChEBI["15486"], metabolite["pail3p_hs", _] -> 
  ChEBI["17283"], metabolite["prostg1", _] -> ChEBI["15548"], 
 metabolite["dopa", _] -> ChEBI["18243"], metabolite["23camp", _] -> 
  ChEBI["27844"], metabolite["idour", _] -> ChEBI["28481"], 
 metabolite["cdpdhdecg", _] -> ChEBI["17962"], 
 metabolite["1tdec7eg3p", _] -> ChEBI["16975"], 
 metabolite["catechol", _] -> ChEBI["18135"], metabolite["4mbzald", _] -> 
  ChEBI["28617"], metabolite["34dhcinm", _] -> ChEBI["16433"], 
 metabolite["trnapro", _] -> ChEBI["29177"], metabolite["1p3h5c", _] -> 
  ChEBI["6151"], metabolite["pmtcrn", _] -> ChEBI["17490"], 
 metabolite["bilirub", _] -> ChEBI["16990"], metabolite["athr-L", _] -> 
  ChEBI["28718"], metabolite["dsmsterol", _] -> ChEBI["17737"], 
 metabolite["leuktrB4", _] -> ChEBI["15647"], 
 metabolite["apnnox", _] -> ChEBI["29060"], metabolite["34dhpac", _] -> 
  ChEBI["27978"], metabolite["ppgpp", _] -> ChEBI["17633"], 
 metabolite["crn-D", _] -> ChEBI["3424"], metabolite["pe180", _] -> 
  ChEBI["16038"], metabolite["dhlpro", _] -> ChEBI["16194"], 
 metabolite["ptcys", _] -> ChEBI["18416"], metabolite["uaGgla", _] -> 
  ChEBI["37738"], metabolite["epm", _] -> ChEBI["4808"], 
 metabolite["am6sa", _] -> ChEBI["15745"], metabolite["aprop", _] -> 
  ChEBI["27959"], metabolite["acybut", _] -> ChEBI["28474"], 
 metabolite["fdxrd", _] -> ChEBI["17513"], metabolite["ugam", _] -> 
  ChEBI["13497"], metabolite["3mox4hpac", _] -> ChEBI["28111"], 
 metabolite["4tmeabut", _] -> ChEBI["18020"], 
 metabolite["aact", _] -> ChEBI["17906"], metabolite["tdchola", _] -> 
  ChEBI["16525"], metabolite["pgp141", _] -> ChEBI["37393"], 
 metabolite["5odhf2a", _] -> ChEBI["18267"], metabolite["acmum6p", _] -> 
  ChEBI["47968"], metabolite["ddsmsterol", _] -> ChEBI["27910"], 
 metabolite["dmgly", _] -> ChEBI["17724"], metabolite["hg2", _] -> 
  ChEBI["16793"], metabolite["1tdecg3p", _] -> ChEBI["16975"], 
 metabolite["apep", _] -> ChEBI["18061"], metabolite["co2dam", _] -> 
  ChEBI["27937"], metabolite["3oodcoa", _] -> ChEBI["50571"], 
 metabolite["3hbcoa-R", _] -> ChEBI["15452"], 
 metabolite["glyc2p", _] -> ChEBI["17270"], metabolite["ps120", _] -> 
  ChEBI["11750"], metabolite["3oxoadp", _] -> ChEBI["15775"], 
 metabolite["nwharg", _] -> ChEBI["7101"], metabolite["gullac", _] -> 
  ChEBI["17587"], metabolite["alpp", _] -> ChEBI["6495"]}
