(* Created by Wolfram Mathematica 8.0 : www.wolfram.com *)
{metabolite["2pg", _] -> SMILES["OC[C@@H](OP(=O)(O)O)C(=O)O"], 
 metabolite["fdp", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)[C@H](O)C(=O)COP(=O)(O)O"], 
 metabolite["atp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O)(O)OP(=O)(O)O)[C@@H](O)\
[C@H]3O"], metabolite["acald", _] -> SMILES["CC=O"], 
 metabolite["asp-L", _] -> SMILES["N[C@@H](CC(=O)O)C(=O)O"], 
 metabolite["ala-D", _] -> SMILES["C[C@@H](N)C(=O)O"], 
 metabolite["5mdr1p", _] -> 
  SMILES["CSC[C@H]1O[C@H](OP(O)(O)=O)[C@H](O)[C@@H]1O"], 
 metabolite["5mta", _] -> 
  SMILES["CSC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n2cnc3c(N)ncnc23"], 
 metabolite["acglu", _] -> SMILES["CC(=O)N[C@@H](CCC(=O)O)C(=O)O"], 
 metabolite["3c2hmp", _] -> 
  SMILES["CC(C)[C@@H]([C@@H](O)C([O-])=O)C([O-])=O"], 
 metabolite["3mop", _] -> SMILES["CC[C@H](C)C(=O)C(O)=O"], 
 metabolite["3c3hmp", _] -> SMILES["CC(C)[C@@](O)(CC([O-])=O)C([O-])=O"], 
 metabolite["3dhq", _] -> SMILES["O[C@@H]1C[C@@](O)(CC(=O)[C@H]1O)C(=O)O"], 
 metabolite["aps", _] -> 
  SMILES[
   "Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OS(=O)(=O)O)[C@@H](O)[C@H]3O"], 
 metabolite["paps", _] -> SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OS(=O\
)(=O)O)[C@@H](OP(=O)(O)O)[C@H]3O"], metabolite["aspsa", _] -> 
  SMILES["[H]C(=O)C[C@H](N)C([O-])=O"], metabolite["lys-L", _] -> 
  SMILES["NCCCC[C@H](N)C(=O)O"], metabolite["dad-2", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3C[C@H](O)[C@@H](CO)O3"], 
 metabolite["ins", _] -> 
  SMILES["OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n2cnc3c(O)ncnc23"], 
 metabolite["dgdp", _] -> 
  SMILES[
   "NC1=Nc2c(ncn2[C@H]3C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)O)O3)C(=O)N1"], 
 metabolite["dttp", _] -> 
  SMILES[
   "CC1=CN([C@H]2C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O2)C(=O)NC1=O"]\
, metabolite["dgtp", _] -> 
  SMILES["NC1=Nc2c(ncn2[C@H]3C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O3\
)C(=O)N1"], metabolite["din", _] -> 
  SMILES["OC[C@H]1O[C@H](C[C@@H]1O)n2cnc3C(=O)NC=Nc23"], 
 metabolite["5pmev", _] -> SMILES["C[C@@](O)(CCOP(=O)(O)O)CC(=O)O"], 
 metabolite["4ampm", _] -> SMILES["Cc1ncc(COP(=O)(O)O)c(N)n1"], 
 metabolite["2mahmp", _] -> SMILES["Cc1ncc(COP(O)(=O)OP(O)(O)=O)c(N)n1"], 
 metabolite["dpcoa", _] -> SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C\
@H](O)[C@@H]1O)n2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCS"], 
 metabolite["23dhb", _] -> SMILES["OC(=O)c1cccc(O)c1O"], 
 metabolite["ru5p-L", _] -> SMILES["OCC(=O)[C@@H](O)[C@@H](O)COP(=O)(O)O"], 
 metabolite["tre", _] -> SMILES["OC[C@H]1O[C@H](O[C@H]2O[C@H](CO)[C@@H](O)[C@\
H](O)[C@H]2O)[C@H](O)[C@@H](O)[C@@H]1O"], metabolite["udcpp", _] -> 
  SMILES["CC(C)=CCC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\\
CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\COP(O)(O)=O"], 
 metabolite["ugmda", _] -> SMILES["C[C@@H](NC(=O)[C@@H](C)NC(=O)[C@H](CCC[C@@\
H](N)C(O)=O)NC(=O)CC[C@@H](NC(=O)[C@H](C)NC(=O)[C@@H](C)O[C@H]1[C@H](O)[C@@H]\
(CO)O[C@H](OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=\
O)[C@@H]1NC(C)=O)C(O)=O)C(O)=O"], metabolite["glu-D", _] -> 
  SMILES["N[C@H](CCC(O)=O)C(O)=O"], metabolite["metsox-S-L", _] -> 
  SMILES["C[S+]([O-])CC[C@H](N)C(=O)O"], metabolite["ppp9", _] -> 
  SMILES["CC1=C(C=C)c2cc3[nH]c(cc4nc(cc5[nH]c(cc1n2)C(=C5C)C=C)c(C)c4CCC(=O)O\
)c(CCC(=O)O)c3C"], metabolite["fcl-L", _] -> 
  SMILES["C[C@H](O)[C@@H](O)[C@@H](O)C(=O)CO"], 
 metabolite["itp", _] -> SMILES["O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)OP(\
=O)(O)OP(=O)(O)O)n2cnc3c(O)ncnc23"], metabolite["Lfmkynr", _] -> 
  SMILES["[H]C(=O)Nc1ccccc1C(=O)C[C@H](N)C(O)=O"], 
 metabolite["n4abutn", _] -> SMILES["[H]C(=O)CCCNC(C)=O"], 
 metabolite["5aop", _] -> SMILES["NCC(=O)CCC(=O)O"], 
 metabolite["ttdca", _] -> SMILES["CCCCCCCCCCCCCC(O)=O"], 
 metabolite["ocdca", _] -> SMILES["CCCCCCCCCCCCCCCCCC([O-])=O"], 
 metabolite["dcacoa", _] -> SMILES["CCCCCCCCCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(\
C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)nc\
nc12"], metabolite["fuc-L", _] -> 
  SMILES["C[C@@H]1OC(O)[C@@H](O)[C@H](O)[C@@H]1O"], 
 metabolite["glcr", _] -> 
  SMILES["O[C@@H]([C@H](O)[C@@H](O)C(O)=O)[C@H](O)C(O)=O"], 
 metabolite["seln", _] -> SMILES["[SeH2]"], metabolite["gbbtn", _] -> 
  SMILES["C[N+](C)(C)CCCC(=O)O"], metabolite["btamp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OC(=O)CCCC[C@@H]4SC[C@@H]5NC(\
=O)N[C@H]45)[C@@H](O)[C@H]3O"], metabolite["mg2", _] -> SMILES["[Mg+2]"], 
 metabolite["pre6b", _] -> SMILES["[H][C@]12N=C(\\C=C3N[C@@](C)(CC4=C(CCC(O)=\
O)[C@](C)(CC(O)=O)C(/C=C5\\N[C@]1(C)[C@@](C)(CC(O)=O)[C@@H]5CCC(O)=O)=N4)C(CC\
(O)=O)=C/3CCC(O)=O)[C@](C)(CCC(O)=O)[C@H]2CC(O)=O"], 
 metabolite["ppcoa", _] -> SMILES["CCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP\
(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["minohp", _] -> SMILES["OP(O)(=O)O[C@@H]1[C@H](OP(O)(O)=O)[C@H](O\
P(O)(O)=O)[C@@H](OP(O)(O)=O)[C@H](OP(O)(O)=O)[C@H]1OP(O)(O)=O"], 
 metabolite["cholcoads", _] -> SMILES["[H][C@@](C)(CCC=C(C)C(=O)SCCNC(=O)CCNC\
(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=\
O)n1cnc2c(N)ncnc12)[C@@]1([H])CC[C@@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C[C@H\
](O)CC[C@]4(C)[C@@]3([H])C[C@H](O)[C@]12C"], metabolite["carn", _] -> 
  SMILES["NCCC(=O)N[C@@H](Cc1cnc[nH]1)C(=O)O"], 
 metabolite["chlstol", _] -> SMILES["[H][C@@]12CC=C3[C@]4([H])CC[C@]([H])([C@\
H](C)CCC=C(C)C)[C@@]4(C)CC[C@]3([H])[C@@]1(C)CC[C@H](O)C2"], 
 metabolite["11docrtsl", _] -> 
  SMILES[
   "C[C@]12CCC(=O)C=C1CC[C@@H]3[C@@H]2CC[C@@]4(C)[C@H]3CC[C@]4(O)C(=O)CO"], 
 metabolite["prostgf2", _] -> 
  SMILES[
   "CCCCC[C@H](O)\\C=C\\[C@H]1[C@H](O)C[C@H](O)[C@@H]1C\\C=C/CCCC(=O)O"], 
 metabolite["bildglcur", _] -> SMILES["CC1=C(C=C)\\C(NC1=O)=C/c1[nH]c(Cc2[nH]\
c(\\C=C3NC(=O)C(C=C)=C\\3C)c(C)c2CCC(=O)O[C@@H]2O[C@@H]([C@@H](O)[C@H](O)[C@H\
]2O)C(O)=O)c(CCC(=O)O[C@@H]2O[C@@H]([C@@H](O)[C@H](O)[C@H]2O)C(O)=O)c1C"], 
 metabolite["1pipdn2c", _] -> SMILES["OC(=O)C1=NCCCC1"], 
 metabolite["so2", _] -> SMILES["O=S=O"], metabolite["pg161", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["pe141", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["pa120", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["12ppd-R", _] -> SMILES["C[C@@H](O)CO"], 
 metabolite["forcoa", _] -> SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([\
C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCSC=O"], 
 metabolite["mthgxl", _] -> SMILES["CC(=O)C=O"], 
 metabolite["thdp", _] -> SMILES["OC(=O)[C@@H]1CCCC(=N1)C(O)=O"], 
 metabolite["dhpt", _] -> 
  SMILES["NC1=NC2=C(N=C(CNc3ccc(cc3)C(=O)O)CN2)C(=O)N1"], 
 metabolite["mn2", _] -> SMILES["[Mn]"], metabolite["uacgam", _] -> 
  SMILES["CC(=O)N[C@@H]1[C@@H](O)[C@H](O)[C@@H](CO)O[C@@H]1OP(=O)(O)OP(=O)(O)\
OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)N3C=CC(=O)NC3=O"], 
 metabolite["2maacoa", _] -> SMILES["CC(C(C)=O)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)\
C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)\
ncnc12"], metabolite["f6p", _] -> 
  SMILES["OCC(=O)[C@@H](O)[C@H](O)[C@H](O)COP(=O)(O)O"], 
 metabolite["q8", _] -> SMILES["COC1=C(OC)C(=O)C(=C(C)C1=O)CC=C(C)C"], 
 metabolite["acnam", _] -> 
  SMILES["[H][C@]1(OC(O)(C[C@H](O)[C@H]1NC(C)=O)C(O)=O)[C@H](O)[C@H](O)CO"], 
 metabolite["dxyl", _] -> SMILES["[H][C@@](O)(CO)[C@]([H])(O)C(C)=O"], 
 metabolite["4per", _] -> SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)C(=O)O"], 
 metabolite["4abutn", _] -> SMILES["[H]C(=O)CCCN"], 
 metabolite["cyst-L", _] -> SMILES["N[C@@H](CCSC[C@H](N)C(O)=O)C(O)=O"], 
 metabolite["odecoa", _] -> SMILES["CCCCCCCC\\C=C/CCCCCCCC(=O)SCCNC(=O)CCNC(=\
O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)\
n1cnc2c(N)ncnc12"], metabolite["2pglyc", _] -> SMILES["OC(=O)COP(=O)(O)O"], 
 metabolite["adocbip", _] -> SMILES["[H][C@]12[C@H](CC(N)=O)[C@@](C)(CCC(=O)N\
C[C@@H](C)OP(O)(O)=O)\\C(N1[Co+]C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc3c(N)ncnc\
13)=C(C)\\C1=N\\C(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4CCC(N)\
=O)[C@@](C)(CC(N)=O)[C@@H]3CCC(N)=O)C(C)(C)[C@@H]1CCC(N)=O"], 
 metabolite["fuc1p-L", _] -> 
  SMILES["C[C@@H]1OC(OP(O)(O)=O)[C@@H](O)[C@H](O)[C@@H]1O"], 
 metabolite["methf", _] -> SMILES["[H][C@]12CNc3nc(N)[nH]c(=O)c3[N+]1=CN(C2)c\
1ccc(cc1)C(=O)N[C@@H](CCC(O)=O)C(O)=O"], metabolite["frmd", _] -> 
  SMILES["NC=O"], metabolite["dgmp", _] -> 
  SMILES["Nc1nc(O)c2ncn([C@H]3C[C@H](O)[C@@H](COP(=O)(O)O)O3)c2n1"], 
 metabolite["6ax", _] -> SMILES["NCCCCCC(O)=O"], 
 metabolite["pre2", _] -> SMILES["C[C@]1(CC(O)=O)[C@H](CCC(O)=O)\\C2=C\\c3[nH\
]c(Cc4[nH]c(\\C=C5/N=C(/C=C1\\N2)[C@@H](CCC(O)=O)[C@]5(C)CC(O)=O)c(CC(O)=O)c4\
CCC(O)=O)c(CCC(O)=O)c3CC(O)=O"], metabolite["ca2", _] -> SMILES["[Ca+2]"], 
 metabolite["dmpp", _] -> SMILES["CC(C)=CCOP(O)(=O)OP(O)(O)=O"], 
 metabolite["3hmp", _] -> SMILES["CC(CO)C([O-])=O"], 
 metabolite["rbl-D", _] -> SMILES["OC[C@@H](O)[C@@H](O)C(=O)CO"], 
 metabolite["dhcholoylcoa", _] -> SMILES["[H][C@@](C)(CCC=C(C)C(=O)SCCNC(=O)C\
CNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(\
O)=O)n1cnc2c(N)ncnc12)[C@@]1([H])CC[C@@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C[\
C@H](O)CC[C@]4(C)[C@@]3([H])CC[C@]12C"], metabolite["cdpdtdecg", _] -> 
  SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)[C@@H](O)[C@H]2O)c(=O)n1"], metabolite["npthl", _] -> 
  SMILES["c1ccc2ccccc2c1"], metabolite["clpn180", _] -> 
  SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)COP(O)(=O)OC[C@@H](COC([\
*])=O)OC([*])=O"], metabolite["msh", _] -> SMILES["CC(=O)N[C@@H](CS)C(=O)N[C@\
@H]1[C@@H](O)[C@H](O)[C@@H](CO)O[C@@H]1O[C@H]1[C@H](O)[C@@H](O)[C@H](O)[C@@H]\
(O)[C@H]1O"], metabolite["andrstandn", _] -> 
  SMILES["C[C@]12CCC(=O)C[C@H]1CC[C@@H]3[C@@H]2CC[C@@]4(C)[C@H]3CCC4=O"], 
 metabolite["5aptn", _] -> SMILES["NCCCCC(=O)O"], 
 metabolite["met-L", _] -> SMILES["CSCC[C@H](N)C(=O)O"], 
 metabolite["56dthm", _] -> SMILES["CC1CNC(=O)NC1=O"], 
 metabolite["lgt-S", _] -> 
  SMILES["C[C@@H](O)C(=O)SC[C@H](NC(=O)CC[C@H](N)C(O)=O)C(=O)NCC(O)=O"], 
 metabolite["s17bp", _] -> 
  SMILES["O[C@H](COP(O)(O)=O)[C@@H](O)[C@@H](O)[C@H](O)C(=O)COP(O)(O)=O"], 
 metabolite["lipidX", _] -> SMILES["CCCCCCCCCCC[C@@H](O)CC(=O)N[C@H]1[C@@H](O\
P(=O)(O)O)O[C@H](CO)[C@@H](O)[C@@H]1OC(=O)C[C@H](O)CCCCCCCCCCC"], 
 metabolite["dhpmp", _] -> 
  SMILES["Nc1nc2NCC(=Nc2c(=O)[nH]1)[C@H](O)[C@H](O)COP(O)(O)=O"], 
 metabolite["pydx", _] -> SMILES["Cc1ncc(CO)c(C=O)c1O"], 
 metabolite["gdpmann", _] -> SMILES["NC1=Nc2c(ncn2[C@@H]3O[C@H](COP(=O)(O)OP(\
=O)(O)O[C@H]4O[C@H](CO)[C@@H](O)[C@H](O)[C@@H]4O)[C@@H](O)[C@H]3O)C(=O)N1"], 
 metabolite["35cimp", _] -> 
  SMILES["O[C@@H]1[C@@H]2OP(O)(=O)OC[C@H]2O[C@H]1n1cnc2c(O)ncnc12"], 
 metabolite["hqn", _] -> SMILES["Oc1ccc(O)cc1"], 
 metabolite["NPmehis", _] -> SMILES["Cn1cncc1C[C@H](N)C(=O)O"], 
 metabolite["hxdcal", _] -> SMILES["CCCCCCCCCCCCCCCC=O"], 
 metabolite["arachd", _] -> 
  SMILES["CCCCC\\C=C/C\\C=C/C\\C=C/C\\C=C/CCCC(=O)O"], 
 metabolite["bhb", _] -> SMILES["C[C@@H](O)CC([O-])=O"], 
 metabolite["copre3", _] -> SMILES["C\\C1=C2\\N=C(\\C=C3/N4[Co]n5c(CC6=C(CCC(\
O)=O)C(CC(O)=O)C(/C=C4/[C@@H](CCC(O)=O)[C@]3(C)CC(O)=O)=N6)c(CCC(O)=O)c(CC(O)\
=O)c15)[C@@H](CCC(O)=O)[C@]2(C)CC(O)=O"], metabolite["xylu-L", _] -> 
  SMILES["OC[C@H](O)[C@@H](O)C(=O)CO"], metabolite["zymstnl", _] -> 
  SMILES["[H][C@@]12CCC3=C(CC[C@]4(C)[C@]([H])(CC[C@@]34[H])[C@H](C)CCCC(C)C)\
[C@@]1(C)CC[C@H](O)C2"], metabolite["11docrtstrn", _] -> 
  SMILES[
   "C[C@]12CC[C@H]3[C@@H](CCC4=CC(=O)CC[C@]34C)[C@@H]1CC[C@@H]2C(=O)CO"], 
 metabolite["prostgi2", _] -> 
  SMILES[
   "CCCCC[C@H](O)\\C=C\\[C@H]1[C@H](O)C[C@@H]2O\\C(=C/CCCC(=O)O)\\C[C@H]12"], 
 metabolite["crtsl", _] -> SMILES["C[C@]12CCC(=O)C=C1CC[C@H]3[C@@H]4CC[C@](O)\
(C(=O)CO)[C@@]4(C)C[C@H](O)[C@H]23"], metabolite["o2s", _] -> 
  SMILES["[O][O-]"], metabolite["5fthf", _] -> SMILES["[H]C(=O)N1[C@@H](CNc2c\
cc(cc2)C(=O)N[C@@H](CCC(O)=O)C(O)=O)CNc2nc(N)[nH]c(=O)c12"], 
 metabolite["tagur", _] -> 
  SMILES["OCC(=O)[C@@H](O)[C@@H](O)[C@H](O)C([O-])=O"], 
 metabolite["f26bp", _] -> 
  SMILES["OC[C@@]1(OP(=O)(O)O)O[C@H](COP(=O)(O)O)[C@@H](O)[C@@H]1O"], 
 metabolite["pgp_EC", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["scl", _] -> SMILES["C[C@]1(CC(O)=O)[C@H](CCC(O)=O)c2cc3[nH]c(cc4\
nc(cc5[nH]c(cc1n2)c(CC(O)=O)c5CCC(O)=O)c(CCC(O)=O)c4CC(O)=O)[C@@H](CCC(O)=O)[\
C@]3(C)CC(O)=O"], metabolite["malt6p", _] -> SMILES["OC[C@H]1O[C@H](O)[C@H](O\
)[C@@H](O)[C@@H]1O[C@H]1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H](O)[C@H]1O"], 
 metabolite["adprbp", _] -> SMILES["Nc1ncnc2n(cnc12)[C@@H]1O[C@H](COP(O)(=O)O\
P(O)(=O)OC2O[C@H](CO)[C@@H](O)[C@H]2O)[C@@H](O)[C@H]1OP(O)(O)=O"], 
 metabolite["citmcoa-L", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H\
]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)C\
[C@](C)(O)C(O)=O"], metabolite["saccrp-L", _] -> 
  SMILES["N[C@@H](CCCCN[C@@H](CCC(=O)O)C(=O)O)C(=O)O"], 
 metabolite["dad-5", _] -> 
  SMILES["C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n2cnc3c(N)ncnc23"], 
 metabolite["dhcholestanate", _] -> SMILES["[H][C@@]12C[C@H](O)CC[C@]1(C)[C@@\
]1([H])CC[C@]3(C)[C@]([H])(CC[C@@]3([H])[C@]1([H])[C@H](O)C2)[C@H](C)CCCC(C)C\
(O)=O"], metabolite["pg181", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["perillyl", _] -> SMILES["CC(=C)[C@H]1CCC(=CC1)CO"], 
 metabolite["vanlt", _] -> SMILES["COc1cc(ccc1O)C(=O)O"], 
 metabolite["26dap-LL", _] -> SMILES["N[C@@H](CCC[C@H](N)C(O)=O)C(O)=O"], 
 metabolite["uAgl", _] -> SMILES["C[C@H](NC(=O)[C@@H](C)O[C@H]1[C@H](O)[C@@H]\
(CO)O[C@H](OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=\
O)[C@@H]1NC(C)=O)C(=O)N[C@H](CCC(O)=O)C(=O)N[C@@H](CCCCN)C(O)=O"], 
 metabolite["amuco", _] -> SMILES["N\\C(=C/C=C/C(O)=O)C(O)=O"], 
 metabolite["3dsphgn", _] -> SMILES["CCCCCCCCCCCCCCCC(=O)[C@@H](N)CO"], 
 metabolite["xu5p-L", _] -> SMILES["OCC(=O)[C@H](O)[C@@H](O)COP(O)(O)=O"], 
 metabolite["3hanthrn", _] -> SMILES["Nc1c(O)cccc1C(=O)O"], 
 metabolite["malm", _] -> SMILES["NC(=O)\\C=C/C(O)=O"], 
 metabolite["cysam", _] -> SMILES["NCCS"], metabolite["34dhmald", _] -> 
  SMILES["[H]C(=O)C(O)c1ccc(O)c(O)c1"], metabolite["15HPET", _] -> 
  SMILES["CCCCC[C@H](OO)\\C=C\\C=C/C\\C=C/C\\C=C/CCCC(=O)O"], 
 metabolite["4tmeabutn", _] -> SMILES["C[N+](C)(C)CCCC(=O)O"], 
 metabolite["arach", _] -> SMILES["CCCCCCCCCCCCCCCCCCCC(=O)O"], 
 metabolite["Nacasp", _] -> SMILES["CC(=O)N[C@@H](CC([O-])=O)C([O-])=O"], 
 metabolite["confrl", _] -> SMILES["COc1cc(\\C=C\\CO)ccc1O"], 
 metabolite["rml1p", _] -> 
  SMILES["C[C@H](O)[C@@H](O)[C@H](O)C(=O)COP(O)(O)=O"], 
 metabolite["raffin", _] -> SMILES["OC[C@H]1O[C@H](OC[C@H]2O[C@H](O[C@]3(CO)O\
[C@H](CO)[C@@H](O)[C@@H]3O)[C@H](O)[C@@H](O)[C@@H]2O)[C@H](O)[C@@H](O)[C@H]1O\
"], metabolite["pc_EC", _] -> 
  SMILES["C[N+](C)(C)CCOP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["hicit", _] -> 
  SMILES["O[C@H]([C@H](CCC([O-])=O)C([O-])=O)C([O-])=O"], 
 metabolite["hgbyr", _] -> SMILES["[H][C@]12N=C(\\C(C)=C3/N=C(/C=C4\\N=C(\\C(\
C)=C5/N[C@]1(C)[C@@](C)(CC(O)=O)[C@@H]5CCC(O)=O)[C@@](C)(CC(O)=O)[C@@H]4CCC(O\
)=O)C(C)(C)[C@@H]3CCC(O)=O)[C@](C)(CCC(O)=O)[C@H]2CC(O)=O"], 
 metabolite["mi3p-D", _] -> 
  SMILES["O[C@H]1[C@H](O)[C@H](O)[C@H](OP(O)(O)=O)[C@@H](O)[C@@H]1O"], 
 metabolite["dhcholestancoa", _] -> SMILES["[H][C@@](C)(CCCC(C)C(=O)SCCNC(=O)\
CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)\
(O)=O)n1cnc2c(N)ncnc12)[C@@]1([H])CC[C@@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C\
[C@H](O)CC[C@]4(C)[C@@]3([H])CC[C@]12C"], metabolite["12dgr181", _] -> 
  SMILES["OC[C@@H](COC([*])=O)OC([*])=O"], metabolite["C04051", _] -> 
  SMILES["NC(=O)c1nc[nH]c1N"], metabolite["2c25dho", _] -> 
  SMILES["OC(=O)CC1(OC(=O)C=C1)C(O)=O"], metabolite["nformanth", _] -> 
  SMILES["OC(=O)c1ccccc1NC=O"], metabolite["hexdp", _] -> 
  SMILES["CC(C)=CCC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\\
COP(O)(=O)OP(O)(O)=O"], metabolite["nal2a6o", _] -> 
  SMILES["CC(=O)N[C@@H](CCCC(=O)C(O)=O)C(O)=O"], 
 metabolite["acetol", _] -> SMILES["CC(=O)CO"], 
 metabolite["h", _] -> SMILES["[H+]"], metabolite["pyr", _] -> 
  SMILES["CC(=O)C(=O)O"], metabolite["r5p", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)[C@@H](O)C=O"], 
 metabolite["cit", _] -> SMILES["OC(=O)CC(O)(CC(=O)O)C(=O)O"], 
 metabolite["ppi", _] -> SMILES["[O-]P(=O)([O-])OP(=O)([O-])[O-]"], 
 metabolite["utp", _] -> SMILES["O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)OP(\
=O)(O)OP(=O)(O)O)N2C=CC(=O)NC2=O"], metabolite["ala-L", _] -> 
  SMILES["C[C@H](N)C(=O)O"], metabolite["5mdru1p", _] -> 
  SMILES["CSC[C@@H](O)[C@@H](O)C(=O)COP(O)(O)=O"], 
 metabolite["urea", _] -> SMILES["NC(=O)N"], metabolite["ptrc", _] -> 
  SMILES["NCCCCN"], metabolite["glu5p", _] -> 
  SMILES["N[C@@H](CCC(=O)OP(O)(O)=O)C(O)=O"], 
 metabolite["ile-L", _] -> SMILES["CC[C@H](C)[C@H](N)C(=O)O"], 
 metabolite["2dda7p", _] -> 
  SMILES["O[C@H](COP(O)(O)=O)[C@@H](O)[C@H](O)CC(=O)C(O)=O"], 
 metabolite["3php", _] -> SMILES["OC(=O)C(=O)COP(=O)(O)O"], 
 metabolite["pser-L", _] -> SMILES["N[C@@H](COP(=O)(O)O)C(=O)O"], 
 metabolite["h2s", _] -> SMILES["S"], metabolite["imp", _] -> 
  SMILES["O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)O)n2cnc3C(=O)NC=Nc23"], 
 metabolite["dudp", _] -> 
  SMILES["O[C@H]1C[C@@H](O[C@@H]1COP(=O)(O)OP(=O)(O)O)N2C=CC(=O)NC2=O"], 
 metabolite["4ahmmp", _] -> SMILES["Cc1ncc(CO)c(N)n1"], 
 metabolite["pnto-R", _] -> SMILES["CC(C)(CO)[C@@H](O)C(=O)NCCC([O-])=O"], 
 metabolite["3uib", _] -> SMILES["CC(CNC(N)=O)C(O)=O"], 
 metabolite["gly", _] -> SMILES["NCC(=O)O"], metabolite["pro-L", _] -> 
  SMILES["OC(=O)[C@@H]1CCCN1"], metabolite["sucr", _] -> 
  SMILES["OC[C@H]1O[C@H](O[C@]2(CO)O[C@H](CO)[C@@H](O)[C@@H]2O)[C@H](O)[C@@H]\
(O)[C@@H]1O"], metabolite["arg-L", _] -> SMILES["N[C@@H](CCCNC(=N)N)C(=O)O"], 
 metabolite["hxan", _] -> SMILES["O=C1NC=Nc2nc[nH]c12"], 
 metabolite["leu-L", _] -> SMILES["CC(C)C[C@H](N)C(=O)O"], 
 metabolite["no3", _] -> SMILES["O[N+](=O)[O-]"], 
 metabolite["air", _] -> 
  SMILES["Nc1cncn1C1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]1O"], 
 metabolite["gthox", _] -> SMILES["N[C@@H](CCC(=O)N[C@@H](CSSC[C@H](NC(=O)CC[\
C@H](N)C(=O)O)C(=O)NCC(=O)O)C(=O)NCC(=O)O)C(=O)O"], 
 metabolite["pydx5p", _] -> SMILES["[H]C(=O)c1c(COP(O)(O)=O)cnc(C)c1O"], 
 metabolite["4hthr", _] -> SMILES["N[C@@H]([C@H](O)CO)C(=O)O"], 
 metabolite["cdpea", _] -> 
  SMILES[
   "NCCOP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1ccc(N)nc1=O"], 
 metabolite["sphgn", _] -> SMILES["CCCCCCCCCCCCCCC[C@@H](O)[C@@H](N)CO"], 
 metabolite["sql", _] -> 
  SMILES[
   "CC(=CCC\\C(=C\\CC\\C(=C\\CC\\C=C(/C)\\CC\\C=C(/C)\\CCC=C(C)C)\\C)\\C)C"], 
 metabolite["aacald", _] -> SMILES["NCC=O"], metabolite["5dglcn", _] -> 
  SMILES["OCC(=O)[C@@H](O)[C@H](O)[C@@H](O)C(O)=O"], 
 metabolite["glcn", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)[C@@H](O)C(=O)O"], 
 metabolite["udpgalfur", _] -> SMILES["[H][C@]1(OC(OP(O)(=O)OP(O)(=O)OC[C@H]2\
O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@H](O)[C@H]1O)[C@H](O)CO"], 
 metabolite["ap4a", _] -> SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O\
)(O)OP(=O)(O)OP(=O)(O)OC[C@H]4O[C@H]([C@H](O)[C@@H]4O)n5cnc6c(N)ncnc56)[C@@H]\
(O)[C@H]3O"], metabolite["acon-T", _] -> 
  SMILES["OC(=O)C\\C(=C/C(=O)O)\\C(=O)O"], metabolite["dmbzid", _] -> 
  SMILES["Cc1cc2nc[nH]c2cc1C"], metabolite["glyclt", _] -> 
  SMILES["OCC(=O)O"], metabolite["galur", _] -> 
  SMILES["[H]C(=O)[C@H](O)[C@@H](O)[C@@H](O)[C@H](O)C([O-])=O"], 
 metabolite["cynt", _] -> SMILES["OC#N"], metabolite["fmnh2", _] -> 
  SMILES[
   "Cc1cc2NC3=C(NC(=O)NC3=O)N(C[C@H](O)[C@H](O)[C@H](O)COP(=O)(O)O)c2cc1C"], 
 metabolite["1pyr5c", _] -> SMILES["[H][C@]1(CCC=N1)C(O)=O"], 
 metabolite["hatrz", _] -> SMILES["CCNc1nc(O)nc(NC(C)C)n1"], 
 metabolite["dma", _] -> SMILES["CNC"], metabolite["meoh", _] -> 
  SMILES["CO"], metabolite["pheme", _] -> SMILES["CC1=C(C=C)C2=CC3=N4C(=Cc5c(\
CCC(=O)O)c(C)c6C=C7C(=C(C=C)C8=N7[Fe]4(N2C1=C8)n56)C)C(=C3C)CCC(=O)O"], 
 metabolite["2ppoh", _] -> SMILES["CC(C)O"], metabolite["f430", _] -> 
  SMILES["[H][C@@]12CC3=N[C@@]([H])(C[C@]45NC(=O)C[C@@]4(C)[C@H](CCC(O)=O)C(\
\\C=C4\\[C@@H](CC(O)=O)[C@H](CCC(O)=O)\\C(N4[Ni])=C4C(=O)CC[C@@]([H])([C@@H]1\
CC(O)=O)C/4=N2)=N5)[C@@H](CCC(O)=O)[C@]3(C)CC(N)=O"], 
 metabolite["fe3hox", _] -> 
  SMILES["[*]C1=[O][Fe]234(ON1)ONC([*])=[O]2.[*]C(NO3)=[O]4"], 
 metabolite["nmthsrtn", _] -> SMILES["CNCCc1c[nH]c2ccc(O)cc12"], 
 metabolite["txa2", _] -> 
  SMILES[
   "CCCCC[C@H](O)\\C=C\\[C@H]1O[C@H]2C[C@H](O2)[C@@H]1C\\C=C/CCCC(O)=O"], 
 metabolite["1p2cbxl", _] -> SMILES["[O-]C(=O)C1=[NH+]CCC1"], 
 metabolite["tmlys", _] -> SMILES["C[N+](C)(C)CCCC[C@H](N)C(=O)O"], 
 metabolite["prostge1", _] -> 
  SMILES["CCCCC[C@H](O)\\C=C\\[C@H]1[C@H](O)CC(=O)[C@@H]1CCCCCCC(=O)O"], 
 metabolite["xol7ah3", _] -> SMILES["[H][C@@]12C[C@H](O)CC[C@]1(C)[C@@]1([H])\
CC[C@]3(C)[C@]([H])(CC[C@@]3([H])[C@]1([H])[C@H](O)C2)[C@H](C)CCCC(C)CO"], 
 metabolite["xol7ah2", _] -> SMILES["[H][C@@]12C[C@H](O)CC[C@]1(C)[C@@]1([H])\
CC[C@]3(C)[C@]([H])(CC[C@@]3([H])[C@]1([H])[C@H](O)C2)[C@H](C)CCCC(C)C"], 
 metabolite["sl-L", _] -> SMILES["O[C@H](CS(O)(=O)=O)C(O)=O"], 
 metabolite["pgp160", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["pe160", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["cdpdddecg", _] -> SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=\
O)OC[C@@H](COC([*])=O)OC([*])=O)[C@@H](O)[C@H]2O)c(=O)n1"], 
 metabolite["aldstrn", _] -> SMILES["C[C@]12CCC(=O)C=C1CC[C@H]3[C@@H]4CC[C@H]\
(C(=O)CO)[C@]4(C[C@H](O)[C@H]23)C=O"], metabolite["pgp161", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["pprdn", _] -> SMILES["C1CCN=CC1"], 
 metabolite["tol", _] -> SMILES["Cc1ccccc1"], 
 metabolite["hisp", _] -> SMILES["N[C@H](COP(=O)(O)O)Cc1c[nH]cn1"], 
 metabolite["mmcoa-R", _] -> SMILES["C[C@H](C(=O)O)C(=O)SCCNC(=O)CCNC(=O)[C@H\
](O)C(C)(C)COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3\
c(N)ncnc23"], metabolite["2aobut", _] -> SMILES["CC(=O)[C@H](N)C([O-])=O"], 
 metabolite["pppi", _] -> 
  SMILES["[O-]P([O-])(=O)OP([O-])(=O)OP([O-])([O-])=O"], 
 metabolite["5dpmev", _] -> 
  SMILES["C[C@@](O)(CCOP(=O)(O)OP(=O)(O)O)CC(=O)O"], 
 metabolite["2shchc", _] -> 
  SMILES["O[C@@H]1C=CC=C([C@H]1C(=O)O)C(=O)CCC(=O)O"], 
 metabolite["2dmmq8", _] -> SMILES["CC(=CCC1=CC(=O)c2ccccc2C1=O)C"], 
 metabolite["ni2", _] -> SMILES["[Ni]"], metabolite["uaaGgla", _] -> 
  SMILES["C[C@@H](NC(=O)[C@@H](C)NC(=O)[C@H](CCCCN)NC(=O)CC[C@@H](NC(=O)[C@H]\
(C)NC(=O)[C@@H](C)O[C@@H]1[C@@H](NC(C)=O)[C@H](O[C@H](CO)[C@H]1O[C@@H]1O[C@H]\
(CO)[C@@H](O)[C@H](O)[C@H]1NC(C)=O)OP(O)(=O)OP(O)(=O)OC\\C=C(\\C)CC\\C=C(\\C)\
CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C\
=C(/C)CC\\C=C(/C)CCC=C(C)C)C(O)=O)C(O)=O"], metabolite["actn-R", _] -> 
  SMILES["C[C@@H](O)C(=O)C"], metabolite["3c4mop", _] -> 
  SMILES["CC(C)[C@H](C(O)=O)C(=O)C(O)=O"], metabolite["no2", _] -> 
  SMILES["[O-]N=O"], metabolite["fc1p", _] -> 
  SMILES["C[C@@H]1O[C@@H](OP(O)(O)=O)[C@@H](O)[C@H](O)[C@@H]1O"], 
 metabolite["acoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@\
H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC([*])=O"], 
 metabolite["galt", _] -> SMILES["OC[C@H](O)[C@@H](O)[C@@H](O)[C@H](O)CO"], 
 metabolite["lpam", _] -> SMILES["NC(=O)CCCCC1CCSS1"], 
 metabolite["psd5p", _] -> 
  SMILES["O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)O)C2=CNC(=O)NC2=O"], 
 metabolite["malACP", _] -> SMILES["OC(=O)CC(=O)S[*]"], 
 metabolite["gdpfuc", _] -> SMILES["C[C@@H]1OC(OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@\
H]([C@H](O)[C@@H]2O)n2cnc3c2nc(N)[nH]c3=O)[C@@H](O)[C@H](O)[C@@H]1O"], 
 metabolite["ind3ac", _] -> SMILES["OC(=O)Cc1c[nH]c2ccccc12"], 
 metabolite["fecrm", _] -> SMILES["[H][C@]12CCCN3O[Fe-3]456(ON(CCC[C@]([H])(N\
C(=O)CNC(=O)CNC(=O)CNC1=O)C(=O)N[C@@]([H])(CCCN(O4)C(C)=[O+]5)C(=O)N2)C(C)=[O\
+]6)[O+]=C3C"], metabolite["5hoxnfkyn", _] -> 
  SMILES["[H]C(=O)Nc1ccc(O)cc1C(=O)CC(N)C(O)=O"], 
 metabolite["lnlncgcoa", _] -> SMILES["CCCCC\\C=C/C\\C=C/C\\C=C/CCCCC(=O)SCCN\
C(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1\
OP(O)(O)=O)n1cnc2c(N)ncnc12"], metabolite["lnlncg", _] -> 
  SMILES["CCCCC\\C=C/C\\C=C/C\\C=C/CCCCC(=O)O"], 
 metabolite["dopaqn", _] -> SMILES["N[C@@H](CC1=CC(=O)C(=O)C=C1)C(O)=O"], 
 metabolite["sphings", _] -> 
  SMILES["CCCCCCCCCCCCC\\C=C\\[C@@H](O)[C@@H](N)CO"], 
 metabolite["23cump", _] -> 
  SMILES["OC[C@H]1O[C@H]([C@@H]2OP(O)(=O)O[C@H]12)n1ccc(=O)[nH]c1=O"], 
 metabolite["3cmp", _] -> 
  SMILES["Nc1ccn([C@@H]2O[C@H](CO)[C@@H](OP(O)(O)=O)[C@H]2O)c(=O)n1"], 
 metabolite["bz", _] -> SMILES["OC(=O)c1ccccc1"], 
 metabolite["ps161", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["12dgr161", _] -> SMILES["OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["clpn161", _] -> SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], metabolite["dh3mchc", _] -> 
  SMILES["CC1=CC=CC(O)(C1O)C(O)=O"], metabolite["mnl", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)[C@H](O)CO"], 
 metabolite["inost", _] -> 
  SMILES["O[C@@H]1[C@H](O)[C@H](O)[C@@H](O)[C@H](O)[C@H]1O"], 
 metabolite["2ins", _] -> 
  SMILES["O[C@@H]1[C@@H](O)[C@H](O)C(=O)[C@H](O)[C@H]1O"], 
 metabolite["4hglusa", _] -> SMILES["N[C@@H](C[C@@H](O)C=O)C(O)=O"], 
 metabolite["zymst", _] -> SMILES["[H][C@@]12CCC3=C(CC[C@]4(C)[C@]([H])(CC[C@\
@]34[H])[C@H](C)CCC=C(C)C)[C@@]1(C)CC[C@H](O)C2"], 
 metabolite["pre5", _] -> SMILES["CC(=O)C12N\\C(=C/C3=NC(C[C@]4(C)N=C(CC5=NC1\
=C(CC(O)=O)[C@@]5(C)CCC(O)=O)C(CCC(O)=O)=C4CC(O)=O)=C(CCC(O)=O)[C@]3(C)CC(O)=\
O)[C@@H](CCC(O)=O)[C@]2(C)CC(O)=O"], metabolite["cobya", _] -> 
  SMILES["[H][C@]12[C@H](CC(O)=O)[C@@](C)(CCC(O)=O)\\C(N1[Co++])=C(C)\\C1=N\\\
C(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(O)=O)[C@@H]4CCC(O)=O)[C@@](C)(CC(O\
)=O)[C@@H]3CCC(O)=O)C(C)(C)[C@@H]1CCC(O)=O"], 
 metabolite["octa", _] -> SMILES["CCCCCCCC(=O)O"], 
 metabolite["tma", _] -> SMILES["CN(C)C"], metabolite["34dhoxmand", _] -> 
  SMILES["OC(C(O)=O)c1ccc(O)c(O)c1"], metabolite["thyox-L", _] -> 
  SMILES["N[C@@H](Cc1cc(I)c(Oc2cc(I)c(O)c(I)c2)c(I)c1)C(=O)O"], 
 metabolite["2hyoxplac", _] -> SMILES["OC(=O)Cc1ccccc1O"], 
 metabolite["kynate", _] -> SMILES["OC(=O)C1=CC(=O)c2ccccc2N1"], 
 metabolite["cys-D", _] -> SMILES["N[C@H](CS)C(=O)O"], 
 metabolite["dcaACP", _] -> SMILES["CCCCCCCCCC(=O)S[*]"], 
 metabolite["pa181", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["dopasf", _] -> SMILES["NCCc1ccc(O)c(OS(O)(=O)=O)c1"], 
 metabolite["dc2coa", _] -> SMILES["CCCCCCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@H]\
(O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c\
(N)ncnc12"], metabolite["dxyl5p", _] -> 
  SMILES["CC(=O)[C@@H](O)[C@H](O)COP(=O)(O)O"], 
 metabolite["ps_EC", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["melt", _] -> SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)[C@@H](O)COC[C@\
H]1O[C@H](O)[C@H](O)[C@@H](O)[C@H]1O"], metabolite["cmpacna", _] -> 
  SMILES["CC(=O)N[C@@H]1[C@@H](O)C[C@](OP(=O)(O)OC[C@H]2O[C@H]([C@H](O)[C@@H]\
2O)N3C=CC(=NC3=O)N)(O[C@H]1[C@H](O)[C@H](O)CO)C(=O)O"], 
 metabolite["estrone", _] -> 
  SMILES["C[C@]12CC[C@H]3[C@@H](CCc4cc(O)ccc34)[C@@H]1CCC2=O"], 
 metabolite["prostgh2", _] -> 
  SMILES[
   "CCCCC[C@H](O)\\C=C\\[C@H]1[C@H]2C[C@H](OO2)[C@@H]1C\\C=C/CCCC(O)=O"], 
 metabolite["sphs1p", _] -> 
  SMILES["CCCCCCCCCCCCC\\C=C\\[C@@H](O)[C@@H](N)COP(=O)(O)O"], 
 metabolite["nrpphr", _] -> SMILES["NC[C@H](O)c1ccc(O)c(O)c1"], 
 metabolite["acmalt", _] -> SMILES["CC(=O)O[C@H]1O[C@H](CO)[C@@H](O[C@H]2O[C@\
H](CO)[C@@H](O)[C@H](O)[C@H]2O)[C@H](O)[C@H]1O"], 
 metabolite["acanth", _] -> SMILES["CC(=O)Nc1ccccc1C([O-])=O"], 
 metabolite["tagat-D", _] -> SMILES["OCC1(O)OC[C@@H](O)[C@H](O)[C@@H]1O"], 
 metabolite["6p2dhglcn", _] -> 
  SMILES["O[C@H](COP(O)(O)=O)[C@@H](O)[C@H](O)C(=O)C(O)=O"], 
 metabolite["e4p", _] -> SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)C=O"], 
 metabolite["rml", _] -> SMILES["C[C@H](O)[C@@H](O)[C@H](O)C(=O)CO"], 
 metabolite["glutar", _] -> SMILES["OC(=O)CCCC(=O)O"], 
 metabolite["b124tc", _] -> SMILES["OC(=O)CC\\C(=C\\C(O)=O)C(O)=O"], 
 metabolite["sprm", _] -> SMILES["NCCCNCCCCNCCCN"], 
 metabolite["pre4", _] -> SMILES["CC(=O)C12N\\C(=C/C3=NC(Cc4[nH]c(CC5=NC1=C(C\
C(O)=O)[C@@]5(C)CCC(O)=O)c(CCC(O)=O)c4CC(O)=O)=C(CCC(O)=O)[C@]3(C)CC(O)=O)[C@\
@H](CCC(O)=O)[C@]2(C)CC(O)=O"], metabolite["all-D", _] -> 
  SMILES["OC[C@H]1OC(O)[C@H](O)[C@H](O)[C@@H]1O"], 
 metabolite["oh1", _] -> SMILES["[OH-]"], metabolite["oxalc", _] -> 
  SMILES["OC(=O)\\C=C/CC(=O)C(O)=O"], metabolite["Dara14lac", _] -> 
  SMILES["OC[C@H]1OC(=O)[C@@H](O)[C@@H]1O"], metabolite["cmusa", _] -> 
  SMILES["N\\C(C(O)=O)=C(\\C=C/C=O)C(O)=O"], metabolite["all6p", _] -> 
  SMILES["[H]C(=O)[C@H](O)[C@H](O)[C@H](O)[C@H](O)COP(O)(O)=O"], 
 metabolite["seasmet", _] -> 
  SMILES[
   "C[Se+](CC[C@H](N)C(O)=O)C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc2c(N)ncnc12"]\
, metabolite["limnen", _] -> SMILES["CC(=C)C1CCC(=CC1)C"], 
 metabolite["4cmcoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([\
C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)C=Cc\
1ccc(O)cc1"], metabolite["oxadpcoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)O\
C[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=\
O)NCCSC(=O)CC(=O)CCC(O)=O"], metabolite["xol7ah", _] -> 
  SMILES["[H][C@]12C[C@@H](O)[C@]3([H])[C@]([H])(CC[C@]4(C)[C@]([H])(CC[C@@]3\
4[H])[C@H](C)CCCC(C)C)[C@@]1(C)CCC(=O)C2"], metabolite["aso4", _] -> 
  SMILES["O[As](O)(O)=O"], metabolite["ps141", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["scys-L", _] -> SMILES["N[C@@H](CSS(=O)(=O)O)C(=O)O"], 
 metabolite["pqqh2", _] -> 
  SMILES["OC(=O)c1cc(C(O)=O)c2c(n1)c(O)c(O)c1cc([nH]c21)C(O)=O"], 
 metabolite["thglu", _] -> SMILES["Nc1nc2NC[C@H](CNc3ccc(cc3)C(=O)N[C@@H](CCC\
(=O)N[C@@H](CCC(=O)N[C@@H](CCC(O)=O)C(O)=O)C(O)=O)C(O)=O)Nc2c(=O)[nH]1"], 
 metabolite["3hacoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([\
C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)C[C@\
@H](O)[*]"], metabolite["man6pglyc", _] -> 
  SMILES["OC[C@@H](O[C@H]1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H](O)[C@@H]1O)C(O)=O\
"], metabolite["mmtsa", _] -> SMILES["C[C@@H](C=O)C(O)=O"], 
 metabolite["pg140", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["3mcat", _] -> SMILES["Cc1cccc(O)c1O"], 
 metabolite["dhap", _] -> SMILES["OCC(=O)COP(=O)(O)O"], 
 metabolite["g6p", _] -> 
  SMILES["OC1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H](O)[C@H]1O"], 
 metabolite["nadh", _] -> SMILES["NC(=O)C1=CN(C=CC1)[C@@H]2O[C@H](COP(=O)(O)O\
P(=O)(O)OC[C@H]3O[C@H]([C@H](O)[C@@H]3O)n4cnc5c(N)ncnc45)[C@@H](O)[C@H]2O"], 
 metabolite["co2", _] -> SMILES["O=C=O"], metabolite["6pgl", _] -> 
  SMILES["O[C@H]1[C@H](O)[C@@H](COP(O)(O)=O)OC(=O)[C@@H]1O"], 
 metabolite["akg", _] -> SMILES["OC(=O)CCC(=O)C(=O)O"], 
 metabolite["succ", _] -> SMILES["OC(=O)CCC(=O)O"], 
 metabolite["agm", _] -> SMILES["NCCCCNC(=N)N"], 
 metabolite["imacp", _] -> SMILES["OP(O)(=O)OCC(=O)Cc1c[nH]cn1"], 
 metabolite["adn", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](CO)[C@@H](O)[C@H]3O"], 
 metabolite["thf", _] -> 
  SMILES[
   "NC1=NC(=O)C2=C(NC[C@H](CNc3ccc(cc3)C(=O)N[C@@H](CCC(=O)O)C(=O)O)N2)N1"], 
 metabolite["cytd", _] -> 
  SMILES["NC1=NC(=O)N(C=C1)[C@@H]2O[C@H](CO)[C@@H](O)[C@H]2O"], 
 metabolite["gtp", _] -> SMILES["NC1=Nc2c(ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O)(\
O)OP(=O)(O)O)[C@@H](O)[C@H]3O)C(=O)N1"], metabolite["2dr1p", _] -> 
  SMILES["OC[C@H]1OC(C[C@@H]1O)OP(O)(O)=O"], metabolite["grdp", _] -> 
  SMILES["CC(=CCC\\C(=C\\COP(=O)(O)OP(=O)(O)O)\\C)C"], 
 metabolite["frdp", _] -> 
  SMILES["CC(=CCC\\C(=C\\CC\\C(=C\\COP(=O)(O)OP(=O)(O)O)\\C)\\C)C"], 
 metabolite["2ahhmd", _] -> 
  SMILES["NC1=NC2=C(N=C(COP(=O)(O)OP(=O)(O)O)CN2)C(=O)N1"], 
 metabolite["o2", _] -> SMILES["O=O"], metabolite["ala-B", _] -> 
  SMILES["NCCC(=O)O"], metabolite["hx2coa", _] -> 
  SMILES["CCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)O\
C[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["sdhlam", _] -> SMILES["NC(=O)CCCCC(S)CCSC(=O)CCC(O)=O"], 
 metabolite["glx", _] -> SMILES["OC(=O)C=O"], 
 metabolite["fe3", _] -> SMILES["[Fe+3]"], metabolite["sbt-D", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)[C@@H](O)CO"], 
 metabolite["glu1sa", _] -> SMILES["[H]C(=O)[C@@H](N)CCC(O)=O"], 
 metabolite["ac", _] -> SMILES["CC(=O)O"], metabolite["3ophb", _] -> 
  SMILES["CC(C)=CCC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\\
CC\\C(C)=C\\CC\\C(C)=C\\Cc1cc(ccc1O)C([O-])=O"], 
 metabolite["ara5p", _] -> SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)[C@H](O)C=O"], 
 metabolite["5caiz", _] -> 
  SMILES["O[C@@H]1[C@@H](COP(O)(O)=O)O[C@H]([C@@H]1O)n1cncc1NC(O)=O"], 
 metabolite["25aics", _] -> 
  SMILES["Nc1c(ncn1[C@@H]1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]1O)C(=O)NC(CC(O)=O\
)C(O)=O"], metabolite["aacoa", _] -> SMILES["CC(=O)CC(=O)SCCNC(=O)CCNC(=O)[C@\
H](O)C(C)(C)COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc\
3c(N)ncnc23"], metabolite["na1", _] -> SMILES["[Na+]"], 
 metabolite["13dampp", _] -> SMILES["NCCCN"], 
 metabolite["stcoa", _] -> SMILES["CCCCCCCCCCCCCCCCCC(=O)SCCNC(=O)CCNC(=O)[C@\
H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc\
2c(N)ncnc12"], metabolite["pmtcoa", _] -> SMILES["CCCCCCCCCCCCCCCC(=O)SCCNC(=\
O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(\
O)(O)=O)n1cnc2c(N)ncnc12"], metabolite["lcts", _] -> 
  SMILES["OC[C@H]1O[C@@H](O[C@@H]2[C@@H](CO)OC(O)[C@H](O)[C@H]2O)[C@H](O)[C@@\
H](O)[C@H]1O"], metabolite["ddcacoa", _] -> SMILES["CCCCCCCCCCCC(=O)SCCNC(=O)\
CCNC(=O)[C@H](O)C(C)(C)COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O\
)(O)O)n2cnc3c(N)ncnc23"], metabolite["2dhguln", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)C(=O)C(O)=O"], 
 metabolite["etha", _] -> SMILES["NCCO"], metabolite["ddca", _] -> 
  SMILES["CCCCCCCCCCCC(=O)O"], metabolite["sucarg", _] -> 
  SMILES["NC(=N)NCCC[C@H](NC(=O)CCC(=O)O)C(=O)O"], 
 metabolite["gtspmd", _] -> 
  SMILES["NCCCCNCCCNC(=O)CNC(=O)[C@H](CS)NC(=O)CC[C@H](N)C(=O)O"], 
 metabolite["pram", _] -> 
  SMILES["N[C@@H]1O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]1O"], 
 metabolite["acryl", _] -> SMILES["OC(=O)C=C"], 
 metabolite["co1dam", _] -> SMILES["[H][C@]12[C@H](CC(O)=O)[C@@](C)(CCC(O)=O)\
\\C(N1[Co])=C(C)\\C1=N\\C(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H\
]4CCC(O)=O)[C@@](C)(CC(N)=O)[C@@H]3CCC(O)=O)C(C)(C)[C@@H]1CCC(O)=O"], 
 metabolite["adcobdam", _] -> SMILES["[H][C@]12[C@H](CC(O)=O)[C@@](C)(CCC(O)=\
O)\\C(N1[Co+]C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc3c(N)ncnc13)=C(C)\\C1=N\\C(=\
C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4CCC(O)=O)[C@@](C)(CC(N)=O\
)[C@@H]3CCC(O)=O)C(C)(C)[C@@H]1CCC(O)=O"], metabolite["ascb-L", _] -> 
  SMILES["OC[C@H](O)[C@H]1OC(=O)C(=C1O)O"], metabolite["fol", _] -> 
  SMILES["Nc1nc2ncc(CNc3ccc(cc3)C(=O)N[C@@H](CCC(O)=O)C(O)=O)nc2c(=O)[nH]1"], 
 metabolite["mobd", _] -> SMILES["[O-][Mo](=O)(=O)[O-]"], 
 metabolite["thbpt", _] -> SMILES["CC(O)C(O)C1CNc2nc(N)nc(O)c2N1"], 
 metabolite["xtp", _] -> SMILES["O[C@@H]1[C@@H](COP(O)(=O)OP(O)(=O)OP(O)(O)=O\
)O[C@H]([C@@H]1O)n1cnc2c1[nH]c(=O)[nH]c2=O"], 
 metabolite["bdg2hc", _] -> 
  SMILES[
   "OC[C@H]1O[C@@H](Oc2ccccc2\\C=C/C([O-])=O)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["asp-D", _] -> SMILES["N[C@H](CC(=O)O)C(=O)O"], 
 metabolite["fald", _] -> SMILES["[H]C([H])=O"], 
 metabolite["srtn", _] -> SMILES["NCCc1c[nH]c2ccc(O)cc12"], 
 metabolite["gchola", _] -> SMILES["C[C@H](CCC(=O)NCC(=O)O)[C@H]1CC[C@H]2[C@@\
H]3[C@H](O)C[C@@H]4C[C@H](O)CC[C@]4(C)[C@H]3C[C@H](O)[C@]12C"], 
 metabolite["sulfac", _] -> SMILES["OC(=O)CS(=O)(=O)O"], 
 metabolite["thcholstoic", _] -> SMILES["[H][C@@]12C[C@H](O)CC[C@]1(C)[C@@]1(\
[H])C[C@H](O)[C@]3(C)[C@]([H])(CC[C@@]3([H])[C@]1([H])[C@H](O)C2)[C@H](C)CCCC\
(C)C(O)=O"], metabolite["1hdecg3p", _] -> 
  SMILES["O[C@H](COC([*])=O)COP(O)(O)=O"], metabolite["cdpdhdec9eg", _] -> 
  SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)[C@@H](O)[C@H]2O)c(=O)n1"], metabolite["cdpdodec11eg", _] -> 
  SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)[C@@H](O)[C@H]2O)c(=O)n1"], metabolite["nad", _] -> 
  SMILES["NC(=O)c1ccc[n+](c1)[C@@H]1O[C@H](COP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H](\
[C@H](O)[C@@H]2O)n2cnc3c(N)ncnc23)[C@@H](O)[C@H]1O"], 
 metabolite["spmd", _] -> SMILES["NCCCCNCCCN"], 
 metabolite["dcamp", _] -> SMILES["O[C@@H]1[C@@H](COP(O)(O)=O)O[C@H]([C@@H]1O\
)n1cnc2c(NC(CC(O)=O)C(O)=O)ncnc12"], metabolite["dhf", _] -> 
  SMILES[
   "NC1=NC(=O)C2=C(NCC(=N2)CNc3ccc(cc3)C(=O)N[C@@H](CCC(=O)O)C(=O)O)N1"], 
 metabolite["uppg1", _] -> SMILES["OC(=O)CCc1c2Cc3[nH]c(Cc4[nH]c(Cc5[nH]c(Cc(\
[nH]2)c1CC(O)=O)c(CCC(O)=O)c5CC(O)=O)c(CCC(O)=O)c4CC(O)=O)c(CCC(O)=O)c3CC(O)=\
O"], metabolite["lac-L", _] -> SMILES["C[C@H](O)C(=O)O"], 
 metabolite["lipidAds", _] -> SMILES["CCCCCCCCCCC[C@@H](O)CC(=O)N[C@H]1[C@H](\
OC[C@H]2O[C@H](OP(O)(O)=O)[C@H](NC(=O)C[C@H](O)CCCCCCCCCCC)[C@@H](OC(=O)C[C@H\
](O)CCCCCCCCCCC)[C@@H]2O)O[C@H](CO)[C@@H](O)[C@@H]1OC(=O)C[C@H](O)CCCCCCCCCCC\
"], metabolite["pmcoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]\
([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)CC\
CCCC(O)=O"], metabolite["4mzym", _] -> SMILES["[H][C@@]12CCC3=C(CC[C@]4(C)[C@\
]([H])(CC[C@@]34[H])[C@H](C)CCC=C(C)C)[C@@]1(C)CC[C@H](O)[C@H]2C"], 
 metabolite["4h2opntn", _] -> SMILES["CC(O)CC(=O)C(O)=O"], 
 metabolite["met-D", _] -> SMILES["CSCC[C@@H](N)C(=O)O"], 
 metabolite["h2mb4p", _] -> SMILES["C\\C(=C/COP(=O)(O)OP(=O)(O)O)\\CO"], 
 metabolite["tcynt", _] -> SMILES["SC#N"], metabolite["6ax6ax", _] -> 
  SMILES["NCCCCCC(=O)NCCCCCC([O-])=O"], metabolite["copre6", _] -> 
  SMILES["C[C@]1(CCC(O)=O)C2=NC(=C1CC(O)=O)[C@]1(C)N3[Co+][N]4=C(C2)C(CCC(O)=\
O)=C(CC(O)=O)[C@]4(C)CC2=C(CCC(O)=O)[C@](C)(CC(O)=O)C(/C=C3/[C@@H](CCC(O)=O)[\
C@]1(C)CC(O)=O)=N2"], metabolite["n2", _] -> SMILES["N#N"], 
 metabolite["prpncoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H](\
[C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)C=C\
"], metabolite["estradiol", _] -> 
  SMILES["C[C@]12CC[C@H]3[C@@H](CCc4cc(O)ccc34)[C@@H]1CC[C@@H]2O"], 
 metabolite["camp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@@H]4COP(=O)(O)O[C@H]4[C@H]3O"], 
 metabolite["2coum", _] -> SMILES["OC(=O)\\C=C/c1ccccc1O"], 
 metabolite["g3pe", _] -> SMILES["[H][C@](O)(CO)COP(O)(=O)OCCN"], 
 metabolite["23cgmp", _] -> 
  SMILES["Nc1nc2n(cnc2c(=O)[nH]1)[C@@H]1O[C@H](CO)[C@H]2OP(O)(=O)O[C@@H]12"], 
 metabolite["dlnlcg", _] -> SMILES["CCCCC\\C=C/C\\C=C/C\\C=C/CCCCCCC(=O)O"], 
 metabolite["n2o", _] -> SMILES["[O-][N+]#N"], 
 metabolite["xoltriol", _] -> SMILES["[H][C@@]12C[C@H](O)CC[C@]1(C)[C@@]1([H]\
)C[C@H](O)[C@]3(C)[C@]([H])(CC[C@@]3([H])[C@]1([H])[C@H](O)C2)[C@H](C)CCCC(C)\
C"], metabolite["formcoa", _] -> SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C\
@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCSC=O"]\
, metabolite["12dgr140", _] -> SMILES["OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["hxa", _] -> SMILES["CCCCCC(=O)O"], 
 metabolite["actp", _] -> SMILES["CC(=O)OP(=O)(O)O"], 
 metabolite["op4en", _] -> SMILES["OC(=O)C(\\O)=C/C=C"], 
 metabolite["glyc-R", _] -> SMILES["OC[C@@H](O)C(=O)O"], 
 metabolite["malthx", _] -> SMILES["OC[C@@H](O)[C@@H](O[C@H]1O[C@H](CO)[C@@H]\
(O[C@H]2O[C@H](CO)[C@@H](O[C@H]3O[C@H](CO)[C@@H](O[C@H]4O[C@H](CO)[C@@H](O[C@\
H]5O[C@H](CO)[C@@H](O)[C@H](O)[C@H]5O)[C@H](O)[C@H]4O)[C@H](O)[C@H]3O)[C@H](O\
)[C@H]2O)[C@H](O)[C@H]1O)[C@H](O)[C@@H](O)C=O"], 
 metabolite["gmhep17bp", _] -> 
  SMILES[
   "[H][C@@]1(OC(OP(O)(O)=O)[C@@H](O)[C@@H](O)[C@@H]1O)[C@H](O)COP(O)(O)=O"], 
 metabolite["thmpp", _] -> 
  SMILES["Cc1ncc(C[n+]2csc(CCOP(=O)(O)OP(=O)(O)O)c2C)c(N)n1"], 
 metabolite["3hhdcoa", _] -> SMILES["CCCCCCCCCCCCC[C@H](O)CC(=O)SCCNC(=O)CCNC\
(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=\
O)n1cnc2c(N)ncnc12"], metabolite["feenter", _] -> 
  SMILES["[H][C@]12COC(=O)[C@]3([H])COC(=O)[C@]([H])(COC1=O)NC(=O)c1cccc4O[Fe\
-3]56(Oc7cccc(C(=O)N2)c7O5)(Oc2cccc(C(=O)N3)c2O6)Oc14"], 
 metabolite["xoldioloneh", _] -> SMILES["[H][C@]12C[C@@H](O)[C@@]3([H])[C@]4(\
[H])CC[C@]([H])([C@H](C)CCCC(C)C)[C@@]4(C)[C@@H](O)C[C@]3([H])[C@@]1(C)CCC(=O\
)C2"], metabolite["didp", _] -> 
  SMILES["O[C@H]1C[C@@H](O[C@@H]1COP(O)(=O)OP(O)(O)=O)n1cnc2c1nc[nH]c2=O"], 
 metabolite["pa180", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["p-xyl", _] -> SMILES["Cc1ccc(C)cc1"], 
 metabolite["argsuc", _] -> 
  SMILES["N[C@@H](CCCNC(=N)NC(CC(O)=O)C(O)=O)C(O)=O"], 
 metabolite["kdolipid4", _] -> SMILES["CCCCCCCCCCC[C@@H](O)CC(=O)N[C@H]1[C@H]\
(O[C@H](CO[C@@H]2O[C@H](CO[C@@]3(C[C@@H](O)[C@@H](O)[C@H](O3)[C@H](O)CO)C(O)=\
O)[C@@H](OP(O)(O)=O)[C@H](OC(=O)C[C@H](O)CCCCCCCCCCC)[C@H]2NC(=O)C[C@H](O)CCC\
CCCCCCCC)[C@@H](O)[C@@H]1OC(=O)C[C@H](O)CCCCCCCCCCC)OP(O)(O)=O"], 
 metabolite["cdpchol", _] -> SMILES["C[N+](C)(C)CCOP(=O)([O-])OP(=O)(O)OC[C@H\
]1O[C@H]([C@H](O)[C@@H]1O)N2C=CC(=NC2=O)N"], metabolite["23dhba", _] -> 
  SMILES["Nc1ncnc2n(cnc12)[C@@H]1O[C@H](COP(O)(=O)OC(=O)c2cccc(O)c2O)[C@@H](O\
)[C@H]1O"], metabolite["hkntd", _] -> 
  SMILES["[H]C(=CC([H])=C(O)C(O)=O)C(=O)C([H])=CC(O)=O"], 
 metabolite["adrnl", _] -> SMILES["CNC[C@H](O)c1ccc(O)c(O)c1"], 
 metabolite["cholate", _] -> SMILES["C[C@H](CCC(=O)O)[C@H]1CC[C@H]2[C@@H]3[C@\
H](O)C[C@@H]4C[C@H](O)CC[C@]4(C)[C@H]3C[C@H](O)[C@]12C"], 
 metabolite["pg141", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["oxalcoa", _] -> SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H](\
[C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)C(=\
O)O"], metabolite["conialdh", _] -> SMILES["COc1cc(\\C=C\\C=O)ccc1O"], 
 metabolite["3mgcoa", _] -> SMILES["C\\C(CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(\
C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc1\
2)=C/C(O)=O"], metabolite["glutcoa", _] -> SMILES["CC(C)(COP(=O)(O)OP(=O)(O)O\
C[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=\
O)NCCSC(=O)CCCC(=O)O"], metabolite["L-dpchrm", _] -> 
  SMILES["[H][C@]1(CC2=CC(=O)C(=O)C=C2N1)C(O)=O"], 
 metabolite["ergst", _] -> SMILES["CC(C)[C@@H](C)\\C=C\\[C@@H](C)[C@H]1CC[C@H\
]2C3=CC=C4C[C@@H](O)CC[C@]4(C)[C@H]3CC[C@]12C"], 
 metabolite["ptth", _] -> SMILES["CC(C)(CO)[C@@H](O)C(=O)NCCC(=O)NCCS"], 
 metabolite["hphaccoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]\
([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)Cc\
1ccc(O)cc1"], metabolite["34dhphe", _] -> 
  SMILES["N[C@@H](Cc1ccc(O)c(O)c1)C(=O)O"], metabolite["xol7a", _] -> 
  SMILES["CC(C)CCC[C@@H](C)[C@H]1CC[C@H]2[C@@H]3[C@H](O)C=C4C[C@@H](O)CC[C@]4\
(C)[C@H]3CC[C@]12C"], metabolite["xoltetrol", _] -> 
  SMILES["[H][C@@](C)(CCC(=O)C(C)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(\
=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@]1(\
[H])CC[C@@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C[C@H](O)CC[C@]4(C)[C@@]3([H])C\
C[C@]12C"], metabolite["selcyst", _] -> 
  SMILES["N[C@@H](CC[Se]C[C@H](N)C(O)=O)C(O)=O"], 
 metabolite["hista", _] -> SMILES["NCCc1c[nH]cn1"], 
 metabolite["5dh4dglc", _] -> SMILES["O[C@@H](CC(=O)C(O)=O)[C@@H](O)C(O)=O"], 
 metabolite["3AStmyn", _] -> SMILES["CN[C@@H]1[C@@H](O[C@@H](CO)[C@H](O)[C@H]\
1OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc2c(N)ncnc12)O[C@H]1[C@@H](O[C@\
@H](C)[C@]1(O)C=O)O[C@H]1[C@H](O)[C@@H](O)[C@H](NC(N)=N)[C@@H](O)[C@@H]1NC(N)\
=N"], metabolite["mcom", _] -> SMILES["CSCCS(O)(=O)=O"], 
 metabolite["gg4abut", _] -> SMILES["N[C@@H](CCC(=O)NCCCC(O)=O)C(O)=O"], 
 metabolite["5htrp", _] -> SMILES["N[C@@H](Cc1c[nH]c2ccc(O)cc12)C(=O)O"], 
 metabolite["3ump", _] -> 
  SMILES["OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1ccc(=O)[nH]c1=O"], 
 metabolite["2mb2coa", _] -> SMILES["C\\C=C(/C)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)\
C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)\
ncnc12"], metabolite["4gudbutn", _] -> SMILES["NC(=N)NCCCC(=O)O"], 
 metabolite["bzalc", _] -> SMILES["OCc1ccccc1"], 
 metabolite["rbflvrd", _] -> 
  SMILES[
   "Cc1cc2Nc3c([nH]c(=O)[nH]c3=O)N(C[C@H](O)[C@H](O)[C@H](O)CO)c2cc1C"], 
 metabolite["2oph", _] -> SMILES["CC(=CCC\\C(=C\\CC\\C(=C\\CC\\C(=C\\CC\\C(=C\
\\CC\\C(=C\\CC\\C(=C\\CC\\C(=C\\Cc1ccccc1O)\\C)\\C)\\C)\\C)\\C)\\C)\\C)C"], 
 metabolite["octp", _] -> SMILES["C[C@@H](N[C@@H](CCCNC(N)=N)C(O)=O)C(O)=O"], 
 metabolite["scl2", _] -> SMILES["C[C@]1(CC(O)=O)[C@H](CCC(O)=O)c2cc3[nH]c(cc\
4nc(cc5[nH]c(cc1n2)c(CC(O)=O)c5CCC(O)=O)c(CCC(O)=O)c4CC(O)=O)[C@@H](CCC(O)=O)\
[C@]3(C)CC(O)=O"], metabolite["mercplac", _] -> SMILES["O[C@@H](CS)C(O)=O"], 
 metabolite["omaenol", _] -> SMILES["OC(=O)\\C=C(\\C=C(/O)C(O)=O)C(O)=O"], 
 metabolite["3hpp", _] -> SMILES["OCCC(O)=O"], 
 metabolite["mescoa", _] -> SMILES["C\\C(=C/C(O)=O)C(=O)SCCNC(=O)CCNC(=O)[C@H\
](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2\
c(N)ncnc12"], metabolite["3gmp", _] -> 
  SMILES["NC1=Nc2c(ncn2[C@@H]3O[C@H](CO)[C@@H](OP(=O)(O)O)[C@H]3O)C(=O)N1"], 
 metabolite["nicrns", _] -> 
  SMILES["OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)[n+]2cccc(c2)C(=O)O"], 
 metabolite["acglc-D", _] -> 
  SMILES["CC(=O)OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["pqq", _] -> 
  SMILES["OC(=O)c1cc(C(O)=O)c-2c(n1)C(=O)C(=O)c1cc([nH]c-21)C(O)=O"], 
 metabolite["3pg", _] -> SMILES["O[C@H](COP(=O)(O)O)C(=O)O"], 
 metabolite["3dhsk", _] -> SMILES["O[C@@H]1CC(=CC(=O)[C@H]1O)C(=O)O"], 
 metabolite["3psme", _] -> 
  SMILES["O[C@H]1[C@@H](CC(=C[C@H]1OP(=O)(O)O)C(=O)O)OC(=C)C(=O)O"], 
 metabolite["prpp", _] -> 
  SMILES["O[C@H]1[C@@H](O)[C@@H](OP(=O)(O)OP(=O)(O)O)O[C@@H]1COP(=O)(O)O"], 
 metabolite["ser-L", _] -> SMILES["N[C@@H](CO)C(=O)O"], 
 metabolite["cys-L", _] -> SMILES["N[C@@H](CS)C(=O)O"], 
 metabolite["pap", _] -> 
  SMILES[
   "Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)O)[C@@H](OP(=O)(O)O)[C@H]3O"], 
 metabolite["so3", _] -> SMILES["OS(=O)O"], metabolite["26dap-M", _] -> 
  SMILES["N[C@H](CCC[C@H](N)C(=O)O)C(=O)O"], metabolite["sl26da", _] -> 
  SMILES["N[C@@H](CCC[C@H](NC(=O)CCC(O)=O)C(O)=O)C(O)=O"], 
 metabolite["xmp", _] -> 
  SMILES["O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)O)n2cnc3C(=O)NC(=O)Nc23"], 
 metabolite["gmp", _] -> 
  SMILES["NC1=Nc2c(ncn2[C@@H]3O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]3O)C(=O)N1"], 
 metabolite["cdp", _] -> 
  SMILES[
   "NC1=NC(=O)N(C=C1)[C@@H]2O[C@H](COP(=O)(O)OP(=O)(O)O)[C@@H](O)[C@H]2O"], 
 metabolite["dctp", _] -> 
  SMILES[
   "NC1=NC(=O)N(C=C1)[C@H]2C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O2"]\
, metabolite["glc-D", _] -> SMILES["OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["h2o", _] -> SMILES["O"], metabolite["4mhetz", _] -> 
  SMILES["Cc1ncsc1CCO"], metabolite["2mop", _] -> SMILES["CC(C=O)C(O)=O"], 
 metabolite["chol", _] -> SMILES["C[N+](C)(C)CCO"], 
 metabolite["nadph", _] -> SMILES["NC(=O)C1=CN(C=CC1)[C@@H]2O[C@H](COP(=O)(O)\
OP(=O)(O)OC[C@H]3O[C@H]([C@H](OP(=O)(O)O)[C@@H]3O)n4cnc5c(N)ncnc45)[C@@H](O)[\
C@H]2O"], metabolite["mal-L", _] -> SMILES["O[C@@H](CC(=O)O)C(=O)O"], 
 metabolite["dcyt", _] -> 
  SMILES["NC1=NC(=O)N(C=C1)[C@H]2C[C@H](O)[C@@H](CO)O2"], 
 metabolite["ura", _] -> SMILES["O=C1NC=CC(=O)N1"], 
 metabolite["etoh", _] -> SMILES["CCO"], metabolite["asn-L", _] -> 
  SMILES["N[C@@H](CC(=O)N)C(=O)O"], metabolite["orn", _] -> 
  SMILES["NCCCC(N)C(O)=O"], metabolite["hcit", _] -> 
  SMILES["OC(=O)CCC(O)(CC(O)=O)C(O)=O"], metabolite["ggl", _] -> 
  SMILES["OC[C@@H](O)CO[C@@H]1O[C@H](CO)[C@H](O)[C@H](O)[C@H]1O"], 
 metabolite["thm", _] -> SMILES["Cc1ncc(C[n+]2csc(CCO)c2C)c(N)n1"], 
 metabolite["8aonn", _] -> SMILES["CC(N)C(=O)CCCCCC([O-])=O"], 
 metabolite["chitin", _] -> SMILES["CC(=O)N[C@H]1[C@H](O)O[C@H](CO)[C@@H](O[C\
@@H]2O[C@H](CO)[C@@H](O[C@@H]3O[C@H](CO)[C@@H](O)[C@H](O)[C@H]3NC(=O)C)[C@H](\
O)[C@H]2NC(=O)C)[C@@H]1O"], metabolite["mmcoa-S", _] -> 
  SMILES["C[C@@H](C(O)=O)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)\
(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["5mthf", _] -> 
  SMILES[
   "CN1[C@@H](CNc2ccc(cc2)C(=O)N[C@@H](CCC(=O)O)C(=O)O)CNc3nc(N)nc(O)c13"], 
 metabolite["25dkglcn", _] -> SMILES["OCC(=O)[C@@H](O)[C@H](O)C(=O)C(O)=O"], 
 metabolite["dtdp4addg", _] -> SMILES["C[C@H]1OC(OP(O)(=O)OP(O)(=O)OC[C@H]2O[\
C@H](C[C@@H]2O)n2cc(C)c(=O)[nH]c2=O)[C@H](O)[C@@H](O)[C@@H]1N"], 
 metabolite["uacmam", _] -> SMILES["CC(=O)N[C@H]1[C@@H](O)[C@H](O)[C@@H](CO)O\
C1OP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1ccc(=O)[nH]c1=O"], 
 metabolite["maltttr", _] -> SMILES["OC[C@@H](O)[C@@H](O[C@H]1O[C@H](CO)[C@@H\
](O[C@H]2O[C@H](CO)[C@@H](O[C@H]3O[C@H](CO)[C@@H](O)[C@H](O)[C@H]3O)[C@H](O)[\
C@H]2O)[C@H](O)[C@H]1O)[C@H](O)[C@@H](O)C=O"], 
 metabolite["pac", _] -> SMILES["OC(=O)Cc1ccccc1"], 
 metabolite["acACP", _] -> SMILES["CC(=O)S[*]"], 
 metabolite["thmtp", _] -> 
  SMILES["Cc1ncc(C[n+]2csc(CCOP(O)(=O)OP(O)(=O)OP(O)(O)=O)c2C)c(N)n1"], 
 metabolite["tmao", _] -> SMILES["CN(C)(C)=O"], 
 metabolite["cmaphis", _] -> 
  SMILES["C[NH2+]C(CCc1nc(C[C@H](N)C(O)=O)c[nH]1)C(O)=O"], 
 metabolite["25dhpp", _] -> 
  SMILES["Nc1nc(O)c(N)c(N[C@@H]2O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]2O)n1"], 
 metabolite["sheme", _] -> SMILES["C[C@]1(CC(O)=O)[C@H](CCC(O)=O)C2=C/c3c(CC(\
O)=O)c(CCC(O)=O)c4\\C=C5/N=C(/C=C6\\N([Fe]n34)/C(=C\\C1=N\\2)[C@@H](CCC(O)=O)\
[C@]6(C)CC(O)=O)C(CC(O)=O)=C/5CCC(O)=O"], metabolite["btcoa", _] -> 
  SMILES["CCCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1\
O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["2ombz", _] -> SMILES["COC1=CC(=O)C=C(C\\C=C(/C)CC\\C=C(/C)CC\\C=\
C(/C)CC\\C=C(/C)CC\\C=C(/C)CC\\C=C(/C)CC\\C=C(/C)CCC=C(C)C)C1=O"], 
 metabolite["cbi", _] -> SMILES["[H][C@@]12[C@H](CC(N)=O)[C@@](C)(CCC(=O)NC[C\
@@H](C)O)C3=C(C)C4=[N]5C(=CC6=[N]7C(=C(C)C8=[N]([C@]1(C)[C@@](C)(CC(N)=O)[C@@\
H]8CCC(N)=O)[Co++]57N23)[C@@](C)(CC(N)=O)[C@@H]6CCC(N)=O)C(C)(C)[C@@H]4CCC(N)\
=O"], metabolite["4abut", _] -> SMILES["NCCCC(=O)O"], 
 metabolite["creat", _] -> SMILES["CN(CC(=O)O)C(=N)N"], 
 metabolite["urate", _] -> SMILES["O=C1NC(=O)C2=C(NC(=O)N2)N1"], 
 metabolite["retinol", _] -> 
  SMILES["C\\C(=C/CO)\\C=C\\C=C(/C)\\C=C\\C1=C(C)CCCC1(C)C"], 
 metabolite["pa160", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["pe181", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["ppal", _] -> SMILES["CCC=O"], metabolite["5mtr", _] -> 
  SMILES["CSC[C@@H](O)[C@@H](O)[C@@H](O)C=O"], 
 metabolite["glu5sa", _] -> SMILES["N[C@@H](CCC=O)C(=O)O"], 
 metabolite["pphn", _] -> SMILES["OC1C=CC(CC(=O)C(O)=O)(C=C1)C(O)=O"], 
 metabolite["3ig3p", _] -> SMILES["OC(COP(O)(O)=O)C(O)c1c[nH]c2ccccc12"], 
 metabolite["sucbz", _] -> SMILES["[O-]C(=O)CCC(=O)c1ccccc1C([O-])=O"], 
 metabolite["2mecdp", _] -> SMILES["C[C@@]1(CO)OP(=O)(O)OP(=O)(O)OC[C@H]1O"], 
 metabolite["uamr", _] -> SMILES["C[C@@H](O[C@H]1[C@H](O)[C@@H](CO)OC(OP(O)(=\
O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@@H]1NC(C)=O)C\
(O)=O"], metabolite["pyam5p", _] -> SMILES["Cc1ncc(COP(=O)(O)O)c(CN)c1O"], 
 metabolite["sucorn", _] -> SMILES["NCCC[C@H](NC(=O)CCC(=O)O)C(=O)O"], 
 metabolite["lanost", _] -> SMILES["C[C@H](CCC=C(C)C)[C@H]1CC[C@@]2(C)C3=C(CC\
[C@]12C)[C@@]4(C)CC[C@H](O)C(C)(C)[C@@H]4CC3"], 
 metabolite["fgam", _] -> 
  SMILES["O[C@H]1[C@@H](O)C(NC(=O)CNC=O)O[C@@H]1COP(O)(O)=O"], 
 metabolite["q10", _] -> SMILES["COC1=C(OC)C(=O)C(=C(C)C1=O)CC=C(C)C"], 
 metabolite["cu2", _] -> SMILES["[Cu]"], metabolite["pre3a", _] -> 
  SMILES["C\\C1=C2\\N\\C(=C/C3=N/C(=C\\c4[nH]c(Cc5[nH]c1c(CC(O)=O)c5CCC(O)=O)\
c(CCC(O)=O)c4CC(O)=O)[C@@H](CCC(O)=O)[C@]3(C)CC(O)=O)[C@@H](CCC(O)=O)[C@]2(C)\
CC(O)=O"], metabolite["mppp9", _] -> SMILES["CC1=C(CCC(O)=O)C2=N\\C\\1=C/c1c(\
C)c(C=C)c3\\C=C4/N=C(C=c5c(C)c(CCC(O)=O)c(=C2)n5[Mg]n13)C(C=C)=C/4C"], 
 metabolite["r15bp", _] -> 
  SMILES["O[C@H]1[C@@H](O)C(O[C@@H]1COP(O)(O)=O)OP(O)(O)=O"], 
 metabolite["5forthf", _] -> SMILES["[H]C(=N)N1[C@@H](CNc2ccc(cc2)C(=O)N[C@@H\
](CCC(O)=O)C(O)=O)CNc2nc(N)[nH]c(=O)c12"], metabolite["male", _] -> 
  SMILES["OC(=O)\\C=C/C(=O)O"], metabolite["35diotyr", _] -> 
  SMILES["N[C@@H](Cc1cc(I)c(O)c(I)c1)C(=O)O"], 
 metabolite["3ityr-L", _] -> SMILES["N[C@@H](Cc1ccc(O)c(I)c1)C(=O)O"], 
 metabolite["2ameph", _] -> SMILES["NCCP(=O)(O)O"], 
 metabolite["mi1346p", _] -> SMILES["O[C@H]1[C@H](OP(O)(O)=O)[C@@H](OP(O)(O)=\
O)[C@@H](O)[C@@H](OP(O)(O)=O)[C@@H]1OP(O)(O)=O"], 
 metabolite["lipa", _] -> SMILES["[H][C@@]1(O[C@@](C[C@@H](O)[C@H]1O)(O[C@@H]\
1C[C@@](OC[C@H]2O[C@@H](OC[C@H]3O[C@H](OP(O)(O)=O)[C@H](NC(=O)C[C@H](O)CCCCCC\
CCCCC)[C@@H](OC(=O)C[C@H](O)CCCCCCCCCCC)[C@@H]3O)[C@H](NC(=O)C[C@@H](CCCCCCCC\
CCC)OC(=O)CCCCCCCCCCC)[C@@H](OC(=O)C[C@@H](CCCCCCCCCCC)OC(=O)CCCCCCCCCCCCC)[C\
@@H]2OP(O)(O)=O)(O[C@]([H])([C@H](O)CO)[C@@H]1O)C(O)=O)C(O)=O)[C@H](O)CO"], 
 metabolite["pg120", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["sbt6p", _] -> 
  SMILES["OC[C@H](O)[C@@H](O)[C@H](O)[C@H](O)COP(=O)(O)O"], 
 metabolite["3otdcoa", _] -> SMILES["CCCCCCCCCCCC(=O)CC(=O)SCCNC(=O)CCNC(=O)[\
C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1c\
nc2c(N)ncnc12"], metabolite["unaga", _] -> SMILES["CC(=O)N[C@@H]1[C@@H](O)[C@\
H](O)[C@@H](CO)OC1OP(O)(=O)OP(O)(=O)OC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C\
=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(/C)CC\\C=C(/C)\
CCC=C(C)C"], metabolite["g3pi", _] -> 
  SMILES[
   "[H][C@](O)(CO)COP(O)(=O)O[C@H]1[C@H](O)[C@@H](O)[C@H](O)[C@@H](O)[C@H]1O"]\
, metabolite["arbt6p", _] -> 
  SMILES["O[C@H]1[C@H](O)[C@@H](O)[C@@H](O[C@@H]1COP(O)(O)=O)Oc1ccc(O)cc1"], 
 metabolite["indpyr", _] -> SMILES["OC(=O)C(=O)Cc1c[nH]c2ccccc12"], 
 metabolite["pacald", _] -> SMILES["O=CCc1ccccc1"], 
 metabolite["adocbi", _] -> SMILES["[H][C@]12[C@H](CC(N)=O)[C@@](C)(CCC(=O)NC\
[C@@H](C)O)\\C(N1[Co+]C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc3c(N)ncnc13)=C(C)\\\
C1=N\\C(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4CCC(N)=O)[C@@](C\
)(CC(N)=O)[C@@H]3CCC(N)=O)C(C)(C)[C@@H]1CCC(N)=O"], 
 metabolite["5hoxindoa", _] -> SMILES["OC(=O)Cc1c[nH]c2ccc(O)cc12"], 
 metabolite["ditp", _] -> 
  SMILES[
   "O[C@H]1C[C@@H](O[C@@H]1COP(O)(=O)OP(O)(=O)OP(O)(O)=O)n1cnc2c1nc[nH]c2=O"]\
, metabolite["leuktrA4", _] -> 
  SMILES["CCCCC\\C=C/C\\C=C/C=C/C=C/[C@@H]1O[C@H]1CCCC(=O)O"], 
 metabolite["selcys", _] -> SMILES["NC(C[SeH])C(O)=O"], 
 metabolite["sel", _] -> SMILES["[H]O[Se](=O)(=O)O[H]"], 
 metabolite["ach", _] -> SMILES["CC(=O)OCC[N+](C)(C)C"], 
 metabolite["elaid", _] -> SMILES["CCCCCCCC\\C=C\\CCCCCCCC(=O)O"], 
 metabolite["1odecg3p", _] -> SMILES["O[C@H](COC([*])=O)COP(O)(O)=O"], 
 metabolite["ps160", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["pe120", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["pe140", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["clpn140", _] -> SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], metabolite["aprgstrn", _] -> 
  SMILES[
   "C[C@H](O)[C@H]1CC[C@H]2[C@@H]3CCC4=CC(=O)CC[C@]4(C)[C@H]3CC[C@]12C"], 
 metabolite["aprut", _] -> SMILES["CC(=O)NCCCCN"], 
 metabolite["sbt-L", _] -> SMILES["OC[C@H](O)[C@H](O)[C@@H](O)[C@H](O)CO"], 
 metabolite["ppap", _] -> SMILES["CCC(=O)OP(O)(O)=O"], 
 metabolite["cinnm", _] -> SMILES["OC(=O)\\C=C\\c1ccccc1"], 
 metabolite["2dh3dgal", _] -> SMILES["OC[C@@H](O)[C@H](O)CC(=O)C(O)=O"], 
 metabolite["dhptd", _] -> SMILES["CC(=O)C(=O)[C@@H](O)CO"], 
 metabolite["prostgd2", _] -> 
  SMILES[
   "CCCCC[C@H](O)\\C=C\\[C@@H]1[C@@H](C\\C=C/CCCC(=O)O)[C@@H](O)CC1=O"], 
 metabolite["lnlnca", _] -> SMILES["CC\\C=C/C\\C=C/C\\C=C/CCCCCCCC(=O)O"], 
 metabolite["arbtn", _] -> SMILES["CC(=O)N(O)CCCC[C@H](NC(=O)CC(O)(CC(=O)N[C@\
@H](CCCCN(O)C(C)=O)C(O)=O)C(O)=O)C(O)=O"], metabolite["5a2opntn", _] -> 
  SMILES["NCCCC(=O)C([O-])=O"], metabolite["2mp2coa", _] -> 
  SMILES["CC(=C)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(=O)(O)OP(=O)(O)OC[C@\
H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23"], 
 metabolite["mi145p", _] -> SMILES["O[C@@H]1[C@H](O)[C@@H](OP(=O)(O)O)[C@H](O\
P(=O)(O)O)[C@@H](O)[C@@H]1OP(=O)(O)O"], metabolite["clpn120", _] -> 
  SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)COP(O)(=O)OC[C@@H](COC([\
*])=O)OC([*])=O"], metabolite["p-tol", _] -> SMILES["Cc1ccc(cc1)C(=O)O"], 
 metabolite["tagdp-D", _] -> 
  SMILES["O[C@@H]1[C@H](O)C(O)(COP(O)(O)=O)O[C@@H]1COP(O)(O)=O"], 
 metabolite["1Dgali", _] -> SMILES["OC[C@H]1O[C@H](O[C@H]2[C@@H](O)[C@@H](O)[\
C@H](O)[C@@H](O)[C@@H]2O)[C@H](O)[C@@H](O)[C@H]1O"], 
 metabolite["N1sprm", _] -> SMILES["CC(=O)NCCCNCCCCNCCCN"], 
 metabolite["selnp", _] -> SMILES["[O-]P([O-])([O-])=[Se]"], 
 metabolite["adphep-LD", _] -> SMILES["[H][C@@]1(OC(OP(O)(=O)OP(O)(=O)OC[C@H]\
2O[C@H]([C@H](O)[C@@H]2O)n2cnc3c(N)ncnc23)[C@@H](O)[C@@H](O)[C@@H]1O)[C@@H](O\
)CO"], metabolite["clpn_SC", _] -> SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)O\
C([*])=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["hkndd", _] -> SMILES["[H]C(=CC([H])=C(O)C(O)=O)C(=O)CCC(O)=O"], 
 metabolite["hsfd", _] -> 
  SMILES["C[C@@H](OP(O)(O)=O)[C@H](NC(=O)CCCCCCSSCCS(O)(=O)=O)C(O)=O"], 
 metabolite["mi3456p", _] -> SMILES["O[C@@H]1[C@H](O)[C@H](OP(=O)(O)O)[C@@H](\
OP(=O)(O)O)[C@H](OP(=O)(O)O)[C@H]1OP(=O)(O)O"], 
 metabolite["acgpail_hs", _] -> SMILES["[H][C@@](COC([*])=O)(COP(O)(=O)O[C@@H\
]1[C@H](O)[C@H](O)[C@@H](O)[C@H](O)[C@H]1O[C@H]1O[C@H](CO)[C@@H](O)[C@H](O)[C\
@H]1NC(C)=O)OC([*])=O"], metabolite["dcholcoa", _] -> 
  SMILES["[H][C@@](C)(CCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(\
=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@]1([H])CC[C@\
@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C[C@H](O)CC[C@]4(C)[C@@]3([H])CC[C@]12C"]\
, metabolite["bzal", _] -> SMILES["O=Cc1ccccc1"], 
 metabolite["3oacoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([\
C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)CC([\
*])=O"], metabolite["ppt", _] -> SMILES["[O-]P(=O)[O-]"], 
 metabolite["3mox4hoxm", _] -> SMILES["COc1cc(ccc1O)C(O)C(=O)O"], 
 metabolite["coke", _] -> 
  SMILES["COC(=O)[C@H]1[C@H](C[C@@H]2CC[C@H]1N2C)OC(=O)c3ccccc3"], 
 metabolite["retn", _] -> 
  SMILES["C\\C(=C/C=C/C(=C/C(=O)O)/C)\\C=C\\C1=C(C)CCCC1(C)C"], 
 metabolite["dgal6p", _] -> 
  SMILES["OC1O[C@H](COP(=O)(O)O)[C@H](O)[C@H](O)[C@H]1O"], 
 metabolite["n6all26d", _] -> 
  SMILES["CC(=O)N[C@@H](CCC[C@H](N)C([O-])=O)C([O-])=O"], 
 metabolite["homoval", _] -> SMILES["COc1cc(CC(O)=O)ccc1O"], 
 metabolite["cholcoaone", _] -> SMILES["[H][C@@](C)(CCC(=O)C(C)C(=O)SCCNC(=O)\
CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)\
(O)=O)n1cnc2c(N)ncnc12)[C@@]1([H])CC[C@@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C\
[C@H](O)CC[C@]4(C)[C@@]3([H])C[C@H](O)[C@]12C"], 
 metabolite["ggbutal", _] -> SMILES["[H]C(=O)CCCNC(=O)CC[C@H](N)C(O)=O"], 
 metabolite["acnamp", _] -> 
  SMILES[
   "[H][C@]1(OC(O)(C[C@H](O)[C@H]1NC(C)=O)C(O)=O)[C@H](O)[C@H](O)COP(O)(O)=O"]\
, metabolite["retinal", _] -> 
  SMILES["C\\C(=C/C=O)\\C=C\\C=C(/C)\\C=C\\C1=C(C)CCCC1(C)C"], 
 metabolite["12dgr180", _] -> SMILES["OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["mndn", _] -> SMILES["CC1=CC(=O)c2ccccc2C1=O"], 
 metabolite["46dhoxquin", _] -> SMILES["Oc1ccc2nccc(O)c2c1"], 
 metabolite["lthstrl", _] -> SMILES["[H][C@@]12CC=C3[C@]4([H])CC[C@]([H])([C@\
H](C)CCCC(C)C)[C@@]4(C)CC[C@]3([H])[C@@]1(C)CC[C@H](O)C2"], 
 metabolite["2hmc", _] -> SMILES["O\\C(=C/C=C/C([O-])=O)C([O-])=O"], 
 metabolite["4mcat", _] -> SMILES["Cc1ccc(O)c(O)c1"], 
 metabolite["pi", _] -> SMILES["[O-]P(=O)([O-])[O-]"], 
 metabolite["6pgc", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)[C@H](O)[C@@H](O)C(=O)O"], 
 metabolite["lac-D", _] -> SMILES["C[C@@H](O)C(O)=O"], 
 metabolite["udpgal", _] -> SMILES["OC[C@H]1OC(OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@\
H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@H](O)[C@@H](O)[C@H]1O"], 
 metabolite["glyc3p", _] -> SMILES["OCC(O)COP(=O)(O)O"], 
 metabolite["acorn", _] -> SMILES["CC(=O)N[C@@H](CCCN)C(=O)O"], 
 metabolite["cbp", _] -> SMILES["NC(=O)OP(=O)(O)O"], 
 metabolite["acg5p", _] -> SMILES["CC(=O)N[C@@H](CCC(=O)OP(=O)(O)O)C(=O)O"], 
 metabolite["23dhmb", _] -> SMILES["CC(C)(O)[C@@H](O)C(O)=O"], 
 metabolite["2obut", _] -> SMILES["CCC(=O)C(=O)O"], 
 metabolite["2cpr5p", _] -> 
  SMILES["[H][C@@](O)(COP(O)(O)=O)[C@@]([H])(O)C(=O)CNc1ccccc1C(O)=O"], 
 metabolite["so4", _] -> SMILES["[O-]S(=O)(=O)[O-]"], 
 metabolite["10fthf", _] -> SMILES["[H]C(=O)N(C[C@H]1CNc2nc(N)[nH]c(=O)c2N1)c\
1ccc(cc1)C(=O)N[C@@H](CCC(O)=O)C(O)=O"], metabolite["dgsn", _] -> 
  SMILES["NC1=NC(=O)c2ncn([C@H]3C[C@H](O)[C@@H](CO)O3)c2N1"], 
 metabolite["gdp", _] -> 
  SMILES[
   "NC1=Nc2c(ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O)(O)O)[C@@H](O)[C@H]3O)C(=O)N1"]\
, metabolite["for", _] -> SMILES["OC=O"], metabolite["dmlz", _] -> 
  SMILES["CC1=C(C)N(C[C@H](O)[C@H](O)[C@H](O)CO)C2=NC(=O)NC(=O)C2=N1"], 
 metabolite["ahdt", _] -> 
  SMILES[
   "Nc1nc2NCC(=Nc2c(=O)[nH]1)[C@H](O)[C@H](O)COP(O)(=O)OP(O)(=O)OP(O)(O)=O"], 
 metabolite["cala", _] -> SMILES["NC(=O)NCCC(=O)O"], 
 metabolite["dhna", _] -> SMILES["OC(=O)c1cc(O)c2ccccc2c1O"], 
 metabolite["rnam", _] -> 
  SMILES["NC(=O)c1ccc[n+](c1)[C@@H]2O[C@H](CO)[C@@H](O)[C@H]2O"], 
 metabolite["36dahx", _] -> SMILES["NCCC[C@H](N)CC(=O)O"], 
 metabolite["cpppg3", _] -> SMILES["Cc1c(CCC(=O)O)c2Cc3[nH]c(Cc4[nH]c(Cc5[nH]\
c(Cc1[nH]2)c(C)c5CCC(=O)O)c(CCC(=O)O)c4C)c(CCC(=O)O)c3C"], 
 metabolite["3ohcoa", _] -> SMILES["CCCC(=O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(\
C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)nc\
nc12"], metabolite["gln-L", _] -> SMILES["N[C@@H](CCC(=O)N)C(=O)O"], 
 metabolite["uaagmda", _] -> SMILES["C[C@@H](NC(=O)[C@@H](C)NC(=O)[C@H](CCC[C\
@@H](N)C(O)=O)NC(=O)CC[C@@H](NC(=O)[C@H](C)NC(=O)[C@@H](C)O[C@@H]1[C@@H](NC(C\
)=O)[C@H](O[C@H](CO)[C@H]1O[C@H]1O[C@H](CO)[C@@H](O)[C@H](O)[C@H]1NC(C)=O)OP(\
O)(=O)OP(O)(=O)OC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\
\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(/C)CC\\C=C(/C)CCC=C(C)C)C(O)=O)C(O)\
=O"], metabolite["uaccg", _] -> SMILES["CC(=O)N[C@H]1C(O[C@H](CO)[C@@H](O)[C@\
@H]1OC(=C)C(O)=O)OP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1ccc(=O)[\
nH]c1=O"], metabolite["gcald", _] -> SMILES["[H]C(=O)CO"], 
 metabolite["adp", _] -> 
  SMILES[
   "Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O)(O)O)[C@@H](O)[C@H]3O"], 
 metabolite["4pasp", _] -> SMILES["N[C@@H](CC(=O)OP(=O)(O)O)C(=O)O"], 
 metabolite["amob", _] -> 
  SMILES["C[S+](CCC(=O)C(O)=O)C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc2c(N)ncnc12\
"], metabolite["pdx5p", _] -> SMILES["Cc1ncc(COP(=O)(O)O)c(CO)c1O"], 
 metabolite["btn", _] -> SMILES["OC(=O)CCCC[C@@H]1SC[C@@H]2NC(=O)N[C@H]12"], 
 metabolite["g6p-B", _] -> 
  SMILES["O[C@@H]1O[C@H](COP(=O)(O)O)[C@@H](O)[C@H](O)[C@H]1O"], 
 metabolite["3oddcoa", _] -> SMILES["CCCCCCCCCC(=O)CC(=O)SCCNC(=O)CCNC(=O)[C@\
H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc\
2c(N)ncnc12"], metabolite["Ssq23epx", _] -> 
  SMILES[
   "CC(C)=CCC\\C(C)=C\\CC\\C(C)=C\\CC\\C=C(/C)CC\\C=C(/C)CC[C@@H]1OC1(C)C"], 
 metabolite["35ccmp", _] -> 
  SMILES["NC1=NC(=O)N(C=C1)[C@@H]2O[C@@H]3COP(=O)(O)O[C@H]3[C@H]2O"], 
 metabolite["acac", _] -> SMILES["CC(=O)CC([O-])=O"], 
 metabolite["malttr", _] -> SMILES["OC[C@H]1O[C@H](O[C@H]2[C@H](O)[C@@H](O)[C\
@@H](O[C@H]3[C@H](O)[C@@H](O)[C@@H](O)O[C@@H]3CO)O[C@@H]2CO)[C@H](O)[C@@H](O)\
[C@@H]1O"], metabolite["aconm", _] -> 
  SMILES["COC(=O)C(\\CC(O)=O)=C\\C(O)=O"], metabolite["rdmbzi", _] -> 
  SMILES["Cc1cc2ncn([C@H]3O[C@H](CO)[C@@H](O)[C@H]3O)c2cc1C"], 
 metabolite["acmanap", _] -> 
  SMILES[
   "[H][C@@](O)(COP(O)(O)=O)[C@@]([H])(O)[C@]([H])(O)[C@]([H])(NC(C)=O)C=O"], 
 metabolite["but", _] -> SMILES["CCCC(O)=O"], metabolite["palmACP", _] -> 
  SMILES["CCCCCCCCCCCCCCCC(=O)S[*]"], metabolite["uama", _] -> 
  SMILES["C[C@H](NC(=O)[C@@H](C)O[C@H]1[C@H](O)[C@@H](CO)OC(OP(O)(=O)OP(O)(=O\
)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@@H]1NC(C)=O)C(O)=O"], 
 metabolite["dca", _] -> SMILES["CCCCCCCCCC(=O)O"], 
 metabolite["glyb", _] -> SMILES["C[N+](C)(C)CC(=O)[O-]"], 
 metabolite["im4ac", _] -> SMILES["OC(=O)Cc1c[nH]cn1"], 
 metabolite["prgstrn", _] -> 
  SMILES["CC(=O)[C@H]1CC[C@H]2[C@@H]3CCC4=CC(=O)CC[C@]4(C)[C@H]3CC[C@]12C"], 
 metabolite["ibcoa", _] -> SMILES["CC(C)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)\
COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23"]\
, metabolite["cholp", _] -> SMILES["C[N+](C)(C)CCOP(=O)(O)O"], 
 metabolite["metsox-R-L", _] -> SMILES["C[S@@](=O)CC[C@H](N)C(=O)O"], 
 metabolite["dheas", _] -> 
  SMILES[
   "C[C@]12CC[C@H]3[C@@H](CC=C4C[C@H](CC[C@]34C)OS(=O)(=O)O)[C@@H]1CCC2=O"], 
 metabolite["udpLa4o", _] -> SMILES["O[C@@H]1[C@@H](COP(O)(=O)OP(O)(=O)O[C@H]\
2OCC(=O)[C@H](O)[C@H]2O)O[C@H]([C@@H]1O)n1ccc(=O)[nH]c1=O"], 
 metabolite["aso3", _] -> SMILES["[O-][As]([O-])[O-]"], 
 metabolite["3snpyr", _] -> SMILES["OC(=O)C(=O)CS(O)=O"], 
 metabolite["3opalmACP", _] -> SMILES["CCCCCCCCCCCCCC(=O)CC(=O)S[*]"], 
 metabolite["pgp140", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["bilglcur", _] -> SMILES["CC1=C(C=C)\\C(NC1=O)=C/c1[nH]c(Cc2[nH]c\
(\\C=C3NC(=O)C(C=C)=C\\3C)c(C)c2CCC(O)=O)c(CCC(=O)O[C@@H]2O[C@@H]([C@@H](O)[C\
@H](O)[C@H]2O)C(O)=O)c1C"], metabolite["ppa", _] -> SMILES["CCC(=O)O"], 
 metabolite["34dhbz", _] -> SMILES["OC(=O)c1ccc(O)c(O)c1"], 
 metabolite["amet", _] -> 
  SMILES[
   "C[S+](CC[C@H](N)C(=O)O)C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n2cnc3c(N)ncnc23"], 
 metabolite["2ippm", _] -> SMILES["CC(C)C(\\C(O)=O)=C\\C(O)=O"], 
 metabolite["histd", _] -> SMILES["N[C@H](CO)Cc1c[nH]cn1"], 
 metabolite["acser", _] -> SMILES["CC(=O)OC[C@H](N)C(=O)O"], 
 metabolite["56dura", _] -> SMILES["O=C1CCNC(=O)N1"], 
 metabolite["2p4c2me", _] -> SMILES["C[C@@](CO)(OP(=O)(O)O)[C@H](O)COP(=O)(O)\
OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)N2C=CC(=NC2=O)N"], 
 metabolite["altrn", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@@H](O)[C@H](O)C([O-])=O"], 
 metabolite["actACP", _] -> SMILES["CC(=O)CC(=O)S[*]"], 
 metabolite["lald-L", _] -> SMILES["[H]C(=O)[C@H](C)O"], 
 metabolite["12ppd-S", _] -> SMILES["C[C@H](O)CO"], 
 metabolite["hdcoa", _] -> SMILES["CCCCCCCCCCCCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)\
[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1\
cnc2c(N)ncnc12"], metabolite["udpglcur", _] -> SMILES["O[C@@H]1[C@@H](O)[C@@H\
](OP(=O)(O)OP(=O)(O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)N3C=CC(=O)NC3=O)O[C@@H]([\
C@H]1O)C(=O)O"], metabolite["dms", _] -> SMILES["CSC"], 
 metabolite["urdglyc", _] -> SMILES["NC(=O)N[C@@H](O)C(O)=O"], 
 metabolite["fpram", _] -> 
  SMILES["O[C@H]1[C@@H](O)C(NC(=N)CNC=O)O[C@@H]1COP(O)(O)=O"], 
 metabolite["4adcho", _] -> 
  SMILES["N[C@@H]1C=CC(=C[C@H]1OC(=C)C(O)=O)C(O)=O"], 
 metabolite["cd2", _] -> SMILES["[Cd+2]"], metabolite["enter", _] -> 
  SMILES["Oc1cccc(C(=O)N[C@H]2COC(=O)[C@H](COC(=O)[C@H](COC2=O)NC(=O)c3cccc(O\
)c3O)NC(=O)c4cccc(O)c4O)c1O"], metabolite["codhpre6", _] -> 
  SMILES["[H][C@]12[C@H](CC(O)=O)[C@@](C)(CCC(O)=O)C3=[N]1[Co+]14N5C(=CC6=[N]\
1C(C[C@@]1(C)C(CC(O)=O)=C(CCC(O)=O)C(C3)=[N]41)=C(CCC(O)=O)[C@]6(C)CC(O)=O)[C\
@@H](CCC(O)=O)[C@](C)(CC(O)=O)[C@]25C"], metabolite["cholcoa", _] -> 
  SMILES["[H][C@@](C)(CCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(\
=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@]1([H])CC[C@\
@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C[C@H](O)CC[C@]4(C)[C@@]3([H])C[C@H](O)[\
C@]12C"], metabolite["dimp", _] -> 
  SMILES["O[C@H]1C[C@@H](O[C@@H]1COP(=O)(O)O)n2cnc3C(=O)NC=Nc23"], 
 metabolite["fruur", _] -> SMILES["OCC1(O)O[C@@H]([C@@H](O)[C@@H]1O)C(O)=O"], 
 metabolite["guln", _] -> 
  SMILES["OC[C@H](O)[C@@H](O)[C@H](O)[C@H](O)C([O-])=O"], 
 metabolite["pylald", _] -> SMILES["CC(=C)C1CCC(=CC1)C=O"], 
 metabolite["gpail_hs", _] -> SMILES["[H][C@@](COC([*])=O)(COP(O)(=O)O[C@@H]1\
[C@H](O)[C@H](O)[C@@H](O)[C@H](O)[C@H]1O[C@H]1O[C@H](CO)[C@@H](O)[C@H](O)[C@H\
]1N)OC([*])=O"], metabolite["tchola", _] -> SMILES["C[C@H](CCC(=O)NCCS(=O)(=O\
)O)[C@H]1CC[C@H]2[C@@H]3[C@H](O)C[C@@H]4C[C@H](O)CC[C@]4(C)[C@H]3C[C@H](O)[C@\
]12C"], metabolite["andrstrn", _] -> 
  SMILES[
   "C[C@]12CC[C@@H](O)C[C@@H]1CC[C@@H]3[C@@H]2CC[C@@]4(C)[C@H]3CCC4=O"], 
 metabolite["2mcit", _] -> 
  SMILES["C[C@H](C([O-])=O)[C@](O)(CC([O-])=O)C([O-])=O"], 
 metabolite["CCbuttc", _] -> SMILES["OC(=O)\\C=C/C(=C\\C(O)=O)C(O)=O"], 
 metabolite["4mbzalc", _] -> SMILES["Cc1ccc(CO)cc1"], 
 metabolite["pep", _] -> SMILES["OP(O)(=O)OC(=C)C([O-])=O"], 
 metabolite["nh4oh", _] -> SMILES["[NH4+].[OH-]"], 
 metabolite["quln", _] -> SMILES["OC(=O)c1cccnc1C(=O)O"], 
 metabolite["3htdcoa", _] -> SMILES["CCCCCCCCCCC[C@H](O)CC(=O)SCCNC(=O)CCNC(=\
O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)\
n1cnc2c(N)ncnc12"], metabolite["gam", _] -> 
  SMILES["N[C@H]1C(O)O[C@H](CO)[C@@H](O)[C@@H]1O"], 
 metabolite["e4hglu", _] -> 
  SMILES["[NH3+][C@@H](C[C@@H](O)C([O-])=O)C([O-])=O"], 
 metabolite["pydam", _] -> SMILES["Cc1ncc(CO)c(CN)c1O"], 
 metabolite["fecost", _] -> SMILES["[H][C@@]12CCC3=C(CC[C@]4(C)[C@]([H])(CC[C\
@@]34[H])[C@H](C)CCC(=C)C(C)C)[C@@]1(C)CC[C@H](O)C2"], 
 metabolite["tartr-L", _] -> SMILES["O[C@H]([C@@H](O)C(=O)O)C(=O)O"], 
 metabolite["dtdp4d6dm", _] -> SMILES["C[C@@H]1OC(OP(O)(=O)OP(O)(=O)OC[C@H]2O\
[C@H](C[C@@H]2O)n2cc(C)c(=O)[nH]c2=O)[C@H](O)[C@H](O)C1=O"], 
 metabolite["uacmamu", _] -> SMILES["CC(=O)N[C@H]1[C@@H](O)[C@H](O)[C@H](O[C@\
@H]1OP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1ccc(=O)[nH]c1=O)C(O)=\
O"], metabolite["hLkynr", _] -> SMILES["N[C@@H](CC(=O)c1cccc(O)c1N)C(O)=O"], 
 metabolite["idon-L", _] -> 
  SMILES["OC[C@H](O)[C@@H](O)[C@H](O)[C@@H](O)C([O-])=O"], 
 metabolite["itacon", _] -> SMILES["OC(=O)CC(=C)C(=O)O"], 
 metabolite["ind3acnl", _] -> SMILES["N#CCc1c[nH]c2ccccc12"], 
 metabolite["com", _] -> SMILES["OS(=O)(=O)CCS"], 
 metabolite["ptp", _] -> SMILES["Nc1nc(N[C@@H]2O[C@H](COP(O)(=O)OP(O)(=O)OP(O\
)(O)=O)[C@@H](O)[C@H]2O)c(N)c(=O)[nH]1"], metabolite["cob", _] -> 
  SMILES["C[C@@H](OP(O)(O)=O)[C@H](NC(=O)CCCCCCS)C(O)=O"], 
 metabolite["acmum", _] -> 
  SMILES["C[C@@H](O[C@H]1[C@H](O)[C@@H](CO)OC(O)[C@@H]1NC(C)=O)C(O)=O"], 
 metabolite["mi134p", _] -> SMILES["O[C@@H]1[C@@H](O)[C@H](OP(=O)(O)O)[C@@H](\
OP(=O)(O)O)[C@@H](O)[C@H]1OP(=O)(O)O"], metabolite["4pyrdx", _] -> 
  SMILES["Cc1ncc(CO)c(C(O)=O)c1O"], metabolite["pg180", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["ps181", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["2me4p", _] -> SMILES["C[C@](O)(CO)[C@H](O)COP(O)(O)=O"], 
 metabolite["sucgsa", _] -> SMILES["[H]C(=O)CC[C@H](NC(=O)CCC(O)=O)C(O)=O"], 
 metabolite["3dhguln", _] -> 
  SMILES["OC[C@H](O)[C@@H](O)C(=O)[C@H](O)C(O)=O"], 
 metabolite["3pop", _] -> SMILES["OC(=O)C(=O)CP(=O)(O)O"], 
 metabolite["hspmd", _] -> SMILES["NCCCCNCCCCN"], 
 metabolite["4nph", _] -> SMILES["Oc1ccc(cc1)[N+](=O)[O-]"], 
 metabolite["i", _] -> SMILES["[I-]"], metabolite["acetone", _] -> 
  SMILES["CC(=O)C"], metabolite["thcholoylcoa", _] -> 
  SMILES["[H][C@@](C)(CCC(O)C(C)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=\
O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@]1([\
H])CC[C@@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C[C@H](O)CC[C@]4(C)[C@@]3([H])CC\
[C@]12C"], metabolite["dhocholoylcoa", _] -> SMILES["[H][C@@]12C[C@H](O)CC[C@\
]1(C)[C@@]1([H])C[C@H](O)[C@]3(C)[C@]([H])(CC[C@@]3([H])[C@]1([H])[C@H](O)C2)\
[C@H](C)CCCC(C)CO"], metabolite["ag", _] -> SMILES["[Ag]"], 
 metabolite["12dgr160", _] -> SMILES["OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["clpn160", _] -> SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["salc", _] -> SMILES["OC(=O)c1ccccc1O"], 
 metabolite["ferulcoa", _] -> SMILES["COc1cc(\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@\
H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2OP(O)(O)=O)n2cnc\
3c(N)ncnc23)ccc1O"], metabolite["caffcoa", _] -> 
  SMILES["[H]C(=CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C\
@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)c1ccc(O)c(O)c1"], 
 metabolite["dd2coa", _] -> SMILES["CCCCCCCCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@\
H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc\
2c(N)ncnc12"], metabolite["1agly3p_SC", _] -> 
  SMILES["OP(O)(=O)OCC(=O)COC([*])=O"], metabolite["myrsACP", _] -> 
  SMILES["CCCCCCCCCCCCCC(=O)S[*]"], metabolite["oxur", _] -> 
  SMILES["NC(=O)NC(=O)C(O)=O"], metabolite["pg_EC", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["f420-2", _] -> SMILES["C[C@H](OP(=O)(O)OC[C@@H](O)[C@@H](O)[C@@H\
](O)CN1C2=NC(=O)NC(=O)C2=Cc3ccc(O)cc13)C(=O)N[C@@H](CCC(=O)N[C@@H](CCC(=O)O)C\
(=O)O)C(=O)O"], metabolite["copre4", _] -> SMILES["CC1OC(=O)C[C@@]2(C)[C@H](C\
CC(O)=O)\\C3=C\\C4=N\\C(=C/c5c(CC(O)=O)c(CCC(O)=O)c6CC7=NC(=C(CC(O)=O)[C@@]7(\
C)CCC(O)=O)C12N3[Co]n56)[C@@H](CCC(O)=O)[C@]4(C)CC(O)=O"], 
 metabolite["4hphac", _] -> SMILES["OC(=O)Cc1ccc(O)cc1"], 
 metabolite["frulysp", _] -> 
  SMILES["N[C@@H](CCCCNCC(=O)[C@@H](O)[C@H](O)[C@H](O)COP(O)(O)=O)C(O)=O"], 
 metabolite["1mpyr", _] -> SMILES["C[N+]1=CCCC1"], 
 metabolite["pg160", _] -> 
  SMILES["OCC(O)COP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["chols", _] -> SMILES["C[N+](C)(C)CCOS([O-])(=O)=O"], 
 metabolite["galt1p", _] -> 
  SMILES["OC[C@@H](O)[C@H](O)[C@H](O)[C@@H](O)COP(O)(O)=O"], 
 metabolite["ch4", _] -> SMILES["C"], metabolite["pgp181", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["gdbtal", _] -> SMILES["NC(=N)NCCCC=O"], 
 metabolite["2hmcnsad", _] -> SMILES["[H]C(=O)\\C=C\\C=C(/O)C(O)=O"], 
 metabolite["vanln", _] -> SMILES["COc1cc(C=O)ccc1O"], 
 metabolite["pser-D", _] -> SMILES["N[C@H](COP(=O)(O)O)C(=O)O"], 
 metabolite["2h3oppan", _] -> SMILES["[H]C(=O)C(O)C(O)=O"], 
 metabolite["caphis", _] -> 
  SMILES["NC(CCc1ncc(C[C@H](N)C(O)=O)[nH]1)C(O)=O"], 
 metabolite["manglyc", _] -> 
  SMILES["OC[C@H]1O[C@H](O[C@H](CO)C(O)=O)[C@@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["3hibutcoa", _] -> SMILES["C[C@@H](CO)C(=O)SCCNC(=O)CCNC(=O)[C@H]\
(O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c\
(N)ncnc12"], metabolite["5g2oxpt", _] -> SMILES["NC(=N)NCCCC(=O)C(O)=O"], 
 metabolite["udpLa4fn", _] -> SMILES["[H]C(=O)N[C@H]1CO[C@H](OP(O)(=O)OP(O)(=\
O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@H](O)[C@H]1O"], 
 metabolite["4mptnl", _] -> SMILES["CC(C)CCC=O"], 
 metabolite["adhlam", _] -> SMILES["CC(=O)SC(CCS)CCCCC(N)=O"], 
 metabolite["s7p", _] -> 
  SMILES["OCC(=O)[C@@H](O)[C@H](O)[C@H](O)[C@H](O)COP(=O)(O)O"], 
 metabolite["oaa", _] -> SMILES["OC(=O)CC(=O)C(O)=O"], 
 metabolite["xylu-D", _] -> SMILES["OC[C@@H](O)[C@H](O)C(=O)CO"], 
 metabolite["glu-L", _] -> SMILES["N[C@@H](CCC(=O)O)C(=O)O"], 
 metabolite["fum", _] -> SMILES["OC(=O)\\C=C\\C(=O)O"], 
 metabolite["hom-L", _] -> SMILES["N[C@@H](CCO)C(=O)O"], 
 metabolite["4izp", _] -> SMILES["OC(=O)CCC1NC=NC1=O"], 
 metabolite["fprica", _] -> 
  SMILES["NC(=O)c1ncn([C@@H]2O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]2O)c1NC=O"], 
 metabolite["orot5p", _] -> 
  SMILES[
   "O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)O)N2C(=O)NC(=O)C=C2C(=O)O"], 
 metabolite["orot", _] -> SMILES["OC(=O)C1=CC(=O)NC(=O)N1"], 
 metabolite["gsn", _] -> 
  SMILES["Nc1nc2n(cnc2c(=O)[nH]1)[C@@H]1O[C@H](CO)[C@@H](O)[C@H]1O"], 
 metabolite["ade", _] -> SMILES["Nc1ncnc2[nH]cnc12"], 
 metabolite["damp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@H]3C[C@H](O)[C@@H](COP(=O)(O)O)O3"], 
 metabolite["dtdp", _] -> 
  SMILES["CC1=CN([C@H]2C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)O)O2)C(=O)NC1=O"], 
 metabolite["datp", _] -> 
  SMILES[
   "Nc1ncnc2c1ncn2[C@H]3C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O3"], 
 metabolite["gua", _] -> SMILES["NC1=Nc2[nH]cnc2C(=O)N1"], 
 metabolite["xan", _] -> SMILES["O=C1NC(=O)c2nc[nH]c2N1"], 
 metabolite["mlthf", _] -> 
  SMILES[
   "NC1=NC(=O)C2=C(NC[C@@H]3CN(CN23)c4ccc(cc4)C(=O)N[C@@H](CCC(=O)O)C(=O)O)N1\
"], metabolite["fmn", _] -> 
  SMILES[
   "Cc1cc2N=C3C(=O)NC(=O)N=C3N(C[C@H](O)[C@H](O)[C@H](O)COP(=O)(O)O)c2cc1C"], 
 metabolite["4r5au", _] -> 
  SMILES["Nc1c(NC[C@H](O)[C@H](O)[C@H](O)CO)[nH]c(=O)[nH]c1=O"], 
 metabolite["pime", _] -> SMILES["OC(=O)CCCCCC(=O)O"], 
 metabolite["thmmp", _] -> 
  SMILES["Cc1ncc(C[n+]2csc(CCOP(=O)(O)O)c2C)c(N)n1"], 
 metabolite["pant-R", _] -> SMILES["CC(C)(CO)C(O)C(O)=O"], 
 metabolite["4ppcys", _] -> 
  SMILES["CC(C)(COP(O)(O)=O)[C@@H](O)C(=O)NCCC(=O)N[C@@H](CS)C(O)=O"], 
 metabolite["dnad", _] -> SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O\
)(O)OC[C@H]4O[C@H]([C@H](O)[C@@H]4O)[n+]5cccc(c5)C(=O)O)[C@@H](O)[C@H]3O"], 
 metabolite["fadh2", _] -> SMILES["Cc1cc2NC3=C(NC(=O)NC3=O)N(C[C@H](O)[C@H](O\
)[C@H](O)COP(=O)(O)OP(=O)(O)OC[C@H]4O[C@H]([C@H](O)[C@@H]4O)n5cnc6c(N)ncnc56)\
c2cc1C"], metabolite["alltn", _] -> SMILES["NC(=O)NC1NC(=O)NC1=O"], 
 metabolite["gdptp", _] -> SMILES["Nc1nc2n(cnc2c(=O)[nH]1)[C@@H]1O[C@H](COP(O\
)(=O)OP(O)(=O)OP(O)(O)=O)[C@@H](OP(O)(=O)OP(O)(O)=O)[C@H]1O"], 
 metabolite["hmbil", _] -> SMILES["OCc1[nH]c(Cc2[nH]c(Cc3[nH]c(Cc4[nH]cc(CCC(\
=O)O)c4CC(=O)O)c(CCC(=O)O)c3CC(=O)O)c(CCC(=O)O)c2CC(=O)O)c(CCC(=O)O)c1CC(=O)O\
"], metabolite["3ohdcoa", _] -> SMILES["CCCCCCCCCCCCCC(=O)CC(=O)SCCNC(=O)CCNC\
(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=\
O)n1cnc2c(N)ncnc12"], metabolite["rib-D", _] -> 
  SMILES["OC[C@H]1OC(O)[C@H](O)[C@@H]1O"], metabolite["crn", _] -> 
  SMILES["C[N+](C)(C)C[C@H](O)CC(=O)[O-]"], metabolite["zn2", _] -> 
  SMILES["[Zn+2]"], metabolite["4hbz", _] -> SMILES["OC(=O)c1ccc(O)cc1"], 
 metabolite["acmana", _] -> 
  SMILES["CC(=O)N[C@@H](C=O)[C@H](O)[C@@H](O)[C@@H](O)CO"], 
 metabolite["tag6p-D", _] -> 
  SMILES["OCC1(O)O[C@H](COP(O)(O)=O)[C@H](O)[C@@H]1O"], 
 metabolite["melib", _] -> SMILES["OC[C@H]1O[C@H](OC[C@H]2OC(O)[C@H](O)[C@@H]\
(O)[C@@H]2O)[C@H](O)[C@@H](O)[C@H]1O"], metabolite["34hpp", _] -> 
  SMILES["OC(=O)C(=O)Cc1ccc(O)cc1"], metabolite["oxag", _] -> 
  SMILES["OC(=O)CCC(C(O)=O)C(=O)C(O)=O"], metabolite["nac", _] -> 
  SMILES["OC(=O)c1cccnc1"], metabolite["pppg9", _] -> 
  SMILES["Cc1c2Cc3[nH]c(Cc4[nH]c(Cc5[nH]c(Cc([nH]2)c1CCC(O)=O)c(CCC(O)=O)c5C)\
c(C=C)c4C)c(C=C)c3C"], metabolite["dtbt", _] -> 
  SMILES["CC1NC(=O)NC1CCCCCC(O)=O"], metabolite["4h2oglt", _] -> 
  SMILES["OC(CC(=O)C(O)=O)C(O)=O"], metabolite["2ahhmp", _] -> 
  SMILES["NC1=NC2=C(N=C(CO)CN2)C(=O)N1"], metabolite["3hddcoa", _] -> 
  SMILES["CCCCCCCCC[C@H](O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP\
(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["hdca", _] -> SMILES["CCCCCCCCCCCCCCCC(O)=O"], 
 metabolite["15dap", _] -> SMILES["NCCCCCN"], metabolite["dtdpglu", _] -> 
  SMILES["CC1=CN([C@H]2C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)O[C@H]3O[C@H](CO)[C\
@@H](O)[C@H](O)[C@H]3O)O2)C(=O)NC1=O"], metabolite["gp4g", _] -> 
  SMILES["NC1=Nc2c(ncn2[C@H]3O[C@H](COP(=O)(O)OP(=O)(O)OP(=O)(O)OP(=O)(O)OC[C\
@H]4O[C@@H]([C@@H](O)[C@H]4O)n5cnc6C(=O)NC(=Nc56)N)[C@H](O)[C@@H]3O)C(=O)N1"]\
, metabolite["mi1p-D", _] -> 
  SMILES["O[C@H]1[C@H](O)[C@@H](O)[C@H](OP(O)(O)=O)[C@H](O)[C@@H]1O"], 
 metabolite["4mlacac", _] -> SMILES["OC(=O)CC(=O)CC(=O)\\C=C/C(O)=O"], 
 metabolite["betald", _] -> SMILES["C[N+](C)(C)CC=O"], 
 metabolite["cbl1", _] -> SMILES["[H][C@]12[C@H](CC(N)=O)[C@@](C)(CCC(=O)NC[C\
@@H](C)OP(O)(=O)O[C@@H]3[C@@H](CO)O[C@@H]([C@@H]3O)n3c[nH]c4cc(C)c(C)cc34)\\C\
(N1[Co])=C(C)\\C1=N\\C(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4C\
CC(N)=O)[C@@](C)(CC(N)=O)[C@@H]3CCC(N)=O)C(C)(C)[C@@H]1CCC(N)=O"], 
 metabolite["pppn", _] -> SMILES["OC(=O)CCc1ccccc1"], 
 metabolite["mmet", _] -> SMILES["C[S+](C)CC[C@H](N)C(=O)O"], 
 metabolite["ddcaACP", _] -> SMILES["CCCCCCCCCCCC(=O)S[*]"], 
 metabolite["ocdcea", _] -> SMILES["CCCCCCCC\\C=C/CCCCCCCC(O)=O"], 
 metabolite["glucys", _] -> 
  SMILES["N[C@@H](CCC(=O)N[C@@H](CS)C(=O)O)C(=O)O"], 
 metabolite["citr-L", _] -> SMILES["N[C@@H](CCCNC(=O)N)C(=O)O"], 
 metabolite["pre8", _] -> SMILES["[H][C@]12N=C(C(C)C3=N[C@@](C)(CC4=N\\C(=C(C\
)/C5=N[C@]1(C)[C@@](C)(CC(O)=O)[C@@H]5CCC(O)=O)[C@@](C)(CC(O)=O)[C@@H]4CCC(O)\
=O)C(C)=C3CCC(O)=O)[C@](C)(CCC(O)=O)[C@H]2CC(O)=O"], 
 metabolite["succoa", _] -> SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([\
C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)CCC(\
=O)O"], metabolite["mma", _] -> SMILES["CN"], 
 metabolite["6pthp", _] -> SMILES["CC(=O)C(=O)C1CNc2nc(N)[nH]c(=O)c2N1"], 
 metabolite["udpacgal", _] -> SMILES["CC(=O)N[C@@H]1[C@@H](O)[C@@H](O)[C@@H](\
CO)OC1OP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1ccc(=O)[nH]c1=O"], 
 metabolite["malt", _] -> SMILES["OC[C@H]1O[C@H](O[C@@H]2[C@@H](CO)OC(O)[C@H]\
(O)[C@H]2O)[C@H](O)[C@@H](O)[C@@H]1O"], metabolite["xoltri27", _] -> 
  SMILES["[H][C@@]1(CC[C@@]2([H])[C@]3([H])[C@H](O)C=C4C[C@@H](O)CC[C@]4(C)[C\
@@]3([H])CC[C@]12C)[C@H](C)CCCC(C)CO"], metabolite["48dhoxquin", _] -> 
  SMILES["Oc1ccnc2c(O)cccc12"], metabolite["adprib", _] -> 
  SMILES["Nc1ncnc2n(cnc12)[C@@H]1O[C@H](COP(O)(=O)OP(O)(=O)OC[C@H]2OC(O)[C@H]\
(O)[C@@H]2O)[C@@H](O)[C@H]1O"], metabolite["prgnlone", _] -> 
  SMILES["CC(=O)[C@H]1CC[C@H]2[C@@H]3CC=C4C[C@@H](O)CC[C@]4(C)[C@H]3CC[C@]12C\
"], metabolite["selmeth", _] -> SMILES["C[Se]CCC(N)C(=O)O"], 
 metabolite["acgal", _] -> 
  SMILES["CC(=O)N[C@H]1C(O)O[C@H](CO)[C@H](O)[C@@H]1O"], 
 metabolite["lnlc", _] -> SMILES["CCCCC\\C=C/C\\C=C/CCCCCCCC(=O)O"], 
 metabolite["cmp", _] -> 
  SMILES["NC1=NC(=O)N(C=C1)[C@@H]2O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]2O"], 
 metabolite["dtmp", _] -> 
  SMILES["CC1=CN([C@H]2C[C@H](O)[C@@H](COP(=O)(O)O)O2)C(=O)NC1=O"], 
 metabolite["3sala", _] -> SMILES["N[C@@H](CS(=O)O)C(=O)O"], 
 metabolite["cdpdodecg", _] -> SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=\
O)OC[C@@H](COC([*])=O)OC([*])=O)[C@@H](O)[C@H]2O)c(=O)n1"], 
 metabolite["1ddecg3p", _] -> SMILES["O[C@H](COC([*])=O)COP(O)(O)=O"], 
 metabolite["pgp180", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["5adtststerone", _] -> 
  SMILES["C[C@]12CC[C@H]3[C@@H](CC[C@H]4CC(=O)CC[C@]34C)[C@@H]1CC[C@@H]2O"], 
 metabolite["thp2c", _] -> SMILES["[H][C@]1(CCCC=N1)C(O)=O"], 
 metabolite["fer", _] -> SMILES["COc1cc(\\C=C\\C(=O)O)ccc1O"], 
 metabolite["4hbald", _] -> SMILES["Oc1ccc(C=O)cc1"], 
 metabolite["g3p", _] -> SMILES["O[C@H](COP(=O)(O)O)C=O"], 
 metabolite["adpglc", _] -> SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OP(\
=O)(O)O[C@H]4O[C@H](CO)[C@@H](O)[C@H](O)[C@H]4O)[C@@H](O)[C@H]3O"], 
 metabolite["nadp", _] -> SMILES["NC(=O)c1ccc[n+](c1)[C@@H]1O[C@H](COP(O)(=O)\
OP(O)(=O)OC[C@H]2O[C@H]([C@H](OP(O)(O)=O)[C@@H]2O)n2cnc3c(N)ncnc23)[C@@H](O)[\
C@H]1O"], metabolite["acg5sa", _] -> SMILES["CC(=O)N[C@@H](CCC=O)C(O)=O"], 
 metabolite["2ahbut", _] -> SMILES["CC[C@](O)(C(C)=O)C(O)=O"], 
 metabolite["phe-L", _] -> SMILES["N[C@@H](Cc1ccccc1)C(=O)O"], 
 metabolite["thym", _] -> SMILES["CC1=CNC(=O)NC1=O"], 
 metabolite["ipdp", _] -> SMILES["CC(=C)CCOP(=O)(O)OP(=O)(O)O"], 
 metabolite["hepdp", _] -> SMILES["CC(C)=CCC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\
\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\COP(O)(=O)OP(O)(O)=O"], 
 metabolite["5apru", _] -> 
  SMILES[
   "Nc1c(N[C@@H]2O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]2O)[nH]c(=O)[nH]c1=O"], 
 metabolite["4mpetz", _] -> SMILES["Cc1ncsc1CCOP(=O)(O)O"], 
 metabolite["oc2coa", _] -> SMILES["CCCCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@H](O\
)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N\
)ncnc12"], metabolite["salc6p", _] -> 
  SMILES["OCc1ccccc1O[C@@H]1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H](O)[C@H]1O"], 
 metabolite["tre6p", _] -> SMILES["OC[C@H]1O[C@H](O[C@H]2O[C@H](COP(O)(O)=O)[\
C@@H](O)[C@H](O)[C@H]2O)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["23dhmp", _] -> SMILES["CC[C@@](C)(O)[C@@H](O)C(=O)O"], 
 metabolite["prlp", _] -> SMILES["NC(=O)c1ncn([C@@H]2O[C@H](COP(=O)(O)O)[C@@H\
](O)[C@H]2O)c1N\\C=N/CC(=O)[C@H](O)[C@H](O)COP(=O)(O)O"], 
 metabolite["alltt", _] -> SMILES["NC(=O)NC(NC(N)=O)C(O)=O"], 
 metabolite["4hpro-LT", _] -> SMILES["O[C@H]1CN[C@@H](C1)C(=O)O"], 
 metabolite["td2coa", _] -> SMILES["CCCCCCCCCCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[\
C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1c\
nc2c(N)ncnc12"], metabolite["dhcinnm", _] -> 
  SMILES["OC(=O)\\C=C\\c1cccc(O)c1O"], metabolite["23doguln", _] -> 
  SMILES["OC[C@H](O)[C@@H](O)C(=O)C(=O)C(O)=O"], 
 metabolite["ap5a", _] -> SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O\
)(O)OP(=O)(O)OP(=O)(O)OP(=O)(O)OC[C@H]4O[C@H]([C@H](O)[C@@H]4O)n5cnc6c(N)ncnc\
56)[C@@H](O)[C@H]3O"], metabolite["cyan", _] -> SMILES["C#N"], 
 metabolite["thfglu", _] -> SMILES["Nc1nc2NCC(CNc3ccc(cc3)C(=O)N[C@@H](CCC(=O\
)N[C@@H](CCC(O)=O)C(O)=O)C(O)=O)Nc2c(=O)[nH]1"], 
 metabolite["iasp", _] -> SMILES["OC(=O)CC(=N)C(O)=O"], 
 metabolite["3mbdhl", _] -> SMILES["CC(C)CC(=O)SCCC(S)CCCCC(N)=O"], 
 metabolite["copre5", _] -> SMILES["CC1OC(=O)C[C@@]2(C)[C@H](CCC(O)=O)C3=[N]4\
C12C1=[N]2C(=CC5=[N]6[C@@](C)(CC7=C(CCC(O)=O)[C@](C)(CC(O)=O)C(=C3)N7[Co]426)\
C(CC(O)=O)=C5CCC(O)=O)[C@](C)(CCC(O)=O)C1CC(O)=O"], 
 metabolite["adcobhex", _] -> SMILES["[H][C@]12[C@H](CC(N)=O)[C@@](C)(CCC(O)=\
O)\\C(N1[Co+]C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc3c(N)ncnc13)=C(C)\\C1=N\\C(=\
C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4CCC(N)=O)[C@@](C)(CC(N)=O\
)[C@@H]3CCC(N)=O)C(C)(C)[C@@H]1CCC(N)=O"], metabolite["phaccoa", _] -> 
  SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n\
2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)Cc4ccccc4"], 
 metabolite["triodthy", _] -> 
  SMILES["N[C@@H](Cc1cc(I)c(Oc2ccc(O)c(I)c2)c(I)c1)C(O)=O"], 
 metabolite["lald-D", _] -> SMILES["[H]C(=O)[C@@H](C)O"], 
 metabolite["cholcoar", _] -> SMILES["[H][C@@](C)(CCCC(C)C(=O)SCCNC(=O)CCNC(=\
O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)\
n1cnc2c(N)ncnc12)[C@@]1([H])CC[C@@]2([H])[C@]3([H])[C@H](O)C[C@]4([H])C[C@H](\
O)CC[C@]4(C)[C@@]3([H])C[C@H](O)[C@]12C"], metabolite["phyQ", _] -> 
  SMILES[
   "CC(C)CCC[C@@H](C)CCC[C@@H](C)CCC\\C(=C\\CC1=C(C)C(=O)c2ccccc2C1=O)\\C"], 
 metabolite["3hmbcoa", _] -> SMILES["C[C@H](O)[C@H](C)C(=O)SCCNC(=O)CCNC(=O)[\
C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1c\
nc2c(N)ncnc12"], metabolite["thcys", _] -> SMILES["N[C@@H](CSS)C(=O)O"], 
 metabolite["3aib", _] -> SMILES["C[C@@H](CN)C(=O)[O-]"], 
 metabolite["glcur1p", _] -> 
  SMILES["O[C@@H]1[C@@H](O)C(O[C@@H]([C@H]1O)C([O-])=O)OP(O)(O)=O"], 
 metabolite["pgp120", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["mal-D", _] -> SMILES["O[C@H](CC(=O)O)C(=O)O"], 
 metabolite["cl", _] -> SMILES["[Cl-]"], metabolite["lys-D", _] -> 
  SMILES["NCCCC[C@@H](N)C(=O)O"], metabolite["ccmuac", _] -> 
  SMILES["OC(=O)\\C=C/C=C\\C(=O)O"], metabolite["skm5p", _] -> 
  SMILES["O[C@@H]1CC(=C[C@@H](OP(=O)(O)O)[C@H]1O)C(=O)O"], 
 metabolite["23ddhb", _] -> SMILES["OC1C=CC=C(C1O)C(O)=O"], 
 metabolite["uGgl", _] -> SMILES["C[C@H](NC(=O)C(C)O[C@H]1[C@H](O)[C@@H](CO)O\
C(OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@@H]1\
NC(C)=O)C(=O)NC(CCC(=O)N[C@@H](CCCCN)C(O)=O)C(O)=O"], 
 metabolite["hpyr", _] -> SMILES["OCC(=O)C(=O)O"], 
 metabolite["gmhep1p", _] -> 
  SMILES["[H][C@@]1(OC(OP(O)(O)=O)[C@@H](O)[C@@H](O)[C@@H]1O)[C@H](O)CO"], 
 metabolite["applp", _] -> SMILES["C[C@H](CN)OP(O)(O)=O"], 
 metabolite["24dab", _] -> SMILES["NCC[C@H](N)C(O)=O"], 
 metabolite["nmptrc", _] -> SMILES["CNCCCCN"], 
 metabolite["Sfglutth", _] -> 
  SMILES["N[C@@H](CCC(=O)N[C@@H](CSC=O)C(=O)NCC(O)=O)C(O)=O"], 
 metabolite["tyrp", _] -> SMILES["N[C@@H](Cc1ccc(OP(=O)(O)O)cc1)C(=O)O"], 
 metabolite["eandrstrn", _] -> SMILES["[H][C@@]12CC=C3C[C@@H](O)CC[C@]3(C)[C@\
@]1([H])CC[C@]1(C)C(=O)[C@H](O)C[C@@]21[H]"], 
 metabolite["mucl", _] -> SMILES["OC(=O)CC1OC(=O)C=C1"], 
 metabolite["ppbng", _] -> SMILES["NCc1[nH]cc(CCC(=O)O)c1CC(=O)O"], 
 metabolite["35cgmp", _] -> 
  SMILES["NC1=Nc2c(ncn2[C@@H]3O[C@@H]4COP(=O)(O)O[C@H]4[C@H]3O)C(=O)N1"], 
 metabolite["23dpg", _] -> SMILES["OC(=O)[C@@H](COP(=O)(O)O)OP(=O)(O)O"], 
 metabolite["acmama", _] -> SMILES["C[C@H](NC(=O)[C@@H](C)O[C@H]1[C@H](O)[C@@\
H](CO)O[C@H](O)[C@@H]1NC(=O)C)C(=O)O"], metabolite["pre3b", _] -> 
  SMILES["C[C@]1(CC(O)=O)[C@H](CCC(O)=O)C2=C/c3[nH]c(Cc4[nH]c(c(CC(O)=O)c4CCC\
(O)=O)[C@](C)(O)[C@@]45N/C(=C\\C1=N\\2)[C@@H](CCC(O)=O)[C@]4(C)CC(=O)O5)c(CCC\
(O)=O)c3CC(O)=O"], metabolite["hgbam", _] -> SMILES["[H][C@]12N=C(\\C(C)=C3/N\
=C(/C=C4\\N=C(\\C(C)=C5/N[C@]1(C)[C@@](C)(CC(N)=O)[C@@H]5CCC(O)=O)[C@@](C)(CC\
(N)=O)[C@@H]4CCC(O)=O)C(C)(C)[C@@H]3CCC(O)=O)[C@](C)(CCC(O)=O)[C@H]2CC(O)=O"]\
, metabolite["mso3", _] -> SMILES["CS(O)(=O)=O"], 
 metabolite["6a2ohxnt", _] -> SMILES["NCCCCC(=O)C(O)=O"], 
 metabolite["pa161", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["clpn141", _] -> SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], metabolite["5apentam", _] -> 
  SMILES["NCCCCC(N)=O"], metabolite["uGgla", _] -> 
  SMILES["C[C@@H](NC(=O)[C@@H](C)NC(=O)[C@H](CCCCN)NC(=O)CCC(NC(=O)[C@H](C)NC\
(=O)C(C)O[C@H]1[C@H](O)[C@@H](CO)OC(OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)\
[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@@H]1NC(C)=O)C(O)=O)C(O)=O"], 
 metabolite["4aabutn", _] -> SMILES["CC(=O)NCCCC([O-])=O"], 
 metabolite["3hodcoa", _] -> SMILES["CCCCCCCCCCCCCCCC(O)CC(=O)SCCNC(=O)CCNC(=\
O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)\
n1cnc2c(N)ncnc12"], metabolite["ctbt", _] -> 
  SMILES["C[N+](C)(C)C\\C=C\\C(O)=O"], metabolite["thcholst", _] -> 
  SMILES["[H]C(=O)C(C)CCC[C@@H](C)[C@@]1([H])CC[C@@]2([H])[C@]3([H])[C@H](O)C\
[C@]4([H])C[C@H](O)CC[C@]4(C)[C@@]3([H])C[C@H](O)[C@]12C"], 
 metabolite["cdpdtdec7eg", _] -> SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)\
(=O)OC[C@@H](COC([*])=O)OC([*])=O)[C@@H](O)[C@H]2O)c(=O)n1"], 
 metabolite["3oocoa", _] -> SMILES["CCCCCC(=O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)\
C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)\
ncnc12"], metabolite["S2hglut", _] -> SMILES["O[C@@H](CCC(=O)O)C(=O)O"], 
 metabolite["trypta", _] -> SMILES["NCCc1c[nH]c2ccccc12"], 
 metabolite["2amac", _] -> SMILES["NC(=C)C(=O)O"], 
 metabolite["hyptaur", _] -> SMILES["NCCS(=O)O"], 
 metabolite["xylnt", _] -> SMILES["OC[C@H](O)[C@@H](O)[C@H](O)C(O)=O"], 
 metabolite["ggptrc", _] -> SMILES["NCCCCNC(=O)CC[C@H](N)C(O)=O"], 
 metabolite["arg-D", _] -> SMILES["N[C@H](CCCN=C(N)N)C(=O)O"], 
 metabolite["cortsn", _] -> 
  SMILES[
   "C[C@]12CCC(=O)C=C1CC[C@H]3[C@@H]4CC[C@](O)(C(=O)CO)[C@@]4(C)CC(=O)[C@H]23\
"], metabolite["pa141", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["Nforglu", _] -> SMILES["[H]C(=O)N[C@@H](CCC(O)=O)C(O)=O"], 
 metabolite["dhpyr", _] -> SMILES["Oc1ccc(O)nc1"], 
 metabolite["4hoxoh", _] -> SMILES["CCC(O)CC(=O)C(O)=O"], 
 metabolite["iodine", _] -> SMILES["II"], metabolite["6hnac", _] -> 
  SMILES["OC(=O)c1ccc(O)nc1"], metabolite["13dpg", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)C(=O)OP(=O)(O)O"], 
 metabolite["xu5p-D", _] -> SMILES["OCC(=O)[C@@H](O)[C@H](O)COP(=O)(O)O"], 
 metabolite["accoa", _] -> SMILES["CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(\
=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23"], 
 metabolite["hco3", _] -> SMILES["OC(=O)[O-]"], 
 metabolite["gal", _] -> SMILES["OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@H]1O"], 
 metabolite["gal1p", _] -> 
  SMILES["OC[C@H]1O[C@H](OP(=O)(O)O)[C@H](O)[C@@H](O)[C@H]1O"], 
 metabolite["gam6p", _] -> 
  SMILES["N[C@H]1[C@@H](O)O[C@H](COP(=O)(O)O)[C@@H](O)[C@@H]1O"], 
 metabolite["rbl-L", _] -> SMILES["OC[C@H](O)[C@H](O)C(=O)CO"], 
 metabolite["ametam", _] -> 
  SMILES["C[S+](CCCN)C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc2c(N)ncnc12"], 
 metabolite["val-L", _] -> SMILES["CC(C)[C@H](N)C(=O)O"], 
 metabolite["thr-L", _] -> SMILES["C[C@@H](O)[C@H](N)C(=O)O"], 
 metabolite["anth", _] -> SMILES["Nc1ccccc1C(=O)O"], 
 metabolite["chor", _] -> SMILES["O[C@@H]1C=CC(=C[C@H]1OC(=C)C(O)=O)C(O)=O"], 
 metabolite["phpyr", _] -> SMILES["OC(=O)C(=O)Cc1ccccc1"], 
 metabolite["indole", _] -> SMILES["c1ccc2[nH]ccc2c1"], 
 metabolite["prfp", _] -> SMILES["NC(=O)c1ncn([C@@H]2O[C@H](COP(O)(O)=O)[C@@H\
](O)[C@H]2O)c1\\N=C\\N[C@@H]1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]1O"], 
 metabolite["hcys-L", _] -> SMILES["N[C@@H](CCS)C(=O)O"], 
 metabolite["dump", _] -> 
  SMILES["O[C@H]1C[C@@H](O[C@@H]1COP(=O)(O)O)N2C=CC(=O)NC2=O"], 
 metabolite["thymd", _] -> 
  SMILES["CC1=CN([C@H]2C[C@H](O)[C@@H](CO)O2)C(=O)NC1=O"], 
 metabolite["dadp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@H]3C[C@H](O)[C@@H](COP(=O)(O)OP(=O)(O)O)O3"], 
 metabolite["nicrnt", _] -> 
  SMILES["O[C@@H]1[C@@H](COP(O)(O)=O)O[C@H]([C@@H]1O)[n+]1cccc(c1)C(O)=O"], 
 metabolite["2dhp", _] -> SMILES["CC(C)(CO)C(=O)C([O-])=O"], 
 metabolite["4mop", _] -> SMILES["CC(C)CC(=O)C(=O)O"], 
 metabolite["b2coa", _] -> SMILES["C\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)\
(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc\
12"], metabolite["4c2me", _] -> SMILES["C[C@](O)(CO)[C@H](O)COP(=O)(O)OP(=O)(\
O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)N2C=CC(=NC2=O)N"], 
 metabolite["mana", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)[C@H](O)C([O-])=O"], 
 metabolite["fe2", _] -> SMILES["[Fe]"], metabolite["arab-L", _] -> 
  SMILES["O[C@H]1COC(O)[C@H](O)[C@H]1O"], metabolite["udcpdp", _] -> 
  SMILES["CC(C)=CCC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C/CC\\C(C)=C/CC\\C(C)=C/CC\
\\C(C)=C/CC\\C(C)=C/CC\\C(C)=C/CC\\C(C)=C/CC\\C(C)=C/COP(O)(=O)OP(O)(O)=O"], 
 metabolite["amp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]3O"], 
 metabolite["gam1p", _] -> 
  SMILES["N[C@@H]1[C@@H](O)[C@H](O)[C@@H](CO)O[C@@H]1OP(=O)(O)O"], 
 metabolite["k", _] -> SMILES["[K+]"], metabolite["glyald", _] -> 
  SMILES["OC[C@@H](O)C=O"], metabolite["malcoa", _] -> 
  SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n\
2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)CC(=O)O"], 
 metabolite["idp", _] -> 
  SMILES[
   "O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)OP(=O)(O)O)n2cnc3C(=O)NC=Nc23"], 
 metabolite["ch4s", _] -> SMILES["CS"], metabolite["3mob", _] -> 
  SMILES["CC(C)C(=O)C([O-])=O"], metabolite["dann", _] -> 
  SMILES["CC(N)C(N)CCCCCC(O)=O"], metabolite["id3acald", _] -> 
  SMILES["[H]C(=O)Cc1c[nH]c2ccccc12"], metabolite["tdcoa", _] -> 
  SMILES["CCCCCCCCCCCCCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=\
O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["3odcoa", _] -> SMILES["CCCCCCCC(=O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](\
O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(\
N)ncnc12"], metabolite["hdcea", _] -> SMILES["CCCCCC\\C=C/CCCCCCCC(=O)O"], 
 metabolite["drib", _] -> SMILES["OC[C@@H](O)[C@@H](O)CC=O"], 
 metabolite["g3pg", _] -> SMILES["OCC(O)COP(O)(=O)OCC(O)CO"], 
 metabolite["2oxoadp", _] -> SMILES["OC(=O)CCCC(=O)C(O)=O"], 
 metabolite["L2aadp", _] -> SMILES["N[C@@H](CCCC(=O)O)C(=O)O"], 
 metabolite["4fumacac", _] -> SMILES["OC(=O)CC(=O)CC(=O)\\C=C\\C(O)=O"], 
 metabolite["Lkynr", _] -> SMILES["N[C@@H](CC(=O)c1ccccc1N)C(=O)O"], 
 metabolite["oxam", _] -> SMILES["NC(=O)C(=O)O"], 
 metabolite["dha", _] -> SMILES["OCC(=O)CO"], 
 metabolite["rb15bp", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)C(=O)COP(=O)(O)O"], 
 metabolite["occoa", _] -> SMILES["CCCCCCCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(\
C)COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc2\
3"], metabolite["glyc1p", _] -> SMILES["OC[C@H](O)COP(=O)(O)O"], 
 metabolite["man", _] -> SMILES["OC[C@H]1OC(O)[C@@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["alac-S", _] -> SMILES["CC(=O)[C@](C)(O)C(O)=O"], 
 metabolite["fad", _] -> SMILES["Cc1cc2N=C3C(=O)NC(=O)N=C3N(C[C@H](O)[C@H](O)\
[C@H](O)COP(=O)(O)OP(=O)(O)OC[C@H]4O[C@H]([C@H](O)[C@@H]4O)n5cnc6c(N)ncnc56)c\
2cc1C"], metabolite["dtt", _] -> SMILES["OC(CS)C(O)CS"], 
 metabolite["biocyt", _] -> 
  SMILES[
   "[H][C@]12CS[C@@H](CCCCC(=O)NCCCC[C@H](N)C(O)=O)[C@@]1([H])NC(=O)N2"], 
 metabolite["2mbcoa", _] -> SMILES["CCC(C)C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(\
C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc1\
2"], metabolite["Lcystin", _] -> SMILES["N[C@@H](CSSC[C@H](N)C(=O)O)C(=O)O"], 
 metabolite["peamn", _] -> SMILES["NCCc1ccccc1"], 
 metabolite["dcmp", _] -> 
  SMILES["NC1=NC(=O)N(C=C1)[C@H]2C[C@H](O)[C@@H](COP(=O)(O)O)O2"], 
 metabolite["xolest_hs", _] -> SMILES["[H][C@@]1(CC[C@@]2([H])[C@]3([H])CC=C4\
C[C@H](CC[C@]4(C)[C@@]3([H])CC[C@]12C)OC([*])=O)[C@H](C)CCCC(C)C"], 
 metabolite["gthrd", _] -> 
  SMILES["N[C@@H](CCC(=O)N[C@@H](CS)C(=O)NCC(=O)O)C(=O)O"], 
 metabolite["12dgr120", _] -> SMILES["OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["ru5p-D", _] -> SMILES["OCC(=O)[C@H](O)[C@H](O)COP(=O)(O)O"], 
 metabolite["appnn", _] -> SMILES["CC1=CC[C@@H]2C[C@H]1C2(C)C"], 
 metabolite["kdo2lipid4", _] -> SMILES["CCCCCCCCCCC[C@@H](O)CC(=O)N[C@H]1[C@H\
](OC[C@H]2O[C@H](OP(O)(O)=O)[C@H](NC(=O)C[C@H](O)CCCCCCCCCCC)[C@@H](OC(=O)C[C\
@H](O)CCCCCCCCCCC)[C@@H]2O)O[C@H](CO[C@@]2(C[C@@H](O[C@@]3(C[C@@H](O)[C@@H](O\
)[C@H](O3)[C@H](O)CO)C(O)=O)[C@@H](O)[C@H](O2)[C@H](O)CO)C(O)=O)[C@@H](OP(O)(\
O)=O)[C@@H]1OC(=O)C[C@H](O)CCCCCCCCCCC"], metabolite["Lpipecol", _] -> 
  SMILES["[H][C@]1(CCCCN1)C([O-])=O"], metabolite["ga", _] -> 
  SMILES["OC(=O)c1cc(O)c(O)c(O)c1"], metabolite["2ddg6p", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)CC(=O)C(=O)O"], 
 metabolite["prbatp", _] -> SMILES["O[C@@H]1[C@@H](COP(O)(=O)OP(O)(=O)OP(O)(O\
)=O)O[C@H]([C@@H]1O)n1cnc2c1ncn(C1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]1O)c2=N"], 
 metabolite["sl2a6o", _] -> 
  SMILES["OC(=O)CCC(=O)N[C@@H](CCCC(=O)C(=O)O)C(=O)O"], 
 metabolite["db4p", _] -> SMILES["CC(=O)C(O)COP(O)(O)=O"], 
 metabolite["pan4p", _] -> SMILES["CC(C)(COP(O)(O)=O)C(O)C(=O)NCCC(=O)NCCS"], 
 metabolite["octdp", _] -> SMILES["CC(=CCC\\C(=C\\CC\\C(=C\\CC\\C(=C\\CC\\C(=\
C\\CC\\C(=C\\CC\\C(=C\\CC\\C(=C\\COP(=O)(O)OP(=O)(O)O)\\C)\\C)\\C)\\C)\\C)\\C\
)\\C)C"], metabolite["nmn", _] -> 
  SMILES["NC(=O)c1ccc[n+](c1)[C@@H]2O[C@H](COP(=O)(O)[O-])[C@@H](O)[C@H]2O"], 
 metabolite["3hocoa", _] -> SMILES["CCCCC[C@H](O)CC(=O)SCCNC(=O)CCNC(=O)[C@H]\
(O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c\
(N)ncnc12"], metabolite["suc6p", _] -> SMILES["OC[C@H]1O[C@H](O[C@]2(CO)O[C@H\
](COP(=O)(O)O)[C@@H](O)[C@@H]2O)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["kdo8p", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)[C@H](O)[C@H](O)CC(=O)C(=O)O"], 
 metabolite["kdo", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)[C@H](O)CC(=O)C(O)=O"], 
 metabolite["u23ga", _] -> SMILES["CCCCCCCCCCCC(O)CC(=O)N[C@H]1C(O[C@H](CO)[C\
@@H](O)[C@@H]1OC(=O)CC(O)CCCCCCCCCCC)OP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O\
)[C@@H]1O)n1ccc(=O)[nH]c1=O"], metabolite["acrn", _] -> 
  SMILES["CC(=O)O[C@H](CC(=O)O)C[N+](C)(C)C"], 
 metabolite["sucglu", _] -> SMILES["OC(=O)CC[C@H](NC(=O)CCC(O)=O)C(O)=O"], 
 metabolite["galctn-D", _] -> 
  SMILES["OC[C@@H](O)[C@H](O)[C@H](O)[C@@H](O)C([O-])=O"], 
 metabolite["micit", _] -> SMILES["C[C@@](O)([C@H](CC(=O)O)C(=O)O)C(=O)O"], 
 metabolite["ethamp", _] -> SMILES["NCCOP(=O)(O)O"], 
 metabolite["5prdmbz", _] -> 
  SMILES["Cc1cc2ncn([C@H]3O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]3O)c2cc1C"], 
 metabolite["itaccoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H](\
[C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)CC(\
=C)C(O)=O"], metabolite["N1aspmd", _] -> SMILES["CC(=O)NCCCNCCCCN"], 
 metabolite["gar", _] -> 
  SMILES["NCC(=O)NC1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]1O"], 
 metabolite["cgly", _] -> SMILES["N[C@@H](CS)C(=O)NCC(=O)O"], 
 metabolite["no", _] -> SMILES["O=[N]"], metabolite["acgam", _] -> 
  SMILES["CC(=O)N[C@H]1C(O)O[C@H](CO)[C@@H](O)[C@@H]1O"], 
 metabolite["2ommb", _] -> SMILES["COC1=CC(=O)C(C)=C(C\\C=C(/C)CC\\C=C(/C)CC\
\\C=C(/C)CC\\C=C(/C)CC\\C=C(/C)CC\\C=C(/C)CC\\C=C(/C)CCC=C(C)C)C1=O"], 
 metabolite["bgly", _] -> SMILES["OC(=O)CNC(=O)c1ccccc1"], 
 metabolite["copre8", _] -> SMILES["[H][C@]12[C@H](CC(O)=O)[C@@](C)(CCC(O)=O)\
C3=[N]1[Co+]14N5C([C@@H](CCC(O)=O)[C@](C)(CC(O)=O)[C@]25C)=C(C)C2=[N]1C(C[C@@\
]1(C)C(C)=C(CCC(O)=O)C(C3C)=[N]41)=C(CCC(O)=O)[C@]2(C)CC(O)=O"], 
 metabolite["co", _] -> SMILES["[C-]#[O+]"], metabolite["xol7aone", _] -> 
  SMILES["[H][C@@]1(CC[C@@]2([H])[C@]3([H])[C@H](O)CC4=CC(=O)CC[C@]4(C)[C@@]3\
([H])CC[C@]12C)[C@H](C)CCCC(C)C"], metabolite["g1p", _] -> 
  SMILES["OC[C@H]1OC(OP(O)(O)=O)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["3hpcoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([\
C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)CCO"]\
, metabolite["mercppyr", _] -> SMILES["OC(=O)C(=O)CS"], 
 metabolite["mi13456p", _] -> SMILES["O[C@@H]1[C@H](OP(O)(O)=O)[C@@H](OP(O)(O\
)=O)[C@H](OP(O)(O)=O)[C@@H](OP(O)(O)=O)[C@@H]1OP(O)(O)=O"], 
 metabolite["mi1345p", _] -> SMILES["O[C@H]1[C@H](OP(=O)(O)O)[C@H](O)[C@H](OP\
(=O)(O)O)[C@@H](OP(=O)(O)O)[C@@H]1OP(=O)(O)O"], 
 metabolite["coumarin", _] -> SMILES["O=c1ccc2ccccc2o1"], 
 metabolite["prostge2", _] -> 
  SMILES["CCCCC[C@H](O)\\C=C\\[C@H]1[C@H](O)CC(=O)[C@@H]1C\\C=C/CCCC(O)=O"], 
 metabolite["tym", _] -> SMILES["NCCc1ccc(O)cc1"], 
 metabolite["4hoxpacd", _] -> SMILES["[H]C(=O)Cc1ccc(O)cc1"], 
 metabolite["chsterol", _] -> SMILES["CC(C)CCC[C@@H](C)[C@H]1CC[C@H]2[C@@H]3C\
C=C4C[C@@H](O)CC[C@]4(C)[C@H]3CC[C@]12C"], metabolite["udpxyl", _] -> 
  SMILES["O[C@@H]1CO[C@H](OP(=O)(O)OP(=O)(O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)N\
3C=CC(=O)NC3=O)[C@H](O)[C@H]1O"], metabolite["xol7ah2al", _] -> 
  SMILES["[H]C(=O)C(C)CCC[C@@H](C)[C@@]1([H])CC[C@@]2([H])[C@]3([H])[C@H](O)C\
[C@]4([H])C[C@H](O)CC[C@]4(C)[C@@]3([H])CC[C@]12C"], 
 metabolite["alaala", _] -> SMILES["C[C@@H](N)C(=O)N[C@H](C)C(=O)O"], 
 metabolite["ps180", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["rbt", _] -> SMILES["OC[C@H](O)[C@H](O)[C@H](O)CO"], 
 metabolite["crtstrn", _] -> 
  SMILES[
   "C[C@]12C[C@H](O)[C@H]3[C@@H](CCC4=CC(=O)CC[C@]34C)[C@@H]1CC[C@@H]2C(=O)CO\
"], metabolite["nh3", _] -> SMILES["N"], metabolite["oxptn", _] -> 
  SMILES["[H]C(=O)CCCC(O)=O"], metabolite["suchms", _] -> 
  SMILES["N[C@@H](CCOC(=O)CCC(O)=O)C(O)=O"], metabolite["urcan", _] -> 
  SMILES["OC(=O)\\C=C\\c1c[nH]cn1"], metabolite["ctp", _] -> 
  SMILES["NC1=NC(=O)N(C=C1)[C@@H]2O[C@H](COP(=O)(O)OP(=O)(O)OP(=O)(O)O)[C@@H]\
(O)[C@H]2O"], metabolite["salcn", _] -> 
  SMILES["OC[C@H]1O[C@@H](Oc2ccccc2CO)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["mhpglu", _] -> SMILES["CN1[C@@H](CNc2ccc(cc2)C(=O)N[C@@H](CCC(=O\
)N[C@@H](CCC(=O)N[C@@H](CCC(O)=O)C(O)=O)C(O)=O)C(O)=O)CNc2nc(N)[nH]c(=O)c12"]\
, metabolite["taur", _] -> SMILES["NCCS(O)(=O)=O"], 
 metabolite["3hpppn", _] -> SMILES["OC(=O)CCc1cccc(O)c1"], 
 metabolite["u3hga", _] -> SMILES["CCCCCCCCCCCC(O)CC(=O)O[C@@H]1[C@@H](N)C(O[\
C@H](CO)[C@H]1O)OP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1ccc(=O)[n\
H]c1=O"], metabolite["udcp", _] -> SMILES["CC(C)=CCC\\C(C)=C\\CC\\C(C)=C\\CC\
\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C)=C\\CC\\C(C\
)=C\\CC\\C(C)=C\\CO"], metabolite["seramp", _] -> 
  SMILES[
   "N[C@@H](CO)C(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc2c(N)ncnc12\
"], metabolite["2mbdhl", _] -> SMILES["CCC(C)C(=O)SCCC(S)CCCCC(N)=O"], 
 metabolite["melatn", _] -> SMILES["COc1ccc2[nH]cc(CCNC(=O)C)c2c1"], 
 metabolite["Lcyst", _] -> SMILES["N[C@@H](CS(=O)(=O)O)C(=O)O"], 
 metabolite["pro-D", _] -> SMILES["OC(=O)[C@H]1CCCN1"], 
 metabolite["5HPET", _] -> 
  SMILES["CCCCC\\C=C/C\\C=C/C\\C=C/C=C/[C@H](CCCC(O)=O)OO"], 
 metabolite["crtn", _] -> SMILES["CN1CC(=O)NC1=N"], 
 metabolite["pail345p_hs", _] -> SMILES["[H][C@@](COC([*])=O)(COP(O)(=O)O[C@@\
H]1[C@H](O)[C@H](OP(O)(O)=O)[C@@H](OP(O)(O)=O)[C@H](OP(O)(O)=O)[C@H]1O)OC([*]\
)=O"], metabolite["carveol", _] -> SMILES["CC(=C)[C@@H]1CC=C(C)[C@@H](O)C1"], 
 metabolite["pa_EC", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["pe_EC", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["xylt", _] -> SMILES["OC[C@H](O)[C@@H](O)[C@H](O)CO"], 
 metabolite["g3pc", _] -> SMILES["C[N+](C)(C)CCOP(=O)(O)OC[C@H](O)CO"], 
 metabolite["2ddglcn", _] -> SMILES["OC[C@@H](O)[C@@H](O)CC(=O)C(=O)O"], 
 metabolite["nop", _] -> 
  SMILES["NC(=N)NCCC[C@H](N[C@H](CCC(O)=O)C(O)=O)C(O)=O"], 
 metabolite["im4act", _] -> SMILES["O=CCc1c[nH]cn1"], 
 metabolite["msa", _] -> SMILES["[H]C(=O)CC(O)=O"], 
 metabolite["mi4p-D", _] -> 
  SMILES["O[C@@H]1[C@H](O)[C@H](O)[C@@H](OP(O)(O)=O)[C@H](O)[C@H]1O"], 
 metabolite["crmp_hs", _] -> 
  SMILES["CCCCCCCCCCCCC\\C=C\\[C@@H](O)[C@H](COP(O)(O)=O)NC([*])=O"], 
 metabolite["pa140", _] -> SMILES["OP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["ichor", _] -> 
  SMILES["O[C@@H]1[C@@H](OC(=C)C(O)=O)C=CC=C1C(O)=O"], 
 metabolite["3ddgc", _] -> SMILES["OC[C@@H](O)[C@@H](O)C(=O)CC(O)=O"], 
 metabolite["u3aga", _] -> SMILES["CCCCCCCCCCCC(O)CC(=O)O[C@H]1[C@H](O)[C@@H]\
(CO)O[C@@H](OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2\
=O)[C@@H]1NC(C)=O"], metabolite["3mldz", _] -> SMILES["Cn1cnc(CC=O)c1"], 
 metabolite["5hoxindact", _] -> SMILES["Oc1ccc2[nH]cc(CC=O)c2c1"], 
 metabolite["ntm2amep", _] -> SMILES["C[N+](C)(C)CCP(O)(O)=O"], 
 metabolite["tststerone", _] -> 
  SMILES["C[C@]12CC[C@H]3[C@@H](CCC4=CC(=O)CC[C@]34C)[C@@H]1CC[C@@H]2O"], 
 metabolite["mi13p", _] -> 
  SMILES[
   "O[C@H]1[C@H](O)[C@@H](OP(O)(O)=O)[C@@H](O)[C@@H](OP(O)(O)=O)[C@@H]1O"], 
 metabolite["12dgr141", _] -> SMILES["OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["dhlam", _] -> SMILES["NC(=O)CCCCC(S)CCS"], 
 metabolite["4gudbd", _] -> SMILES["NC(=N)NCCCC(N)=O"], 
 metabolite["hxcoa", _] -> SMILES["CCCCCC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)\
COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23"]\
, metabolite["cdpglyc", _] -> 
  SMILES[
   "Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=O)OCC(O)CO)[C@@H](O)[C@H]2O)c(=O)n1\
"], metabolite["mi34p", _] -> 
  SMILES[
   "O[C@H]1[C@H](O)[C@@H](O)[C@H](OP(O)(O)=O)[C@@H](OP(O)(O)=O)[C@H]1O"], 
 metabolite["S-gtrdhdlp", _] -> SMILES["NC(=O)CCCCC(S)CCSC(=O)CCCC(O)=O"], 
 metabolite["pre6a", _] -> SMILES["C[C@@]12CC3=C(CCC(O)=O)[C@](C)(CC(O)=O)C(/\
C=C4\\N[C@@](C)(C5=C(CC(O)=O)[C@@](C)(CCC(O)=O)C(CC(=N1)C(CCC(O)=O)=C2CC(O)=O\
)=N5)[C@@](C)(CC(O)=O)[C@@H]4CCC(O)=O)=N3"], metabolite["copre2", _] -> 
  SMILES["C[C@]1(CC(O)=O)[C@H](CCC(O)=O)C2=CC3=[N]4C(Cc5c(CCC(O)=O)c(CC(O)=O)\
c6C=C7[N]8=C(C=C1N2[Co]48n56)[C@@H](CCC(O)=O)[C@]7(C)CC(O)=O)=C(CCC(O)=O)C3CC\
(O)=O"], metabolite["mhista", _] -> SMILES["Cn1cnc(CCN)c1"], 
 metabolite["17ahprgnlone", _] -> 
  SMILES[
   "CC(=O)[C@@]1(O)CC[C@H]2[C@@H]3CC=C4C[C@@H](O)CC[C@]4(C)[C@H]3CC[C@]12C"], 
 metabolite["hmgth", _] -> 
  SMILES["N[C@@H](CCC(=O)N[C@@H](CSCO)C(=O)NCC(=O)O)C(=O)O"], 
 metabolite["3amp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](CO)[C@@H](OP(=O)(O)O)[C@H]3O"], 
 metabolite["allphn", _] -> SMILES["NC(=O)NC(O)=O"], 
 metabolite["4aphdob", _] -> SMILES["Nc1ccccc1C(=O)CC(=O)C(O)=O"], 
 metabolite["5hxkynam", _] -> SMILES["NCCC(=O)c1cc(O)ccc1N"], 
 metabolite["ahandrostan", _] -> 
  SMILES["C[C@]12CC[C@@H](O)C[C@H]1CC[C@@H]3[C@@H]2CC[C@@]4(C)[C@H]3CCC4=O"], 
 metabolite["estriol", _] -> 
  SMILES["C[C@]12CC[C@H]3[C@@H](CCc4cc(O)ccc34)[C@@H]1C[C@@H](O)[C@@H]2O"], 
 metabolite["Nmtrp", _] -> SMILES["CN[C@@H](Cc1c[nH]c2ccccc12)C(=O)O"], 
 metabolite["ps140", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["5mthglu", _] -> SMILES["CN1[C@@H](CNc2ccc(cc2)C(=O)N[C@@H](CCC(=\
O)N[C@@H](CCC(=O)N[C@@H](CCC(O)=O)C(O)=O)C(O)=O)C(O)=O)CNc2nc(N)[nH]c(=O)c12"]\
, metabolite["icit", _] -> SMILES["OC(C(CC(=O)O)C(=O)O)C(=O)O"], 
 metabolite["udpg", _] -> SMILES["OC[C@H]1OC(OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]\
([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["man1p", _] -> 
  SMILES["OC[C@H]1OC(OP(O)(O)=O)[C@@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["2dr5p", _] -> SMILES["O[C@H](COP(=O)(O)O)[C@@H](O)CC=O"], 
 metabolite["pran", _] -> 
  SMILES["O[C@H]1[C@@H](O)[C@H](Nc2ccccc2C(O)=O)O[C@@H]1COP(O)(O)=O"], 
 metabolite["tyr-L", _] -> SMILES["N[C@@H](Cc1ccc(O)cc1)C(=O)O"], 
 metabolite["trp-L", _] -> SMILES["N[C@@H](Cc1c[nH]c2ccccc12)C(O)=O"], 
 metabolite["his-L", _] -> SMILES["N[C@@H](Cc1cnc[nH]1)C(=O)O"], 
 metabolite["eig3p", _] -> SMILES["O[C@H](COP(O)(O)=O)[C@@H](O)c1c[nH]cn1"], 
 metabolite["phom", _] -> SMILES["N[C@@H](CCOP(O)(O)=O)C(O)=O"], 
 metabolite["ahcys", _] -> 
  SMILES[
   "N[C@@H](CCSC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n2cnc3c(N)ncnc23)C(=O)O"], 
 metabolite["aicar", _] -> 
  SMILES["NC(=O)c1ncn([C@@H]2O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]2O)c1N"], 
 metabolite["dhor-S", _] -> SMILES["OC(=O)[C@@H]1CC(=O)NC(=O)N1"], 
 metabolite["cbasp", _] -> SMILES["NC(=O)N[C@@H](CC(=O)O)C(=O)O"], 
 metabolite["ump", _] -> 
  SMILES["O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)O)N2C=CC(=O)NC2=O"], 
 metabolite["xtsn", _] -> 
  SMILES["OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)n2cnc3c(O)nc(O)nc23"], 
 metabolite["udp", _] -> 
  SMILES["O[C@H]1[C@@H](O)[C@@H](O[C@@H]1COP(=O)(O)OP(=O)(O)O)N2C=CC(=O)NC2=O\
"], metabolite["dutp", _] -> 
  SMILES[
   "O[C@H]1C[C@@H](O[C@@H]1COP(=O)(O)OP(=O)(O)OP(=O)(O)O)N2C=CC(=O)NC2=O"], 
 metabolite["ribflv", _] -> 
  SMILES["Cc1cc2nc3c(nc(=O)[nH]c3=O)n(C[C@H](O)[C@H](O)[C@H](O)CO)c2cc1C"], 
 metabolite["4abz", _] -> SMILES["Nc1ccc(cc1)C(O)=O"], 
 metabolite["4ppan", _] -> 
  SMILES["CC(C)(COP(=O)(O)O)[C@@H](O)C(=O)NCCC(=O)O"], 
 metabolite["ncam", _] -> SMILES["NC(=O)c1cccnc1"], 
 metabolite["uppg3", _] -> SMILES["OC(=O)CCc1c(CC(=O)O)c2Cc3[nH]c(Cc4[nH]c(Cc\
5[nH]c(Cc1[nH]2)c(CCC(=O)O)c5CC(=O)O)c(CC(=O)O)c4CCC(=O)O)c(CC(=O)O)c3CCC(=O)\
O"], metabolite["3hdcoa", _] -> SMILES["CCCCCCC[C@H](O)CC(=O)SCCNC(=O)CCNC(=O\
)[C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n\
1cnc2c(N)ncnc12"], metabolite["btal", _] -> SMILES["CCCC=O"], 
 metabolite["coa", _] -> SMILES["CC(C)(COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H\
](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)ncnc23)[C@@H](O)C(=O)NCCC(=O)NCCS"], 
 metabolite["xyl-D", _] -> SMILES["OC[C@@H](O)[C@H](O)[C@@H](O)C=O"], 
 metabolite["acgam6p", _] -> 
  SMILES["CC(=O)N[C@H]1C(O)O[C@H](COP(O)(O)=O)[C@@H](O)[C@@H]1O"], 
 metabolite["csn", _] -> SMILES["NC1=CC=NC(=O)N1"], 
 metabolite["duri", _] -> SMILES["OC[C@H]1O[C@H](C[C@@H]1O)N2C=CC(=O)NC2=O"], 
 metabolite["acgam1p", _] -> 
  SMILES["CC(=O)N[C@@H]1[C@@H](O)[C@H](O)[C@@H](CO)OC1OP(O)(O)=O"], 
 metabolite["ivcoa", _] -> SMILES["CC(C)CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C\
)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12\
"], metabolite["nh4", _] -> SMILES["[NH4+]"], 
 metabolite["h2o2", _] -> SMILES["OO"], metabolite["h2", _] -> 
  SMILES["[H][H]"], metabolite["cdpdag_EC", _] -> 
  SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)[C@@H](O)[C@H]2O)c(=O)n1"], metabolite["5aizc", _] -> 
  SMILES["Nc1c(ncn1[C@@H]2O[C@H](COP(=O)(O)O)[C@@H](O)[C@H]2O)C(=O)O"], 
 metabolite["clpn_EC", _] -> SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["dhnpt", _] -> 
  SMILES["NC1=NC(=O)C2=C(NCC(=N2)[C@H](O)[C@H](O)CO)N1"], 
 metabolite["dscl", _] -> SMILES["C[C@]1(CC(O)=O)[C@H](CCC(O)=O)\\C2=C\\c3[nH\
]c(Cc4[nH]c(\\C=C5/N=C(/C=C1\\N2)[C@@H](CCC(O)=O)[C@]5(C)CC(O)=O)c(CC(O)=O)c4\
CCC(O)=O)c(CCC(O)=O)c3CC(O)=O"], metabolite["ohpb", _] -> 
  SMILES["O[C@H](COP(O)(O)=O)C(=O)C(O)=O"], metabolite["pydxn", _] -> 
  SMILES["Cc1ncc(CO)c(CO)c1O"], metabolite["dkmpp", _] -> 
  SMILES["CSCCC(=O)C(=O)COP(O)(O)=O"], metabolite["hdd2coa", _] -> 
  SMILES["CCCCCCCCCCCCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O)\
OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["abt", _] -> SMILES["OC[C@H](O)C(O)[C@@H](O)CO"], 
 metabolite["gdpddman", _] -> SMILES["C[C@H]1O[C@H](OP(O)(=O)OP(O)(=O)OC[C@H]\
2O[C@H]([C@H](O)[C@@H]2O)n2cnc3c2nc(N)[nH]c3=O)[C@@H](O)[C@@H](O)C1=O"], 
 metabolite["dtdprmn", _] -> SMILES["C[C@@H]1O[C@H](OP(=O)(O)OP(=O)(O)OC[C@H]\
2O[C@H](C[C@@H]2O)N3C=C(C)C(=O)NC3=O)[C@H](O)[C@H](O)[C@H]1O"], 
 metabolite["3dhgulnp", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)[C@@H](O)C(=O)[C@H](O)C(O)=O"], 
 metabolite["L2aadp6sa", _] -> SMILES["N[C@@H](CCCC=O)C(=O)O"], 
 metabolite["hgentis", _] -> SMILES["OC(=O)Cc1cc(O)ccc1O"], 
 metabolite["agdpcbi", _] -> SMILES["[H][C@]12[C@H](CC(N)=O)[C@@](C)(CCC(=O)N\
C[C@@H](C)OP(O)(=O)OP(O)(=O)OC[C@H]3O[C@H]([C@H](O)[C@@H]3O)n3cnc4c3nc(N)[nH]\
c4=O)\\C(N1[Co+]C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc3c(N)ncnc13)=C(C)\\C1=N\\\
C(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4CCC(N)=O)[C@@](C)(CC(N\
)=O)[C@@H]3CCC(N)=O)C(C)(C)[C@@H]1CCC(N)=O"], 
 metabolite["adocbl", _] -> SMILES["[H][C@]12[C@H](CC(N)=O)[C@@](C)(CCC(=O)NC\
[C@@H](C)OP([O-])(=O)O[C@@H]3[C@@H](CO)O[C@@H]([C@@H]3O)n3c[nH]c4cc(C)c(C)cc3\
4)\\C(N1[Co+]C[C@H]1O[C@H]([C@H](O)[C@@H]1O)n1cnc3c(N)ncnc13)=C(C)\\C1=N\\C(=\
C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4CCC(N)=O)[C@@](C)(CC(N)=O\
)[C@@H]3CCC(N)=O)C(C)(C)[C@@H]1CCC(N)=O"], metabolite["uamag", _] -> 
  SMILES["C[C@H](NC(=O)[C@@H](C)O[C@H]1[C@H](O)[C@@H](CO)OC(OP(O)(=O)OP(O)(=O\
)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2=O)[C@@H]1NC(C)=O)C(=O)N[C@H]\
(CCC(O)=O)C(O)=O"], metabolite["thrp", _] -> 
  SMILES["C[C@@H](OP(O)(O)=O)[C@H](N)C(O)=O"], 
 metabolite["lipoate", _] -> SMILES["OC(=O)CCCC[C@@H]1CCSS1"], 
 metabolite["3hbcoa", _] -> SMILES["C[C@H](O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C\
(C)(C)COP(=O)(O)OP(=O)(O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(=O)(O)O)n2cnc3c(N)n\
cnc23"], metabolite["Nacsertn", _] -> SMILES["CC(=O)NCCc1c[nH]c2ccc(O)cc12"], 
 metabolite["sarcs", _] -> SMILES["CNCC(=O)O"], 
 metabolite["mev-R", _] -> SMILES["C[C@@](O)(CCO)CC(O)=O"], 
 metabolite["7dhchsterol", _] -> SMILES["[H][C@@]1(CC[C@@]2([H])C3=CC=C4C[C@@\
H](O)CC[C@]4(C)[C@@]3([H])CC[C@]12C)[C@H](C)CCCC(C)C"], 
 metabolite["uri", _] -> 
  SMILES["OC[C@H]1O[C@H]([C@H](O)[C@@H]1O)N2C=CC(=O)NC2=O"], 
 metabolite["23dappa", _] -> SMILES["NCC(N)C(=O)O"], 
 metabolite["mi14p", _] -> 
  SMILES[
   "O[C@H]1[C@@H](O)[C@@H](OP(O)(O)=O)[C@H](O)[C@@H](O)[C@@H]1OP(O)(O)=O"], 
 metabolite["isetac", _] -> SMILES["OCCS(O)(=O)=O"], 
 metabolite["23ccmp", _] -> 
  SMILES["Nc1ccn([C@@H]2O[C@H](CO)[C@H]3OP(O)(=O)O[C@@H]23)c(=O)n1"], 
 metabolite["2amsa", _] -> SMILES["[H]C(=O)[C@H](N)C(O)=O"], 
 metabolite["gdchola", _] -> SMILES["[H][C@@]12C[C@H](O)CC[C@]1(C)[C@@]1([H])\
CC[C@]3(C)[C@]([H])(CC[C@@]3([H])[C@]1([H])[C@H](O)C2)[C@H](C)CCC(=O)NCC(O)=O\
"], metabolite["T4hcinnm", _] -> SMILES["OC(=O)\\C=C\\c1ccc(O)cc1"], 
 metabolite["pheacgln", _] -> SMILES["NC(=O)CC[C@H](NC(=O)Cc1ccccc1)C(O)=O"], 
 metabolite["cbl2", _] -> SMILES["[H][C@]12[C@H](CC(N)=O)[C@@](C)(CCC(=O)NC[C\
@@H](C)OP([O-])(=O)O[C@@H]3[C@@H](CO)O[C@@H]([C@@H]3O)n3c[nH]c4cc(C)c(C)cc34)\
\\C(N1[Co+])=C(C)\\C1=N\\C(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@\
H]4CCC(N)=O)[C@@](C)(CC(N)=O)[C@@H]3CCC(N)=O)C(C)(C)[C@@H]1CCC(N)=O"], 
 metabolite["pe161", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["prbamp", _] -> SMILES["O[C@@H]1[C@@H](COP(O)(O)=O)O[C@H]([C@@H]1\
O)n1cnc2c1ncn([C@@H]1O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]1O)c2=N"], 
 metabolite["23dhdp", _] -> SMILES["OC(=O)[C@@H]1CC=CC(=N1)C(O)=O"], 
 metabolite["ser-D", _] -> SMILES["N[C@H](CO)C(O)=O"], 
 metabolite["cpppg1", _] -> SMILES["Cc1c(CCC(=O)O)c2Cc3[nH]c(Cc4[nH]c(Cc5[nH]\
c(Cc1[nH]2)c(CCC(=O)O)c5C)c(CCC(=O)O)c4C)c(CCC(=O)O)c3C"], 
 metabolite["3hhcoa", _] -> SMILES["CCC[C@H](O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](O\
)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N\
)ncnc12"], metabolite["glyc", _] -> SMILES["OCC(O)CO"], 
 metabolite["hpglu", _] -> SMILES["Nc1nc2NC[C@H](CNc3ccc(cc3)C(=O)N[C@@H](CCC\
(=O)N[C@@H](CCC(=O)N[C@@H](CCC(O)=O)C(O)=O)C(O)=O)C(O)=O)Nc2c(=O)[nH]1"], 
 metabolite["achms", _] -> SMILES["CC(=O)OCC[C@H](N)C(O)=O"], 
 metabolite["25drapp", _] -> 
  SMILES["Nc1nc(O)c(N)c(N[C@@H]2O[C@H](COP(O)(O)=O)[C@@H](O)[C@H]2O)n1"], 
 metabolite["rmn", _] -> SMILES["C[C@H](O)[C@H](O)[C@@H](O)[C@@H](O)C=O"], 
 metabolite["phthr", _] -> SMILES["N[C@@H]([C@H](O)COP(=O)(O)O)C(=O)O"], 
 metabolite["44mzym", _] -> SMILES["[H][C@@]1(CC[C@@]2([H])C3=C(CC[C@]12C)[C@\
@]1(C)CC[C@H](O)C(C)(C)[C@]1([H])CC3)[C@H](C)CCC=C(C)C"], 
 metabolite["ergtetrol", _] -> SMILES["[H][C@@]1(CC[C@@]2([H])C3=CC=C4C[C@@H]\
(O)CC[C@]4(C)[C@@]3([H])CC[C@]12C)[C@H](C)\\C=C\\C(=C)C(C)C"], 
 metabolite["hmgcoa", _] -> SMILES["C[C@](O)(CC(O)=O)CC(=O)SCCNC(=O)CCNC(=O)[\
C@H](O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1c\
nc2c(N)ncnc12"], metabolite["2dh3dgal6p", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@H](O)CC(=O)C(=O)O"], 
 metabolite["2mcacn", _] -> SMILES["C\\C(C(O)=O)=C(/CC(O)=O)C(O)=O"], 
 metabolite["sph1p", _] -> 
  SMILES["CCCCCCCCCCCCCCC[C@@H](O)[C@@H](N)COP(=O)(O)O"], 
 metabolite["adphep-DD", _] -> SMILES["[H][C@@]1(OC(OP(O)(=O)OP(O)(=O)OC[C@H]\
2O[C@H]([C@H](O)[C@@H]2O)n2cnc3c(N)ncnc23)[C@@H](O)[C@@H](O)[C@@H]1O)[C@H](O)\
CO"], metabolite["ugmd", _] -> SMILES["C[C@H](NC(=O)[C@@H](C)O[C@H]1[C@H](O)[\
C@@H](CO)OC(OP(O)(=O)OP(O)(=O)OC[C@H]2O[C@H]([C@H](O)[C@@H]2O)n2ccc(=O)[nH]c2\
=O)[C@@H]1NC(C)=O)C(=O)N[C@H](CCC(=O)N[C@H](CCC[C@H](N)C(O)=O)C(O)=O)C(O)=O"]\
, metabolite["pad", _] -> SMILES["NC(=O)Cc1ccccc1"], 
 metabolite["Stmyn", _] -> SMILES["CN[C@H]1[C@H](O)[C@@H](O)[C@H](CO)O[C@H]1O\
[C@H]1[C@@H](O[C@@H](C)[C@]1(O)C=O)O[C@H]1[C@H](O)[C@@H](O)[C@H](NC(N)=N)[C@@\
H](O)[C@@H]1NC(N)=N"], metabolite["atrz", _] -> 
  SMILES["CCNc1nc(Cl)nc(NC(C)C)n1"], metabolite["aa", _] -> 
  SMILES["NC(=O)C=C"], metabolite["forglu", _] -> 
  SMILES["[H]C(=N)N[C@@H](CCC(O)=O)C(O)=O"], metabolite["lyx-L", _] -> 
  SMILES["OC[C@H](O)[C@@H](O)[C@@H](O)C=O"], metabolite["dmso", _] -> 
  SMILES["C[S+](C)[O-]"], metabolite["34dhpha", _] -> 
  SMILES["OC(=O)Cc1ccc(O)c(O)c1"], metabolite["2hb", _] -> 
  SMILES["CCC(O)C(O)=O"], metabolite["3htmelys", _] -> 
  SMILES["C[N+](C)(C)CCCC(O)[C@H](N)C(O)=O"], metabolite["estrones", _] -> 
  SMILES["C[C@]12CC[C@H]3[C@@H](CCc4cc(OS(=O)(=O)O)ccc34)[C@@H]1CCC2=O"], 
 metabolite["phyt", _] -> SMILES["CC(C)CCCC(C)CCCC(C)CCCC(C)CC(O)=O"], 
 metabolite["aqcobal", _] -> SMILES["[H][O+]([H])[Co+]N1\\C2=C(C)/C3=N/C(=C\\\
C4=N\\C(=C(C)/C5=N[C@@](C)([C@@]1([H])[C@H](CC(N)=O)[C@@]2(C)CCC(=O)NC[C@@H](\
C)OP([O-])(=O)O[C@@H]1[C@@H](CO)O[C@@H]([C@@H]1O)n1c[nH]c2cc(C)c(C)cc12)[C@@]\
(C)(CC(N)=O)[C@@H]5CCC(N)=O)[C@@](C)(CC(N)=O)[C@@H]4CCC(N)=O)C(C)(C)[C@@H]3CC\
C(N)=O"], metabolite["ocACP", _] -> SMILES["CCCCCCCC(=O)S[*]"], 
 metabolite["clpn181", _] -> SMILES["OC(COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])\
=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["acon-C", _] -> SMILES["OC(=O)C\\C(=C\\C(=O)O)\\C(=O)O"], 
 metabolite["mnl1p", _] -> 
  SMILES["OC[C@@H](O)[C@@H](O)[C@H](O)[C@H](O)COP(O)(O)=O"], 
 metabolite["skm", _] -> SMILES["O[C@@H]1CC(=C[C@@H](O)[C@H]1O)C(=O)O"], 
 metabolite["sucsal", _] -> SMILES["OC(=O)CCC=O"], 
 metabolite["ggdp", _] -> 
  SMILES[
   "CC(=CCC\\C(=C\\CC\\C(=C\\CC\\C(=C\\COP(=O)(O)OP(=O)(O)O)\\C)\\C)\\C)C"], 
 metabolite["5aprbu", _] -> 
  SMILES["Nc1c(NC[C@H](O)[C@H](O)[C@H](O)COP(O)(O)=O)[nH]c(=O)[nH]c1=O"], 
 metabolite["sbzcoa", _] -> SMILES["CC(C)(COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([\
C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12)[C@@H](O)C(=O)NCCC(=O)NCCSC(=O)c1cc\
ccc1C(=O)CCC(O)=O"], metabolite["2dglcn", _] -> 
  SMILES["OC[C@@H](O)[C@H](O)[C@@H](O)CC(O)=O"], 
 metabolite["f6p-B", _] -> 
  SMILES["OC[C@@]1(O)O[C@H](COP(=O)(O)O)[C@@H](O)[C@@H]1O"], 
 metabolite["srb-L", _] -> SMILES["OCC1(O)OC[C@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["dhpppn", _] -> SMILES["OC(=O)CCc1cccc(O)c1O"], 
 metabolite["35cdamp", _] -> 
  SMILES["Nc1ncnc2n(cnc12)[C@H]1C[C@@H]2OP(O)(=O)OC[C@H]2O1"], 
 metabolite["gmhep7p", _] -> 
  SMILES["O[C@H](COP(=O)(O)O)[C@H]1OC(O)[C@@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["kdo2lipid4L", _] -> SMILES["[H][C@@]1(O[C@@](C[C@@H](O)[C@H]1O)(\
O[C@@H]1C[C@@](OC[C@H]2O[C@@H](OC[C@H]3O[C@H](OP(O)(O)=O)[C@H](NC(=O)C[C@H](O\
)CCCCCCCCCCC)[C@@H](OC(=O)C[C@H](O)CCCCCCCCCCC)[C@@H]3O)[C@H](NC(=O)C[C@@H](C\
CCCCCCCCCC)OC(=O)CCCCCCCCCCC)[C@@H](OC(=O)C[C@H](O)CCCCCCCCCCC)[C@@H]2OP(O)(O\
)=O)(O[C@]([H])([C@H](O)CO)[C@@H]1O)C(O)=O)C(O)=O)[C@H](O)CO"], 
 metabolite["n8aspmd", _] -> SMILES["CC(=O)NCCCCNCCCN"], 
 metabolite["biliverd", _] -> SMILES["CC1=C(C=C)\\C(=C\\c2[nH]c(\\C=C\\3/N=C(\
\\C=C\\4/NC(=O)C(=C4C)C=C)C(=C3CCC(=O)O)C)c(CCC(=O)O)c2C)\\NC1=O"], 
 metabolite["cobalt2", _] -> SMILES["[Co]"], metabolite["2mpdhl", _] -> 
  SMILES["CC(C)C(=O)SCCC(S)CCCCC(N)=O"], metabolite["oxa", _] -> 
  SMILES["OC(=O)C(=O)O"], metabolite["eryth", _] -> 
  SMILES["OC[C@H](O)C(=O)CO"], metabolite["od2coa", _] -> 
  SMILES["CCCCCCCCCCCCCCC\\C=C\\C(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=\
O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["3mb2coa", _] -> SMILES["CC(C)=CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C\
)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncn\
c12"], metabolite["pail3p_hs", _] -> SMILES["[H][C@@](COC([*])=O)(COP(O)(=O)O\
[C@H]1[C@H](O)[C@@H](O)[C@H](O)[C@@H](OP(O)(O)=O)[C@H]1O)OC([*])=O"], 
 metabolite["prostg1", _] -> 
  SMILES["CCCCCC(=O)\\C=C\\[C@H]1[C@H](O)CC(=O)[C@@H]1CCCCCCC(O)=O"], 
 metabolite["dopa", _] -> SMILES["NCCc1ccc(O)c(O)c1"], 
 metabolite["23camp", _] -> 
  SMILES["Nc1ncnc2c1ncn2[C@@H]3O[C@H](CO)[C@H]4OP(=O)(O)O[C@@H]34"], 
 metabolite["idour", _] -> 
  SMILES["[H]C(=O)[C@]([H])(O)[C@@]([H])(O)[C@]([H])(O)[C@@]([H])(O)C(O)=O"], 
 metabolite["cdpdhdecg", _] -> SMILES["Nc1ccn([C@@H]2O[C@H](COP(O)(=O)OP(O)(=\
O)OC[C@@H](COC([*])=O)OC([*])=O)[C@@H](O)[C@H]2O)c(=O)n1"], 
 metabolite["1tdec7eg3p", _] -> SMILES["O[C@H](COC([*])=O)COP(O)(O)=O"], 
 metabolite["catechol", _] -> SMILES["Oc1ccccc1O"], 
 metabolite["4mbzald", _] -> SMILES["Cc1ccc(C=O)cc1"], 
 metabolite["34dhcinm", _] -> SMILES["OC(=O)\\C=C\\c1ccc(O)c(O)c1"], 
 metabolite["1p3h5c", _] -> SMILES["[H][C@]1(C[C@@H](O)C=N1)C(O)=O"], 
 metabolite["pmtcrn", _] -> 
  SMILES["CCCCCCCCCCCCCCCC(=O)O[C@@H](CC([O-])=O)C[N+](C)(C)C"], 
 metabolite["bilirub", _] -> SMILES["CC1=C(C=C)\\C(=C\\c2[nH]c(Cc3[nH]c(\\C=C\
\\4/NC(=O)C(=C4C)C=C)c(C)c3CCC(=O)O)c(CCC(=O)O)c2C)\\NC1=O"], 
 metabolite["athr-L", _] -> SMILES["C[C@H](O)[C@H](N)C(=O)O"], 
 metabolite["dsmsterol", _] -> SMILES["C[C@H](CCC=C(C)C)[C@H]1CC[C@H]2[C@@H]3\
CC=C4C[C@@H](O)CC[C@]4(C)[C@H]3CC[C@]12C"], metabolite["leuktrB4", _] -> 
  SMILES["CCCCC\\C=C/C[C@@H](O)\\C=C\\C=C\\C=C/[C@@H](O)CCCC(=O)O"], 
 metabolite["apnnox", _] -> SMILES["CC1(C)C2CC3OC3(C)C1C2"], 
 metabolite["34dhpac", _] -> SMILES["[H]C(=O)Cc1ccc(O)c(O)c1"], 
 metabolite["ppgpp", _] -> SMILES["NC1=Nc2c(ncn2[C@@H]3O[C@H](COP(=O)(O)OP(=O\
)(O)O)[C@@H](OP(=O)(O)OP(=O)(O)O)[C@H]3O)C(=O)N1"], 
 metabolite["crn-D", _] -> SMILES["C[N+](C)(C)CC(O)CC(=O)O"], 
 metabolite["pe180", _] -> SMILES["NCCOP(O)(=O)OCC(COC([*])=O)OC([*])=O"], 
 metabolite["ptcys", _] -> 
  SMILES["CC(C)(CO)[C@@H](O)C(=O)NCCC(=O)N[C@@H](CS)C(O)=O"], 
 metabolite["uaGgla", _] -> SMILES["C[C@@H](NC(=O)[C@@H](C)NC(=O)[C@H](CCCCN)\
NC(=O)CC[C@@H](NC(=O)[C@H](C)NC(=O)[C@@H](C)O[C@H]1[C@H](O)[C@@H](CO)O[C@H](O\
P(O)(=O)OP(O)(=O)OC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)\
CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(\\C)CC\\C=C(/C)CC\\C=C(/C)CCC=C(C)C)[C@@H]1NC\
(C)=O)C(O)=O)C(O)=O"], metabolite["epm", _] -> SMILES["OC[C@H]1O[C@H](OC[C@H]\
2O[C@H](O)[C@H](O)[C@@H](O)[C@H]2O)[C@@H](O)[C@@H](O)[C@@H]1O"], 
 metabolite["am6sa", _] -> SMILES["[H]C(=O)\\C=C/C=C(/N)C(O)=O"], 
 metabolite["aprop", _] -> SMILES["CC(N)C#N"], 
 metabolite["acybut", _] -> SMILES["NC(CCC(O)=O)C#N"], 
 metabolite["3mox4hpac", _] -> SMILES["[H]C(=O)Cc1ccc(O)c(OC)c1"], 
 metabolite["4tmeabut", _] -> SMILES["[H]C(=O)CCC[N+](C)(C)C"], 
 metabolite["aact", _] -> SMILES["CC(=O)CN"], metabolite["tdchola", _] -> 
  SMILES["C[C@H](CCC(=O)NCCS(=O)(=O)O)[C@H]1CC[C@H]2[C@@H]3[C@H](O)C[C@@H]4C[\
C@H](O)CC[C@]4(C)[C@H]3CC[C@]12C"], metabolite["pgp141", _] -> 
  SMILES["O[C@@H](COP(O)(O)=O)COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O"], 
 metabolite["5odhf2a", _] -> SMILES["OC(=O)CC1=CCC(=O)O1"], 
 metabolite["acmum6p", _] -> 
  SMILES[
   "C[C@@H](O[C@H]1[C@H](O)[C@@H](COP(O)(O)=O)OC(O)[C@@H]1NC(C)=O)C(O)=O"], 
 metabolite["ddsmsterol", _] -> SMILES["[H][C@@]1(CC[C@@]2([H])C3=CC=C4C[C@@H\
](O)CC[C@]4(C)[C@@]3([H])CC[C@]12C)[C@H](C)CCC=C(C)C"], 
 metabolite["dmgly", _] -> SMILES["CN(C)CC(=O)O"], 
 metabolite["hg2", _] -> SMILES["[Hg+2]"], metabolite["1tdecg3p", _] -> 
  SMILES["O[C@H](COC([*])=O)COP(O)(O)=O"], metabolite["co2dam", _] -> 
  SMILES["[H][C@]12[C@H](CC(O)=O)[C@@](C)(CCC(O)=O)\\C(N1[Co+])=C(C)\\C1=N\\C\
(=C/C3=N/C(=C(C)\\C4=N[C@]2(C)[C@@](C)(CC(N)=O)[C@@H]4CCC(O)=O)[C@@](C)(CC(N)\
=O)[C@@H]3CCC(O)=O)C(C)(C)[C@@H]1CCC(O)=O"], metabolite["3oodcoa", _] -> 
  SMILES["CCCCCCCCCCCCCCCC(=O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](O)C(C)(C)COP(O)(=O\
)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(N)ncnc12"], 
 metabolite["3hbcoa-R", _] -> SMILES["C[C@@H](O)CC(=O)SCCNC(=O)CCNC(=O)[C@H](\
O)C(C)(C)COP(O)(=O)OP(O)(=O)OC[C@H]1O[C@H]([C@H](O)[C@@H]1OP(O)(O)=O)n1cnc2c(\
N)ncnc12"], metabolite["glyc2p", _] -> SMILES["OCC(CO)OP(=O)(O)O"], 
 metabolite["ps120", _] -> 
  SMILES["N[C@@H](COP(O)(=O)OC[C@@H](COC([*])=O)OC([*])=O)C(O)=O"], 
 metabolite["3oxoadp", _] -> SMILES["[O-]C(=O)CCC(=O)CC([O-])=O"], 
 metabolite["nwharg", _] -> SMILES["NC(CCCN\\C(N)=N/O)C(O)=O"], 
 metabolite["gullac", _] -> 
  SMILES["[H][C@@]1(OC(=O)[C@@H](O)[C@H]1O)[C@@H](O)CO"]}
