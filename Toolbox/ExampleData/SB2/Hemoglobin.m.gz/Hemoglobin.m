(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$1093", "Stoichiometry" -> 
   SparseArray[Automatic, {13, 8}, 0, {1, {{0, 3, 8, 10, 12, 14, 16, 17, 18, 
      19, 20, 21, 22, 23}, {{1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {3}, {4}, 
      {4}, {5}, {5}, {6}, {6}, {7}, {7}, {3}, {2}, {1}, {1}, {2}, {1}}}, {-1, 
     1, -1, -1, -1, -1, -1, -1, -1, -1, 1, -1, 1, -1, 1, -1, 1, 1, -1, 1, 1, 
     1, -1}}], "Species" -> {metabolite["dpg23", "c"], metabolite["o2", "c"], 
    species["Hb", "c"], complex[species["Hb", "c"], metabolite["o2", "c"]], 
    complex[species["Hb", "c"], metabolite["o2", "c"], 
     metabolite["o2", "c"]], complex[species["Hb", "c"], 
     metabolite["o2", "c"], metabolite["o2", "c"], metabolite["o2", "c"]], 
    complex[species["Hb", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
     metabolite["o2", "c"], metabolite["o2", "c"]], species["deoxyHb", "c"], 
    metabolite["pg13", "c"], metabolite["pg3", "c"], metabolite["phos", "c"], 
    metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Fluxes" -> {v["vdpgase"], v["vdpgm"], v["vhbdpg"], v["vhbo1"], v["vhbo2"], 
    v["vhbo3"], v["vhbo4"], v["vo2"]}, "Constraints" -> {}, 
  "InitialConditions" -> {species["deoxyHb", "c"] -> 
     Quantity[0.04620957029335471, "Millimoles"/"Liters"], 
    species["Hb", "c"] -> Quantity[0.059625251991425425, 
      "Millimoles"/"Liters"], complex[species["Hb", "c"], 
      metabolite["o2", "c"]] -> Quantity[0.05008521167279736, 
      "Millimoles"/"Liters"], complex[species["Hb", "c"], 
      metabolite["o2", "c"], metabolite["o2", "c"]] -> 
     Quantity[0.07362526115901212, "Millimoles"/"Liters"], 
    complex[species["Hb", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"]] -> Quantity[0.26284218233767326, 
      "Millimoles"/"Liters"], complex[species["Hb", "c"], 
      metabolite["o2", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"]] -> Quantity[6.807612522545737, 
      "Millimoles"/"Liters"], metabolite["o2", "c"] -> 
     Quantity[0.0200788, "Millimoles"/"Liters"], metabolite["dpg23", "c"] -> 
     Quantity[3.1, "Millimoles"/"Liters"], metabolite["pg13", "c"] -> 
     Quantity[0.000243, "Millimoles"/"Liters"], metabolite["pg3", "c"] -> 
     Quantity[0.0773, "Millimoles"/"Liters"], metabolite["phos", "c"] -> 
     Quantity[2.5, "Millimoles"/"Liters"], metabolite["h", "c"] -> 
     Quantity[0.00008997573444801929, "Millimoles"/"Liters"], 
    metabolite["h2o", "c"] -> Quantity[1., "Millimoles"/"Liters"]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Quantity[1, "Liters"], 
    Keq["vdpgase"] -> Quantity[Infinity, "Millimoles"/"Liters"], 
    Keq["vdpgm"] -> Infinity, Keq["vhbdpg"] -> 
     Quantity[1/4, "Liters"/"Millimoles"], Keq["vhbo1"] -> 
     Quantity[41.835169432436196, "Liters"/"Millimoles"], 
    Keq["vhbo2"] -> Quantity[73.21154650676336, "Liters"/"Millimoles"], 
    Keq["vhbo3"] -> Quantity[177.79947008785382, "Liters"/"Millimoles"], 
    Keq["vhbo4"] -> Quantity[1289.9177241667828, "Liters"/"Millimoles"], 
    Keq["vo2"] -> 1, rateconst["vdpgase", True] -> 
     Quantity[0.14225806451612902, "Hours"^(-1)], rateconst["vdpgm", True] -> 
     Quantity[1814.8148148148148, "Hours"^(-1)], rateconst["vhbo1", True] -> 
     Quantity[506935.270702259, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vhbo2", True] -> Quantity[511077.050923776, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vhbo3", True] -> 
     Quantity[509243.459567699, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vhbo4", True] -> Quantity[501595.340624411, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vhbdpg", True] -> 
     Quantity[519612.560391792, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vo2", True] -> Quantity[509725.707725914, "Hours"^(-1)], 
    metabolite["o2", "Xt"] -> Quantity[0.0200788, "Millimoles"/"Liters"]}, 
  "GPR" -> {}, "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8}, 
  "CustomRateLaws" -> {}, "CustomODE" -> {}, "Name" -> "Hemoglobin", 
  "Notes" -> "", "Ignore" -> {metabolite["h2o", "c"], metabolite["h", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "ElementalComposition" -> {metabolite["dpg23", "c"] -> 
     3*"C" + 3*"H" + 10*"O" + 2*"P", metabolite["o2", "c"] -> 2*"O", 
    species["Hb", "c"] -> "&Hb&", species["deoxyHb", "c"] -> 
     3*"C" + 3*"H" + "&Hb&" + 10*"O" + 2*"P", 
    complex[species["Hb", "c"], metabolite["o2", "c"]] -> "&Hb&" + 2*"O", 
    complex[species["Hb", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"]] -> "&Hb&" + 4*"O", 
    complex[species["Hb", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"]] -> "&Hb&" + 6*"O", 
    complex[species["Hb", "c"], metabolite["o2", "c"], metabolite["o2", "c"], 
      metabolite["o2", "c"], metabolite["o2", "c"]] -> "&Hb&" + 8*"O", 
    metabolite["pg13", "c"] -> 3*"C" + 4*"H" + 10*"O" + 2*"P", 
    metabolite["pg3", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["phos", "c"] -> "H" + 4*"O" + "P", metabolite["h", "c"] -> 
     "H", metabolite["h2o", "c"] -> 2*"H" + "O"}}]
