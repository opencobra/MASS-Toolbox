(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$1093", "Stoichiometry" -> 
   SparseArray[Automatic, {13, 8}, 0, {1, {{0, 3, 8, 10, 12, 14, 16, 17, 18, 
      19, 20, 21, 22, 23}, {{1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {3}, {4}, 
      {4}, {5}, {5}, {6}, {6}, {7}, {7}, {3}, {2}, {1}, {1}, {2}, {1}}}, {-1, 
     1, -1, -1, -1, -1, -1, -1, -1, -1, 1, -1, 1, -1, 1, -1, 1, 1, -1, 1, 1, 
     1, -1}}], "Species" -> {metabolite["DPG23", "c"], metabolite["O2", "c"], 
    species["HB", "c"], complex[species["HB", "c"], metabolite["O2", "c"]], 
    complex[species["HB", "c"], metabolite["O2", "c"], 
     metabolite["O2", "c"]], complex[species["HB", "c"], 
     metabolite["O2", "c"], metabolite["O2", "c"], metabolite["O2", "c"]], 
    complex[species["HB", "c"], metabolite["O2", "c"], metabolite["O2", "c"], 
     metabolite["O2", "c"], metabolite["O2", "c"]], species["DHB", "c"], 
    metabolite["PG13", "c"], metabolite["PG3", "c"], metabolite["PHOS", "c"], 
    metabolite["H", "c"], metabolite["H2O", "c"]}, 
  "Fluxes" -> {v["DPGASE"], v["DPGM"], v["HBDPG"], v["HBO1"], v["HBO2"], 
    v["HBO3"], v["HBO4"], v["O2"]}, "Constraints" -> {}, 
  "InitialConditions" -> {species["DHB", "c"] -> 
     Quantity[0.04620957029335471, "Millimoles"/"Liters"], 
    species["HB", "c"] -> Quantity[0.059625251991425425, 
      "Millimoles"/"Liters"], complex[species["HB", "c"], 
      metabolite["O2", "c"]] -> Quantity[0.05008521167279736, 
      "Millimoles"/"Liters"], complex[species["HB", "c"], 
      metabolite["O2", "c"], metabolite["O2", "c"]] -> 
     Quantity[0.07362526115901212, "Millimoles"/"Liters"], 
    complex[species["HB", "c"], metabolite["O2", "c"], metabolite["O2", "c"], 
      metabolite["O2", "c"]] -> Quantity[0.26284218233767326, 
      "Millimoles"/"Liters"], complex[species["HB", "c"], 
      metabolite["O2", "c"], metabolite["O2", "c"], metabolite["O2", "c"], 
      metabolite["O2", "c"]] -> Quantity[6.807612522545737, 
      "Millimoles"/"Liters"], metabolite["O2", "c"] -> 
     Quantity[0.0200788, "Millimoles"/"Liters"], metabolite["DPG23", "c"] -> 
     Quantity[3.1, "Millimoles"/"Liters"], metabolite["PG13", "c"] -> 
     Quantity[0.000243, "Millimoles"/"Liters"], metabolite["PG3", "c"] -> 
     Quantity[0.0773, "Millimoles"/"Liters"], metabolite["PHOS", "c"] -> 
     Quantity[2.5, "Millimoles"/"Liters"], metabolite["H", "c"] -> 
     Quantity[0.00008997573444801929, "Millimoles"/"Liters"], 
    metabolite["H2O", "c"] -> Quantity[1., "Millimoles"/"Liters"]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Quantity[1, "Liters"], 
    Keq["DPGASE"] -> Quantity[Infinity, "Millimoles"/"Liters"], 
    Keq["DPGM"] -> Infinity, Keq["HBDPG"] -> Quantity[1/4, 
      "Liters"/"Millimoles"], Keq["HBO1"] -> Quantity[41.835169432436196, 
      "Liters"/"Millimoles"], Keq["HBO2"] -> Quantity[73.21154650676336, 
      "Liters"/"Millimoles"], Keq["HBO3"] -> Quantity[177.79947008785382, 
      "Liters"/"Millimoles"], Keq["HBO4"] -> Quantity[1289.9177241667828, 
      "Liters"/"Millimoles"], Keq["O2"] -> 1, rateconst["DPGASE", True] -> 
     Quantity[0.14225806451612902, "Hours"^(-1)], rateconst["DPGM", True] -> 
     Quantity[1814.8148148148148, "Hours"^(-1)], rateconst["HBO1", True] -> 
     Quantity[506935.270702259, "Liters"/("Hours"*"Millimoles")], 
    rateconst["HBO2", True] -> Quantity[511077.050923776, 
      "Liters"/("Hours"*"Millimoles")], rateconst["HBO3", True] -> 
     Quantity[509243.459567699, "Liters"/("Hours"*"Millimoles")], 
    rateconst["HBO4", True] -> Quantity[501595.340624411, 
      "Liters"/("Hours"*"Millimoles")], rateconst["HBDPG", True] -> 
     Quantity[519612.560391792, "Liters"/("Hours"*"Millimoles")], 
    rateconst["O2", True] -> Quantity[509725.707725914, "Hours"^(-1)], 
    metabolite["O2", "Xt"] -> Quantity[0.0200788, "Millimoles"/"Liters"]}, 
  "GPR" -> {}, "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8}, 
  "CustomRateLaws" -> {}, "CustomODE" -> {}, "Name" -> "Hemoglobin", 
  "Notes" -> "", "Ignore" -> {metabolite["H2O", "c"], metabolite["H", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "ElementalComposition" -> {metabolite["DPG23", "c"] -> 
     3*"C" + 3*"H" + 10*"O" + 2*"P" - 5*"q", metabolite["O2", "c"] -> 2*"O", 
    species["HB", "c"] -> "&Hb&", species["DHB", "c"] -> 
     3*"C" + 3*"H" + "&Hb&" + 10*"O" + 2*"P" - 5*"q", 
    complex[species["HB", "c"], metabolite["O2", "c"]] -> "&Hb&" + 2*"O", 
    complex[species["HB", "c"], metabolite["O2", "c"], 
      metabolite["O2", "c"]] -> "&Hb&" + 4*"O", 
    complex[species["HB", "c"], metabolite["O2", "c"], metabolite["O2", "c"], 
      metabolite["O2", "c"]] -> "&Hb&" + 6*"O", 
    complex[species["HB", "c"], metabolite["O2", "c"], metabolite["O2", "c"], 
      metabolite["O2", "c"], metabolite["O2", "c"]] -> "&Hb&" + 8*"O", 
    metabolite["PG13", "c"] -> 3*"C" + 4*"H" + 10*"O" + 2*"P" - 4*"q", 
    metabolite["PG3", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P" - 3*"q", 
    metabolite["PHOS", "c"] -> "H" + 4*"O" + "P" - 2*"q", 
    metabolite["H", "c"] -> "H" + "q", metabolite["H2O", "c"] -> 
     2*"H" + "O"}}]
