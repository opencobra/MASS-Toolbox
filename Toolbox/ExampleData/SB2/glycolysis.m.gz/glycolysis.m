(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$774", "Stoichiometry" -> 
   SparseArray[Automatic, {20, 21}, 0, {1, {{0, 2, 4, 6, 8, 10, 13, 15, 17, 
      19, 21, 24, 26, 29, 32, 35, 41, 47, 49, 57, 60}, {{1}, {18}, {1}, {2}, 
      {2}, {3}, {3}, {5}, {4}, {5}, {4}, {5}, {6}, {6}, {7}, {7}, {8}, {8}, 
      {9}, {9}, {10}, {10}, {11}, {14}, {11}, {15}, {6}, {11}, {17}, {6}, 
      {11}, {17}, {12}, {13}, {19}, {1}, {3}, {7}, {10}, {13}, {16}, {1}, 
      {3}, {7}, {10}, {13}, {16}, {6}, {16}, {1}, {3}, {6}, {10}, {11}, {16}, 
      {17}, {20}, {9}, {16}, {21}}}, {-1, 1, 1, -1, 1, -1, 1, -1, -1, 1, 1, 
     1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, 1, 1, 1, -1, 
     -1, -1, 1, 1, 1, 1, -1, -1, -2, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, 
     -1, -1, 1, 1, -1, 1, -1, -1}}], 
  "Species" -> {metabolite["glu", "c"], metabolite["g6p", "c"], 
    metabolite["f6p", "c"], metabolite["fdp", "c"], metabolite["dhap", "c"], 
    metabolite["gap", "c"], metabolite["pg13", "c"], metabolite["pg3", "c"], 
    metabolite["pg2", "c"], metabolite["pep", "c"], metabolite["pyr", "c"], 
    metabolite["lac", "c"], metabolite["nad", "c"], metabolite["nadh", "c"], 
    metabolite["amp", "c"], metabolite["adp", "c"], metabolite["atp", "c"], 
    metabolite["phos", "c"], metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Fluxes" -> {v["vhk"], v["vpgi"], v["vpfk"], v["vtpi"], v["vald"], 
    v["vgapdh"], v["vpgk"], v["vpglm"], v["veno"], v["vpk"], v["vldh"], 
    v["vamp"], v["vapk"], v["vpyr"], v["vlac"], v["vatp"], v["vnadh"], 
    v["vgluin"], v["vampin"], v["vh"], v["vh2o"]}, 
  "Constraints" -> {v["vgluin"] -> {-Infinity, 0}, 
    v["vampin"] -> {-Infinity, 0}}, "GPR" -> {}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21}, "CustomRateLaws" -> {}, 
  "CustomODE" -> {}, "Name" -> "MASSmodel$774", 
  "ElementalComposition" -> {metabolite["glu", "c"] -> 
     6*"C" + 12*"H" + 6*"O", metabolite["g6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P" - 2*"&q&", metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P" - 2*"&q&", metabolite["fdp", "c"] -> 
     6*"C" + 10*"H" + 12*"O" + 2*"P" - 4*"&q&", metabolite["dhap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P" - 2*"&q&", metabolite["gap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P" - 2*"&q&", metabolite["pg13", "c"] -> 
     3*"C" + 4*"H" + 10*"O" + 2*"P" - 4*"&q&", metabolite["pg3", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P" - 3*"&q&", metabolite["pg2", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P" - 3*"&q&", metabolite["pep", "c"] -> 
     3*"C" + 2*"H" + 6*"O" + "P" - 3*"&q&", metabolite["pyr", "c"] -> 
     3*"C" + 3*"H" + 3*"O" - "&q&", metabolite["lac", "c"] -> 
     3*"C" + 5*"H" + 3*"O" - "&q&", metabolite["nad", "c"] -> 
     "&NAD&" - "&q&", metabolite["nadh", "c"] -> "H" + "&NAD&" - 2*"&q&", 
    metabolite["amp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + "P" - 
      2*"&q&", metabolite["adp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 
      2*"P" - 3*"&q&", metabolite["atp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 
      13*"O" + 3*"P" - 4*"&q&", metabolite["phos", "c"] -> 
     "H" + 4*"O" + "P" - 2*"&q&", metabolite["h", "c"] -> "H" + "&q&", 
    metabolite["h2o", "c"] -> 2*"H" + "O"}, "Notes" -> "Model constructed on \
Wed 6 Mar 2013 11:19:45 by niko on Nikolauss-MacBook-Pro.ucsd.edu using \
Mathematica 9.0 for Mac OS X x86 (64-bit) (November 20, 2012) at the \
following geodetic location: latitude 32.88; longitude -117.24", 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "InitialConditions" -> {metabolite["glu", "c"] -> 
     Quantity[1., "Millimoles"/"Liters"], metabolite["g6p", "c"] -> 
     Quantity[0.0486, "Millimoles"/"Liters"], metabolite["f6p", "c"] -> 
     Quantity[0.0198, "Millimoles"/"Liters"], metabolite["fdp", "c"] -> 
     Quantity[0.0146, "Millimoles"/"Liters"], metabolite["dhap", "c"] -> 
     Quantity[0.16, "Millimoles"/"Liters"], metabolite["gap", "c"] -> 
     Quantity[0.00728, "Millimoles"/"Liters"], metabolite["pg13", "c"] -> 
     Quantity[0.000243, "Millimoles"/"Liters"], metabolite["pg3", "c"] -> 
     Quantity[0.0773, "Millimoles"/"Liters"], metabolite["pg2", "c"] -> 
     Quantity[0.0113, "Millimoles"/"Liters"], metabolite["pep", "c"] -> 
     Quantity[0.017, "Millimoles"/"Liters"], metabolite["pyr", "c"] -> 
     Quantity[0.060301, "Millimoles"/"Liters"], metabolite["lac", "c"] -> 
     Quantity[1.36, "Millimoles"/"Liters"], metabolite["nad", "c"] -> 
     Quantity[0.0589, "Millimoles"/"Liters"], metabolite["nadh", "c"] -> 
     Quantity[0.0301, "Millimoles"/"Liters"], metabolite["amp", "c"] -> 
     Quantity[0.08672812499999999, "Millimoles"/"Liters"], 
    metabolite["adp", "c"] -> Quantity[0.29, "Millimoles"/"Liters"], 
    metabolite["atp", "c"] -> Quantity[1.6, "Millimoles"/"Liters"], 
    metabolite["phos", "c"] -> Quantity[2.5, "Millimoles"/"Liters"], 
    metabolite["h", "c"] -> Quantity[0.00008997573444801929, 
      "Millimoles"/"Liters"], metabolite["h2o", "c"] -> 
     Quantity[1., "Millimoles"/"Liters"], 
    v["vhk"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["vpgi"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["vpfk"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["vtpi"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["vald"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["vgapdh"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["vpgk"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["vpglm"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["veno"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["vpk"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["vldh"] -> Quantity[2.016, "Millimoles"/("Hours"*"Liters")], 
    v["vamp"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vapk"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["vpyr"] -> Quantity[0.22400000000000003, "Millimoles"/
       ("Hours"*"Liters")], v["vlac"] -> Quantity[2.016, 
      "Millimoles"/("Hours"*"Liters")], v["vatp"] -> 
     Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["vnadh"] -> Quantity[0.22400000000000003, 
      "Millimoles"/("Hours"*"Liters")], v["vgluin"] -> 
     Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["vampin"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vh"] -> Quantity[2.688, "Millimoles"/("Hours"*"Liters")], 
    v["vh2o"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Quantity[1, "Liters"], 
    Keq["vhk"] -> 850, Keq["vpgi"] -> 0.41, Keq["vpfk"] -> 310, 
    Keq["vtpi"] -> 0.05714285714285714, Keq["vald"] -> 
     Quantity[0.082, "Millimoles"/"Liters"], Keq["vgapdh"] -> 
     Quantity[0.0179, "Liters"/"Millimoles"], Keq["vpgk"] -> 1800, 
    Keq["vpglm"] -> 0.14705882352941177, Keq["veno"] -> 1.6949152542372883, 
    Keq["vpk"] -> 363000, Keq["vldh"] -> 26300, Keq["vamp"] -> Infinity, 
    Keq["vapk"] -> 1.65, Keq["vpyr"] -> 1., Keq["vlac"] -> 1., 
    Keq["vatp"] -> Quantity[Infinity, "Millimoles"/"Liters"], 
    Keq["vnadh"] -> Infinity, Keq["vgluin"] -> Infinity, 
    Keq["vampin"] -> Infinity, Keq["vh"] -> 1., Keq["vh2o"] -> 1., 
    metabolite["pyr", "Xt"] -> Quantity[0.06, "Millimoles"/"Liters"], 
    metabolite["amp", "Xt"] -> Quantity[1, "Millimoles"/"Liters"], 
    metabolite["h", "Xt"] -> Quantity[0.00006309573444801929, 
      "Millimoles"/"Liters"], metabolite["h2o", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["glu", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["lac", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], rateconst["vhk", True] -> 
     Quantity[0.7000072543398843, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vpgi", True] -> Quantity[3644.444444444491, "Hours"^(-1)], 
    rateconst["vpfk", True] -> Quantity[35.36878374779938, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vtpi", True] -> 
     Quantity[34.35582822085891, "Hours"^(-1)], rateconst["vald", True] -> 
     Quantity[2834.567901234576, "Hours"^(-1)], rateconst["vgapdh", True] -> 
     Quantity[3376.7492421768247, "Liters"^2/("Hours"*"Millimoles"^2)], 
    rateconst["vpgk", True] -> Quantity[1.2735312697410057*^6, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vpglm", True] -> 
     Quantity[4869.565217391283, "Hours"^(-1)], rateconst["veno", True] -> 
     Quantity[1763.7795275590574, "Hours"^(-1)], rateconst["vpk", True] -> 
     Quantity[454.38555191136817, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vldh", True] -> Quantity[1112.573988602781, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vamp", True] -> 
     Quantity[0.16142399019925777, "Hours"^(-1)], rateconst["vapk", True] -> 
     Quantity[100000, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vpyr", True] -> Quantity[744.1860465116215, "Hours"^(-1)], 
    rateconst["vlac", True] -> Quantity[5.599999999999999, "Hours"^(-1)], 
    rateconst["vatp", True] -> Quantity[1.4000000000000001, "Hours"^(-1)], 
    rateconst["vnadh", True] -> Quantity[7.44186046511628, "Hours"^(-1)], 
    rateconst["vgluin", True] -> Quantity[1.12, "Hours"^(-1)], 
    rateconst["vampin", True] -> Quantity[0.014, "Hours"^(-1)], 
    rateconst["vh", True] -> Quantity[100000.00000000001, "Hours"^(-1)], 
    rateconst["vh2o", True] -> Quantity[100000, "Hours"^(-1)]}}]
