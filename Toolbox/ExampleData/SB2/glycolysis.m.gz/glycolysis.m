(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$774", "Stoichiometry" -> 
   SparseArray[Automatic, {20, 21}, 0, {1, {{0, 2, 4, 6, 8, 10, 13, 15, 17, 
      19, 21, 24, 26, 29, 32, 35, 41, 47, 49, 57, 60}, {{1}, {18}, {1}, {2}, 
      {2}, {3}, {3}, {5}, {4}, {5}, {4}, {5}, {6}, {6}, {7}, {7}, {8}, {8}, 
      {9}, {9}, {10}, {10}, {11}, {14}, {11}, {15}, {6}, {11}, {17}, {6}, 
      {11}, {17}, {12}, {13}, {19}, {1}, {3}, {7}, {10}, {13}, {16}, {1}, 
      {3}, {7}, {10}, {13}, {16}, {6}, {16}, {1}, {3}, {6}, {10}, {11}, {16}, 
      {17}, {20}, {9}, {16}, {21}}}, {-1, 1, 1, -1, 1, -1, 1, -1, -1, 1, 1, 
     1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, 1, 1, 1, -1, 
     -1, -1, 1, 1, 1, 1, -1, -1, -2, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, 1, 
     -1, -1, 1, 1, -1, 1, -1, -1}}], 
  "Species" -> {metabolite["GLU", "c"], metabolite["G6P", "c"], 
    metabolite["F6P", "c"], metabolite["FDP", "c"], metabolite["DHAP", "c"], 
    metabolite["GAP", "c"], metabolite["PG13", "c"], metabolite["PG3", "c"], 
    metabolite["PG2", "c"], metabolite["PEP", "c"], metabolite["PYR", "c"], 
    metabolite["LAC", "c"], metabolite["NAD", "c"], metabolite["NADH", "c"], 
    metabolite["AMP", "c"], metabolite["ADP", "c"], metabolite["ATP", "c"], 
    metabolite["PHOS", "c"], metabolite["H", "c"], metabolite["H2O", "c"]}, 
  "Fluxes" -> {v["HK"], v["PGI"], v["PFK"], v["TPI"], v["ALD"], v["GAPDH"], 
    v["PGK"], v["PGLM"], v["ENO"], v["PK"], v["LDH"], v["AMP"], v["APK"], 
    v["PYR"], v["LAC"], v["ATP"], v["NADH"], v["GLUIN"], v["AMPIN"], v["H"], 
    v["H2O"]}, "Constraints" -> {v["GLUIN"] -> {-Infinity, 0}, 
    v["AMPIN"] -> {-Infinity, 0}}, "GPR" -> {}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21}, "CustomRateLaws" -> {}, 
  "CustomODE" -> {}, "Name" -> "MASSmodel$774", 
  "ElementalComposition" -> {metabolite["GLU", "c"] -> 
     6*"C" + 12*"H" + 6*"O", metabolite["G6P", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P" - 2*"q", metabolite["F6P", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P" - 2*"q", metabolite["FDP", "c"] -> 
     6*"C" + 10*"H" + 12*"O" + 2*"P" - 4*"q", metabolite["DHAP", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P" - 2*"q", metabolite["GAP", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P" - 2*"q", metabolite["PG13", "c"] -> 
     3*"C" + 4*"H" + 10*"O" + 2*"P" - 4*"q", metabolite["PG3", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P" - 3*"q", metabolite["PG2", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P" - 3*"q", metabolite["PEP", "c"] -> 
     3*"C" + 2*"H" + 6*"O" + "P" - 3*"q", metabolite["PYR", "c"] -> 
     3*"C" + 3*"H" + 3*"O" - "q", metabolite["LAC", "c"] -> 
     3*"C" + 5*"H" + 3*"O" - "q", metabolite["NAD", "c"] -> "&NAD&" - "q", 
    metabolite["NADH", "c"] -> "H" + "&NAD&" - 2*"q", 
    metabolite["AMP", "c"] -> 10*"C" + 12*"H" + 5*"N" + 7*"O" + "P" - 2*"q", 
    metabolite["ADP", "c"] -> 10*"C" + 12*"H" + 5*"N" + 10*"O" + 2*"P" - 
      3*"q", metabolite["ATP", "c"] -> 10*"C" + 12*"H" + 5*"N" + 13*"O" + 
      3*"P" - 4*"q", metabolite["PHOS", "c"] -> "H" + 4*"O" + "P" - 2*"q", 
    metabolite["H", "c"] -> "H" + "q", metabolite["H2O", "c"] -> 
     2*"H" + "O"}, "Notes" -> "Model constructed on Wed 6 Mar 2013 11:19:45 \
by niko on Nikolauss-MacBook-Pro.ucsd.edu using Mathematica 9.0 for Mac OS X \
x86 (64-bit) (November 20, 2012) at the following geodetic location: latitude \
32.88; longitude -117.24", "Ignore" -> {metabolite["H", "c"], 
    metabolite["H2O", "c"]}, "UnitChecking" -> True, "Synonyms" -> {}, 
  "Events" -> {}, "InitialConditions" -> 
   {metabolite["GLU", "c"] -> Quantity[1., "Millimoles"/"Liters"], 
    metabolite["G6P", "c"] -> Quantity[0.0486, "Millimoles"/"Liters"], 
    metabolite["F6P", "c"] -> Quantity[0.0198, "Millimoles"/"Liters"], 
    metabolite["FDP", "c"] -> Quantity[0.0146, "Millimoles"/"Liters"], 
    metabolite["DHAP", "c"] -> Quantity[0.16, "Millimoles"/"Liters"], 
    metabolite["GAP", "c"] -> Quantity[0.00728, "Millimoles"/"Liters"], 
    metabolite["PG13", "c"] -> Quantity[0.000243, "Millimoles"/"Liters"], 
    metabolite["PG3", "c"] -> Quantity[0.0773, "Millimoles"/"Liters"], 
    metabolite["PG2", "c"] -> Quantity[0.0113, "Millimoles"/"Liters"], 
    metabolite["PEP", "c"] -> Quantity[0.017, "Millimoles"/"Liters"], 
    metabolite["PYR", "c"] -> Quantity[0.060301, "Millimoles"/"Liters"], 
    metabolite["LAC", "c"] -> Quantity[1.36, "Millimoles"/"Liters"], 
    metabolite["NAD", "c"] -> Quantity[0.0589, "Millimoles"/"Liters"], 
    metabolite["NADH", "c"] -> Quantity[0.0301, "Millimoles"/"Liters"], 
    metabolite["AMP", "c"] -> Quantity[0.08672812499999999, 
      "Millimoles"/"Liters"], metabolite["ADP", "c"] -> 
     Quantity[0.29, "Millimoles"/"Liters"], metabolite["ATP", "c"] -> 
     Quantity[1.6, "Millimoles"/"Liters"], metabolite["PHOS", "c"] -> 
     Quantity[2.5, "Millimoles"/"Liters"], metabolite["H", "c"] -> 
     Quantity[0.00008997573444801929, "Millimoles"/"Liters"], 
    metabolite["H2O", "c"] -> Quantity[1., "Millimoles"/"Liters"], 
    v["HK"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["PGI"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["PFK"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["TPI"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["ALD"] -> Quantity[1.12, "Millimoles"/("Hours"*"Liters")], 
    v["GAPDH"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["PGK"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["PGLM"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["ENO"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["PK"] -> Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["LDH"] -> Quantity[2.016, "Millimoles"/("Hours"*"Liters")], 
    v["AMP"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["APK"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["PYR"] -> Quantity[0.22400000000000003, "Millimoles"/
       ("Hours"*"Liters")], v["LAC"] -> Quantity[2.016, 
      "Millimoles"/("Hours"*"Liters")], v["ATP"] -> 
     Quantity[2.24, "Millimoles"/("Hours"*"Liters")], 
    v["NADH"] -> Quantity[0.22400000000000003, "Millimoles"/
       ("Hours"*"Liters")], v["GLUIN"] -> Quantity[1.12, 
      "Millimoles"/("Hours"*"Liters")], v["AMPIN"] -> 
     Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["H"] -> Quantity[2.688, "Millimoles"/("Hours"*"Liters")], 
    v["H2O"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Quantity[1, "Liters"], 
    Keq["HK"] -> 850, Keq["PGI"] -> 0.41, Keq["PFK"] -> 310, 
    Keq["TPI"] -> 0.05714285714285714, Keq["ALD"] -> 
     Quantity[0.082, "Millimoles"/"Liters"], Keq["GAPDH"] -> 
     Quantity[0.0179, "Liters"/"Millimoles"], Keq["PGK"] -> 1800, 
    Keq["PGLM"] -> 0.14705882352941177, Keq["ENO"] -> 1.6949152542372883, 
    Keq["PK"] -> 363000, Keq["LDH"] -> 26300, Keq["AMP"] -> Infinity, 
    Keq["APK"] -> 1.65, Keq["PYR"] -> 1., Keq["LAC"] -> 1., 
    Keq["ATP"] -> Quantity[Infinity, "Millimoles"/"Liters"], 
    Keq["NADH"] -> Infinity, Keq["GLUIN"] -> Infinity, 
    Keq["AMPIN"] -> Infinity, Keq["H"] -> 1., Keq["H2O"] -> 1., 
    metabolite["PYR", "Xt"] -> Quantity[0.06, "Millimoles"/"Liters"], 
    metabolite["AMP", "Xt"] -> Quantity[1, "Millimoles"/"Liters"], 
    metabolite["H", "Xt"] -> Quantity[0.00006309573444801929, 
      "Millimoles"/"Liters"], metabolite["H2O", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["GLU", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["LAC", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], rateconst["HK", True] -> 
     Quantity[0.7000072543398843, "Liters"/("Hours"*"Millimoles")], 
    rateconst["PGI", True] -> Quantity[3644.444444444491, "Hours"^(-1)], 
    rateconst["PFK", True] -> Quantity[35.36878374779938, 
      "Liters"/("Hours"*"Millimoles")], rateconst["TPI", True] -> 
     Quantity[34.35582822085891, "Hours"^(-1)], rateconst["ALD", True] -> 
     Quantity[2834.567901234576, "Hours"^(-1)], rateconst["GAPDH", True] -> 
     Quantity[3376.7492421768247, "Liters"^2/("Hours"*"Millimoles"^2)], 
    rateconst["PGK", True] -> Quantity[1.2735312697410057*^6, 
      "Liters"/("Hours"*"Millimoles")], rateconst["PGLM", True] -> 
     Quantity[4869.565217391283, "Hours"^(-1)], rateconst["ENO", True] -> 
     Quantity[1763.7795275590574, "Hours"^(-1)], rateconst["PK", True] -> 
     Quantity[454.38555191136817, "Liters"/("Hours"*"Millimoles")], 
    rateconst["LDH", True] -> Quantity[1112.573988602781, 
      "Liters"/("Hours"*"Millimoles")], rateconst["AMP", True] -> 
     Quantity[0.16142399019925777, "Hours"^(-1)], rateconst["APK", True] -> 
     Quantity[100000, "Liters"/("Hours"*"Millimoles")], 
    rateconst["PYR", True] -> Quantity[744.1860465116215, "Hours"^(-1)], 
    rateconst["LAC", True] -> Quantity[5.599999999999999, "Hours"^(-1)], 
    rateconst["ATP", True] -> Quantity[1.4000000000000001, "Hours"^(-1)], 
    rateconst["NADH", True] -> Quantity[7.44186046511628, "Hours"^(-1)], 
    rateconst["GLUIN", True] -> Quantity[1.12, "Hours"^(-1)], 
    rateconst["AMPIN", True] -> Quantity[0.014, "Hours"^(-1)], 
    rateconst["H", True] -> Quantity[100000.00000000001, "Hours"^(-1)], 
    rateconst["H2O", True] -> Quantity[100000, "Hours"^(-1)]}}]
