(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$774", "Stoichiometry" -> 
   SparseArray[Automatic, {20, 21}, 0, {1, {{0, 6, 9, 15, 17, 19, 21, 23, 26, 
      28, 36, 39, 41, 44, 46, 48, 50, 52, 55, 58, 60}, {{1}, {3}, {7}, {10}, 
      {13}, {16}, {12}, {13}, {19}, {1}, {3}, {7}, {10}, {13}, {16}, {4}, 
      {5}, {2}, {3}, {3}, {5}, {1}, {2}, {4}, {5}, {6}, {1}, {18}, {1}, {3}, 
      {6}, {10}, {11}, {16}, {17}, {20}, {9}, {16}, {21}, {11}, {15}, {6}, 
      {11}, {17}, {9}, {10}, {6}, {7}, {8}, {9}, {7}, {8}, {10}, {11}, {14}, 
      {6}, {11}, {17}, {6}, {16}}}, {1, 1, -1, -1, -2, 1, -1, 1, 1, -1, -1, 
     1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1, -1, 
     -1, 1, 1, -1, 1, -1, -1, 1, -1, -1, 1, 1, 1, -1, 1, -1, 1, -1, 1, -1, 1, 
     -1, -1, 1, -1, -1, -1, 1}}], "Species" -> {metabolite["adp", "c"], 
    metabolite["amp", "c"], metabolite["atp", "c"], metabolite["dhap", "c"], 
    metabolite["f6p", "c"], metabolite["fdp", "c"], metabolite["g6p", "c"], 
    metabolite["gap", "c"], metabolite["glu", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["lac", "c"], metabolite["nad", "c"], 
    metabolite["pep", "c"], metabolite["pg13", "c"], metabolite["pg2", "c"], 
    metabolite["pg3", "c"], metabolite["pyr", "c"], metabolite["nadh", "c"], 
    metabolite["phos", "c"]}, "Fluxes" -> {v["vhk"], v["vpgi"], v["vpfk"], 
    v["vtpi"], v["vald"], v["vgapdh"], v["vpgk"], v["vpglm"], v["veno"], 
    v["vpk"], v["vldh"], v["vamp"], v["vapk"], v["vpyr"], v["vlac"], 
    v["vatp"], v["vnadh"], v["vgluin"], v["vampin"], v["vh"], v["vh2o"]}, 
  "Constraints" -> {v["vgluin"] -> {-Infinity, 0}, 
    v["vampin"] -> {-Infinity, 0}}, "GPR" -> {}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21}, "CustomRateLaws" -> {}, 
  "CustomODE" -> {}, "Name" -> "MASSmodel$774", 
  "ElementalComposition" -> {metabolite["adp", "c"] -> 
     10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", metabolite["amp", "c"] -> 
     10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", metabolite["atp", "c"] -> 
     10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", metabolite["dhap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["fdp", "c"] -> 
     6*"C" + 10*"H" + 12*"O" + 2*"P", metabolite["g6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["gap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["glu", "c"] -> 
     6*"C" + 12*"H" + 6*"O", metabolite["h", "c"] -> "H", 
    metabolite["h2o", "c"] -> 2*"H" + "O", metabolite["lac", "c"] -> 
     3*"C" + 5*"H" + 3*"O", metabolite["nad", "c"] -> "&NAD&", 
    metabolite["nadh", "c"] -> "H" + "&NAD&", metabolite["pep", "c"] -> 
     3*"C" + 2*"H" + 6*"O" + "P", metabolite["pg13", "c"] -> 
     3*"C" + 4*"H" + 10*"O" + 2*"P", metabolite["pg2", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P", metabolite["pg3", "c"] -> 
     3*"C" + 4*"H" + 7*"O" + "P", metabolite["phos", "c"] -> 
     "H" + 4*"O" + "P", metabolite["pyr", "c"] -> 3*"C" + 3*"H" + 3*"O"}, 
  "Notes" -> "Model constructed on Wed 6 Mar 2013 11:19:45 by niko on \
Nikolauss-MacBook-Pro.ucsd.edu using Mathematica 9.0 for Mac OS X x86 \
(64-bit) (November 20, 2012) at the following geodetic location: latitude \
32.88; longitude -117.24", "Ignore" -> {metabolite["h", "c"], 
    metabolite["h2o", "c"]}, "UnitChecking" -> True, "Synonyms" -> {}, 
  "Events" -> {}, "InitialConditions" -> 
   {metabolite["glu", "c"] -> Unit[1., "Millimole"/"Liter"], 
    metabolite["g6p", "c"] -> Unit[0.0486, "Millimole"/"Liter"], 
    metabolite["f6p", "c"] -> Unit[0.0198, "Millimole"/"Liter"], 
    metabolite["fdp", "c"] -> Unit[0.0146, "Millimole"/"Liter"], 
    metabolite["dhap", "c"] -> Unit[0.16, "Millimole"/"Liter"], 
    metabolite["gap", "c"] -> Unit[0.00728, "Millimole"/"Liter"], 
    metabolite["pg13", "c"] -> Unit[0.000243, "Millimole"/"Liter"], 
    metabolite["pg3", "c"] -> Unit[0.0773, "Millimole"/"Liter"], 
    metabolite["pg2", "c"] -> Unit[0.0113, "Millimole"/"Liter"], 
    metabolite["pep", "c"] -> Unit[0.017, "Millimole"/"Liter"], 
    metabolite["pyr", "c"] -> Unit[0.060301, "Millimole"/"Liter"], 
    metabolite["lac", "c"] -> Unit[1.36, "Millimole"/"Liter"], 
    metabolite["nad", "c"] -> Unit[0.0589, "Millimole"/"Liter"], 
    metabolite["nadh", "c"] -> Unit[0.0301, "Millimole"/"Liter"], 
    metabolite["amp", "c"] -> Unit[0.08672812499999999, "Millimole"/"Liter"], 
    metabolite["adp", "c"] -> Unit[0.29, "Millimole"/"Liter"], 
    metabolite["atp", "c"] -> Unit[1.6, "Millimole"/"Liter"], 
    metabolite["phos", "c"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["h", "c"] -> Unit[0.00008997573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "c"] -> 
     Unit[1., "Millimole"/"Liter"], v["vhk"] -> 
     Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vpgi"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vpfk"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vtpi"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vald"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vgapdh"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["vpgk"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["vpglm"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["veno"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["vpk"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["vldh"] -> Unit[2.016, "Millimole"/("Hour"*"Liter")], 
    v["vamp"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vapk"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vpyr"] -> Unit[0.22400000000000003, "Millimole"/("Hour"*"Liter")], 
    v["vlac"] -> Unit[2.016, "Millimole"/("Hour"*"Liter")], 
    v["vatp"] -> Unit[2.24, "Millimole"/("Hour"*"Liter")], 
    v["vnadh"] -> Unit[0.22400000000000003, "Millimole"/("Hour"*"Liter")], 
    v["vgluin"] -> Unit[1.12, "Millimole"/("Hour"*"Liter")], 
    v["vampin"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vh"] -> Unit[2.688, "Millimole"/("Hour"*"Liter")], 
    v["vh2o"] -> Unit[0., "Millimole"/("Hour"*"Liter")]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["vhk"] -> 850, Keq["vpgi"] -> 0.41, Keq["vpfk"] -> 310, 
    Keq["vtpi"] -> 0.05714285714285714, Keq["vald"] -> 
     Unit[0.082, "Millimole"/"Liter"], Keq["vgapdh"] -> 
     Unit[0.0179, "Liter"/"Millimole"], Keq["vpgk"] -> 1800, 
    Keq["vpglm"] -> 0.14705882352941177, Keq["veno"] -> 1.6949152542372883, 
    Keq["vpk"] -> 363000, Keq["vldh"] -> 26300, Keq["vamp"] -> Infinity, 
    Keq["vapk"] -> 1.65, Keq["vpyr"] -> 1., Keq["vlac"] -> 1., 
    Keq["vatp"] -> Unit[Infinity, "Millimole"/"Liter"], 
    Keq["vnadh"] -> Infinity, Keq["vgluin"] -> Infinity, 
    Keq["vampin"] -> Infinity, Keq["vh"] -> 1., Keq["vh2o"] -> 1., 
    metabolite["pyr", "Xt"] -> Unit[0.06, "Millimole"/"Liter"], 
    metabolite["amp", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    metabolite["h", "Xt"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["glu", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["lac", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], rateconst["vhk", True] -> 
     Unit[0.7000072543398843, "Liter"/("Hour"*"Millimole")], 
    rateconst["vpgi", True] -> Unit[3644.444444444491, "Hour"^(-1)], 
    rateconst["vpfk", True] -> Unit[35.36878374779938, 
      "Liter"/("Hour"*"Millimole")], rateconst["vtpi", True] -> 
     Unit[34.35582822085891, "Hour"^(-1)], rateconst["vald", True] -> 
     Unit[2834.567901234576, "Hour"^(-1)], rateconst["vgapdh", True] -> 
     Unit[3376.7492421768247, "Liter"^2/("Hour"*"Millimole"^2)], 
    rateconst["vpgk", True] -> Unit[1.2735312697410057*^6, 
      "Liter"/("Hour"*"Millimole")], rateconst["vpglm", True] -> 
     Unit[4869.565217391283, "Hour"^(-1)], rateconst["veno", True] -> 
     Unit[1763.7795275590574, "Hour"^(-1)], rateconst["vpk", True] -> 
     Unit[454.38555191136817, "Liter"/("Hour"*"Millimole")], 
    rateconst["vldh", True] -> Unit[1112.573988602781, 
      "Liter"/("Hour"*"Millimole")], rateconst["vamp", True] -> 
     Unit[0.16142399019925777, "Hour"^(-1)], rateconst["vapk", True] -> 
     Unit[100000, "Liter"/("Hour"*"Millimole")], rateconst["vpyr", True] -> 
     Unit[744.1860465116215, "Hour"^(-1)], rateconst["vlac", True] -> 
     Unit[5.599999999999999, "Hour"^(-1)], rateconst["vatp", True] -> 
     Unit[1.4000000000000001, "Hour"^(-1)], rateconst["vnadh", True] -> 
     Unit[7.44186046511628, "Hour"^(-1)], rateconst["vgluin", True] -> 
     Unit[1.12, "Hour"^(-1)], rateconst["vampin", True] -> 
     Unit[0.014, "Hour"^(-1)], rateconst["vh", True] -> 
     Unit[100000.00000000001, "Hour"^(-1)], rateconst["vh2o", True] -> 
     Unit[100000, "Hour"^(-1)]}}]
