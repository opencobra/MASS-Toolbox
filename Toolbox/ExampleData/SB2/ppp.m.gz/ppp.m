(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$977", "Stoichiometry" -> 
   SparseArray[Automatic, {17, 17}, 0, {1, {{0, 3, 5, 9, 11, 13, 16, 19, 22, 
      24, 26, 29, 32, 34, 36, 38, 43, 45}, {{7}, {8}, {13}, {1}, {12}, {6}, 
      {7}, {8}, {17}, {1}, {2}, {2}, {3}, {3}, {4}, {5}, {4}, {6}, {7}, {5}, 
      {6}, {14}, {6}, {8}, {7}, {8}, {1}, {3}, {9}, {1}, {3}, {9}, {9}, {10}, 
      {9}, {10}, {3}, {11}, {1}, {2}, {9}, {10}, {15}, {2}, {16}}}, {1, 1, 
     -1, -1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, 1, -1, -1, 
     1, -1, -1, 1, -1, -1, 1, 1, 1, -1, 2, -2, -1, 1, 1, -1, 1, 1, -1, 2, -1, 
     -1, -1}}], "Species" -> {metabolite["F6P", "c"], metabolite["G6P", "c"], 
    metabolite["GAP", "c"], metabolite["GL6P", "c"], metabolite["GO6P", "c"], 
    metabolite["RU5P", "c"], metabolite["X5P", "c"], metabolite["R5P", "c"], 
    metabolite["S7P", "c"], metabolite["E4P", "c"], metabolite["NADP", "c"], 
    metabolite["NADPH", "c"], metabolite["GSH", "c"], 
    metabolite["GSSG", "c"], metabolite["CO2", "c"], metabolite["H", "c"], 
    metabolite["H2O", "c"]}, "Fluxes" -> {v["G6PDH"], v["PGLASE"], 
    v["GL6PDH"], v["R5PE"], v["R5PI"], v["TKI"], v["TKII"], v["TALA"], 
    v["GSSGR"], v["GSHR"], v["CO2"], v["EX_G6P_C"], v["EX_F6P_C"], 
    v["EX_R5P_C"], v["EX_H_C"], v["EX_H2O_C"], v["EX_GAP_C"]}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17}, "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "Name" -> "PentosePhosphatePathway", "ElementalComposition" -> 
   {metabolite["CO2", "c"] -> "C" + 2*"O", metabolite["E4P", "c"] -> 
     4*"C" + 7*"H" + 7*"O" + "P" - 2*"q", metabolite["F6P", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P" - 2*"q", metabolite["G6P", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P" - 2*"q", metabolite["GAP", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P" - 2*"q", metabolite["GL6P", "c"] -> 
     6*"C" + 9*"H" + 9*"O" + "P" - 2*"q", metabolite["GO6P", "c"] -> 
     6*"C" + 10*"H" + 10*"O" + "P" - 3*"q", metabolite["GSH", "c"] -> 
     10*"C" + 17*"H" + 3*"N" + 6*"O" - "q" + "S", metabolite["GSSG", "c"] -> 
     20*"C" + 32*"H" + 6*"N" + 12*"O" - 2*"q" + 2*"S", 
    metabolite["H", "c"] -> "H" + "q", metabolite["H2O", "c"] -> 2*"H" + "O", 
    metabolite["NADP", "c"] -> "&NADP&" - 3*"q", metabolite["NADPH", "c"] -> 
     "H" + "&NADP&" - 4*"q", metabolite["R5P", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P" - 2*"q", metabolite["RU5P", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P" - 2*"q", metabolite["S7P", "c"] -> 
     7*"C" + 13*"H" + 10*"O" + "P" - 2*"q", metabolite["X5P", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P" - 2*"q"}, 
  "Ignore" -> {metabolite["H", "c"], metabolite["H2O", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "Constraints" -> {v["EX_F6P_C"] -> {-Infinity, Infinity}, 
    v["EX_G6P_C"] -> {-0.21, Infinity}, v["EX_GAP_C"] -> {0, Infinity}, 
    v["EX_H2O_C"] -> {-Infinity, Infinity}, v["EX_H_C"] -> {0, Infinity}, 
    v["EX_R5P_C"] -> {0.01, 0.01}}, "InitialConditions" -> 
   {metabolite["G6P", "c"] -> Unit[0.0486, "Millimole"/"Liter"], 
    metabolite["F6P", "c"] -> Unit[0.0198, "Millimole"/"Liter"], 
    metabolite["GAP", "c"] -> Unit[0.00728, "Millimole"/"Liter"], 
    metabolite["GL6P", "c"] -> Unit[0.001754242723, "Millimole"/"Liter"], 
    metabolite["GO6P", "c"] -> Unit[0.037475258, "Millimole"/"Liter"], 
    metabolite["RU5P", "c"] -> Unit[0.0049367903, "Millimole"/"Liter"], 
    metabolite["X5P", "c"] -> Unit[0.014784196, "Millimole"/"Liter"], 
    metabolite["R5P", "c"] -> Unit[0.012668936, "Millimole"/"Liter"], 
    metabolite["S7P", "c"] -> Unit[0.023987984, "Millimole"/"Liter"], 
    metabolite["E4P", "c"] -> Unit[0.0050750696, "Millimole"/"Liter"], 
    metabolite["NADP", "c"] -> Unit[0.0002, "Millimole"/"Liter"], 
    metabolite["NADPH", "c"] -> Unit[0.0658, "Millimole"/"Liter"], 
    metabolite["GSH", "c"] -> Unit[3.2, "Millimole"/"Liter"], 
    metabolite["GSSG", "c"] -> Unit[0.11999999999999966, 
      "Millimole"/"Liter"], metabolite["CO2", "c"] -> 
     Unit[1.0000021, "Millimole"/"Liter"], metabolite["H", "c"] -> 
     Unit[0.0000714957344480193, "Millimole"/"Liter"], 
    metabolite["H2O", "c"] -> Unit[0.9999979, "Millimole"/"Liter"], 
    v["G6PDH"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["PGLASE"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["GL6PDH"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["R5PE"] -> Unit[0.1333333333333333, "Millimole"/("Hour"*"Liter")], 
    v["R5PI"] -> Unit[0.07666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["TKI"] -> Unit[0.06666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["TKII"] -> Unit[0.06666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["TALA"] -> Unit[0.06666666666666665, "Millimole"/("Hour"*"Liter")], 
    v["GSSGR"] -> Unit[0.42, "Millimole"/("Hour"*"Liter")], 
    v["GSHR"] -> Unit[0.42, "Millimole"/("Hour"*"Liter")], 
    v["CO2"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["EX_G6P_C"] -> Unit[-0.21, "Millimole"/("Hour"*"Liter")], 
    v["EX_F6P_C"] -> Unit[0.1333333333333333, "Millimole"/("Hour"*"Liter")], 
    v["EX_R5P_C"] -> Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["EX_H_C"] -> Unit[0.84, "Millimole"/("Hour"*"Liter")], 
    v["EX_H2O_C"] -> Unit[-0.21, "Millimole"/("Hour"*"Liter")], 
    v["EX_GAP_C"] -> Unit[0.06666666666666665, 
      "Millimole"/("Hour"*"Liter")]}, "Notes" -> "Model constructed on Wed 6 \
Mar 2013 11:21:59 by niko on Nikolauss-MacBook-Pro.ucsd.edu using Mathematica \
9.0 for Mac OS X x86 (64-bit) (November 20, 2012) at the following geodetic \
location: latitude 32.88; longitude -117.24\nModel constructed on Wed 6 Mar \
2013 11:22:01 by niko on Nikolauss-MacBook-Pro.ucsd.edu using Mathematica 9.0 \
for Mac OS X x86 (64-bit) (November 20, 2012) at the following geodetic \
location: latitude 32.88; longitude -117.24", 
  "Parameters" -> {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["EX_R5P_C"] -> Infinity, Keq["EX_H_C"] -> 1, Keq["EX_H2O_C"] -> 1, 
    Keq["EX_G6P_C"] -> 1, Keq["EX_GAP_C"] -> Infinity, 
    Keq["EX_F6P_C"] -> Infinity, Keq["G6PDH"] -> 1000, Keq["PGLASE"] -> 1000, 
    Keq["GL6PDH"] -> Unit[1000, "Millimole"/"Liter"], Keq["R5PE"] -> 3, 
    Keq["R5PI"] -> 2.57, Keq["TKI"] -> 1.2, Keq["TKII"] -> 10.3, 
    Keq["TALA"] -> 1.05, Keq["GSSGR"] -> Unit[100, "Millimole"/"Liter"], 
    Keq["GSHR"] -> Unit[2, "Liter"/"Millimole"], Keq["CO2"] -> 1, 
    metabolite["H", "Xt"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], metabolite["CO2", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["G6P", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["F6P", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["R5P", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["H2O", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["GAP", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], rateconst["G6PDH", True] -> 
     Unit[21864.5896565954, "Liter"/("Hour"*"Millimole")], 
    rateconst["PGLASE", True] -> Unit[122.32291459460994, "Hour"^(-1)], 
    rateconst["GL6PDH", True] -> Unit[29287.844651669573, 
      "Liter"/("Hour"*"Millimole")], rateconst["R5PE", True] -> 
     Unit[15281.81578535149, "Hour"^(-1)], rateconst["R5PI", True] -> 
     Unit[10584.613581831474, "Hour"^(-1)], rateconst["TKI", True] -> 
     Unit[1595.9298680575926, "Liter"/("Hour"*"Millimole")], 
    rateconst["TKII", True] -> Unit[1092.246904389965, 
      "Liter"/("Hour"*"Millimole")], rateconst["TALA", True] -> 
     Unit[844.6173037124239, "Liter"/("Hour"*"Millimole")], 
    rateconst["GSSGR", True] -> Unit[53.32981187273998, 
      "Liter"/("Hour"*"Millimole")], rateconst["GSHR", True] -> 
     Unit[0.04125736738703339, "Liter"/("Hour"*"Millimole")], 
    rateconst["CO2", True] -> Unit[100000.0000050546, "Hour"^(-1)], 
    rateconst["EX_G6P_C", True] -> Unit[0.22072734916964473, "Hour"^(-1)], 
    rateconst["EX_F6P_C", True] -> Unit[6.734006734006732, "Hour"^(-1)], 
    rateconst["EX_R5P_C", True] -> Unit[0.789332269102946, "Hour"^(-1)], 
    rateconst["EX_H_C", True] -> Unit[99999.99999999999, "Hour"^(-1)], 
    rateconst["EX_H2O_C", True] -> Unit[99999.99999976781, "Hour"^(-1)], 
    rateconst["EX_GAP_C", True] -> Unit[9.157509157509157, "Hour"^(-1)]}}]
