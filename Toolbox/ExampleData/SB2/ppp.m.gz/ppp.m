(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$977", "Stoichiometry" -> 
   SparseArray[Automatic, {17, 17}, 0, {1, {{0, 3, 5, 9, 11, 13, 16, 19, 22, 
      24, 26, 29, 32, 34, 36, 38, 43, 45}, {{7}, {8}, {13}, {1}, {12}, {6}, 
      {7}, {8}, {17}, {1}, {2}, {2}, {3}, {3}, {4}, {5}, {4}, {6}, {7}, {5}, 
      {6}, {14}, {6}, {8}, {7}, {8}, {1}, {3}, {9}, {1}, {3}, {9}, {9}, {10}, 
      {9}, {10}, {3}, {11}, {1}, {2}, {9}, {10}, {15}, {2}, {16}}}, {1, 1, 
     -1, -1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, 1, -1, -1, 
     1, -1, -1, 1, -1, -1, 1, 1, 1, -1, 2, -2, -1, 1, 1, -1, 1, 1, -1, 2, -1, 
     -1, -1}}], "Species" -> {metabolite["f6p", "c"], metabolite["g6p", "c"], 
    metabolite["gap", "c"], metabolite["gl6p", "c"], metabolite["go6p", "c"], 
    metabolite["ru5p", "c"], metabolite["x5p", "c"], metabolite["r5p", "c"], 
    metabolite["s7p", "c"], metabolite["e4p", "c"], metabolite["nadp", "c"], 
    metabolite["nadph", "c"], metabolite["gsh", "c"], 
    metabolite["gssg", "c"], metabolite["co2", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"]}, "Fluxes" -> {v["vg6pdh"], v["vpglase"], 
    v["vgl6pdh"], v["vr5pe"], v["vr5pi"], v["vtki"], v["vtkii"], v["vtala"], 
    v["vgssgr"], v["vgshr"], v["vco2"], v["EX_g6p_c"], v["EX_f6p_c"], 
    v["EX_r5p_c"], v["EX_h_c"], v["EX_h2o_c"], v["EX_gap_c"]}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17}, "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$977", "ElementalComposition" -> 
   {metabolite["co2", "c"] -> "C" + 2*"O", metabolite["e4p", "c"] -> 
     4*"C" + 7*"H" + 7*"O" + "P", metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["g6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["gap", "c"] -> 
     3*"C" + 5*"H" + 6*"O" + "P", metabolite["gl6p", "c"] -> 
     6*"C" + 9*"H" + 9*"O" + "P", metabolite["go6p", "c"] -> 
     6*"C" + 10*"H" + 10*"O" + "P", metabolite["gsh", "c"] -> 
     10*"C" + 17*"H" + 3*"N" + 6*"O" + "S", metabolite["gssg", "c"] -> 
     20*"C" + 32*"H" + 6*"N" + 12*"O" + 2*"S", metabolite["h", "c"] -> "H", 
    metabolite["h2o", "c"] -> 2*"H" + "O", metabolite["nadp", "c"] -> 
     "&NADP&", metabolite["nadph", "c"] -> "H" + "&NADP&", 
    metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["ru5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["s7p", "c"] -> 7*"C" + 13*"H" + 10*"O" + "P", 
    metabolite["x5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "Constraints" -> {v["EX_f6p_c"] -> {-Infinity, Infinity}, 
    v["EX_g6p_c"] -> {-0.21, Infinity}, v["EX_gap_c"] -> {0, Infinity}, 
    v["EX_h2o_c"] -> {-Infinity, Infinity}, v["EX_h_c"] -> {0, Infinity}, 
    v["EX_r5p_c"] -> {0.01, 0.01}}, "InitialConditions" -> 
   {metabolite["g6p", "c"] -> Quantity[0.0486, "Millimoles"/"Liters"], 
    metabolite["f6p", "c"] -> Quantity[0.0198, "Millimoles"/"Liters"], 
    metabolite["gap", "c"] -> Quantity[0.00728, "Millimoles"/"Liters"], 
    metabolite["gl6p", "c"] -> Quantity[0.001754242723, 
      "Millimoles"/"Liters"], metabolite["go6p", "c"] -> 
     Quantity[0.037475258, "Millimoles"/"Liters"], 
    metabolite["ru5p", "c"] -> Quantity[0.0049367903, "Millimoles"/"Liters"], 
    metabolite["x5p", "c"] -> Quantity[0.014784196, "Millimoles"/"Liters"], 
    metabolite["r5p", "c"] -> Quantity[0.012668936, "Millimoles"/"Liters"], 
    metabolite["s7p", "c"] -> Quantity[0.023987984, "Millimoles"/"Liters"], 
    metabolite["e4p", "c"] -> Quantity[0.0050750696, "Millimoles"/"Liters"], 
    metabolite["nadp", "c"] -> Quantity[0.0002, "Millimoles"/"Liters"], 
    metabolite["nadph", "c"] -> Quantity[0.0658, "Millimoles"/"Liters"], 
    metabolite["gsh", "c"] -> Quantity[3.2, "Millimoles"/"Liters"], 
    metabolite["gssg", "c"] -> Quantity[0.11999999999999966, 
      "Millimoles"/"Liters"], metabolite["co2", "c"] -> 
     Quantity[1.0000021, "Millimoles"/"Liters"], metabolite["h", "c"] -> 
     Quantity[0.0000714957344480193, "Millimoles"/"Liters"], 
    metabolite["h2o", "c"] -> Quantity[0.9999979, "Millimoles"/"Liters"], 
    v["vg6pdh"] -> Quantity[0.21, "Millimoles"/("Hours"*"Liters")], 
    v["vpglase"] -> Quantity[0.21, "Millimoles"/("Hours"*"Liters")], 
    v["vgl6pdh"] -> Quantity[0.21, "Millimoles"/("Hours"*"Liters")], 
    v["vr5pe"] -> Quantity[0.1333333333333333, "Millimoles"/
       ("Hours"*"Liters")], v["vr5pi"] -> Quantity[0.07666666666666665, 
      "Millimoles"/("Hours"*"Liters")], v["vtki"] -> 
     Quantity[0.06666666666666665, "Millimoles"/("Hours"*"Liters")], 
    v["vtkii"] -> Quantity[0.06666666666666665, 
      "Millimoles"/("Hours"*"Liters")], v["vtala"] -> 
     Quantity[0.06666666666666665, "Millimoles"/("Hours"*"Liters")], 
    v["vgssgr"] -> Quantity[0.42, "Millimoles"/("Hours"*"Liters")], 
    v["vgshr"] -> Quantity[0.42, "Millimoles"/("Hours"*"Liters")], 
    v["vco2"] -> Quantity[0.21, "Millimoles"/("Hours"*"Liters")], 
    v["EX_g6p_c"] -> Quantity[-0.21, "Millimoles"/("Hours"*"Liters")], 
    v["EX_f6p_c"] -> Quantity[0.1333333333333333, 
      "Millimoles"/("Hours"*"Liters")], v["EX_r5p_c"] -> 
     Quantity[0.01, "Millimoles"/("Hours"*"Liters")], 
    v["EX_h_c"] -> Quantity[0.84, "Millimoles"/("Hours"*"Liters")], 
    v["EX_h2o_c"] -> Quantity[-0.21, "Millimoles"/("Hours"*"Liters")], 
    v["EX_gap_c"] -> Quantity[0.06666666666666665, 
      "Millimoles"/("Hours"*"Liters")]}, "Notes" -> "Model constructed on Wed \
6 Mar 2013 11:21:59 by niko on Nikolauss-MacBook-Pro.ucsd.edu using \
Mathematica 9.0 for Mac OS X x86 (64-bit) (November 20, 2012) at the \
following geodetic location: latitude 32.88; longitude -117.24\nModel \
constructed on Wed 6 Mar 2013 11:22:01 by niko on \
Nikolauss-MacBook-Pro.ucsd.edu using Mathematica 9.0 for Mac OS X x86 \
(64-bit) (November 20, 2012) at the following geodetic location: latitude \
32.88; longitude -117.24", "Parameters" -> 
   {parameter["Volume", "c"] -> Quantity[1, "Liters"], 
    Keq["EX_r5p_c"] -> Infinity, Keq["EX_h_c"] -> 1, Keq["EX_h2o_c"] -> 1, 
    Keq["EX_g6p_c"] -> 1, Keq["EX_gap_c"] -> Infinity, 
    Keq["EX_f6p_c"] -> Infinity, Keq["vg6pdh"] -> 1000, 
    Keq["vpglase"] -> 1000, Keq["vgl6pdh"] -> Quantity[1000, 
      "Millimoles"/"Liters"], Keq["vr5pe"] -> 3, Keq["vr5pi"] -> 2.57, 
    Keq["vtki"] -> 1.2, Keq["vtkii"] -> 10.3, Keq["vtala"] -> 1.05, 
    Keq["vgssgr"] -> Quantity[100, "Millimoles"/"Liters"], 
    Keq["vgshr"] -> Quantity[2, "Liters"/"Millimoles"], Keq["vco2"] -> 1, 
    metabolite["h", "Xt"] -> Quantity[0.00006309573444801929, 
      "Millimoles"/"Liters"], metabolite["co2", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["g6p", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["f6p", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["r5p", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["h2o", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], metabolite["gap", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], rateconst["vg6pdh", True] -> 
     Quantity[21864.5896565954, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vpglase", True] -> Quantity[122.32291459460994, "Hours"^(-1)], 
    rateconst["vgl6pdh", True] -> Quantity[29287.844651669573, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vr5pe", True] -> 
     Quantity[15281.81578535149, "Hours"^(-1)], rateconst["vr5pi", True] -> 
     Quantity[10584.613581831474, "Hours"^(-1)], rateconst["vtki", True] -> 
     Quantity[1595.9298680575926, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vtkii", True] -> Quantity[1092.246904389965, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vtala", True] -> 
     Quantity[844.6173037124239, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vgssgr", True] -> Quantity[53.32981187273998, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vgshr", True] -> 
     Quantity[0.04125736738703339, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vco2", True] -> Quantity[100000.0000050546, "Hours"^(-1)], 
    rateconst["EX_g6p_c", True] -> Quantity[0.22072734916964473, 
      "Hours"^(-1)], rateconst["EX_f6p_c", True] -> 
     Quantity[6.734006734006732, "Hours"^(-1)], 
    rateconst["EX_r5p_c", True] -> Quantity[0.789332269102946, "Hours"^(-1)], 
    rateconst["EX_h_c", True] -> Quantity[99999.99999999999, "Hours"^(-1)], 
    rateconst["EX_h2o_c", True] -> Quantity[99999.99999976781, "Hours"^(-1)], 
    rateconst["EX_gap_c", True] -> Quantity[9.157509157509157, 
      "Hours"^(-1)]}}]
