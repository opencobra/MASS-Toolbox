(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$568", "Stoichiometry" -> 
   SparseArray[Automatic, {15, 19}, 0, {1, {{0, 2, 6, 9, 14, 19, 26, 28, 30, 
      34, 37, 43, 45, 47, 49, 52}, {{2}, {4}, {1}, {3}, {5}, {6}, {5}, {15}, 
      {19}, {4}, {5}, {6}, {7}, {16}, {6}, {9}, {15}, {17}, {19}, {1}, {4}, 
      {6}, {7}, {9}, {18}, {19}, {8}, {13}, {7}, {9}, {1}, {9}, {10}, {13}, 
      {1}, {7}, {11}, {4}, {6}, {9}, {12}, {13}, {19}, {4}, {15}, {13}, {14}, 
      {14}, {15}, {5}, {15}, {19}}}, {-1, -1, -1, -1, -1, 1, 1, 2, -1, 1, 1, 
     -1, -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, 
     1, -1, -1, 1, 1, -1, 2, 1, 1, -1, -1, -1, -1, 1, 1, -1, 1, -1, -1, -2, 
     1}}], "Species" -> {metabolite["ade", "c"], metabolite["ado", "c"], 
    metabolite["adp", "c"], metabolite["amp", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["hyp", "c"], metabolite["imp", "c"], 
    metabolite["ino", "c"], metabolite["nh3", "c"], metabolite["phos", "c"], 
    metabolite["prpp", "c"], metabolite["r1p", "c"], metabolite["r5p", "c"], 
    metabolite["atp", "c"]}, "Fluxes" -> {v["vada"], v["vade"], v["vado"], 
    v["vadprt"], v["vak"], v["vampase"], v["vampda"], v["vhyp"], 
    v["vimpase"], v["vino"], v["vnh3"], v["vphos"], v["vpnpase"], v["vprm"], 
    v["vprppsyn"], v["vamp"], v["vh"], v["vh2o"], v["vatpgen"]}, 
  "Constraints" -> {}, "InitialConditions" -> 
   {metabolite["r5p", "c"] -> Unit[0.00494, "Millimole"/"Liter"], 
    metabolite["ade", "c"] -> Unit[0.001, "Millimole"/"Liter"], 
    metabolite["ado", "c"] -> Unit[0.0012, "Millimole"/"Liter"], 
    metabolite["imp", "c"] -> Unit[0.01, "Millimole"/"Liter"], 
    metabolite["ino", "c"] -> Unit[0.001, "Millimole"/"Liter"], 
    metabolite["hyp", "c"] -> Unit[0.002, "Millimole"/"Liter"], 
    metabolite["r1p", "c"] -> Unit[0.06, "Millimole"/"Liter"], 
    metabolite["prpp", "c"] -> Unit[0.005, "Millimole"/"Liter"], 
    metabolite["amp", "c"] -> Unit[0.08672812499999999, "Millimole"/"Liter"], 
    metabolite["adp", "c"] -> Unit[0.29, "Millimole"/"Liter"], 
    metabolite["atp", "c"] -> Unit[1.6, "Millimole"/"Liter"], 
    metabolite["phos", "c"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["h", "c"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "c"] -> 
     Unit[0.99999976, "Millimole"/"Liter"], metabolite["nh3", "c"] -> 
     Unit[0.091, "Millimole"/"Liter"], v["vak"] -> 
     Unit[0.12, "Millimole"/("Hour"*"Liter")], 
    v["vampase"] -> Unit[0.12, "Millimole"/("Hour"*"Liter")], 
    v["vampda"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vimpase"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vada"] -> Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["vpnpase"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vprm"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vatpgen"] -> Unit[0.148, "Millimole"/("Hour"*"Liter")], 
    v["vprppsyn"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vadprt"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vado"] -> Unit[-0.009999999999999995, "Millimole"/("Hour"*"Liter")], 
    v["vade"] -> Unit[-0.014, "Millimole"/("Hour"*"Liter")], 
    v["vino"] -> Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["vhyp"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["vamp"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vh"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vh2o"] -> Unit[-0.024000000000000007, "Millimole"/("Hour"*"Liter")], 
    v["vphos"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["vnh3"] -> Unit[0.024, "Millimole"/("Hour"*"Liter")]}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17, 18, 19}, "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$568", "ElementalComposition" -> 
   {metabolite["ade", "c"] -> 5*"C" + 5*"H" + 5*"N", 
    metabolite["ado", "c"] -> 10*"C" + 13*"H" + 5*"N" + 4*"O", 
    metabolite["adp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["hyp", "c"] -> 5*"C" + 4*"H" + 4*"N" + "O", 
    metabolite["imp", "c"] -> 10*"C" + 12*"H" + 4*"N" + 8*"O" + "P", 
    metabolite["ino", "c"] -> 10*"C" + 12*"H" + 4*"N" + 5*"O", 
    metabolite["nh3", "c"] -> 3*"H" + "N", metabolite["phos", "c"] -> 
     "H" + 4*"O" + "P", metabolite["prpp", "c"] -> 5*"C" + 8*"H" + 14*"O" + 
      3*"P", metabolite["r1p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "Parameters" -> {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["vak"] -> 1000000, Keq["vampase"] -> Unit[1000000, 
      "Millimole"/"Liter"], Keq["vada"] -> Unit[1000000, 
      "Millimole"/"Liter"], Keq["vampda"] -> Unit[1000000, 
      "Millimole"/"Liter"], Keq["vimpase"] -> Unit[1000000, 
      "Millimole"/"Liter"], Keq["vpnpase"] -> 0.09, Keq["vprm"] -> 13.3, 
    Keq["vprppsyn"] -> 1000000, Keq["vadprt"] -> 
     Unit[1000000, "Millimole"/"Liter"], Keq["vade"] -> 1, Keq["vado"] -> 1, 
    Keq["vino"] -> 1, Keq["vhyp"] -> 1, Keq["vphos"] -> 1, Keq["vnh3"] -> 1, 
    Keq["vatpgen"] -> Unit[1000000, "Liter"/"Millimole"], Keq["vh"] -> 1, 
    Keq["vh2o"] -> 1, Keq["vamp"] -> 1, metabolite["ado", "Xt"] -> 
     Unit[0.0012001, "Millimole"/"Liter"], metabolite["ade", "Xt"] -> 
     Unit[0.00100014, "Millimole"/"Liter"], metabolite["ino", "Xt"] -> 
     Unit[0.0009999, "Millimole"/"Liter"], metabolite["hyp", "Xt"] -> 
     Unit[0.00199986, "Millimole"/"Liter"], metabolite["phos", "Xt"] -> 
     Unit[2.5, "Millimole"/"Liter"], metabolite["nh3", "Xt"] -> 
     Unit[0.0909999, "Millimole"/"Liter"], metabolite["amp", "Xt"] -> 
     Unit[0.09540093749999999, "Millimole"/"Liter"], 
    metabolite["h", "Xt"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], rateconst["vada", True] -> 
     Unit[8.333333965277827, "Hour"^(-1)], rateconst["vado", True] -> 
     Unit[99999.9999999433, "Hour"^(-1)], rateconst["vadprt", True] -> 
     Unit[3140.4574868453906, "Liter"/("Hour"*"Millimole")], 
    rateconst["vak", True] -> Unit[62.50081873325923, 
      "Liter"/("Hour"*"Millimole")], rateconst["vampase", True] -> 
     Unit[1.3836342495690155, "Hour"^(-1)], rateconst["vampda", True] -> 
     Unit[0.1614239918930086, "Hour"^(-1)], rateconst["vimpase", True] -> 
     Unit[1.4000003500000875, "Hour"^(-1)], rateconst["vpnpase", True] -> 
     Unit[12., "Liter"/("Hour"*"Millimole")], rateconst["vprm", True] -> 
     Unit[0.2347867752755151, "Hour"^(-1)], rateconst["vprppsyn", True] -> 
     Unit[1.107034449764991, "Liter"^2/("Hour"*"Millimole"^2)], 
    rateconst["vh2o", True] -> Unit[100000.00000637631, "Hour"^(-1)], 
    rateconst["vatpgen", True] -> Unit[0.20413838154677308, 
      "Liter"/("Hour"*"Millimole")], rateconst["vh", True] -> 
     Unit[100000, "Hour"^(-1)], rateconst["vade", True] -> 
     Unit[100000, "Hour"^(-1)], rateconst["vino", True] -> 
     Unit[100000, "Hour"^(-1)], rateconst["vhyp", True] -> 
     Unit[100000, "Hour"^(-1)], rateconst["vnh3", True] -> 
     Unit[100000, "Hour"^(-1)], rateconst["vphos", True] -> 
     Unit[100000, "Hour"^(-1)], rateconst["vamp", True] -> 
     Unit[100000, "Hour"^(-1)]}, "Notes" -> "\nModel constructed on Wed 6 Mar \
2013 11:27:41 by niko on Nikolauss-MacBook-Pro.ucsd.edu using Mathematica 9.0 \
for Mac OS X x86 (64-bit) (November 20, 2012) at the following geodetic \
location: latitude 32.88; longitude -117.24"}]
