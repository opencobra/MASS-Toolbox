(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$568", "Stoichiometry" -> 
   SparseArray[Automatic, {15, 19}, 0, {1, {{0, 5, 8, 11, 17, 22, 29, 32, 36, 
      38, 40, 44, 46, 48, 50, 52}, {{1}, {2}, {3}, {10}, {15}, {1}, {8}, {9}, 
      {1}, {8}, {9}, {2}, {4}, {6}, {8}, {10}, {18}, {2}, {4}, {8}, {9}, 
      {16}, {2}, {3}, {4}, {5}, {8}, {10}, {17}, {3}, {5}, {19}, {1}, {2}, 
      {5}, {11}, {10}, {12}, {3}, {4}, {4}, {5}, {6}, {13}, {6}, {14}, {6}, 
      {7}, {7}, {9}, {9}, {10}}}, {1, -1, -1, 1, -1, 1, -1, 2, -1, 1, -2, 1, 
     1, -1, -1, 2, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 
     -1, 1, -1, -1, -1, -1, 1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 1, -1, 1, 
     -1}}], "Species" -> {metabolite["AMP", "c"], metabolite["ADP", "c"], 
    metabolite["ATP", "c"], metabolite["PHOS", "c"], metabolite["H", "c"], 
    metabolite["H2O", "c"], metabolite["NH3", "c"], metabolite["ADO", "c"], 
    metabolite["ADE", "c"], metabolite["IMP", "c"], metabolite["INO", "c"], 
    metabolite["HYP", "c"], metabolite["R1P", "c"], metabolite["R5P", "c"], 
    metabolite["PRPP", "c"]}, "Fluxes" -> {v["AK"], v["AMPASE"], v["AMPDA"], 
    v["IMPASE"], v["ADA"], v["PNPASE"], v["PRM"], v["ATPGEN"], v["PRPPSYN"], 
    v["ADPRT"], v["ADO"], v["ADE"], v["INO"], v["HYP"], v["AMP"], v["H"], 
    v["H2O"], v["PHOS"], v["NH3"]}, "Constraints" -> {}, 
  "InitialConditions" -> {metabolite["R5P", "c"] -> 
     Quantity[0.00494, "Millimoles"/"Liters"], metabolite["ADE", "c"] -> 
     Quantity[0.001, "Millimoles"/"Liters"], metabolite["ADO", "c"] -> 
     Quantity[0.0012, "Millimoles"/"Liters"], metabolite["IMP", "c"] -> 
     Quantity[0.01, "Millimoles"/"Liters"], metabolite["INO", "c"] -> 
     Quantity[0.001, "Millimoles"/"Liters"], metabolite["HYP", "c"] -> 
     Quantity[0.002, "Millimoles"/"Liters"], metabolite["R1P", "c"] -> 
     Quantity[0.06, "Millimoles"/"Liters"], metabolite["PRPP", "c"] -> 
     Quantity[0.005, "Millimoles"/"Liters"], metabolite["AMP", "c"] -> 
     Quantity[0.08672812499999999, "Millimoles"/"Liters"], 
    metabolite["ADP", "c"] -> Quantity[0.29, "Millimoles"/"Liters"], 
    metabolite["ATP", "c"] -> Quantity[1.6, "Millimoles"/"Liters"], 
    metabolite["PHOS", "c"] -> Quantity[2.5, "Millimoles"/"Liters"], 
    metabolite["H", "c"] -> Quantity[0.00006309573444801929, 
      "Millimoles"/"Liters"], metabolite["H2O", "c"] -> 
     Quantity[0.99999976, "Millimoles"/"Liters"], metabolite["NH3", "c"] -> 
     Quantity[0.091, "Millimoles"/"Liters"], 
    v["AK"] -> Quantity[0.12, "Millimoles"/("Hours"*"Liters")], 
    v["AMPASE"] -> Quantity[0.12, "Millimoles"/("Hours"*"Liters")], 
    v["AMPDA"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["IMPASE"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["ADA"] -> Quantity[0.01, "Millimoles"/("Hours"*"Liters")], 
    v["PNPASE"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["PRM"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["ATPGEN"] -> Quantity[0.148, "Millimoles"/("Hours"*"Liters")], 
    v["PRPPSYN"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["ADPRT"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["ADO"] -> Quantity[-0.009999999999999995, 
      "Millimoles"/("Hours"*"Liters")], v["ADE"] -> 
     Quantity[-0.014, "Millimoles"/("Hours"*"Liters")], 
    v["INO"] -> Quantity[0.01, "Millimoles"/("Hours"*"Liters")], 
    v["HYP"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["AMP"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["H"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["H2O"] -> Quantity[-0.024000000000000007, 
      "Millimoles"/("Hours"*"Liters")], v["PHOS"] -> 
     Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["NH3"] -> Quantity[0.024, "Millimoles"/("Hours"*"Liters")]}, 
  "GPR" -> {}, "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17, 18, 19}, "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$568", "ElementalComposition" -> 
   {metabolite["ADE", "c"] -> 5*"C" + 5*"H" + 5*"N", 
    metabolite["ADO", "c"] -> 10*"C" + 13*"H" + 5*"N" + 4*"O", 
    metabolite["ADP", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P" - 
      3*"q", metabolite["AMP", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + 
      "P" - 2*"q", metabolite["ATP", "c"] -> 10*"C" + 13*"H" + 5*"N" + 
      13*"O" + 3*"P" - 4*"q", metabolite["H", "c"] -> "H" + "q", 
    metabolite["H2O", "c"] -> 2*"H" + "O", metabolite["HYP", "c"] -> 
     5*"C" + 4*"H" + 4*"N" + "O", metabolite["IMP", "c"] -> 
     10*"C" + 12*"H" + 4*"N" + 8*"O" + "P" - 2*"q", 
    metabolite["INO", "c"] -> 10*"C" + 12*"H" + 4*"N" + 5*"O", 
    metabolite["NH3", "c"] -> 3*"H" + "N" + "q", metabolite["PHOS", "c"] -> 
     "H" + 4*"O" + "P" - 2*"q", metabolite["PRPP", "c"] -> 
     5*"C" + 8*"H" + 14*"O" + 3*"P" - 5*"q", metabolite["R1P", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P" - 2*"q", metabolite["R5P", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P" - 2*"q"}, 
  "Ignore" -> {metabolite["H", "c"], metabolite["H2O", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "Parameters" -> {parameter["Volume", "c"] -> Quantity[1, "Liters"], 
    Keq["AK"] -> 1000000, Keq["AMPASE"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["ADA"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["AMPDA"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["IMPASE"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["PNPASE"] -> 0.09, Keq["PRM"] -> 13.3, 
    Keq["PRPPSYN"] -> 1000000, Keq["ADPRT"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["ADE"] -> 1, Keq["ADO"] -> 1, 
    Keq["INO"] -> 1, Keq["HYP"] -> 1, Keq["PHOS"] -> 1, Keq["NH3"] -> 1, 
    Keq["ATPGEN"] -> Quantity[1000000, "Liters"/"Millimoles"], Keq["H"] -> 1, 
    Keq["H2O"] -> 1, Keq["AMP"] -> 1, metabolite["ADO", "Xt"] -> 
     Quantity[0.0012001, "Millimoles"/"Liters"], metabolite["ADE", "Xt"] -> 
     Quantity[0.00100014, "Millimoles"/"Liters"], metabolite["INO", "Xt"] -> 
     Quantity[0.0009999, "Millimoles"/"Liters"], metabolite["HYP", "Xt"] -> 
     Quantity[0.00199986, "Millimoles"/"Liters"], metabolite["PHOS", "Xt"] -> 
     Quantity[2.5, "Millimoles"/"Liters"], metabolite["NH3", "Xt"] -> 
     Quantity[0.0909999, "Millimoles"/"Liters"], metabolite["AMP", "Xt"] -> 
     Quantity[0.09540093749999999, "Millimoles"/"Liters"], 
    metabolite["H", "Xt"] -> Quantity[0.00006309573444801929, 
      "Millimoles"/"Liters"], metabolite["H2O", "Xt"] -> 
     Quantity[1, "Millimoles"/"Liters"], rateconst["ADA", True] -> 
     Quantity[8.333333965277827, "Hours"^(-1)], rateconst["ADO", True] -> 
     Quantity[99999.9999999433, "Hours"^(-1)], rateconst["ADPRT", True] -> 
     Quantity[3140.4574868453906, "Liters"/("Hours"*"Millimoles")], 
    rateconst["AK", True] -> Quantity[62.50081873325923, 
      "Liters"/("Hours"*"Millimoles")], rateconst["AMPASE", True] -> 
     Quantity[1.3836342495690155, "Hours"^(-1)], rateconst["AMPDA", True] -> 
     Quantity[0.1614239918930086, "Hours"^(-1)], rateconst["IMPASE", True] -> 
     Quantity[1.4000003500000875, "Hours"^(-1)], rateconst["PNPASE", True] -> 
     Quantity[12., "Liters"/("Hours"*"Millimoles")], 
    rateconst["PRM", True] -> Quantity[0.2347867752755151, "Hours"^(-1)], 
    rateconst["PRPPSYN", True] -> Quantity[1.107034449764991, 
      "Liters"^2/("Hours"*"Millimoles"^2)], rateconst["H2O", True] -> 
     Quantity[100000.00000637631, "Hours"^(-1)], rateconst["ATPGEN", True] -> 
     Quantity[0.20413838154677308, "Liters"/("Hours"*"Millimoles")], 
    rateconst["H", True] -> Quantity[100000, "Hours"^(-1)], 
    rateconst["ADE", True] -> Quantity[100000, "Hours"^(-1)], 
    rateconst["INO", True] -> Quantity[100000, "Hours"^(-1)], 
    rateconst["HYP", True] -> Quantity[100000, "Hours"^(-1)], 
    rateconst["NH3", True] -> Quantity[100000, "Hours"^(-1)], 
    rateconst["PHOS", True] -> Quantity[100000, "Hours"^(-1)], 
    rateconst["AMP", True] -> Quantity[100000, "Hours"^(-1)]}, 
  "Notes" -> "\nModel constructed on Wed 6 Mar 2013 11:27:41 by niko on \
Nikolauss-MacBook-Pro.ucsd.edu using Mathematica 9.0 for Mac OS X x86 \
(64-bit) (November 20, 2012) at the following geodetic location: latitude \
32.88; longitude -117.24"}]
