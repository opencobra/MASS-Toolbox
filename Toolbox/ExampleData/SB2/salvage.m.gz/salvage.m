(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$568", "Stoichiometry" -> 
   SparseArray[Automatic, {15, 19}, 0, {1, {{0, 5, 8, 11, 17, 22, 29, 32, 36, 
      38, 40, 44, 46, 48, 50, 52}, {{1}, {2}, {3}, {10}, {15}, {1}, {8}, {9}, 
      {1}, {8}, {9}, {2}, {4}, {6}, {8}, {10}, {18}, {1}, {8}, {9}, {10}, 
      {16}, {2}, {3}, {4}, {5}, {8}, {10}, {17}, {3}, {5}, {19}, {1}, {2}, 
      {5}, {11}, {10}, {12}, {3}, {4}, {4}, {5}, {6}, {13}, {6}, {14}, {6}, 
      {7}, {7}, {9}, {9}, {10}}}, {1, -1, -1, 1, -1, 1, -1, 2, -1, 1, -2, 1, 
     1, -1, -1, 2, -1, 1, -1, 1, 1, -1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 
     -1, 1, -1, -1, -1, -1, 1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 1, -1, 1, 
     -1}}], "Species" -> {metabolite["AMP", "c"], metabolite["ADP", "c"], 
    metabolite["ATP", "c"], metabolite["PHOS", "c"], metabolite["H", "c"], 
    metabolite["H2O", "c"], metabolite["NH3", "c"], metabolite["ADO", "c"], 
    metabolite["ADE", "c"], metabolite["IMP", "c"], metabolite["INO", "c"], 
    metabolite["HYP", "c"], metabolite["R1P", "c"], metabolite["R5P", "c"], 
    metabolite["PRPP", "c"]}, "Fluxes" -> {v["AK"], v["AMPASE"], v["AMPDA"], 
    v["IMPASE"], v["ADA"], v["PNPASE"], v["PRM"], v["ATPGEN"], v["PRPPSYN"], 
    v["ADPRT"], v["ADO"], v["ADE"], v["INO"], v["HYP"], v["AMP"], v["H"], 
    v["H2O"], v["PHOS"], v["NH3"]}, "Constraints" -> {}, 
  "InitialConditions" -> {metabolite["R5P", "c"] -> 
     Unit[0.00494, "Millimole"/"Liter"], metabolite["ADE", "c"] -> 
     Unit[0.001, "Millimole"/"Liter"], metabolite["ADO", "c"] -> 
     Unit[0.0012, "Millimole"/"Liter"], metabolite["IMP", "c"] -> 
     Unit[0.01, "Millimole"/"Liter"], metabolite["INO", "c"] -> 
     Unit[0.001, "Millimole"/"Liter"], metabolite["HYP", "c"] -> 
     Unit[0.002, "Millimole"/"Liter"], metabolite["R1P", "c"] -> 
     Unit[0.06, "Millimole"/"Liter"], metabolite["PRPP", "c"] -> 
     Unit[0.005, "Millimole"/"Liter"], metabolite["AMP", "c"] -> 
     Unit[0.08672812499999999, "Millimole"/"Liter"], 
    metabolite["ADP", "c"] -> Unit[0.29, "Millimole"/"Liter"], 
    metabolite["ATP", "c"] -> Unit[1.6, "Millimole"/"Liter"], 
    metabolite["PHOS", "c"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["H", "c"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], metabolite["H2O", "c"] -> 
     Unit[0.99999976, "Millimole"/"Liter"], metabolite["NH3", "c"] -> 
     Unit[0.091, "Millimole"/"Liter"], 
    v["AK"] -> Unit[0.12, "Millimole"/("Hour"*"Liter")], 
    v["AMPASE"] -> Unit[0.12, "Millimole"/("Hour"*"Liter")], 
    v["AMPDA"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["IMPASE"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["ADA"] -> Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["PNPASE"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["PRM"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["ATPGEN"] -> Unit[0.148, "Millimole"/("Hour"*"Liter")], 
    v["PRPPSYN"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["ADPRT"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["ADO"] -> Unit[-0.009999999999999995, "Millimole"/("Hour"*"Liter")], 
    v["ADE"] -> Unit[-0.014, "Millimole"/("Hour"*"Liter")], 
    v["INO"] -> Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["HYP"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["AMP"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["H"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["H2O"] -> Unit[-0.024000000000000007, "Millimole"/("Hour"*"Liter")], 
    v["PHOS"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["NH3"] -> Unit[0.024, "Millimole"/("Hour"*"Liter")]}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17, 18, 19}, "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "Name" -> "NucleotideSalvagePathway", "ElementalComposition" -> 
   {metabolite["ADE", "c"] -> 5*"C" + 5*"H" + 5*"N", 
    metabolite["ADO", "c"] -> 10*"C" + 13*"H" + 5*"N" + 4*"O", 
    metabolite["ADP", "c"] -> 10*"C" + 12*"H" + 5*"N" + 10*"O" + 2*"P" - 
      3*"q", metabolite["AMP", "c"] -> 10*"C" + 12*"H" + 5*"N" + 7*"O" + 
      "P" - 2*"q", metabolite["ATP", "c"] -> 10*"C" + 12*"H" + 5*"N" + 
      13*"O" + 3*"P" - 4*"q", metabolite["H", "c"] -> "H" + "q", 
    metabolite["H2O", "c"] -> 2*"H" + "O", metabolite["HYP", "c"] -> 
     5*"C" + 4*"H" + 4*"N" + "O", metabolite["IMP", "c"] -> 
     10*"C" + 11*"H" + 4*"N" + 8*"O" + "P" - 2*"q", 
    metabolite["INO", "c"] -> 10*"C" + 12*"H" + 4*"N" + 5*"O", 
    metabolite["NH3", "c"] -> 3*"H" + "N", metabolite["PHOS", "c"] -> 
     "H" + 4*"O" + "P" - 2*"q", metabolite["PRPP", "c"] -> 
     5*"C" + 8*"H" + 14*"O" + 3*"P" - 5*"q", metabolite["R1P", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P" - 2*"q", metabolite["R5P", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P" - 2*"q"}, 
  "Ignore" -> {metabolite["H", "c"], metabolite["H2O", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "Parameters" -> {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["AK"] -> 1000000, Keq["AMPASE"] -> Unit[1000000, 
      "Millimole"/"Liter"], Keq["ADA"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["AMPDA"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["IMPASE"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["PNPASE"] -> 0.09, Keq["PRM"] -> 13.3, Keq["PRPPSYN"] -> 1000000, 
    Keq["ADPRT"] -> Unit[1000000, "Millimole"/"Liter"], Keq["ADE"] -> 1, 
    Keq["ADO"] -> 1, Keq["INO"] -> 1, Keq["HYP"] -> 1, Keq["PHOS"] -> 1, 
    Keq["NH3"] -> 1, Keq["ATPGEN"] -> Unit[1000000, "Liter"/"Millimole"], 
    Keq["H"] -> 1, Keq["H2O"] -> 1, Keq["AMP"] -> 1, 
    metabolite["ADO", "Xt"] -> Unit[0.0012001, "Millimole"/"Liter"], 
    metabolite["ADE", "Xt"] -> Unit[0.00100014, "Millimole"/"Liter"], 
    metabolite["INO", "Xt"] -> Unit[0.0009999, "Millimole"/"Liter"], 
    metabolite["HYP", "Xt"] -> Unit[0.00199986, "Millimole"/"Liter"], 
    metabolite["PHOS", "Xt"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["NH3", "Xt"] -> Unit[0.0909999, "Millimole"/"Liter"], 
    metabolite["AMP", "Xt"] -> Unit[0.09540093749999999, 
      "Millimole"/"Liter"], metabolite["H", "Xt"] -> 
     Unit[0.00006309573444801929, "Millimole"/"Liter"], 
    metabolite["H2O", "Xt"] -> Unit[1, "Millimole"/"Liter"], 
    rateconst["ADA", True] -> Unit[8.333333965277827, "Hour"^(-1)], 
    rateconst["ADO", True] -> Unit[99999.9999999433, "Hour"^(-1)], 
    rateconst["ADPRT", True] -> Unit[3140.4574868453906, 
      "Liter"/("Hour"*"Millimole")], rateconst["AK", True] -> 
     Unit[62.50081873325923, "Liter"/("Hour"*"Millimole")], 
    rateconst["AMPASE", True] -> Unit[1.3836342495690155, "Hour"^(-1)], 
    rateconst["AMPDA", True] -> Unit[0.1614239918930086, "Hour"^(-1)], 
    rateconst["IMPASE", True] -> Unit[1.4000003500000875, "Hour"^(-1)], 
    rateconst["PNPASE", True] -> Unit[12., "Liter"/("Hour"*"Millimole")], 
    rateconst["PRM", True] -> Unit[0.2347867752755151, "Hour"^(-1)], 
    rateconst["PRPPSYN", True] -> Unit[1.107034449764991, 
      "Liter"^2/("Hour"*"Millimole"^2)], rateconst["H2O", True] -> 
     Unit[100000.00000637631, "Hour"^(-1)], rateconst["ATPGEN", True] -> 
     Unit[0.20413838154677308, "Liter"/("Hour"*"Millimole")], 
    rateconst["H", True] -> Unit[100000, "Hour"^(-1)], 
    rateconst["ADE", True] -> Unit[100000, "Hour"^(-1)], 
    rateconst["INO", True] -> Unit[100000, "Hour"^(-1)], 
    rateconst["HYP", True] -> Unit[100000, "Hour"^(-1)], 
    rateconst["NH3", True] -> Unit[100000, "Hour"^(-1)], 
    rateconst["PHOS", True] -> Unit[100000, "Hour"^(-1)], 
    rateconst["AMP", True] -> Unit[100000, "Hour"^(-1)]}, 
  "Notes" -> "\nModel constructed on Wed 6 Mar 2013 11:27:41 by niko on \
Nikolauss-MacBook-Pro.ucsd.edu using Mathematica 9.0 for Mac OS X x86 \
(64-bit) (November 20, 2012) at the following geodetic location: latitude \
32.88; longitude -117.24"}]
