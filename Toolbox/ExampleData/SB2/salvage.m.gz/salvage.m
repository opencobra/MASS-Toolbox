(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$568", "Stoichiometry" -> 
   SparseArray[Automatic, {15, 19}, 0, {1, {{0, 5, 8, 11, 17, 22, 29, 32, 36, 
      38, 40, 44, 46, 48, 50, 52}, {{1}, {2}, {3}, {10}, {15}, {1}, {8}, {9}, 
      {1}, {8}, {9}, {2}, {4}, {6}, {8}, {10}, {18}, {2}, {4}, {8}, {9}, 
      {16}, {2}, {3}, {4}, {5}, {8}, {10}, {17}, {3}, {5}, {19}, {1}, {2}, 
      {5}, {11}, {10}, {12}, {3}, {4}, {4}, {5}, {6}, {13}, {6}, {14}, {6}, 
      {7}, {7}, {9}, {9}, {10}}}, {1, -1, -1, 1, -1, 1, -1, 2, -1, 1, -2, 1, 
     1, -1, -1, 2, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 
     -1, 1, -1, -1, -1, -1, 1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 1, -1, 1, 
     -1}}], "Species" -> {metabolite["amp", "c"], metabolite["adp", "c"], 
    metabolite["atp", "c"], metabolite["phos", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["nh3", "c"], metabolite["ado", "c"], 
    metabolite["ade", "c"], metabolite["imp", "c"], metabolite["ino", "c"], 
    metabolite["hyp", "c"], metabolite["r1p", "c"], metabolite["r5p", "c"], 
    metabolite["prpp", "c"]}, "Fluxes" -> {v["vak"], v["vampase"], 
    v["vampda"], v["vimpase"], v["vada"], v["vpnpase"], v["vprm"], 
    v["vatpgen"], v["vprppsyn"], v["vadprt"], v["vado"], v["vade"], 
    v["vino"], v["vhyp"], v["vamp"], v["vh"], v["vh2o"], v["vphos"], 
    v["vnh3"]}, "Constraints" -> {}, "InitialConditions" -> 
   {metabolite["r5p", "c"] -> Quantity[0.00494, "Millimoles"/"Liters"], 
    metabolite["ade", "c"] -> Quantity[0.001, "Millimoles"/"Liters"], 
    metabolite["ado", "c"] -> Quantity[0.0012, "Millimoles"/"Liters"], 
    metabolite["imp", "c"] -> Quantity[0.01, "Millimoles"/"Liters"], 
    metabolite["ino", "c"] -> Quantity[0.001, "Millimoles"/"Liters"], 
    metabolite["hyp", "c"] -> Quantity[0.002, "Millimoles"/"Liters"], 
    metabolite["r1p", "c"] -> Quantity[0.06, "Millimoles"/"Liters"], 
    metabolite["prpp", "c"] -> Quantity[0.005, "Millimoles"/"Liters"], 
    metabolite["amp", "c"] -> Quantity[0.08672812499999999, 
      "Millimoles"/"Liters"], metabolite["adp", "c"] -> 
     Quantity[0.29, "Millimoles"/"Liters"], metabolite["atp", "c"] -> 
     Quantity[1.6, "Millimoles"/"Liters"], metabolite["phos", "c"] -> 
     Quantity[2.5, "Millimoles"/"Liters"], metabolite["h", "c"] -> 
     Quantity[0.00006309573444801929, "Millimoles"/"Liters"], 
    metabolite["h2o", "c"] -> Quantity[0.99999976, "Millimoles"/"Liters"], 
    metabolite["nh3", "c"] -> Quantity[0.091, "Millimoles"/"Liters"], 
    v["vak"] -> Quantity[0.12, "Millimoles"/("Hours"*"Liters")], 
    v["vampase"] -> Quantity[0.12, "Millimoles"/("Hours"*"Liters")], 
    v["vampda"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vimpase"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vada"] -> Quantity[0.01, "Millimoles"/("Hours"*"Liters")], 
    v["vpnpase"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vprm"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vatpgen"] -> Quantity[0.148, "Millimoles"/("Hours"*"Liters")], 
    v["vprppsyn"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vadprt"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vado"] -> Quantity[-0.009999999999999995, 
      "Millimoles"/("Hours"*"Liters")], v["vade"] -> 
     Quantity[-0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vino"] -> Quantity[0.01, "Millimoles"/("Hours"*"Liters")], 
    v["vhyp"] -> Quantity[0.014, "Millimoles"/("Hours"*"Liters")], 
    v["vamp"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["vh"] -> Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["vh2o"] -> Quantity[-0.024000000000000007, 
      "Millimoles"/("Hours"*"Liters")], v["vphos"] -> 
     Quantity[0., "Millimoles"/("Hours"*"Liters")], 
    v["vnh3"] -> Quantity[0.024, "Millimoles"/("Hours"*"Liters")]}, 
  "GPR" -> {}, "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 
    14, 15, 16, 17, 18, 19}, "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$568", "ElementalComposition" -> 
   {metabolite["ade", "c"] -> 5*"C" + 5*"H" + 5*"N", 
    metabolite["ado", "c"] -> 10*"C" + 13*"H" + 5*"N" + 4*"O", 
    metabolite["adp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["hyp", "c"] -> 5*"C" + 4*"H" + 4*"N" + "O", 
    metabolite["imp", "c"] -> 10*"C" + 12*"H" + 4*"N" + 8*"O" + "P", 
    metabolite["ino", "c"] -> 10*"C" + 12*"H" + 4*"N" + 5*"O", 
    metabolite["nh3", "c"] -> 3*"H" + "N", metabolite["phos", "c"] -> 
     "H" + 4*"O" + "P", metabolite["prpp", "c"] -> 5*"C" + 8*"H" + 14*"O" + 
      3*"P", metabolite["r1p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Synonyms" -> {}, "Events" -> {}, 
  "Parameters" -> {parameter["Volume", "c"] -> Quantity[1, "Liters"], 
    Keq["vak"] -> 1000000, Keq["vampase"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["vada"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["vampda"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["vimpase"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["vpnpase"] -> 0.09, Keq["vprm"] -> 13.3, 
    Keq["vprppsyn"] -> 1000000, Keq["vadprt"] -> Quantity[1000000, 
      "Millimoles"/"Liters"], Keq["vade"] -> 1, Keq["vado"] -> 1, 
    Keq["vino"] -> 1, Keq["vhyp"] -> 1, Keq["vphos"] -> 1, Keq["vnh3"] -> 1, 
    Keq["vatpgen"] -> Quantity[1000000, "Liters"/"Millimoles"], 
    Keq["vh"] -> 1, Keq["vh2o"] -> 1, Keq["vamp"] -> 1, 
    metabolite["ado", "Xt"] -> Quantity[0.0012001, "Millimoles"/"Liters"], 
    metabolite["ade", "Xt"] -> Quantity[0.00100014, "Millimoles"/"Liters"], 
    metabolite["ino", "Xt"] -> Quantity[0.0009999, "Millimoles"/"Liters"], 
    metabolite["hyp", "Xt"] -> Quantity[0.00199986, "Millimoles"/"Liters"], 
    metabolite["phos", "Xt"] -> Quantity[2.5, "Millimoles"/"Liters"], 
    metabolite["nh3", "Xt"] -> Quantity[0.0909999, "Millimoles"/"Liters"], 
    metabolite["amp", "Xt"] -> Quantity[0.09540093749999999, 
      "Millimoles"/"Liters"], metabolite["h", "Xt"] -> 
     Quantity[0.00006309573444801929, "Millimoles"/"Liters"], 
    metabolite["h2o", "Xt"] -> Quantity[1, "Millimoles"/"Liters"], 
    rateconst["vada", True] -> Quantity[8.333333965277827, "Hours"^(-1)], 
    rateconst["vado", True] -> Quantity[99999.9999999433, "Hours"^(-1)], 
    rateconst["vadprt", True] -> Quantity[3140.4574868453906, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vak", True] -> 
     Quantity[62.50081873325923, "Liters"/("Hours"*"Millimoles")], 
    rateconst["vampase", True] -> Quantity[1.3836342495690155, "Hours"^(-1)], 
    rateconst["vampda", True] -> Quantity[0.1614239918930086, "Hours"^(-1)], 
    rateconst["vimpase", True] -> Quantity[1.4000003500000875, "Hours"^(-1)], 
    rateconst["vpnpase", True] -> Quantity[12., 
      "Liters"/("Hours"*"Millimoles")], rateconst["vprm", True] -> 
     Quantity[0.2347867752755151, "Hours"^(-1)], 
    rateconst["vprppsyn", True] -> Quantity[1.107034449764991, 
      "Liters"^2/("Hours"*"Millimoles"^2)], rateconst["vh2o", True] -> 
     Quantity[100000.00000637631, "Hours"^(-1)], 
    rateconst["vatpgen", True] -> Quantity[0.20413838154677308, 
      "Liters"/("Hours"*"Millimoles")], rateconst["vh", True] -> 
     Quantity[100000, "Hours"^(-1)], rateconst["vade", True] -> 
     Quantity[100000, "Hours"^(-1)], rateconst["vino", True] -> 
     Quantity[100000, "Hours"^(-1)], rateconst["vhyp", True] -> 
     Quantity[100000, "Hours"^(-1)], rateconst["vnh3", True] -> 
     Quantity[100000, "Hours"^(-1)], rateconst["vphos", True] -> 
     Quantity[100000, "Hours"^(-1)], rateconst["vamp", True] -> 
     Quantity[100000, "Hours"^(-1)]}, "Notes" -> "\nModel constructed on Wed \
6 Mar 2013 11:27:41 by niko on Nikolauss-MacBook-Pro.ucsd.edu using \
Mathematica 9.0 for Mac OS X x86 (64-bit) (November 20, 2012) at the \
following geodetic location: latitude 32.88; longitude -117.24"}]
