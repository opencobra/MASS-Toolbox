(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "PK_Module", "Stoichiometry" -> 
   SparseArray[Automatic, {31, 34}, 0, {1, {{0, 10, 15, 19, 29, 38, 43, 48, 
      50, 52, 55, 60, 62, 64, 67, 72, 74, 76, 79, 84, 86, 88, 91, 95, 97, 99, 
      102, 104, 106, 108, 110, 111}, {{1}, {4}, {6}, {9}, {11}, {14}, {16}, 
      {19}, {21}, {24}, {5}, {10}, {15}, {20}, {25}, {26}, {27}, {28}, {29}, 
      {2}, {3}, {7}, {8}, {12}, {13}, {17}, {18}, {22}, {23}, {5}, {10}, 
      {15}, {20}, {25}, {30}, {31}, {32}, {33}, {5}, {10}, {15}, {20}, {25}, 
      {1}, {2}, {5}, {26}, {34}, {1}, {3}, {2}, {4}, {3}, {4}, {5}, {6}, {7}, 
      {10}, {26}, {27}, {6}, {8}, {7}, {9}, {8}, {9}, {10}, {11}, {12}, {15}, 
      {27}, {28}, {11}, {13}, {12}, {14}, {13}, {14}, {15}, {16}, {17}, {20}, 
      {28}, {29}, {16}, {18}, {17}, {19}, {18}, {19}, {20}, {21}, {22}, {25}, 
      {29}, {21}, {23}, {22}, {24}, {23}, {24}, {25}, {30}, {34}, {30}, {31}, 
      {31}, {32}, {32}, {33}, {33}}}, {-1, -1, -1, -1, -1, -1, -1, -1, -1, 
     -1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
     -1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, -1, 
     -1, 1, -1, 1, -1, 1, 1, -1, -1, -1, 1, 1, -1, 1, -1, 1, -1, 1, 1, -1, 
     -1, -1, 1, 1, -1, 1, -1, 1, -1, 1, 1, -1, -1, -1, 1, 1, -1, 1, -1, 1, 
     -1, 1, 1, -1, -1, -1, 1, 1, 1, -1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 
     1, -1, 1}}], "Species" -> {metabolite["PEP", "c"], 
    metabolite["PYR", "c"], metabolite["FDP", "c"], metabolite["ADP", "c"], 
    metabolite["ATP", "c"], metabolite["H", "c"], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK", "Compartment" -> "c", 
      "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK", "Compartment" -> "c", 
      "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK", "Compartment" -> "c", 
      "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
        Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> 
       {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
        Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
        Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
        Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
        Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"], 
        Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}]}, "Fluxes" -> {v["PK_R01"], v["PK_R02"], 
    v["PK_R03"], v["PK_R04"], v["PK_R05"], v["PK_R11"], v["PK_R12"], 
    v["PK_R13"], v["PK_R14"], v["PK_R15"], v["PK_R21"], v["PK_R22"], 
    v["PK_R23"], v["PK_R24"], v["PK_R25"], v["PK_R31"], v["PK_R32"], 
    v["PK_R33"], v["PK_R34"], v["PK_R35"], v["PK_R41"], v["PK_R42"], 
    v["PK_R43"], v["PK_R44"], v["PK_R45"], v["PK_R10"], v["PK_R20"], 
    v["PK_R30"], v["PK_R40"], v["PK_T1"], v["PK_T2"], v["PK_T3"], v["PK_T4"], 
    v["PK_L"]}, "Constraints" -> {v["PK_R05"] -> {0, Infinity}, 
    v["PK_R15"] -> {0, Infinity}, v["PK_R25"] -> {0, Infinity}, 
    v["PK_R35"] -> {0, Infinity}, v["PK_R45"] -> {0, Infinity}}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14, 16, 
    17, 18, 19, 21, 22, 23, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34}, 
  "CustomODE" -> {}, "Name" -> "MASSmodel$884", 
  "ElementalComposition" -> 
   {enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PK&", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6*"C" + 10*"H" + 12*"O" + 2*"P" + "&PK&" - 4*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     12*"C" + 20*"H" + 24*"O" + 4*"P" + "&PK&" - 8*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     18*"C" + 30*"H" + 36*"O" + 6*"P" + "&PK&" - 12*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     24*"C" + 40*"H" + 48*"O" + 8*"P" + "&PK&" - 16*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 10*"C" + 12*"H" + 5*"N" + 10*"O" + 2*"P" + 
      "&PK&" - 3*"q", enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     16*"C" + 22*"H" + 5*"N" + 22*"O" + 4*"P" + "&PK&" - 7*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     22*"C" + 32*"H" + 5*"N" + 34*"O" + 6*"P" + "&PK&" - 11*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     28*"C" + 42*"H" + 5*"N" + 46*"O" + 8*"P" + "&PK&" - 15*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     34*"C" + 52*"H" + 5*"N" + 58*"O" + 10*"P" + "&PK&" - 19*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 3*"C" + 2*"H" + 6*"O" + "P" + "&PK&" - 
      3*"q", enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     9*"C" + 12*"H" + 18*"O" + 3*"P" + "&PK&" - 7*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     15*"C" + 22*"H" + 30*"O" + 5*"P" + "&PK&" - 11*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     21*"C" + 32*"H" + 42*"O" + 7*"P" + "&PK&" - 15*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     27*"C" + 42*"H" + 54*"O" + 9*"P" + "&PK&" - 19*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 13*"C" + 14*"H" + 5*"N" + 16*"O" + 3*"P" + 
      "&PK&" - 6*"q", enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     19*"C" + 24*"H" + 5*"N" + 28*"O" + 5*"P" + "&PK&" - 10*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     25*"C" + 34*"H" + 5*"N" + 40*"O" + 7*"P" + "&PK&" - 14*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     31*"C" + 44*"H" + 5*"N" + 52*"O" + 9*"P" + "&PK&" - 18*"q", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     37*"C" + 54*"H" + 5*"N" + 64*"O" + 11*"P" + "&PK&" - 22*"q", 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PK&", 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 10*"C" + 12*"H" + 5*"N" + 13*"O" + 3*"P" + 
      "&PK&" - 4*"q", enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 20*"C" + 24*"H" + 10*"N" + 26*"O" + 
      6*"P" + "&PK&" - 8*"q", enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 30*"C" + 36*"H" + 15*"N" + 39*"O" + 
      9*"P" + "&PK&" - 12*"q", enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 40*"C" + 48*"H" + 20*"N" + 52*"O" + 
      12*"P" + "&PK&" - 16*"q", metabolite["ADP", "c"] -> 
     10*"C" + 12*"H" + 5*"N" + 10*"O" + 2*"P" - 3*"q", 
    metabolite["ATP", "c"] -> 10*"C" + 12*"H" + 5*"N" + 13*"O" + 3*"P" - 
      4*"q", metabolite["FDP", "c"] -> 6*"C" + 10*"H" + 12*"O" + 2*"P" - 
      4*"q", metabolite["PEP", "c"] -> 3*"C" + 2*"H" + 6*"O" + "P" - 3*"q", 
    metabolite["PYR", "c"] -> 3*"C" + 3*"H" + 3*"O" - "q", 
    metabolite["H", "c"] -> "H" + "q"}, "Notes" -> "", "Ignore" -> {}, 
  "UnitChecking" -> False, "Synonyms" -> 
   {enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PK_R\), \(0\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(1\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(2\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(3\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(4\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(0, A\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(1, A\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(2, A\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(3, A\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(4, A\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(0, P\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(1, P\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(2, P\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(3, P\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(4, P\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(0, AP\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(1, AP\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(2, AP\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(3, AP\)]\)", 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PK_R\), \(4, AP\)]\)", 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PK_T\), \(0\)]\)", 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PK_T\), \(1\)]\)", 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PK_T\), \(2\)]\)", 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PK_T\), \(3\)]\)", 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PK_T\), \(4\)]\)"}, 
  "Events" -> {}, "CustomRateLaws" -> 
   {v["PK_R01"] -> parameter["Volume", "c"]*rateconst["PK_R01", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PK_R01"]) + 
       enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["PEP", "c"][t]), 
    v["PK_R02"] -> parameter["Volume", "c"]*rateconst["PK_R02", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PK_R02"]) + 
       enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ADP", "c"][t]), 
    v["PK_R03"] -> parameter["Volume", "c"]*rateconst["PK_R03", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PK_R03"]) + 
       enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ADP", "c"][t]), 
    v["PK_R04"] -> parameter["Volume", "c"]*rateconst["PK_R04", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PK_R04"]) + 
       enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["PEP", "c"][t]), 
    v["PK_R05"] -> parameter["Volume", "c"]*rateconst["PK_R05", True]*
      enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
           Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
         "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
         "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
         "InhibitionSites" -> 4}][t], v["PK_R11"] -> 
     parameter["Volume", "c"]*rateconst["PK_R01", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R01"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R12"] -> parameter["Volume", "c"]*
      rateconst["PK_R02", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R02"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R13"] -> parameter["Volume", "c"]*
      rateconst["PK_R03", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R03"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> 
            Infinity, "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R14"] -> parameter["Volume", "c"]*
      rateconst["PK_R04", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R04"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> 
            Infinity, "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R15"] -> parameter["Volume", "c"]*
      rateconst["PK_R05", True]*enzyme[{"ID" -> "PK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
           Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PK_R21"] -> parameter["Volume", "c"]*rateconst["PK_R01", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R01"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R22"] -> parameter["Volume", "c"]*
      rateconst["PK_R02", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R02"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R23"] -> parameter["Volume", "c"]*
      rateconst["PK_R03", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R03"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R24"] -> parameter["Volume", "c"]*
      rateconst["PK_R04", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R04"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R25"] -> parameter["Volume", "c"]*
      rateconst["PK_R05", True]*enzyme[{"ID" -> "PK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
           Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
           Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PK_R31"] -> parameter["Volume", "c"]*rateconst["PK_R01", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R01"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R32"] -> parameter["Volume", "c"]*
      rateconst["PK_R02", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R02"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R33"] -> parameter["Volume", "c"]*
      rateconst["PK_R03", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R03"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R34"] -> parameter["Volume", "c"]*
      rateconst["PK_R04", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R04"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R35"] -> parameter["Volume", "c"]*
      rateconst["PK_R05", True]*enzyme[{"ID" -> "PK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
           Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
           Toolbox`Private`wrap[metabolite]["FDP", "c"], 
           Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PK_R41"] -> parameter["Volume", "c"]*rateconst["PK_R01", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R01"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R42"] -> parameter["Volume", "c"]*
      rateconst["PK_R02", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R02"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R43"] -> parameter["Volume", "c"]*
      rateconst["PK_R03", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R03"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ADP", "c"][t]), v["PK_R44"] -> parameter["Volume", "c"]*
      rateconst["PK_R04", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
              Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_R04"]) + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["PEP", "c"][t]), v["PK_R45"] -> parameter["Volume", "c"]*
      rateconst["PK_R05", True]*enzyme[{"ID" -> "PK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
           Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
           Toolbox`Private`wrap[metabolite]["FDP", "c"], 
           Toolbox`Private`wrap[metabolite]["FDP", "c"], 
           Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PK_R10"] -> rateconst["PK_ACT", True]*
      (-(enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PK_ACT"]) + 4*enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["FDP", "c"][t]), v["PK_20"] -> rateconst["PK_ACT", True]*
      ((-2*enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["PK_ACT"] + 3*enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["FDP", "c"][t]), v["PK_R30"] -> rateconst["PK_ACT", True]*
      ((-3*enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["PK_ACT"] + 2*enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["FDP", "c"][t]), v["PK_R40"] -> rateconst["PK_ACT", True]*
      ((-4*enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "FDP", "c"], Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"], 
              Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["PK_ACT"] + enzyme[{"ID" -> "PK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"], 
             Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["FDP", "c"][t]), v["PK_T1"] -> rateconst["PK_I", True]*
      (-(enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PK_I"]) + 
       4*enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PK_T2"] -> rateconst["PK_I", True]*
      ((-2*enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["PK_I"] + 
       3*enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PK_T3"] -> rateconst["PK_I", True]*
      ((-3*enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["PK_I"] + 
       2*enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
             Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PK_T4"] -> rateconst["PK_I", True]*
      ((-4*enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["PK_I"] + 
       enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
             Toolbox`Private`wrap[metabolite]["ATP", "c"], 
             Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PK_L"] -> parameter["Volume", "c"]*rateconst["PK_L", True]*
      (enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
          "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
          "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
          "InhibitionSites" -> 4}][t] - 
       enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]/Keq["PK_L"])}, 
  "Parameters" -> {parameter["Volume", "c"] -> 1, 
    Keq["PK_R01"] -> 4.444444444444445, Keq["PK_R02"] -> 2.109704641350211, 
    Keq["PK_R04"] -> 4.444444444444445, Keq["PK_R03"] -> 2.109704641350211, 
    Keq["PK_ACT"] -> 200., Keq["PK_I"] -> 0.2949852507374631, 
    Keq["PK_L"] -> 19, rateconst["PK_R01", True] -> 6.686756*^6, 
    rateconst["PK_R02", True] -> 616393., rateconst["PK_R05", True] -> 
     9.99988273553398*^7, rateconst["PK_ACT", True] -> 1000000, 
    rateconst["PK_I", True] -> 1000000, rateconst["PK_L", True] -> 
     1000000000000, rateconst["PK_R04", True] -> 6.686756*^6, 
    rateconst["PK_R03", True] -> 616393.}, "InitialConditions" -> 
   {enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 1.547158543011774*^-7, 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.807081178237752*^-6, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     7.915015560681353*^-6, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     0.000015407896958126368, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     0.000011247764779432248, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 6.84960791183489*^-8, 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     8.00034204102315*^-7, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     3.50414981396814*^-6, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.8214116378579785*^-6, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.979630495636324*^-6, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 1.0464735997673042*^-8, 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.2222811645282109*^-7, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     5.353591500633564*^-7, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.042165812123334*^-6, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     7.607810428500338*^-7, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 9.486561860083065*^-11, 
    enzyme[{"ID" -> "PK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.1080304252577018*^-9, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.853173262628734*^-9, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     9.44751061791727*^-9, enzyme[{"ID" -> "PK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ADP", "c"], 
         Toolbox`Private`wrap[metabolite]["PEP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"], 
         Toolbox`Private`wrap[metabolite]["FDP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.896682751079607*^-9, enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     2.9396012317223706*^-6, enzyme[{"ID" -> "PK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 5.5496896410097845*^-6, 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 3.928983816644096*^-6, 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 1.2362584280492729*^-6, 
    enzyme[{"ID" -> "PK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 1.4587120094976675*^-7}}]
