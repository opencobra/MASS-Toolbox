(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "G6PDH Module", "Stoichiometry" -> 
   SparseArray[Automatic, {13, 7}, 0, {1, {{0, 4, 5, 7, 9, 10, 12, 14, 15, 
      16, 17, 18, 20, 21}, {{1}, {2}, {3}, {4}, {2}, {3}, {5}, {4}, {6}, {1}, 
      {5}, {7}, {6}, {7}, {2}, {3}, {4}, {5}, {1}, {6}, {7}}}, {-1, -1, -1, 
     1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, -1, -1, 1, -1, -1, 1, 1}}], 
  "Species" -> {enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 0, "InhibitionSites" -> 0}], 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
      "InhibitionSites" -> 0}], enzyme[{"ID" -> "G6PDH", 
      "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
      "InhibitionSites" -> 0}], enzyme[{"ID" -> "G6PDH", 
      "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
      "InhibitionSites" -> 0}], enzyme[{"ID" -> "G6PDH", 
      "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["NADPH", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
      "InhibitionSites" -> 0}], enzyme[{"ID" -> "G6PDH", 
      "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["NADP", "c"], 
        Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
      "InhibitionSites" -> 0}], enzyme[{"ID" -> "G6PDH", 
      "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["NADPH", "c"], 
        Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
      "InhibitionSites" -> 0}], metabolite["ATP", "c"], 
    metabolite["G6P", "c"], metabolite["GL6P", "c"], metabolite["NADP", "c"], 
    metabolite["NADPH", "c"], metabolite["H", "c"]}, 
  "Fluxes" -> {v["G6PDH1"], v["G6PDH2"], v["G6PDH3"], v["G6PDH4"], 
    v["G6PDH5"], v["G6PDH6"], v["G6PDH7"]}, "Constraints" -> {}, "GPR" -> {}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, 
  "ReversibleColumnIndices" -> {1, 2, 3, 4, 5, 6, 7}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel", "ElementalComposition" -> 
   {enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> "&G6PDH&", 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 10*"C" + "&G6PDH&" + 12*"H" + 5*"N" + 
      13*"O" + 3*"P" - 4*"q", enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 6*"C" + "&G6PDH&" + 11*"H" + 9*"O" + "P" - 
      2*"q", enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 6*"C" + "&G6PDH&" + 9*"H" + 9*"O" + "P" - 
      2*"q", enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["NADPH", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> "&G6PDH&" + "H" + "&NADP&" - 4*"q", 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["NADP", "c"], 
         Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 6*"C" + "&G6PDH&" + 11*"H" + "&NADP&" + 
      9*"O" + "P" - 5*"q", enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["NADPH", "c"], 
         Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 6*"C" + "&G6PDH&" + 10*"H" + "&NADP&" + 
      9*"O" + "P" - 6*"q", metabolite["ATP", "c"] -> 
     10*"C" + 12*"H" + 5*"N" + 13*"O" + 3*"P" - 4*"q", 
    metabolite["G6P", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P" - 2*"q", 
    metabolite["GL6P", "c"] -> 6*"C" + 9*"H" + 9*"O" + "P" - 2*"q", 
    metabolite["NADP", "c"] -> "&NADP&" - 3*"q", metabolite["NADPH", "c"] -> 
     "H" + "&NADP&" - 4*"q", metabolite["H", "c"] -> "H" + "q"}, 
  "Notes" -> "", "Ignore" -> {}, "UnitChecking" -> False, "Events" -> {}, 
  "CustomRateLaws" -> {}, "Parameters" -> {parameter["Volume", "c"] -> 1, 
    Keq["G6PDH1"] -> 41.666666666666664, Keq["G6PDH2"] -> 22.72727272727273, 
    Keq["G6PDH3"] -> 37.03703703703704, Keq["G6PDH4"] -> 0.05, 
    Keq["G6PDH5"] -> 52.631578947368425, Keq["G6PDH6"] -> 0.0105, 
    Keq["G6PDH7"] -> 977.142857142857, rateconst["G6PDH3", True] -> 
     297886.3377580958, rateconst["G6PDH4", True] -> 5.000385717893088*^7, 
    rateconst["G6PDH5", True] -> 6.258609394291978*^7, 
    rateconst["G6PDH6", True] -> 5.000046911115429*^7, 
    rateconst["G6PDH7", True] -> 5.023697233399537*^7, 
    rateconst["G6PDH1", True] -> 1.*^6, rateconst["G6PDH2", True] -> 1.*^6}, 
  "InitialConditions" -> 
   {enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 0.000024337270455525076, 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 0.0008849916529281846, 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 0.00001769720263957741, 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 8.580692679077181*^-7, 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["NADPH", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 0.00006672468316556457, 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["NADP", "c"], 
         Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 9.687503758298478*^-9, 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["NADPH", "c"], 
         Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 5.381434039483397*^-6}, 
  "Synonyms" -> {enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 
     "\!\(\*SubscriptBox[\(G6PDH\), \(ATP\)]\)", 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 
     "\!\(\*SubscriptBox[\(G6PDH\), \(G6P\)]\)", 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 
     "\!\(\*SubscriptBox[\(G6PDH\), \(GL6P\)]\)", 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["NADPH", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 
     "\!\(\*SuperscriptBox[\(G6PDH\), \(NADPH\)]\)", 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["NADP", "c"], 
         Toolbox`Private`wrap[metabolite]["G6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 
     "\!\(\*SubsuperscriptBox[\(G6PDH\), \(G6P\), \(NADP\)]\)", 
    enzyme[{"ID" -> "G6PDH", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["NADPH", "c"], 
         Toolbox`Private`wrap[metabolite]["GL6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 0, 
       "InhibitionSites" -> 0}] -> 
     "\!\(\*SubsuperscriptBox[\(G6PDH\), \(GL6P\), \(NADPH\)]\)"}}]
