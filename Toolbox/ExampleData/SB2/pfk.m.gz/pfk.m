(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "PFK Module", "Stoichiometry" -> 
   SparseArray[Automatic, {26, 24}, 0, {1, {{0, 5, 10, 14, 19, 28, 33, 37, 
      39, 41, 45, 47, 49, 53, 55, 57, 61, 63, 65, 68, 70, 72, 74, 76, 78, 80, 
      81}, {{2}, {5}, {8}, {11}, {14}, {3}, {6}, {9}, {12}, {15}, {16}, {17}, 
      {18}, {19}, {3}, {6}, {9}, {12}, {15}, {1}, {4}, {7}, {10}, {13}, {20}, 
      {21}, {22}, {23}, {3}, {6}, {9}, {12}, {15}, {1}, {3}, {16}, {24}, {1}, 
      {2}, {2}, {3}, {4}, {6}, {16}, {17}, {4}, {5}, {5}, {6}, {7}, {9}, 
      {17}, {18}, {7}, {8}, {8}, {9}, {10}, {12}, {18}, {19}, {10}, {11}, 
      {11}, {12}, {13}, {15}, {19}, {13}, {14}, {14}, {15}, {20}, {24}, {20}, 
      {21}, {21}, {22}, {22}, {23}, {23}}}, {-1, -1, -1, -1, -1, 1, 1, 1, 1, 
     1, -1, -1, -1, -1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 
     1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, -1, -1, 
     1, 1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, -1, -1, 1, 1, 1, -1, 1, 
     -1, -1, 1, 1, -1, 1, -1, 1, -1, 1}}], 
  "Species" -> {metabolite["F6P", "c"], metabolite["FDP", "c"], 
    metabolite["AMP", "c"], metabolite["ADP", "c"], metabolite["ATP", "c"], 
    metabolite["H", "c"], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> 
       {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"], 
        Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"], 
        Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}]}, "Fluxes" -> {v["PFK_R01"], v["PFK_R02"], 
    v["PFK_R03"], v["PFK_R11"], v["PFK_R12"], v["PFK_R13"], v["PFK_R21"], 
    v["PFK_R22"], v["PFK_R23"], v["PFK_R31"], v["PFK_R32"], v["PFK_R33"], 
    v["PFK_R41"], v["PFK_R42"], v["PFK_R43"], v["PFK_R10"], v["PFK_R20"], 
    v["PFK_R30"], v["PFK_R40"], v["PFK_T1"], v["PFK_T2"], v["PFK_T3"], 
    v["PFK_T4"], v["PFK_L"]}, "Constraints" -> 
   {v["PFK_R03"] -> {0, Infinity}, v["PFK_R13"] -> {0, Infinity}, 
    v["PFK_R23"] -> {0, Infinity}, v["PFK_R33"] -> {0, Infinity}, 
    v["PFK_R43"] -> {0, Infinity}}, "GPR" -> {}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "ReversibleColumnIndices" -> {1, 2, 4, 5, 7, 8, 10, 11, 
    13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$783", "Notes" -> "", "Ignore" -> {}, 
  "UnitChecking" -> False, "Events" -> {}, "CustomRateLaws" -> 
   {v["PFK_R01"] -> parameter["Volume", "c"]*rateconst["PFK_A", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PFK_A"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PFK_R02"] -> parameter["Volume", "c"]*rateconst["PFK_F", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PFK_F"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["F6P", "c"][t]), 
    v["PFK_R03"] -> parameter["Volume", "c"]*rateconst["PFK", True]*
      enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
           Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
         "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
         "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
         "InhibitionSites" -> 4}][t], v["PFK_R11"] -> 
     parameter["Volume", "c"]*rateconst["PFK_A", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_A"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ATP", "c"][t]), v["PFK_R12"] -> 
     parameter["Volume", "c"]*rateconst["PFK_F", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_F"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "AMP", "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> 
            Infinity, "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["F6P", "c"][t]), v["PFK_R13"] -> 
     parameter["Volume", "c"]*rateconst["PFK", True]*
      enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
           Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PFK_R21"] -> parameter["Volume", "c"]*rateconst["PFK_A", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_A"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ATP", "c"][t]), v["PFK_R22"] -> 
     parameter["Volume", "c"]*rateconst["PFK_F", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_F"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "AMP", "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["F6P", "c"][t]), v["PFK_R23"] -> 
     parameter["Volume", "c"]*rateconst["PFK", True]*
      enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
           Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
           Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PFK_R31"] -> parameter["Volume", "c"]*rateconst["PFK_A", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_A"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ATP", "c"][t]), v["PFK_R32"] -> 
     parameter["Volume", "c"]*rateconst["PFK_F", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_F"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "AMP", "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["F6P", "c"][t]), v["PFK_R33"] -> 
     parameter["Volume", "c"]*rateconst["PFK", True]*
      enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
           Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
           Toolbox`Private`wrap[metabolite]["AMP", "c"], 
           Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PFK_R41"] -> parameter["Volume", "c"]*rateconst["PFK_A", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_A"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["ATP", "c"][t]), v["PFK_R42"] -> 
     parameter["Volume", "c"]*rateconst["PFK_F", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_F"]) + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", 
              "c"]}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
              "AMP", "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["F6P", "c"][t]), v["PFK_R43"] -> 
     parameter["Volume", "c"]*rateconst["PFK", True]*
      enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
           Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
           Toolbox`Private`wrap[metabolite]["AMP", "c"], 
           Toolbox`Private`wrap[metabolite]["AMP", "c"], 
           Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["PFK_R10"] -> rateconst["PFK_ACT", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["PFK_ACT"]) + 4*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["AMP", "c"][t]), v["PFK_R20"] -> 
     rateconst["PFK_ACT", True]*
      ((-2*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "AMP", "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["PFK_ACT"] + 3*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["AMP", "c"][t]), v["PFK_R30"] -> 
     rateconst["PFK_ACT", True]*
      ((-3*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "AMP", "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["PFK_ACT"] + 2*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["AMP", "c"][t]), v["PFK_R40"] -> 
     rateconst["PFK_ACT", True]*
      ((-4*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "AMP", "c"], Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"], 
              Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["PFK_ACT"] + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"], 
             Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["AMP", "c"][t]), v["PFK_T1"] -> rateconst["PFK_I", True]*
      (-(enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["PFK_I"]) + 
       4*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PFK_T2"] -> rateconst["PFK_I", True]*
      ((-2*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["PFK_I"] + 
       3*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PFK_T3"] -> rateconst["PFK_I", True]*
      ((-3*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["PFK_I"] + 
       2*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
             Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PFK_T4"] -> rateconst["PFK_I", True]*
      ((-4*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"], 
              Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["PFK_I"] + 
       enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
             Toolbox`Private`wrap[metabolite]["ATP", "c"], 
             Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["ATP", "c"][t]), 
    v["PFK_L"] -> parameter["Volume", "c"]*rateconst["PFK_L", True]*
      (enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
          "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
          "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
          "InhibitionSites" -> 4}][t] - 
       enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]/Keq["PFK_L"])}, 
  "Parameters" -> {parameter["Volume", "c"] -> 1, 
    Keq["PFK_A"] -> 14.705882352941176, Keq["PFK_F"] -> 10., 
    Keq["PFK_ACT"] -> 30.3030303030303, Keq["PFK_I"] -> 10., 
    Keq["PFK_L"] -> 0.0011, rateconst["PFK_A", True] -> 119781., 
    rateconst["PFK_F", True] -> 2.511658*^6, rateconst["PFK", True] -> 
     9.995976014795777*^7, rateconst["PFK_ACT", True] -> 1000000, 
    rateconst["PFK_I", True] -> 1000000, rateconst["PFK_L", True] -> 
     1000000000000}, "InitialConditions" -> 
   {enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 3.926512858770815*^-8, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.1277466427828186*^-7, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.6272351218345387*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     2.851051536380931*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.8732299547627834*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 1.3030264545595522*^-7, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.3698065603557291*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     5.400034299652351*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     9.461310095849221*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.216376398913432*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 6.466419145354888*^-11, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.797823126554322*^-10, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     2.6798293356713363*^-9, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.695284315207487*^-9, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     3.0849485227261687*^-9, enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.3191641446478974*^-11, enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 2.764265052574654*^-9, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 6.634236126179169*^-8, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 7.076518534591115*^-7, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 2.8306074138364465*^-6}, 
  "ElementalComposition" -> {metabolite["F6P", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P" - 2*"q", metabolite["FDP", "c"] -> 
     6*"C" + 10*"H" + 12*"O" + 2*"P" - 4*"q", metabolite["AMP", "c"] -> 
     10*"C" + 13*"H" + 5*"N" + 7*"O" + "P" - 2*"q", 
    metabolite["ADP", "c"] -> 10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P" - 
      3*"q", metabolite["ATP", "c"] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 
      3*"P" - 4*"q", metabolite["H", "c"] -> "H" + "q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P" + 
      "&PFK&" - 4*"q", enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 16*"C" + 24*"H" + 5*"N" + 22*"O" + 4*"P" + 
      "&PFK&" - 6*"q", enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     10*"C" + 13*"H" + 5*"N" + 7*"O" + "P" + "&PFK&" - 2*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     20*"C" + 26*"H" + 10*"N" + 20*"O" + 4*"P" + "&PFK&" - 6*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     26*"C" + 37*"H" + 10*"N" + 29*"O" + 5*"P" + "&PFK&" - 8*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     20*"C" + 26*"H" + 10*"N" + 14*"O" + 2*"P" + "&PFK&" - 4*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     30*"C" + 39*"H" + 15*"N" + 27*"O" + 5*"P" + "&PFK&" - 8*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     36*"C" + 50*"H" + 15*"N" + 36*"O" + 6*"P" + "&PFK&" - 10*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     30*"C" + 39*"H" + 15*"N" + 21*"O" + 3*"P" + "&PFK&" - 6*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     40*"C" + 52*"H" + 20*"N" + 34*"O" + 6*"P" + "&PFK&" - 10*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     46*"C" + 63*"H" + 20*"N" + 43*"O" + 7*"P" + "&PFK&" - 12*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     40*"C" + 52*"H" + 20*"N" + 28*"O" + 4*"P" + "&PFK&" - 8*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     50*"C" + 65*"H" + 25*"N" + 41*"O" + 7*"P" + "&PFK&" - 12*"q", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     56*"C" + 76*"H" + 25*"N" + 50*"O" + 8*"P" + "&PFK&" - 14*"q", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P" + 
      "&PFK&" - 4*"q", enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 20*"C" + 26*"H" + 10*"N" + 26*"O" + 
      6*"P" + "&PFK&" - 8*"q", enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 30*"C" + 39*"H" + 15*"N" + 39*"O" + 
      9*"P" + "&PFK&" - 12*"q", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 40*"C" + 52*"H" + 20*"N" + 52*"O" + 
      12*"P" + "&PFK&" - 16*"q"}, "Synonyms" -> 
   {enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PFK_R\), \(0\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(1\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(2\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(3\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(4\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(0, A\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(1, A\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(2, A\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(3, A\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(4, A\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(0, AF\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(1, AF\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(2, AF\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(3, AF\)]\)", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["F6P", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"], 
         Toolbox`Private`wrap[metabolite]["AMP", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     "\!\(\*SubscriptBox[\(PFK_R\), \(4, AF\)]\)", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PFK_T\), \(0\)]\)", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PFK_T\), \(1\)]\)", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PFK_T\), \(2\)]\)", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PFK_T\), \(3\)]\)", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"], 
         Toolbox`Private`wrap[metabolite]["ATP", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "\!\(\*SubscriptBox[\(PFK_T\), \(4\)]\)"}}]
