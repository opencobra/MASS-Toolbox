(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$783", "Stoichiometry" -> 
   SparseArray[Automatic, {26, 24}, 0, {1, {{0, 5, 10, 14, 19, 28, 33, 37, 
      39, 41, 45, 47, 49, 53, 55, 57, 61, 63, 65, 68, 70, 72, 74, 76, 78, 80, 
      81}, {{2}, {5}, {8}, {11}, {14}, {3}, {6}, {9}, {12}, {15}, {16}, {17}, 
      {18}, {19}, {3}, {6}, {9}, {12}, {15}, {1}, {4}, {7}, {10}, {13}, {20}, 
      {21}, {22}, {23}, {3}, {6}, {9}, {12}, {15}, {1}, {3}, {16}, {24}, {1}, 
      {2}, {2}, {3}, {4}, {6}, {16}, {17}, {4}, {5}, {5}, {6}, {7}, {9}, 
      {17}, {18}, {7}, {8}, {8}, {9}, {10}, {12}, {18}, {19}, {10}, {11}, 
      {11}, {12}, {13}, {15}, {19}, {13}, {14}, {14}, {15}, {20}, {24}, {20}, 
      {21}, {21}, {22}, {22}, {23}, {23}}}, {-1, -1, -1, -1, -1, 1, 1, 1, 1, 
     1, -1, -1, -1, -1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 
     1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, -1, -1, 
     1, 1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, -1, -1, 1, 1, 1, -1, 1, 
     -1, -1, 1, 1, -1, 1, -1, 1, -1, 1}}], 
  "Species" -> {metabolite["f6p", "c"], metabolite["fdp", "c"], 
    metabolite["amp", "c"], metabolite["adp", "c"], metabolite["atp", "c"], 
    metabolite["h", "c"], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> 
       {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}]}, "Fluxes" -> {v["vR01"], v["vR02"], 
    v["vR03"], v["vR11"], v["vR12"], v["vR13"], v["vR21"], v["vR22"], 
    v["vR23"], v["vR31"], v["vR32"], v["vR33"], v["vR41"], v["vR42"], 
    v["vR43"], v["vR10"], v["vR20"], v["vR30"], v["vR40"], v["vT1"], 
    v["vT2"], v["vT3"], v["vT4"], v["vL"]}, 
  "Constraints" -> {v["vR03"] -> {0, Infinity}, v["vR13"] -> {0, Infinity}, 
    v["vR23"] -> {0, Infinity}, v["vR33"] -> {0, Infinity}, 
    v["vR43"] -> {0, Infinity}}, "GPR" -> {}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "ReversibleColumnIndices" -> {1, 2, 4, 5, 7, 8, 10, 11, 
    13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$783", "Notes" -> "", "Ignore" -> {}, 
  "UnitChecking" -> False, "Synonyms" -> {}, "Events" -> {}, 
  "CustomRateLaws" -> {v["vR01"] -> parameter["Volume", "c"]*
      rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vR02"] -> parameter["Volume", "c"]*rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["f6p", "c"][t]), 
    v["vR03"] -> parameter["Volume", "c"]*rateconst["kPFK", True]*
      enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
         "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
         "InhibitionSites" -> 4}][t], v["vR11"] -> parameter["Volume", "c"]*
      rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR12"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR13"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR21"] -> parameter["Volume", "c"]*rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR22"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR23"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR31"] -> parameter["Volume", "c"]*rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR32"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR33"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR41"] -> parameter["Volume", "c"]*rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR42"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR43"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR10"] -> rateconst["kact", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["kact"]) + 4*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vR20"] -> rateconst["kact", True]*
      ((-2*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "amp", "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["kact"] + 3*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vR30"] -> rateconst["kact", True]*
      ((-3*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "amp", "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["kact"] + 2*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vR40"] -> rateconst["kact", True]*
      ((-4*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "amp", "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["kact"] + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vT1"] -> rateconst["ki", True]*
      (-(enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["ki"]) + 
       4*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vT2"] -> rateconst["ki", True]*
      ((-2*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["ki"] + 
       3*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vT3"] -> rateconst["ki", True]*
      ((-3*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["ki"] + 
       2*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"], 
             Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vT4"] -> rateconst["ki", True]*
      ((-4*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["ki"] + 
       enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"], 
             Toolbox`Private`wrap[metabolite]["atp", "c"], 
             Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vL"] -> parameter["Volume", "c"]*rateconst["vL", True]*
      (enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
          "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
          "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
          "InhibitionSites" -> 4}][t] - 
       enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]/Keq["vL"])}, 
  "Parameters" -> {parameter["Volume", "c"] -> 1, 
    Keq["kA"] -> 14.705882352941176, Keq["kF"] -> 10., 
    Keq["kact"] -> 30.3030303030303, Keq["ki"] -> 10., Keq["vL"] -> 0.0011, 
    rateconst["kA", True] -> 119781., rateconst["kF", True] -> 2.511658*^6, 
    rateconst["kPFK", True] -> 9.995976014795777*^7, 
    rateconst["kact", True] -> 1000000, rateconst["ki", True] -> 1000000, 
    rateconst["vL", True] -> 1000000000000}, "InitialConditions" -> 
   {enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 3.926512858770815*^-8, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.1277466427828186*^-7, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.6272351218345387*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     2.851051536380931*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.8732299547627834*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 1.3030264545595522*^-7, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.3698065603557291*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     5.400034299652351*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     9.461310095849221*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.216376398913432*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 6.466419145354888*^-11, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.797823126554322*^-10, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     2.6798293356713363*^-9, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.695284315207487*^-9, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     3.0849485227261687*^-9, enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.3191641446478974*^-11, enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 2.764265052574654*^-9, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 6.634236126179169*^-8, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 7.076518534591115*^-7, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 2.8306074138364465*^-6}, 
  "ElementalComposition" -> {metabolite["f6p", "c"] -> 
     6*"C" + 11*"H" + 9*"O" + "P", metabolite["fdp", "c"] -> 
     6*"C" + 10*"H" + 12*"O" + 2*"P", metabolite["amp", "c"] -> 
     10*"C" + 13*"H" + 5*"N" + 7*"O" + "P", metabolite["adp", "c"] -> 
     10*"C" + 13*"H" + 5*"N" + 10*"O" + 2*"P", metabolite["atp", "c"] -> 
     10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P", metabolite["h", "c"] -> "H", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P" + 
      "&PFK&", enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 16*"C" + 24*"H" + 5*"N" + 22*"O" + 4*"P" + 
      "&PFK&", enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     10*"C" + 13*"H" + 5*"N" + 7*"O" + "P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     20*"C" + 26*"H" + 10*"N" + 20*"O" + 4*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     26*"C" + 37*"H" + 10*"N" + 29*"O" + 5*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     20*"C" + 26*"H" + 10*"N" + 14*"O" + 2*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     30*"C" + 39*"H" + 15*"N" + 27*"O" + 5*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     36*"C" + 50*"H" + 15*"N" + 36*"O" + 6*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     30*"C" + 39*"H" + 15*"N" + 21*"O" + 3*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     40*"C" + 52*"H" + 20*"N" + 34*"O" + 6*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     46*"C" + 63*"H" + 20*"N" + 43*"O" + 7*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     40*"C" + 52*"H" + 20*"N" + 28*"O" + 4*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     50*"C" + 65*"H" + 25*"N" + 41*"O" + 7*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     56*"C" + 76*"H" + 25*"N" + 50*"O" + 8*"P" + "&PFK&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 10*"C" + 13*"H" + 5*"N" + 13*"O" + 3*"P" + 
      "&PFK&", enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 20*"C" + 26*"H" + 10*"N" + 26*"O" + 
      6*"P" + "&PFK&", enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 30*"C" + 39*"H" + 15*"N" + 39*"O" + 
      9*"P" + "&PFK&", enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 40*"C" + 52*"H" + 20*"N" + 52*"O" + 
      12*"P" + "&PFK&"}}]
