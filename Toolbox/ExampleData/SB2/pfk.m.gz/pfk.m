(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
MASSmodel[{"ID" -> "MASSmodel$783", "Stoichiometry" -> 
   SparseArray[Automatic, {26, 24}, 0, {1, {{0, 4, 8, 12, 16, 19, 21, 23, 25, 
      27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 48, 53, 58, 63, 67, 76, 
      81}, {{1}, {3}, {16}, {24}, {4}, {6}, {16}, {17}, {7}, {9}, {17}, {18}, 
      {10}, {12}, {18}, {19}, {13}, {15}, {19}, {1}, {2}, {4}, {5}, {7}, {8}, 
      {10}, {11}, {13}, {14}, {2}, {3}, {5}, {6}, {8}, {9}, {11}, {12}, {14}, 
      {15}, {20}, {24}, {20}, {21}, {21}, {22}, {22}, {23}, {23}, {3}, {6}, 
      {9}, {12}, {15}, {3}, {6}, {9}, {12}, {15}, {3}, {6}, {9}, {12}, {15}, 
      {16}, {17}, {18}, {19}, {1}, {4}, {7}, {10}, {13}, {20}, {21}, {22}, 
      {23}, {2}, {5}, {8}, {11}, {14}}}, {-1, 1, -1, -1, -1, 1, 1, -1, -1, 1, 
     1, -1, -1, 1, 1, -1, -1, 1, 1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 
     1, -1, 1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, -1, 1, 1, 1, 1, 1, 
     1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
     -1, -1, -1, -1, -1, -1, -1, -1}}], 
  "Species" -> {enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
      "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
       {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
      "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"], 
        Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
      "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
      "ActivationSites" -> 4, "InhibitionSites" -> 4}], 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
      "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], enzyme[{"ID" -> "PFK_T", 
      "Compartment" -> "c", "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
      "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"], 
        Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
      "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
      "InhibitionSites" -> 4}], metabolite["adp", "c"], 
    metabolite["fdp", "c"], metabolite["h", "c"], metabolite["amp", "c"], 
    metabolite["atp", "c"], metabolite["f6p", "c"]}, 
  "Fluxes" -> {v["vR01"], v["vR02"], v["vR03"], v["vR11"], v["vR12"], 
    v["vR13"], v["vR21"], v["vR22"], v["vR23"], v["vR31"], v["vR32"], 
    v["vR33"], v["vR41"], v["vR42"], v["vR43"], v["vR10"], v["vR20"], 
    v["vR30"], v["vR40"], v["vT1"], v["vT2"], v["vT3"], v["vT4"], v["vL"]}, 
  "Constraints" -> {v["vR03"] -> {0, Infinity}, v["vR13"] -> {0, Infinity}, 
    v["vR23"] -> {0, Infinity}, v["vR33"] -> {0, Infinity}, 
    v["vR43"] -> {0, Infinity}}, "GPR" -> {}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "ReversibleColumnIndices" -> {1, 2, 4, 5, 7, 8, 10, 11, 
    13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24}, "CustomODE" -> {}, 
  "Name" -> "MASSmodel$783", "ElementalComposition" -> 
   {enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> "&PFK&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK_T&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK_T&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK_T&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK_T&", 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> "&PFK_T&", metabolite["adp", "c"] -> 
     "&adp&", metabolite["amp", "c"] -> "&amp&", metabolite["atp", "c"] -> 
     "&atp&", metabolite["f6p", "c"] -> "&f6p&", metabolite["fdp", "c"] -> 
     "&fdp&", metabolite["h", "c"] -> "&h&"}, "Notes" -> "", "Ignore" -> {}, 
  "UnitChecking" -> False, "Synonyms" -> {}, "Events" -> {}, 
  "CustomRateLaws" -> {v["vR01"] -> parameter["Volume", "c"]*
      rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vR02"] -> parameter["Volume", "c"]*rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["f6p", "c"][t]), 
    v["vR03"] -> parameter["Volume", "c"]*rateconst["kPFK", True]*
      enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
          {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
         "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
         "InhibitionSites" -> 4}][t], v["vR11"] -> parameter["Volume", "c"]*
      rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR12"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR13"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR21"] -> parameter["Volume", "c"]*rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR22"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR23"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR31"] -> parameter["Volume", "c"]*rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR32"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR33"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR41"] -> parameter["Volume", "c"]*rateconst["kA", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kA"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["atp", "c"][t]), v["vR42"] -> parameter["Volume", "c"]*
      rateconst["kF", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/Keq["kF"]) + 
       enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
              "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["f6p", "c"][t]), v["vR43"] -> parameter["Volume", "c"]*
      rateconst["kPFK", True]*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
         "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
           Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
         "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"], 
           Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
         "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
         "ActivationSites" -> 4, "InhibitionSites" -> 4}][t], 
    v["vR10"] -> rateconst["kact", True]*
      (-(enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
            "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", 
               "c"]}, "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]/
         Keq["kact"]) + 4*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vR20"] -> rateconst["kact", True]*
      ((-2*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "amp", "c"], Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["kact"] + 3*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vR30"] -> rateconst["kact", True]*
      ((-3*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "amp", "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["kact"] + 2*enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vR40"] -> rateconst["kact", True]*
      ((-4*enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {Toolbox`Private`wrap[metabolite][
               "amp", "c"], Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"], 
              Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
            "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
            "ActivationSites" -> 4, "InhibitionSites" -> 4}][t])/
        Keq["kact"] + enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
           "BoundCatalytic" -> {}, "BoundActivators" -> 
            {Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"], 
             Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
           "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
           "ActivationSites" -> 4, "InhibitionSites" -> 4}][t]*
        metabolite["amp", "c"][t]), v["vT1"] -> rateconst["ki", True]*
      (-(enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t]/Keq["ki"]) + 
       4*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vT2"] -> rateconst["ki", True]*
      ((-2*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["ki"] + 
       3*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vT3"] -> rateconst["ki", True]*
      ((-3*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["ki"] + 
       2*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
            {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"], 
             Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vT4"] -> rateconst["ki", True]*
      ((-4*enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> 
             {}, "BoundActivators" -> {}, "BoundInhibitors" -> 
             {Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"], 
              Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
            "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
            "InhibitionSites" -> 4}][t])/Keq["ki"] + 
       enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> 
            {Toolbox`Private`wrap[metabolite]["atp", "c"], 
             Toolbox`Private`wrap[metabolite]["atp", "c"], 
             Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]*metabolite["atp", "c"][t]), 
    v["vL"] -> parameter["Volume", "c"]*rateconst["vL", True]*
      (enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
          "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
          "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
          "InhibitionSites" -> 4}][t] - 
       enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
           "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
           "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
           "InhibitionSites" -> 4}][t]/Keq["vL"])}, 
  "Parameters" -> {parameter["Volume", "c"] -> 1, 
    Keq["kA"] -> 14.705882352941176, Keq["kF"] -> 10., 
    Keq["kact"] -> 30.3030303030303, Keq["ki"] -> 10., Keq["vL"] -> 0.0011, 
    rateconst["kA", True] -> 119781., rateconst["kF", True] -> 2.511658*^6, 
    rateconst["kPFK", True] -> 9.995976014795777*^7, 
    rateconst["kact", True] -> 1000000, rateconst["ki", True] -> 1000000, 
    rateconst["vL", True] -> 1000000000000}, "InitialConditions" -> 
   {enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 3.926512858770815*^-8, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.1277466427828186*^-7, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.6272351218345387*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     2.851051536380931*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> 
        {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.8732299547627834*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 1.3030264545595522*^-7, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     1.3698065603557291*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     5.400034299652351*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     9.461310095849221*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.216376398913432*^-6, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> {}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 6.466419145354888*^-11, 
    enzyme[{"ID" -> "PFK", "Compartment" -> "c", "BoundCatalytic" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     6.797823126554322*^-10, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     2.6798293356713363*^-9, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.695284315207487*^-9, enzyme[{"ID" -> "PFK", "Compartment" -> "c", 
       "BoundCatalytic" -> {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["f6p", "c"]}, 
       "BoundActivators" -> {Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"], 
         Toolbox`Private`wrap[metabolite]["amp", "c"]}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     3.0849485227261687*^-9, enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {}, "CatalyticSites" -> Infinity, 
       "ActivationSites" -> 4, "InhibitionSites" -> 4}] -> 
     4.3191641446478974*^-11, enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", 
       "BoundCatalytic" -> {}, "BoundActivators" -> {}, 
       "BoundInhibitors" -> {Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 2.764265052574654*^-9, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 6.634236126179169*^-8, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 7.076518534591115*^-7, 
    enzyme[{"ID" -> "PFK_T", "Compartment" -> "c", "BoundCatalytic" -> {}, 
       "BoundActivators" -> {}, "BoundInhibitors" -> 
        {Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"], 
         Toolbox`Private`wrap[metabolite]["atp", "c"]}, 
       "CatalyticSites" -> Infinity, "ActivationSites" -> 4, 
       "InhibitionSites" -> 4}] -> 2.8306074138364465*^-6}}]
