(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"Synonyms" -> {}, "Events" -> {}, "ID" -> "MODELID_3473243", 
  "Name" -> "E. coli textbook", "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "ElementalComposition" -> {metabolite["13dpg", "c"] -> "&M_13dpg_c&", 
    metabolite["2pg", "c"] -> "&M_2pg_c&", metabolite["3pg", "c"] -> 
     "&M_3pg_c&", metabolite["6pgc", "c"] -> "&M_6pgc_c&", 
    metabolite["6pgl", "c"] -> "&M_6pgl_c&", metabolite["acald", "c"] -> 
     "&M_acald_c&", metabolite["acald", "e"] -> "&M_acald_e&", 
    metabolite["ac", "c"] -> "&M_ac_c&", metabolite["accoa", "c"] -> 
     "&M_accoa_c&", metabolite["ac", "e"] -> "&M_ac_e&", 
    metabolite["acon-C", "c"] -> "&M_acon-C_c&", metabolite["actp", "c"] -> 
     "&M_actp_c&", metabolite["adp", "c"] -> "&M_adp_c&", 
    metabolite["akg", "c"] -> "&M_akg_c&", metabolite["akg", "e"] -> 
     "&M_akg_e&", metabolite["amp", "c"] -> "&M_amp_c&", 
    metabolite["atp", "c"] -> "&M_atp_c&", metabolite["cit", "c"] -> 
     "&M_cit_c&", metabolite["co2", "c"] -> "&M_co2_c&", 
    metabolite["co2", "e"] -> "&M_co2_e&", metabolite["coa", "c"] -> 
     "&M_coa_c&", metabolite["dhap", "c"] -> "&M_dhap_c&", 
    metabolite["e4p", "c"] -> "&M_e4p_c&", metabolite["etoh", "c"] -> 
     "&M_etoh_c&", metabolite["etoh", "e"] -> "&M_etoh_e&", 
    metabolite["f6p", "c"] -> "&M_f6p_c&", metabolite["fdp", "c"] -> 
     "&M_fdp_c&", metabolite["for", "c"] -> "&M_for_c&", 
    metabolite["for", "e"] -> "&M_for_e&", metabolite["fru", "e"] -> 
     "&M_fru_e&", metabolite["fum", "c"] -> "&M_fum_c&", 
    metabolite["fum", "e"] -> "&M_fum_e&", metabolite["g3p", "c"] -> 
     "&M_g3p_c&", metabolite["g6p", "c"] -> "&M_g6p_c&", 
    metabolite["glc-D", "e"] -> "&M_glc-D_e&", metabolite["gln-L", "c"] -> 
     "&M_gln-L_c&", metabolite["gln-L", "e"] -> "&M_gln-L_e&", 
    metabolite["glu-L", "c"] -> "&M_glu-L_c&", metabolite["glu-L", "e"] -> 
     "&M_glu-L_e&", metabolite["glx", "c"] -> "&M_glx_c&", 
    metabolite["h2o", "c"] -> "&M_h2o_c&", metabolite["h2o", "e"] -> 
     "&M_h2o_e&", metabolite["h", "c"] -> "&M_h_c&", 
    metabolite["h", "e"] -> "&M_h_e&", metabolite["icit", "c"] -> 
     "&M_icit_c&", metabolite["lac-D", "c"] -> "&M_lac-D_c&", 
    metabolite["lac-D", "e"] -> "&M_lac-D_e&", metabolite["mal-L", "c"] -> 
     "&M_mal-L_c&", metabolite["mal-L", "e"] -> "&M_mal-L_e&", 
    metabolite["nad", "c"] -> "&M_nad_c&", metabolite["nadh", "c"] -> 
     "&M_nadh_c&", metabolite["nadp", "c"] -> "&M_nadp_c&", 
    metabolite["nadph", "c"] -> "&M_nadph_c&", metabolite["nh4", "c"] -> 
     "&M_nh4_c&", metabolite["nh4", "e"] -> "&M_nh4_e&", 
    metabolite["o2", "c"] -> "&M_o2_c&", metabolite["o2", "e"] -> "&M_o2_e&", 
    metabolite["oaa", "c"] -> "&M_oaa_c&", metabolite["pep", "c"] -> 
     "&M_pep_c&", metabolite["pi", "c"] -> "&M_pi_c&", 
    metabolite["pi", "e"] -> "&M_pi_e&", metabolite["pyr", "c"] -> 
     "&M_pyr_c&", metabolite["pyr", "e"] -> "&M_pyr_e&", 
    metabolite["q8", "c"] -> "&M_q8_c&", metabolite["q8h2", "c"] -> 
     "&M_q8h2_c&", metabolite["r5p", "c"] -> "&M_r5p_c&", 
    metabolite["ru5p-D", "c"] -> "&M_ru5p-D_c&", metabolite["s7p", "c"] -> 
     "&M_s7p_c&", metabolite["succ", "c"] -> "&M_succ_c&", 
    metabolite["succ", "e"] -> "&M_succ_e&", metabolite["succoa", "c"] -> 
     "&M_succoa_c&", metabolite["xu5p-D", "c"] -> "&M_xu5p-D_c&"}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, "UnitChecking" -> False, 
  "Stoichiometry" -> SparseArray[Automatic, {74, 98}, 0, 
    {1, {{0, 2, 4, 7, 9, 11, 13, 15, 18, 20, 27, 29, 31, 44, 50, 52, 54, 56, 
      65, 67, 76, 79, 82, 84, 86, 93, 96, 99, 102, 104, 108, 110, 117, 121, 
      123, 128, 130, 136, 138, 140, 177, 194, 212, 214, 217, 219, 221, 227, 
      229, 241, 251, 255, 257, 259, 261, 266, 274, 286, 297, 299, 302, 305, 
      311, 325, 337, 347, 349, 353, 357, 359, 362, 364, 367, 369, 371}, 
      {{29}, {55}, {18}, {57}, {13}, {55}, {57}, {37}, {56}, {28}, {56}, {3}, 
      {6}, {6}, {76}, {1}, {2}, {10}, {2}, {77}, {1}, {13}, {15}, {42}, {51}, 
      {53}, {62}, {4}, {5}, {3}, {62}, {3}, {7}, {11}, {12}, {13}, {31}, 
      {32}, {52}, {55}, {60}, {63}, {70}, {96}, {8}, {9}, {13}, {33}, {35}, 
      {39}, {9}, {78}, {7}, {61}, {4}, {15}, {8}, {14}, {37}, {39}, {45}, 
      {46}, {51}, {59}, {60}, {14}, {79}, {1}, {8}, {13}, {15}, {42}, {51}, 
      {53}, {62}, {70}, {20}, {75}, {97}, {13}, {71}, {74}, {10}, {19}, {19}, 
      {80}, {13}, {21}, {25}, {52}, {54}, {71}, {74}, {20}, {21}, {52}, {22}, 
      {23}, {53}, {22}, {23}, {81}, {25}, {82}, {24}, {26}, {27}, {69}, {27}, 
      {83}, {13}, {20}, {29}, {71}, {73}, {74}, {75}, {13}, {28}, {30}, {54}, 
      {30}, {84}, {13}, {31}, {32}, {34}, {35}, {32}, {85}, {13}, {31}, {33}, 
      {34}, {35}, {36}, {36}, {86}, {40}, {42}, {1}, {6}, {9}, {10}, {11}, 
      {12}, {13}, {15}, {16}, {17}, {19}, {22}, {27}, {28}, {29}, {31}, {32}, 
      {33}, {35}, {36}, {41}, {42}, {43}, {44}, {47}, {52}, {56}, {58}, {59}, 
      {61}, {63}, {64}, {67}, {68}, {72}, {96}, {97}, {6}, {9}, {12}, {16}, 
      {17}, {19}, {22}, {27}, {36}, {43}, {47}, {58}, {64}, {67}, {68}, {72}, 
      {88}, {4}, {5}, {11}, {12}, {13}, {15}, {16}, {18}, {21}, {26}, {32}, 
      {33}, {34}, {38}, {42}, {56}, {59}, {61}, {38}, {87}, {5}, {39}, {40}, 
      {17}, {41}, {17}, {89}, {26}, {42}, {43}, {44}, {45}, {46}, {43}, {90}, 
      {1}, {8}, {10}, {13}, {29}, {41}, {44}, {45}, {47}, {48}, {51}, {72}, 
      {13}, {28}, {33}, {35}, {37}, {39}, {46}, {48}, {72}, {97}, {31}, {33}, 
      {34}, {49}, {49}, {91}, {16}, {50}, {50}, {92}, {13}, {15}, {44}, {59}, 
      {60}, {13}, {18}, {25}, {30}, {59}, {60}, {61}, {63}, {11}, {12}, {13}, 
      {21}, {29}, {31}, {32}, {58}, {59}, {61}, {62}, {70}, {13}, {25}, {30}, 
      {41}, {45}, {46}, {51}, {53}, {61}, {63}, {64}, {64}, {94}, {13}, {66}, 
      {73}, {37}, {65}, {66}, {24}, {40}, {67}, {68}, {69}, {70}, {3}, {7}, 
      {11}, {12}, {13}, {31}, {32}, {52}, {55}, {60}, {61}, {63}, {70}, {96}, 
      {1}, {8}, {10}, {13}, {29}, {41}, {44}, {45}, {47}, {48}, {51}, {72}, 
      {13}, {28}, {33}, {35}, {37}, {39}, {46}, {48}, {72}, {97}, {58}, {93}, 
      {16}, {24}, {47}, {69}, {16}, {24}, {47}, {69}, {71}, {73}, {67}, {68}, 
      {95}, {8}, {70}, {65}, {73}, {74}, {96}, {98}, {96}, {97}}}, 
     {1, 1, -1, -1, -1.496, -1, 1, -1, 1, 1, -1, -1, 1, -1, 1, -1, 1, 1, -1, 
      1, 1, -3.7478, -1, -1, 1, 1, -1, 1, -1, 1, 1, 1, 2, 1, -1, 59.81, 1, 1, 
      1, 1, 1, -1, 1, 1, -1, 1, 4.1182, 1, -1, 1, -1, 1, -1, 1, -1, 1, 1, 1, 
      1, 1, 1, 1, 1, -1, 1, -1, 1, -1, -1, 3.7478, 1, 1, -1, -1, 1, -1, 1, 
      -1, 1, -0.361, 1, -1, -1, 1, -1, 1, -0.0709, 1, 1, -1, 1, 1, 1, -1, -1, 
      1, 1, -1, 1, -1, 1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -0.129, 1, -1, -1, 
      1, 1, 1, -0.205, -1, 1, -1, -1, 1, -0.2557, 1, 1, -1, -1, -1, 1, 
      -4.9414, -1, -1, 1, 2, 1, -1, 1, 1, -1, 1, 1, 1, 1, 1, 3, 59.81, 1, -2, 
      1, 1, 1, 2, 1, 1, 1, 1, 1, -1, 1, 1, 1, 2, 1, -4, 1, 1, 1, 1, 2, -1, 1, 
      2, 1, 2, 1, 1, -1, -1, -4, 2, -1, -1, -1, -2, -1, -2, 3, -1, -1, -2, 
      -1, -2, 1, 1, -1, -1, 1, -59.81, -1, 1, 1, -1, -1, -1, -1, -1, 1, -1, 
      -1, -1, -1, -1, 1, 1, -1, -1, 1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, 1, 
      -1, -1, -1, -3.547, -1, -1, -1, -1, 1, -1, -1, 1, 13.0279, -1, -1, 1, 
      -1, -1, -1, 1, -1, -1, -1, 1, 1, 1, -1, 1, -0.5, 1, -1, 1, -1.7867, -1, 
      1, 1, -1, -0.5191, 1, -1, -1, -1, 1, 1, -1, 1, -1, 59.81, 1, -1, 1, 1, 
      1, 1, 1, -1, 1, -2.8328, 1, 1, 1, 1, 1, -1, -1, -1, 1, 1, -1, 1, 
      -0.8977, -1, -1, 1, -1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, 1, -59.81, 
      -1, -1, -1, -1, -1, -1, 1, -1, -1, 1, 1, 1, 3.547, 1, 1, 1, 1, -1, 1, 
      1, -1, -13.0279, 1, 1, -1, 1, 1, 1, -1, 1, 1, -1, 1, 1, 1, -1, -1, -1, 
      -1, 1, 1, -1, 1, -1, 1, 1, 1, 1, 1, -1, -1, -1, 1, 1, -1}}], 
  "Species" -> {metabolite["13dpg", "c"], metabolite["2pg", "c"], 
    metabolite["3pg", "c"], metabolite["6pgc", "c"], metabolite["6pgl", "c"], 
    metabolite["ac", "c"], metabolite["ac", "e"], metabolite["acald", "c"], 
    metabolite["acald", "e"], metabolite["accoa", "c"], 
    metabolite["acon-C", "c"], metabolite["actp", "c"], 
    metabolite["adp", "c"], metabolite["akg", "c"], metabolite["akg", "e"], 
    metabolite["amp", "c"], metabolite["cit", "c"], metabolite["co2", "c"], 
    metabolite["co2", "e"], metabolite["coa", "c"], metabolite["dhap", "c"], 
    metabolite["e4p", "c"], metabolite["etoh", "c"], metabolite["etoh", "e"], 
    metabolite["f6p", "c"], metabolite["fdp", "c"], metabolite["for", "c"], 
    metabolite["for", "e"], metabolite["fru", "e"], metabolite["fum", "c"], 
    metabolite["fum", "e"], metabolite["g3p", "c"], metabolite["g6p", "c"], 
    metabolite["glc-D", "e"], metabolite["gln-L", "c"], 
    metabolite["gln-L", "e"], metabolite["glu-L", "c"], 
    metabolite["glu-L", "e"], metabolite["glx", "c"], metabolite["h", "c"], 
    metabolite["h", "e"], metabolite["h2o", "c"], metabolite["h2o", "e"], 
    metabolite["icit", "c"], metabolite["lac-D", "c"], 
    metabolite["lac-D", "e"], metabolite["mal-L", "c"], 
    metabolite["mal-L", "e"], metabolite["nad", "c"], 
    metabolite["nadp", "c"], metabolite["nh4", "c"], metabolite["nh4", "e"], 
    metabolite["o2", "c"], metabolite["o2", "e"], metabolite["oaa", "c"], 
    metabolite["pep", "c"], metabolite["pi", "c"], metabolite["pyr", "c"], 
    metabolite["pyr", "e"], metabolite["r5p", "c"], 
    metabolite["ru5p-D", "c"], metabolite["succ", "c"], 
    metabolite["atp", "c"], metabolite["nadh", "c"], 
    metabolite["nadph", "c"], metabolite["pi", "e"], metabolite["q8", "c"], 
    metabolite["q8h2", "c"], metabolite["s7p", "c"], metabolite["succ", "e"], 
    metabolite["succoa", "c"], metabolite["xu5p-D", "c"], 
    metabolite["glyc", "c"], metabolite["glyc3p", "c"]}, 
  "Fluxes" -> {v["ACALD"], v["ACALDt"], v["ACKr"], v["ACONTa"], v["ACONTb"], 
    v["ACt2r"], v["ADK1"], v["AKGDH"], v["AKGt2r"], v["ALCD2x"], v["ATPM"], 
    v["ATPS4r"], v["Biomass_Ecoli_core_N(w/GAM)_Nmet2"], v["CO2t"], v["CS"], 
    v["CYTBD"], v["D_LACt2"], v["ENO"], v["ETOHt2r"], v["FBA"], v["FBP"], 
    v["FORt2"], v["FORti"], v["FRD7"], v["FRUpts2"], v["FUM"], v["FUMt2_2"], 
    v["G6PDH2r"], v["GAPD"], v["GLCpts"], v["GLNS"], v["GLNabc"], v["GLUDy"], 
    v["GLUN"], v["GLUSy"], v["GLUt2r"], v["GND"], v["H2Ot"], v["ICDHyr"], 
    v["ICL"], v["LDH_D"], v["MALS"], v["MALt2_2"], v["MDH"], v["ME1"], 
    v["ME2"], v["NADH16"], v["NADTRHD"], v["NH4t"], v["O2t"], v["PDH"], 
    v["PFK"], v["PFL"], v["PGI"], v["PGK"], v["PGL"], v["PGM"], v["PIt2r"], 
    v["PPC"], v["PPCK"], v["PPS"], v["PTAr"], v["PYK"], v["PYRt2r"], 
    v["RPE"], v["RPI"], v["SUCCt2_2"], v["SUCCt3"], v["SUCDi"], v["SUCOAS"], 
    v["TALA"], v["THD2"], v["TKT1"], v["TKT2"], v["TPI"], v["EX_ac(e)"], 
    v["EX_acald(e)"], v["EX_akg(e)"], v["EX_co2(e)"], v["EX_etoh(e)"], 
    v["EX_for(e)"], v["EX_fru(e)"], v["EX_fum(e)"], v["EX_glc(e)"], 
    v["EX_gln_L(e)"], v["EX_glu_L(e)"], v["EX_h2o(e)"], v["EX_h(e)"], 
    v["EX_lac_D(e)"], v["EX_mal_L(e)"], v["EX_nh4(e)"], v["EX_o2(e)"], 
    v["EX_pi(e)"], v["EX_pyr(e)"], v["EX_succ(e)"], v["GLYK"], v["G3PD2"], 
    v["EX_glyc(e)"]}, "ReversibleColumnIndices" -> 
   {1, 2, 3, 4, 5, 6, 7, 9, 10, 12, 14, 17, 18, 19, 20, 26, 28, 29, 33, 36, 
    38, 39, 41, 44, 49, 50, 54, 55, 57, 58, 62, 64, 65, 66, 70, 71, 73, 74, 
    75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 
    93, 94, 95, 97, 98}, "Constraints" -> {v["AKGDH"] -> {0, Infinity}, 
    v["ATPM"] -> {0, Infinity}, v["Biomass_Ecoli_core_N(w/GAM)_Nmet2"] -> 
     {0, Infinity}, v["CS"] -> {0, Infinity}, v["CYTBD"] -> {0, Infinity}, 
    v["FBP"] -> {0, Infinity}, v["FORt2"] -> {0, Infinity}, 
    v["FORti"] -> {0, Infinity}, v["FRD7"] -> {0, Infinity}, 
    v["FRUpts2"] -> {0, Infinity}, v["FUMt2_2"] -> {0, Infinity}, 
    v["GLCpts"] -> {0, Infinity}, v["GLNS"] -> {0, Infinity}, 
    v["GLNabc"] -> {0, Infinity}, v["GLUN"] -> {0, Infinity}, 
    v["GLUSy"] -> {0, Infinity}, v["GND"] -> {0, Infinity}, 
    v["ICL"] -> {0, Infinity}, v["MALS"] -> {0, Infinity}, 
    v["MALt2_2"] -> {0, Infinity}, v["ME1"] -> {0, Infinity}, 
    v["ME2"] -> {0, Infinity}, v["NADH16"] -> {0, Infinity}, 
    v["NADTRHD"] -> {0, Infinity}, v["PDH"] -> {0, Infinity}, 
    v["PFK"] -> {0, Infinity}, v["PFL"] -> {0, Infinity}, 
    v["PGL"] -> {0, Infinity}, v["PPC"] -> {0, Infinity}, 
    v["PPCK"] -> {0, Infinity}, v["PPS"] -> {0, Infinity}, 
    v["PYK"] -> {0, Infinity}, v["SUCCt2_2"] -> {0, Infinity}, 
    v["SUCCt3"] -> {0, Infinity}, v["SUCDi"] -> {0, Infinity}, 
    v["THD2"] -> {0, Infinity}, v["EX_ac(e)"] -> {-Infinity, 0}, 
    v["EX_acald(e)"] -> {-Infinity, 0}, v["EX_akg(e)"] -> {-Infinity, 0}, 
    v["EX_co2(e)"] -> {-Infinity, 0}, v["EX_etoh(e)"] -> {-Infinity, 0}, 
    v["EX_for(e)"] -> {-Infinity, 0}, v["EX_fru(e)"] -> {-Infinity, 0}, 
    v["EX_fum(e)"] -> {-Infinity, 0}, v["EX_glc(e)"] -> {-Infinity, 0}, 
    v["EX_gln_L(e)"] -> {-Infinity, 0}, v["EX_glu_L(e)"] -> {-Infinity, 0}, 
    v["EX_h2o(e)"] -> {-Infinity, 0}, v["EX_h(e)"] -> {-Infinity, 0}, 
    v["EX_lac_D(e)"] -> {-Infinity, 0}, v["EX_mal_L(e)"] -> {-Infinity, 0}, 
    v["EX_nh4(e)"] -> {-Infinity, 0}, v["EX_o2(e)"] -> {-Infinity, 0}, 
    v["EX_pi(e)"] -> {-Infinity, 0}, v["EX_pyr(e)"] -> {-Infinity, 0}, 
    v["EX_succ(e)"] -> {-Infinity, 0}, v["GLYK"] -> {0, Infinity}, 
    v["EX_glyc(e)"] -> {-Infinity, 0}}, 
  "GPR" -> {"ACALD" -> protein["MhpF", None] || protein["AdhE", None], 
    "ACALDt" -> protein["SPONTANEOUS", None], 
    "ACKr" -> protein["AckA", None] || protein["TdcD", None] || 
      protein["PurT", None], "ACONTa" -> protein["AcnB", None] || 
      protein["AcnA", None], "ACONTb" -> protein["AcnB", None] || 
      protein["AcnA", None], "ADK1" -> protein["Adk", None], 
    "AKGDH" -> proteinComplex[protein["LpdA", None], protein["SucAec", None], 
      protein["SucBec", None]], "AKGt2r" -> protein["KgtPec", None], 
    "ALCD2x" -> protein["FrmA", None] || protein["AdhP", None] || 
      protein["AdhE", None], "ATPS4r" -> 
     proteinComplex[protein["AtpF0", None], protein["AtpF1", None], 
       protein["AtpI", None]] || proteinComplex[protein["AtpF0", None], 
       protein["AtpF1", None]], "CO2t" -> protein["SPONTANEOUS", None], 
    "CS" -> protein["GltA", None], "CYTBD" -> protein["CbdAB", None] || 
      protein["CydA", None], "D_LACt2" -> protein["GlcA", None] || 
      protein["LldP", None], "ENO" -> protein["Eno", None], 
    "FBA" -> protein["FbaA", None] || protein["FbaB", None] || 
      protein["B1773", None], "FBP" -> protein["Fbp", None] || 
      protein["GlpX", None], "FORt2" -> protein["FocA", None] || 
      protein["FocB", None], "FORti" -> protein["FocA", None] || 
      protein["FocB", None], "FRD7" -> protein["Frd", None], 
    "FRUpts2" -> proteinComplex[protein["ManX", None], protein["ManY", None], 
      protein["ManZ", None], protein["PtsH", None], protein["PtsI", None]], 
    "FUM" -> protein["FumA", None] || protein["FumB", None] || 
      protein["FumCec", None], "FUMt2_2" -> protein["DctA", None], 
    "G6PDH2r" -> protein["Zwf", None], "GAPD" -> protein["GapA", None], 
    "GLCpts" -> proteinComplex[protein["Crr", None], protein["MalX", None], 
       protein["PtsH", None], protein["PtsI", None]] || 
      proteinComplex[protein["Crr", None], protein["PtsG", None], 
       protein["PtsH", None], protein["PtsI", None]] || 
      proteinComplex[protein["ManX", None], protein["ManY", None], 
       protein["ManZ", None], protein["PtsH", None], protein["PtsI", None]], 
    "GLNabc" -> proteinComplex[protein["GlnHec", None], 
      protein["GlnPec", None], protein["GlnQec", None]], 
    "GLNS" -> protein["GlnA", None] || protein["YcjK", None], 
    "GLUDy" -> protein["GdhA", None], "GLUN" -> protein["PabBec", None] || 
      protein["YbaS", None] || protein["YneH", None], 
    "GLUSy" -> protein["GltB", None], "GLUt2r" -> protein["GltP", None], 
    "GND" -> protein["Gnd", None], "H2Ot" -> protein["AqpZ", None], 
    "ICDHyr" -> protein["Icd", None], "ICL" -> protein["AceA", None], 
    "LDH_D" -> protein["Ldh", None] || protein["Dld", None], 
    "MALS" -> protein["GlcB", None] || protein["AceB", None], 
    "MALt2_2" -> protein["DctA", None], "MDH" -> protein["Mdh", None], 
    "ME1" -> protein["Sfc", None], "ME2" -> protein["Mae", None], 
    "NADH16" -> protein["Nuo", None], "NADTRHD" -> protein["Pnt", None] || 
      protein["SthA", None], "NH4t" -> protein["AmtB", None], 
    "O2t" -> protein["SPONTANEOUS", None], 
    "PDH" -> proteinComplex[protein["AceEec", None], protein["AceFec", None], 
      protein["LpdA", None]], "PFK" -> protein["PfkA", None] || 
      protein["PfkB", None], "PFL" -> proteinComplex[protein["PflBec", None], 
       protein["YfiD", None]] || protein["PflBec", None] || 
      protein["TdcEec", None] || protein["PflDec", None], 
    "PGI" -> protein["Pgi", None], "PGK" -> protein["Pgk", None], 
    "PGL" -> protein["Pgl", None], "PGM" -> protein["GpmB", None] || 
      protein["GpmA", None] || protein["YibO", None], 
    "PIt2r" -> protein["PitBec", None] || protein["PitA", None], 
    "PPC" -> protein["Ppc", None], "PPCK" -> protein["Pck", None], 
    "PPS" -> protein["Ppsa", None], "PTAr" -> protein["Pta", None] || 
      protein["EutD", None], "PYK" -> protein["Pyka", None] || 
      protein["Pykf", None], "RPE" -> protein["Rpeec", None] || 
      protein["SgcE", None], "RPI" -> protein["RpiA", None] || 
      protein["RpiB", None], "SUCCt2_2" -> protein["DctA", None], 
    "SUCDi" -> protein["Sdh", None], "SUCOAS" -> protein["SucCD", None], 
    "TALA" -> protein["TalB", None] || protein["TalA", None], 
    "THD2" -> protein["Pnt", None], "TKT1" -> protein["TktA", None] || 
      protein["TktB", None], "TKT2" -> protein["TktA", None] || 
      protein["TktB", None], "TPI" -> protein["Tpi", None], 
    protein["AceA", None] -> gene["b4015", None], protein["AceB", None] -> 
     gene["b4014", None], protein["AceEec", None] -> gene["b0114", None], 
    protein["AceFec", None] -> gene["b0115", None], 
    protein["AckA", None] -> gene["b2296", None], protein["AcnA", None] -> 
     gene["b1276", None], protein["AcnB", None] -> gene["b0118", None], 
    protein["AdhE", None] -> gene["b1241", None], protein["AdhP", None] -> 
     gene["b1478", None], protein["Adk", None] -> gene["b0474", None], 
    protein["AmtB", None] -> gene["b0451", None], protein["AqpZ", None] -> 
     gene["b0875", None], protein["AtpF0", None] -> 
     geneComplex[gene["b3736", None], gene["b3737", None], 
      gene["b3738", None]], protein["AtpF1", None] -> 
     geneComplex[gene["b3731", None], gene["b3732", None], 
      gene["b3733", None], gene["b3734", None], gene["b3735", None]], 
    protein["AtpI", None] -> gene["b3739", None], protein["B1773", None] -> 
     gene["b1773", None], protein["CbdAB", None] -> 
     geneComplex[gene["b0978", None], gene["b0979", None]], 
    protein["Crr", None] -> gene["b2417", None], protein["CydA", None] -> 
     geneComplex[gene["b0733", None], gene["b0734", None]], 
    protein["DctA", None] -> gene["b3528", None], protein["Dld", None] -> 
     gene["b2133", None], protein["Eno", None] -> gene["b2779", None], 
    protein["EutD", None] -> gene["b2458", None], protein["FbaA", None] -> 
     gene["b2925", None], protein["FbaB", None] -> gene["b2097", None], 
    protein["Fbp", None] -> gene["b4232", None], protein["FocA", None] -> 
     gene["b0904", None], protein["FocB", None] -> gene["b2492", None], 
    protein["Frd", None] -> geneComplex[gene["b4151", None], 
      gene["b4152", None], gene["b4153", None], gene["b4154", None]], 
    protein["FrmA", None] -> gene["b0356", None], protein["FumA", None] -> 
     gene["b1612", None], protein["FumB", None] -> gene["b4122", None], 
    protein["FumCec", None] -> gene["b1611", None], 
    protein["GapA", None] -> gene["b1779", None], protein["GdhA", None] -> 
     gene["b1761", None], protein["GlcA", None] -> gene["b2975", None], 
    protein["GlcB", None] -> gene["b2976", None], protein["GlnA", None] -> 
     gene["b3870", None], protein["GlnHec", None] -> gene["b0811", None], 
    protein["GlnPec", None] -> gene["b0810", None], 
    protein["GlnQec", None] -> gene["b0809", None], 
    protein["GlpX", None] -> gene["b3925", None], protein["GltA", None] -> 
     gene["b0720", None], protein["GltB", None] -> 
     geneComplex[gene["b3212", None], gene["b3213", None]], 
    protein["GltP", None] -> gene["b4077", None], protein["Gnd", None] -> 
     gene["b2029", None], protein["GpmA", None] -> gene["b0755", None], 
    protein["GpmB", None] -> gene["b4395", None], protein["Icd", None] -> 
     gene["b1136", None], protein["KgtPec", None] -> gene["b2587", None], 
    protein["Ldh", None] -> gene["b1380", None], protein["LldP", None] -> 
     gene["b3603", None], protein["LpdA", None] -> gene["b0116", None], 
    protein["Mae", None] -> gene["b2463", None], protein["MalX", None] -> 
     gene["b1621", None], protein["ManX", None] -> gene["b1817", None], 
    protein["ManY", None] -> gene["b1818", None], protein["ManZ", None] -> 
     gene["b1819", None], protein["Mdh", None] -> gene["b3236", None], 
    protein["MhpF", None] -> gene["b0351", None], protein["Nuo", None] -> 
     geneComplex[gene["b2276", None], gene["b2277", None], 
      gene["b2278", None], gene["b2279", None], gene["b2280", None], 
      gene["b2281", None], gene["b2282", None], gene["b2283", None], 
      gene["b2284", None], gene["b2285", None], gene["b2286", None], 
      gene["b2287", None], gene["b2288", None]], protein["PabBec", None] -> 
     gene["b1812", None], protein["Pck", None] -> gene["b3403", None], 
    protein["PfkA", None] -> gene["b3916", None], protein["PfkB", None] -> 
     gene["b1723", None], protein["PflBec", None] -> 
     geneComplex[gene["b0902", None], gene["b0903", None]], 
    protein["PflDec", None] -> geneComplex[gene["b3951", None], 
      gene["b3952", None]], protein["Pgi", None] -> gene["b4025", None], 
    protein["Pgk", None] -> gene["b2926", None], protein["Pgl", None] -> 
     gene["b0767", None], protein["PitA", None] -> gene["b3493", None], 
    protein["PitBec", None] -> gene["b2987", None], 
    protein["Pnt", None] -> geneComplex[gene["b1602", None], 
      gene["b1603", None]], protein["Ppc", None] -> gene["b3956", None], 
    protein["Ppsa", None] -> gene["b1702", None], protein["Pta", None] -> 
     gene["b2297", None], protein["PtsG", None] -> gene["b1101", None], 
    protein["PtsH", None] -> gene["b2415", None], protein["PtsI", None] -> 
     gene["b2416", None], protein["PurT", None] -> gene["b1849", None], 
    protein["Pyka", None] -> gene["b1854", None], protein["Pykf", None] -> 
     gene["b1676", None], protein["Rpeec", None] -> gene["b3386", None], 
    protein["RpiA", None] -> gene["b2914", None], protein["RpiB", None] -> 
     gene["b4090", None], protein["Sdh", None] -> 
     geneComplex[gene["b0721", None], gene["b0722", None], 
      gene["b0723", None], gene["b0724", None]], protein["Sfc", None] -> 
     gene["b1479", None], protein["SgcE", None] -> gene["b4301", None], 
    protein["SPONTANEOUS", None] -> gene["s0001", None], 
    protein["SthA", None] -> gene["b3962", None], protein["SucAec", None] -> 
     gene["b0726", None], protein["SucBec", None] -> gene["b0727", None], 
    protein["SucCD", None] -> geneComplex[gene["b0728", None], 
      gene["b0729", None]], protein["TalA", None] -> gene["b2464", None], 
    protein["TalB", None] -> gene["b0008", None], protein["TdcD", None] -> 
     gene["b3115", None], protein["TdcEec", None] -> 
     geneComplex[gene["b0902", None], gene["b3114", None]], 
    protein["TktA", None] -> gene["b2935", None], protein["TktB", None] -> 
     gene["b2465", None], protein["Tpi", None] -> gene["b3919", None], 
    protein["YbaS", None] -> gene["b0485", None], protein["YcjK", None] -> 
     gene["b1297", None], protein["YfiD", None] -> gene["b2579", None], 
    protein["YibO", None] -> gene["b3612", None], protein["YneH", None] -> 
     gene["b1524", None], protein["Zwf", None] -> gene["b1852", None]}, 
  "InitialConditions" -> {}, "Notes" -> "Model constructed on Thu 4 Apr 2013 \
11:27:47 by niko on Nikolauss-MacBook-Pro.Speedport_W_723V_1_27_000 using \
Mathematica 9.0 for Mac OS X x86 (64-bit) (November 20, 2012) at the \
following geodetic location: latitude 49.83; longitude 8.75", 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Objective" -> v["Biomass_Ecoli_core_N(w/GAM)_Nmet2"], 
  "Parameters" -> {parameter["Volume", "c"] -> 1, parameter["Volume", "e"] -> 
     1, Keq["ACALD"] -> Unit[881.9639890201993, "Liter"/"Mole"], 
    Keq["ACALDt"] -> 1., Keq["ACKr"] -> 0.009863720303315907, 
    Keq["ACONTa"] -> 0.033873428341686204, Keq["ACONTb"] -> 
     2.0191736554588604, Keq["ACt2r"] -> Unit[1., "Liter"/"Mole"], 
    Keq["ADK1"] -> 2.317807444256622, Keq["AKGDH"] -> 285734.483274704, 
    Keq["AKGt2r"] -> Unit[1., "Liter"/"Mole"], Keq["ALCD2x"] -> 
     0.0005359278522153397, Keq["ATPM"] -> Unit[6.580638339170971*^6, 
      "Mole"/"Liter"], Keq["ATPS4r"] -> Unit[1.5196094185081444*^-7, 
      "Liter"^5/"Mole"^5], Keq["Biomass_Ecoli_core_N(w/GAM)_Nmet2"] -> 
     Unit[1.69701472067029265110585533201002323799`15.954589770191005*^-655, 
      "Mole"^50.432900000000004/"Liter"^50.432900000000004], 
    Keq["CO2t"] -> 1., Keq["CS"] -> 3.3046093063901997*^8, 
    Keq["CYTBD"] -> Unit[1.7263738720556057*^27, "Mole"^1.5/"Liter"^1.5], 
    Keq["D_LACt2"] -> Unit[1., "Liter"/"Mole"], 
    Keq["ENO"] -> 5.420986448861225, Keq["ETOHt2r"] -> 
     Unit[1., "Liter"/"Mole"], Keq["FBA"] -> Unit[0.00009266038033496128, 
      "Mole"/"Liter"], Keq["FBP"] -> Unit[132.16207822465418, 
      "Mole"/"Liter"], Keq["FORt2"] -> Unit[1., "Liter"/"Mole"], 
    Keq["FORti"] -> 1., Keq["FRD7"] -> 0.5816385662794537, 
    Keq["FRUpts2"] -> 7.371727275992091*^8, Keq["FUM"] -> 4.276712764813309, 
    Keq["FUMt2_2"] -> Unit[1., "Liter"^2/"Mole"^2], 
    Keq["G6PDH2r"] -> 13.923040345730344, Keq["GAPD"] -> 
     Unit[2.2422194618021196, "Liter"/"Mole"], Keq["GLCpts"] -> 
     2.246845302456368*^9, Keq["GLNS"] -> 5.700096163501992, 
    Keq["GLNabc"] -> Unit[6.580638339172186*^6, "Mole"/"Liter"], 
    Keq["GLUDy"] -> Unit[0.0009223295551814294, "Mole"/"Liter"], 
    Keq["GLUN"] -> Unit[37932.12217024058, "Mole"/"Liter"], 
    Keq["GLUSy"] -> 2.0983108022023326*^8, Keq["GLUt2r"] -> 
     Unit[1., "Liter"/"Mole"], Keq["GND"] -> Unit[0.07080597059489328, 
      "Mole"/"Liter"], Keq["H2Ot"] -> 1., Keq["ICDHyr"] -> 
     Unit[0.8167639790774919, "Mole"/"Liter"], 
    Keq["ICL"] -> Unit[0.9028516336606185, "Mole"/"Liter"], 
    Keq["LDH_D"] -> 0.004289848435217588, Keq["MALS"] -> 
     1.1184764057866309*^9, Keq["MALt2_2"] -> Unit[1., "Liter"^2/"Mole"^2], 
    Keq["MDH"] -> 0.00003544824023290012, Keq["ME1"] -> 
     Unit[0.058359547079784684, "Mole"/"Liter"], 
    Keq["ME2"] -> Unit[0.06909973618378078, "Mole"/"Liter"], 
    Keq["NADH16"] -> Unit[3.5808156148289246*^11, "Mole"^3/"Liter"^3], 
    Keq["NADTRHD"] -> 0.8445697524020785, Keq["NH4t"] -> 1., 
    Keq["O2t"] -> 1., Keq["PDH"] -> 19935.725137785976, 
    Keq["PFK"] -> 49792.18265608489, Keq["PFL"] -> 71.17650688988675, 
    Keq["PGI"] -> 0.2803309966391505, Keq["PGK"] -> 0.0350003111520932, 
    Keq["PGL"] -> 915745.1698029245, Keq["PGM"] -> 11.639621069413774, 
    Keq["PIt2r"] -> Unit[1., "Liter"/"Mole"], 
    Keq["PPC"] -> 1.1965100229470268*^8, Keq["PPCK"] -> 
     Unit[0.05499860605398131, "Mole"/"Liter"], 
    Keq["PPS"] -> Unit[94.84733220396322, "Mole"/"Liter"], 
    Keq["PTAr"] -> 0.12832992302981175, Keq["PYK"] -> 29934.05484923974, 
    Keq["PYRt2r"] -> Unit[1., "Liter"/"Mole"], Keq["RPE"] -> 1., 
    Keq["RPI"] -> 0.8306375835580814, Keq["SUCCt2_2"] -> 
     Unit[1., "Liter"^2/"Mole"^2], Keq["SUCCt3"] -> Unit[1., "Liter"/"Mole"], 
    Keq["SUCDi"] -> 1.7192807663987342, Keq["SUCOAS"] -> 1.1040166248280416, 
    Keq["TALA"] -> 6.578968990537067, Keq["THD2"] -> 
     Unit[1.1840348262009803, "Liter"^2/"Mole"^2], 
    Keq["TKT1"] -> 0.13503372861298482, Keq["TKT2"] -> 6.575777126046173, 
    Keq["TPI"] -> 0.04550169495030021, Keq["EX_ac(e)"] -> 
     4.138653352159374*^41, Keq["EX_acald(e)"] -> 2.4227712038882407*^-7, 
    Keq["EX_akg(e)"] -> 3.975588157169852*^108, Keq["EX_co2(e)"] -> 
     4.209184289321576*^67, Keq["EX_etoh(e)"] -> 2.3485807912676607*^-15, 
    Keq["EX_for(e)"] -> 7.807320413944368*^53, Keq["EX_fru(e)"] -> 
     3.076182661299225*^67, Keq["EX_fum(e)"] -> 3.363291559127604*^90, 
    Keq["EX_glc(e)"] -> 3.6002867055536885*^67, Keq["EX_gln_L(e)"] -> 
     1.2203405422712812*^15, Keq["EX_glu_L(e)"] -> 2.5024077423937426*^60, 
    Keq["EX_h2o(e)"] -> 1.1752764037388105*^26, Keq["EX_h(e)"] -> 1, 
    Keq["EX_lac_D(e)"] -> 1.48490587762278*^51, Keq["EX_mal_L(e)"] -> 
     1.6904978277611973*^117, Keq["EX_nh4(e)"] -> 1.2371528541943591*^-17, 
    Keq["EX_o2(e)"] -> 0.001339206500237723, Keq["EX_pi(e)"] -> 
     7.943019435678174*^184, Keq["EX_pyr(e)"] -> 4.511585162941747*^59, 
    Keq["EX_succ(e)"] -> 3.6391428245546977*^90, 
    Keq["GLYK"] -> 1.7215433476268813*^7, Keq["G3PD2"] -> 
     1.8877907764543144*^-7, Keq["EX_glyc(e)"] -> 1.6588756499027838*^25}}]
