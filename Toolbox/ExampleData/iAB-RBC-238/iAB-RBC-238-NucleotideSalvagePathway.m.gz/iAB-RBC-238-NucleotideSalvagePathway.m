(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"Synonyms" -> {}, "Events" -> {}, "ID" -> "iAB-RBC-238", 
  "Name" -> "MASSmodel$15", "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "GPR" -> {"ADA" -> protein["Ada.1", None], 
    "ADNK1" -> protein["Adk.1", None], "ADNK1" -> protein["Adk.2", None], 
    "ADPT" -> protein["AprT.1", None], "AMPDA" -> protein["AmpD3.1", None], 
    "NTD11" -> protein["Nt5C2.1", None], "NTD7" -> protein["Nt5C2.1", None], 
    "PPM" -> protein["Pgm1.1", None], "PRPPS" -> protein["Prps1.1", None], 
    "PRPPS" -> protein["Prps1l1.1", None], 
    "PRPPS" -> protein["Prps1l1.2", None], "PUNP5" -> protein["Np.1", None]}, 
  "ElementalComposition" -> {metabolite["ade", "c"] -> 5*"C" + 5*"H" + 5*"N", 
    metabolite["adn", "c"] -> 10*"C" + 13*"H" + 5*"N" + 4*"O", 
    metabolite["adp", "c"] -> 10*"C" + 12*"H" + 5*"N" + 10*"O" + 2*"P", 
    metabolite["amp", "c"] -> 10*"C" + 12*"H" + 5*"N" + 7*"O" + "P", 
    metabolite["atp", "c"] -> 10*"C" + 12*"H" + 5*"N" + 13*"O" + 3*"P", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["hxan", "c"] -> 5*"C" + 4*"H" + 4*"N" + "O", 
    metabolite["imp", "c"] -> 10*"C" + 11*"H" + 4*"N" + 8*"O" + "P", 
    metabolite["ins", "c"] -> 10*"C" + 12*"H" + 4*"N" + 5*"O", 
    metabolite["nh4", "c"] -> 4*"H" + "N", metabolite["pi", "c"] -> 
     "H" + 4*"O" + "P", metabolite["ppi", "c"] -> "H" + 7*"O" + 2*"P", 
    metabolite["prpp", "c"] -> 5*"C" + 8*"H" + 14*"O" + 3*"P", 
    metabolite["r1p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P", 
    metabolite["r5p", "c"] -> 5*"C" + 9*"H" + 8*"O" + "P"}, 
  "BoundaryConditions" -> {}, "Constant" -> {}, "Objective" -> Automatic, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "UnitChecking" -> True, "Stoichiometry" -> SparseArray[Automatic, {16, 21}, 
    0, {1, {{0, 2, 6, 9, 15, 18, 24, 26, 30, 33, 38, 40, 42, 44, 46, 52, 54}, 
      {{3}, {11}, {1}, {2}, {6}, {12}, {2}, {10}, {21}, {2}, {3}, {4}, {6}, 
      {8}, {16}, {2}, {8}, {10}, {1}, {4}, {5}, {6}, {10}, {18}, {9}, {13}, 
      {1}, {5}, {9}, {14}, {1}, {4}, {20}, {5}, {6}, {9}, {10}, {15}, {3}, 
      {19}, {3}, {8}, {7}, {9}, {7}, {8}, {1}, {2}, {4}, {8}, {10}, {17}, 
      {4}, {5}}}, {-1, -1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, -1, 1, -1, -1, 
     -1, 1, -1, -1, -1, -1, 1, -1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1, 1, -1, 
     -1, -1, 1, -1, -1, 1, -1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, -1}}], 
  "Species" -> {metabolite["ade", "c"], metabolite["adn", "c"], 
    metabolite["adp", "c"], metabolite["amp", "c"], metabolite["atp", "c"], 
    metabolite["h2o", "c"], metabolite["hxan", "c"], metabolite["ins", "c"], 
    metabolite["nh4", "c"], metabolite["pi", "c"], metabolite["ppi", "c"], 
    metabolite["prpp", "c"], metabolite["r1p", "c"], metabolite["r5p", "c"], 
    metabolite["h", "c"], metabolite["imp", "c"]}, 
  "Fluxes" -> {v["ADA"], v["ADNK1"], v["ADPT"], v["AMPDA"], v["NTD11"], 
    v["NTD7"], v["PPM"], v["PRPPS"], v["PUNP5"], v["vatpgen"], 
    v["Sink_ade[c]"], v["Sink_adn[c]"], v["Sink_hxan[c]"], v["Sink_ins[c]"], 
    v["Sink_pi[c]"], v["Sink_amp[c]"], v["Sink_h[c]"], v["Sink_h2o[c]"], 
    v["Sink_ppi[c]"], v["Sink_nh4[c]"], v["Sink_adp[c]"]}, 
  "ReversibleColumnIndices" -> {7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 
    19, 20, 21}, "Constraints" -> {v["ADA"] -> {0., 1000.}, 
    v["ADNK1"] -> {0., 1000.}, v["ADPT"] -> {0., 1000.}, 
    v["AMPDA"] -> {0., 1000.}, v["NTD11"] -> {0., 1000.}, 
    v["NTD7"] -> {0., 1000.}, v["PPM"] -> {-1000., 1000.}, 
    v["PRPPS"] -> {-1000., 1000.}, v["PUNP5"] -> {-1000., 1000.}, 
    v["Sink_ade[c]"] -> {0, Infinity}, v["Sink_adn[c]"] -> {0, Infinity}, 
    v["Sink_hxan[c]"] -> {0, Infinity}, v["Sink_ins[c]"] -> {0, Infinity}, 
    v["Sink_pi[c]"] -> {0, Infinity}, v["Sink_amp[c]"] -> {0, Infinity}, 
    v["Sink_h[c]"] -> {0, Infinity}, v["Sink_h2o[c]"] -> {0, Infinity}, 
    v["Sink_ppi[c]"] -> {0, Infinity}, v["Sink_nh4[c]"] -> {0, Infinity}, 
    v["Sink_adp[c]"] -> {0, Infinity}}, "InitialConditions" -> 
   {metabolite["r5p", "c"] -> Unit[0.00494, "Millimole"/"Liter"], 
    metabolite["ade", "c"] -> Unit[0.001, "Millimole"/"Liter"], 
    metabolite["adn", "c"] -> Unit[0.0012, "Millimole"/"Liter"], 
    metabolite["imp", "c"] -> Unit[0.01, "Millimole"/"Liter"], 
    metabolite["ins", "c"] -> Unit[0.001, "Millimole"/"Liter"], 
    metabolite["hxan", "c"] -> Unit[0.002, "Millimole"/"Liter"], 
    metabolite["r1p", "c"] -> Unit[0.06, "Millimole"/"Liter"], 
    metabolite["prpp", "c"] -> Unit[0.005, "Millimole"/"Liter"], 
    metabolite["amp", "c"] -> Unit[0.08672812499999999, "Millimole"/"Liter"], 
    metabolite["adp", "c"] -> Unit[0.29, "Millimole"/"Liter"], 
    metabolite["atp", "c"] -> Unit[1.6, "Millimole"/"Liter"], 
    metabolite["pi", "c"] -> Unit[2.5, "Millimole"/"Liter"], 
    metabolite["ppi", "c"] -> Unit[0.0015, "Millimole"/"Liter"], 
    metabolite["h", "c"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "c"] -> 
     Unit[0.99999976, "Millimole"/"Liter"], metabolite["nh4", "c"] -> 
     Unit[0.091, "Millimole"/"Liter"], v["ADA"] -> 
     Unit[0.01, "Millimole"/("Hour"*"Liter")], 
    v["ADNK1"] -> Unit[0.12, "Millimole"/("Hour"*"Liter")], 
    v["ADPT"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["AMPDA"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["NTD11"] -> Unit[0.014, "Millimole"/("Hour"*"Liter")], 
    v["NTD7"] -> Unit[0.09600000000000455, "Millimole"/("Hour"*"Liter")], 
    v["PPM"] -> Unit[0.014000000000010004, "Millimole"/("Hour"*"Liter")], 
    v["PRPPS"] -> Unit[0.014000000000010004, "Millimole"/("Hour"*"Liter")], 
    v["PUNP5"] -> Unit[0.014000000000010004, "Millimole"/("Hour"*"Liter")], 
    v["vatpgen"] -> Unit[0.13400000000000456, "Millimole"/("Hour"*"Liter")], 
    v["Sink_ade[c]"] -> Unit[-0.014, "Millimole"/("Hour"*"Liter")], 
    v["Sink_adn[c]"] -> Unit[-0.03399999999999545, 
      "Millimole"/("Hour"*"Liter")], v["Sink_hxan[c]"] -> 
     Unit[0.014, "Millimole"/("Hour"*"Liter")], v["Sink_ins[c]"] -> 
     Unit[0.01000000000000091, "Millimole"/("Hour"*"Liter")], 
    v["Sink_pi[c]"] -> Unit[-0.03799999999999, "Millimole"/("Hour"*"Liter")], 
    v["Sink_amp[c]"] -> Unit[0.038, "Millimole"/("Hour"*"Liter")], 
    v["Sink_h[c]"] -> Unit[-0.023999999999990904, 
      "Millimole"/("Hour"*"Liter")], v["Sink_h2o[c]"] -> 
     Unit[0, "Millimole"/("Hour"*"Liter")], v["Sink_ppi[c]"] -> 
     Unit[0.014, "Millimole"/("Hour"*"Liter")], v["Sink_nh4[c]"] -> 
     Unit[0.024, "Millimole"/("Hour"*"Liter")], v["Sink_adp[c]"] -> 
     Unit[-0.014000000000004552, "Millimole"/("Hour"*"Liter")]}, 
  "Parameters" -> {metabolite["ppi", "Xt"] -> 
     Unit[0.0015, "Millimole"/"Liter"], metabolite["adn", "Xt"] -> 
     Unit[0.0012001, "Millimole"/"Liter"], metabolite["ade", "Xt"] -> 
     Unit[0.00100014, "Millimole"/"Liter"], metabolite["hxan", "Xt"] -> 
     Unit[0.00199986, "Millimole"/"Liter"], metabolite["nh4", "Xt"] -> 
     Unit[0.0909999, "Millimole"/"Liter"], metabolite["amp", "Xt"] -> 
     Unit[0.09540093749999999, "Millimole"/"Liter"], 
    metabolite["h", "Xt"] -> Unit[0.0006309573444801929, 
      "Millimole"/"Liter"], metabolite["pi", "Xt"] -> 
     Unit[0.25, "Millimole"/"Liter"], metabolite["ins", "Xt"] -> 
     Unit[0.0009999, "Millimole"/"Liter"], metabolite["adp", "Xt"] -> 
     Unit[0.3, "Millimole"/"Liter"], metabolite["h2o", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], parameter["Volume", "c"] -> 
     Unit[1, "Liter"], Keq["ADNK1"] -> 1000000, 
    Keq["NTD7"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["ADA"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["AMPDA"] -> Unit[1000000, "Millimole"/"Liter"], 
    Keq["NTD11"] -> Unit[1000000, "Millimole"/"Liter"], Keq["PUNP5"] -> 0.09, 
    Keq["PPM"] -> 13.3, Keq["PRPPS"] -> 1000000, Keq["ADPT"] -> 1000000, 
    Keq["Sink_ade[c]"] -> 1, Keq["Sink_pi[c]"] -> 1, Keq["Sink_adp[c]"] -> 1, 
    Keq["Sink_amp[c]"] -> 1, Keq["Sink_ppi[c]"] -> 100000, 
    Keq["Sink_adn[c]"] -> 0.1, Keq["Sink_ins[c]"] -> 1, 
    Keq["Sink_hxan[c]"] -> 1, Keq["Sink_nh4[c]"] -> 1, 
    Keq["vatpgen"] -> Unit[1000000, "Liter"/"Millimole"], 
    Keq["Sink_h[c]"] -> 1, Keq["Sink_h2o[c]"] -> 1, 
    rateconst["ADA", True] -> Unit[8.333333333333334, "Hour"^(-1)], 
    rateconst["ADNK1", True] -> Unit[62.5, "Liter"/("Hour"*"Millimole")], 
    rateconst["ADPT", True] -> Unit[2799.9999999999995, 
      "Liter"/("Hour"*"Millimole")], rateconst["AMPDA", True] -> 
     Unit[0.16142399019925777, "Hour"^(-1)], rateconst["NTD11", True] -> 
     Unit[1.4000000000000001, "Hour"^(-1)], rateconst["NTD7", True] -> 
     Unit[1.1069073613663916, "Hour"^(-1)], rateconst["PPM", True] -> 
     Unit[0.2347867752756829, "Hour"^(-1)], rateconst["PRPPS", True] -> 
     Unit[1.771255157907161, "Liter"/("Hour"*"Millimole")], 
    rateconst["PUNP5", True] -> Unit[12.000000000008574, 
      "Liter"/("Hour"*"Millimole")], rateconst["vatpgen", True] -> 
     Unit[0.18482799410316572, "Liter"/("Hour"*"Millimole")], 
    rateconst["Sink_ade[c]", True] -> Unit[99999.99999997434, "Hour"^(-1)], 
    rateconst["Sink_adn[c]", True] -> Unit[3.1478566799366217, "Hour"^(-1)], 
    rateconst["Sink_hxan[c]", True] -> Unit[99999.99999997434, "Hour"^(-1)], 
    rateconst["Sink_ins[c]", True] -> Unit[99999.99999995244, "Hour"^(-1)], 
    rateconst["Sink_pi[c]", True] -> Unit[-0.016888888888884443, 
      "Hour"^(-1)], rateconst["Sink_amp[c]", True] -> 
     Unit[-4.381508305408423, "Hour"^(-1)], rateconst["Sink_h[c]", True] -> 
     Unit[42.2638184656137, "Hour"^(-1)], rateconst["Sink_h2o[c]", True] -> 
     Unit[1, "Hour"^(-1)], rateconst["Sink_ppi[c]", True] -> 
     Unit[9.333426667600008, "Hour"^(-1)], rateconst["Sink_nh4[c]", True] -> 
     Unit[239999.99999309864, "Hour"^(-1)], rateconst["Sink_adp[c]", True] -> 
     Unit[1.400000000000454, "Hour"^(-1)]}, "Notes" -> "\nModel constructed \
on Tue 30 Apr 2013 16:15:41 by niko on staphylococcus.ucsd.edu using \
Mathematica 9.0 for Mac OS X x86 (64-bit) (November 20, 2012) at the \
following geodetic location: latitude 32.88; longitude -117.24\n This model \
is a translation of the nucleotide salvage pathway model in 'Simulation of \
dynamic network state' in terms of the iAB-RBC-238 reconstruction by Aarash \
Bordbar."}]
