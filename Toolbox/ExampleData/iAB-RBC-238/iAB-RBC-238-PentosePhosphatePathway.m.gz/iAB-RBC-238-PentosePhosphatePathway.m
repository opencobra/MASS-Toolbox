(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"Synonyms" -> {}, "Events" -> {}, "Name" -> "MASSmodel$15", 
  "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "GPR" -> {"G6PDH2r" -> protein["G6pd.1", None], 
    "GND" -> protein["Pgd.1", None], "GTHO" -> protein["Gsr.2", None], 
    "GTHP" -> protein["Gpx1.1", None], "GTHP" -> protein["Gpx1.2", None], 
    "GTHP" -> protein["Gpx4.1", None], "GTHP" -> protein["Prdx1.1", None], 
    "GTHP" -> protein["Prdx1.2", None], "GTHP" -> protein["Prdx1.3", None], 
    "GTHP" -> protein["Prdx2.1", None], "GTHP" -> protein["Prdx2.2", None], 
    "GTHP" -> protein["Prdx2.3", None], "PGL" -> protein["Pgls.1", None], 
    "RPE" -> protein["Rpe.1", None], "RPE" -> protein["Rpe.2", None], 
    "RPI" -> protein["Rpia.1", None], "TALA" -> protein["Taldo1.1", None], 
    "TKT1" -> protein["Tkt.1", None], "TKT2" -> protein["Tkt.1", None]}, 
  "ElementalComposition" -> {metabolite["6pgc", "c"] -> 
     6*"C" + 10*"H" + 10*"O" + "P", metabolite["6pgl", "c"] -> 
     6*"C" + 9*"H" + 9*"O" + "P", metabolite["co2", "c"] -> "C" + 2*"O", 
    metabolite["e4p", "c"] -> 4*"C" + 7*"H" + 7*"O" + "P", 
    metabolite["f6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["g3p", "c"] -> 3*"C" + 5*"H" + 6*"O" + "P", 
    metabolite["g6p", "c"] -> 6*"C" + 11*"H" + 9*"O" + "P", 
    metabolite["gthox", "c"] -> 20*"C" + 30*"H" + 6*"N" + 12*"O" + 2*"S", 
    metabolite["gthrd", "c"] -> 10*"C" + 16*"H" + 3*"N" + 6*"O" + "S", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["h2o2", "c"] -> 2*"H" + 2*"O", metabolite["nadp", "c"] -> 
     21*"C" + 25*"H" + 7*"N" + 17*"O" + 3*"P", metabolite["nadph", "c"] -> 
     21*"C" + 26*"H" + 7*"N" + 17*"O" + 3*"P", metabolite["r5p", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P", metabolite["ru5p-D", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P", metabolite["s7p", "c"] -> 
     7*"C" + 13*"H" + 10*"O" + "P", metabolite["xu5p-D", "c"] -> 
     5*"C" + 9*"H" + 8*"O" + "P"}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "Objective" -> Automatic, "UnitChecking" -> True, 
  "ID" -> "iAB-RBC-238-PentosePhosphatePathway", 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Stoichiometry" -> SparseArray[Automatic, {18, 17}, 0, 
    {1, {{0, 2, 4, 6, 8, 11, 15, 17, 21, 24, 26, 29, 32, 34, 37, 39, 42, 44, 
      46}, {{2}, {5}, {1}, {5}, {2}, {16}, {8}, {10}, {8}, {10}, {11}, {8}, 
      {9}, {10}, {13}, {3}, {4}, {1}, {3}, {5}, {15}, {4}, {5}, {14}, {4}, 
      {17}, {1}, {2}, {3}, {1}, {2}, {3}, {7}, {9}, {2}, {6}, {7}, {8}, {9}, 
      {6}, {9}, {10}, {1}, {12}, {3}, {4}}}, {-1, 1, 1, -1, 1, -1, 1, -1, 1, 
     1, -1, -1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 2, -1, -1, -1, -1, -1, -1, 1, 
     1, 1, -1, -1, -1, 1, -1, 1, -1, 1, 1, -1, -1, -1, -1, 2, -2}}], 
  "Species" -> {metabolite["6pgc", "c"], metabolite["6pgl", "c"], 
    metabolite["co2", "c"], metabolite["e4p", "c"], metabolite["f6p", "c"], 
    metabolite["g3p", "c"], metabolite["gthox", "c"], metabolite["h", "c"], 
    metabolite["h2o", "c"], metabolite["h2o2", "c"], metabolite["nadp", "c"], 
    metabolite["nadph", "c"], metabolite["r5p", "c"], 
    metabolite["ru5p-D", "c"], metabolite["s7p", "c"], 
    metabolite["xu5p-D", "c"], metabolite["g6p", "c"], 
    metabolite["gthrd", "c"]}, "Fluxes" -> {v["G6PDH2r"], v["GND"], 
    v["GTHO"], v["GTHP"], v["PGL"], v["RPE"], v["RPI"], v["TALA"], v["TKT1"], 
    v["TKT2"], v["Sink_f6p[c]"], v["Sink_g6p[c]"], v["Sink_g3p[c]"], 
    v["Sink_h2o[c]"], v["Sink_h[c]"], v["Sink_co2[c]"], v["Sink_h2o2[c]"]}, 
  "ReversibleColumnIndices" -> {1, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 
    17}, "Constraints" -> {v["G6PDH2r"] -> {-1000., 1000.}, 
    v["GND"] -> {0., 1000.}, v["GTHO"] -> {0., 1000.}, 
    v["GTHP"] -> {0., 1000.}, v["PGL"] -> {0., 1000.}, 
    v["RPE"] -> {-1000., 1000.}, v["RPI"] -> {-1000., 1000.}, 
    v["TALA"] -> {-1000., 1000.}, v["TKT1"] -> {-1000., 1000.}, 
    v["TKT2"] -> {-1000., 1000.}, v["Sink_f6p[c]"] -> {0, Infinity}, 
    v["Sink_g6p[c]"] -> {0, Infinity}, v["Sink_g3p[c]"] -> {0, Infinity}, 
    v["Sink_h2o[c]"] -> {0, Infinity}, v["Sink_h[c]"] -> {0, Infinity}, 
    v["Sink_co2[c]"] -> {0, Infinity}, v["Sink_h2o2[c]"] -> {0, Infinity}}, 
  "InitialConditions" -> 
   {v["G6PDH2r"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["GND"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["GTHO"] -> Unit[0.42, "Millimole"/("Hour"*"Liter")], 
    v["GTHP"] -> Unit[0.42, "Millimole"/("Hour"*"Liter")], 
    v["PGL"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["RPE"] -> Unit[0.13999999999998636, "Millimole"/("Hour"*"Liter")], 
    v["RPI"] -> Unit[-0.07000000000005002, "Millimole"/("Hour"*"Liter")], 
    v["TALA"] -> Unit[0.07000000000005002, "Millimole"/("Hour"*"Liter")], 
    v["TKT1"] -> Unit[0.07000000000005002, "Millimole"/("Hour"*"Liter")], 
    v["TKT2"] -> Unit[0.07000000000005002, "Millimole"/("Hour"*"Liter")], 
    v["Sink_f6p[c]"] -> Unit[0.13999999999999999, 
      "Millimole"/("Hour"*"Liter")], v["Sink_g6p[c]"] -> 
     Unit[-0.21, "Millimole"/("Hour"*"Liter")], v["Sink_g3p[c]"] -> 
     Unit[0.06999999999999999, "Millimole"/("Hour"*"Liter")], 
    v["Sink_h2o[c]"] -> Unit[0.63, "Millimole"/("Hour"*"Liter")], 
    v["Sink_h[c]"] -> Unit[0., "Millimole"/("Hour"*"Liter")], 
    v["Sink_co2[c]"] -> Unit[0.21, "Millimole"/("Hour"*"Liter")], 
    v["Sink_h2o2[c]"] -> Unit[-0.42, "Millimole"/("Hour"*"Liter")], 
    metabolite["g6p", "c"] -> Unit[0.0486, "Millimole"/"Liter"], 
    metabolite["f6p", "c"] -> Unit[0.0198, "Millimole"/"Liter"], 
    metabolite["g3p", "c"] -> Unit[0.00728, "Millimole"/"Liter"], 
    metabolite["6pgl", "c"] -> Unit[0.001754242723, "Millimole"/"Liter"], 
    metabolite["6pgc", "c"] -> Unit[0.037475258, "Millimole"/"Liter"], 
    metabolite["ru5p-D", "c"] -> Unit[0.0049367903, "Millimole"/"Liter"], 
    metabolite["xu5p-D", "c"] -> Unit[0.014784196, "Millimole"/"Liter"], 
    metabolite["r5p", "c"] -> Unit[0.012668936, "Millimole"/"Liter"], 
    metabolite["s7p", "c"] -> Unit[0.023987984, "Millimole"/"Liter"], 
    metabolite["e4p", "c"] -> Unit[0.0050750696, "Millimole"/"Liter"], 
    metabolite["nadp", "c"] -> Unit[0.0002, "Millimole"/"Liter"], 
    metabolite["nadph", "c"] -> Unit[0.0658, "Millimole"/"Liter"], 
    metabolite["gthrd", "c"] -> Unit[3.2, "Millimole"/"Liter"], 
    metabolite["gthox", "c"] -> Unit[0.11999999999999966, 
      "Millimole"/"Liter"], metabolite["h", "c"] -> 
     Unit[0.00006309573444801929, "Millimole"/"Liter"], 
    metabolite["h2o2", "c"] -> Unit[0.00001, "Millimole"/"Liter"], 
    metabolite["h2o", "c"] -> Unit[1.99999683, "Millimole"/"Liter"], 
    metabolite["co2", "c"] -> Unit[1.0000021, "Millimole"/"Liter"]}, 
  "Parameters" -> {parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["Sink_h[c]"] -> 1, Keq["Sink_h2o[c]"] -> 1, Keq["Sink_g6p[c]"] -> 1, 
    Keq["Sink_g3p[c]"] -> Infinity, Keq["Sink_h2o2[c]"] -> 1, 
    Keq["Sink_co2[c]"] -> 1, Keq["Sink_f6p[c]"] -> Infinity, 
    Keq["G6PDH2r"] -> 1000, Keq["PGL"] -> 1000, 
    Keq["GND"] -> Unit[1000, "Millimole"/"Liter"], Keq["RPE"] -> 3, 
    Keq["RPI"] -> 0.38910505836575876, Keq["TKT1"] -> 3, Keq["TKT2"] -> 10.3, 
    Keq["TALA"] -> 1.05, Keq["GTHO"] -> Unit[100, "Millimole"/"Liter"], 
    Keq["GTHP"] -> Unit[Infinity, "Liter"^2/"Millimole"^2], 
    metabolite["h", "Xt"] -> Unit[0.00006309573444801929, 
      "Millimole"/"Liter"], metabolite["co2", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["g6p", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["f6p", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["r5p", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["h2o", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["g3p", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], metabolite["h2o2", "Xt"] -> 
     Unit[1, "Millimole"/"Liter"], rateconst["G6PDH2r", True] -> 
     Unit[21864.5896565954, "Liter"/("Hour"*"Millimole")], 
    rateconst["GND", True] -> Unit[28018.486223630534, 
      "Liter"/("Hour"*"Millimole")], rateconst["GTHO", True] -> 
     Unit[53.191489361702274, "Liter"/("Hour"*"Millimole")], 
    rateconst["GTHP", True] -> Unit[4101.562499999999, 
      "Liter"^2/("Hour"*"Millimole"^2)], rateconst["PGL", True] -> 
     Unit[119.7097740504636, "Hour"^(-1)], rateconst["RPE", True] -> 
     Unit[16045.906574617504, "Hour"^(-1)], rateconst["RPI", True] -> 
     Unit[3760.3939302762114, "Hour"^(-1)], rateconst["TALA", True] -> 
     Unit[886.8481688986791, "Liter"/("Hour"*"Millimole")], 
    rateconst["TKT1", True] -> Unit[542.2607349579007, 
      "Liter"/("Hour"*"Millimole")], rateconst["TKT2", True] -> 
     Unit[1146.859249610283, "Liter"/("Hour"*"Millimole")], 
    rateconst["Sink_f6p[c]", True] -> Unit[7.070707070707069, "Hour"^(-1)], 
    rateconst["Sink_g6p[c]", True] -> Unit[0.22072734916964473, "Hour"^(-1)], 
    rateconst["Sink_g3p[c]", True] -> Unit[9.615384615384615, "Hour"^(-1)], 
    rateconst["Sink_h2o[c]", True] -> Unit[0.6300019971063309, "Hour"^(-1)], 
    rateconst["Sink_h[c]", True] -> Unit[1000000, "Hour"^(-1)], 
    rateconst["Sink_co2[c]", True] -> Unit[100000.0000050546, "Hour"^(-1)], 
    rateconst["Sink_h2o2[c]", True] -> Unit[0.4200042000420004, 
      "Hour"^(-1)]}, "Notes" -> "\nModel constructed on Tue 30 Apr 2013 \
16:15:24 by niko on staphylococcus.ucsd.edu using Mathematica 9.0 for Mac OS \
X x86 (64-bit) (November 20, 2012) at the following geodetic location: \
latitude 32.88; longitude -117.24\n This model is a translation of the \
pentose phosphate pathway model in 'Simulation of dynamic network state' in \
terms of the iAB-RBC-238 reconstruction by Aarash Bordbar."}]
