(* Created by Wolfram Mathematica 9.0 : www.wolfram.com *)
MASSmodel[{"Synonyms" -> {}, "Events" -> {}, "ID" -> "iAB-RBC-238", 
  "Name" -> "MASSmodel$15", "CustomRateLaws" -> {}, "CustomODE" -> {}, 
  "GPR" -> {"DPGase" -> protein["Bpgm.1", None], 
    "DPGase" -> protein["Bpgm.2", None], "DPGM" -> protein["Bpgm.1", None], 
    "DPGM" -> protein["Bpgm.2", None]}, "ElementalComposition" -> 
   {metabolite["13dpg", "c"] -> 3*"C" + 4*"H" + 10*"O" + 2*"P", 
    metabolite["23dpg", "c"] -> 3*"C" + 3*"H" + 10*"O" + 2*"P", 
    metabolite["3pg", "c"] -> 3*"C" + 4*"H" + 7*"O" + "P", 
    metabolite["h", "c"] -> "H", metabolite["h2o", "c"] -> 2*"H" + "O", 
    metabolite["pi", "c"] -> "H" + 4*"O" + "P"}, "BoundaryConditions" -> {}, 
  "Constant" -> {}, "UnitChecking" -> True, "Objective" -> Automatic, 
  "Ignore" -> {metabolite["h", "c"], metabolite["h2o", "c"]}, 
  "Stoichiometry" -> SparseArray[Automatic, {13, 8}, 0, 
    {1, {{0, 1, 4, 5, 6, 7, 8, 10, 11, 16, 18, 20, 22, 23}, {{1}, {1}, {2}, 
      {3}, {2}, {1}, {2}, {2}, {3}, {4}, {3}, {4}, {5}, {6}, {7}, {8}, {4}, 
      {5}, {5}, {6}, {6}, {7}, {7}}}, {-1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, 
     -1, -1, -1, -1, -1, 1, -1, 1, -1, 1, -1, 1}}], 
  "Species" -> {metabolite["13dpg", "c"], metabolite["23dpg", "c"], 
    metabolite["3pg", "c"], metabolite["h", "c"], metabolite["h2o", "c"], 
    metabolite["pi", "c"], metabolite["hb", "c"], metabolite["dhb", "c"], 
    metabolite["o2", "c"], metabolite["hbo2", "c"], metabolite["hbo22", "c"], 
    metabolite["hbo23", "c"], metabolite["hbo24", "c"]}, 
  "Fluxes" -> {v["DPGM"], v["DPGase"], v["vhbdpg"], v["vhbo1"], v["vhbo2"], 
    v["vhbo3"], v["vhbo4"], v["Sink_o2[c]"]}, "ReversibleColumnIndices" -> 
   {1, 3, 4, 5, 6, 7, 8}, "Constraints" -> {v["DPGM"] -> {-1000., 1000.}, 
    v["DPGase"] -> {0., 1000.}, v["Sink_o2[c]"] -> {0, Infinity}}, 
  "InitialConditions" -> {metabolite["13dpg", "c"] -> 
     Unit[0.000243, "Millimole"/"Liter"], metabolite["23dpg", "c"] -> 
     Unit[3.1, "Millimole"/"Liter"], metabolite["3pg", "c"] -> 
     Unit[0.0773, "Millimole"/"Liter"], metabolite["dhb", "c"] -> 
     Unit[0.04620957029335471, "Millimole"/"Liter"], 
    metabolite["h", "c"] -> Unit[0.00008997573444801929, 
      "Millimole"/"Liter"], metabolite["h2o", "c"] -> 
     Unit[1., "Millimole"/"Liter"], metabolite["hb", "c"] -> 
     Unit[0.059625251991425425, "Millimole"/"Liter"], 
    metabolite["hbo2", "c"] -> Unit[0.05008521167279736, 
      "Millimole"/"Liter"], metabolite["hbo22", "c"] -> 
     Unit[0.07362526115901212, "Millimole"/"Liter"], 
    metabolite["hbo23", "c"] -> Unit[0.26284218233767326, 
      "Millimole"/"Liter"], metabolite["hbo24", "c"] -> 
     Unit[6.807612522545737, "Millimole"/"Liter"], 
    metabolite["o2", "c"] -> Unit[0.0200788, "Millimole"/"Liter"], 
    metabolite["pi", "c"] -> Unit[2.5, "Millimole"/"Liter"]}, 
  "Parameters" -> {parameter["Volume", "e"] -> Unit[1, "Liter"], 
    parameter["Volume", "c"] -> Unit[1, "Liter"], 
    Keq["DPGase"] -> Unit[Infinity, "Millimole"/"Liter"], 
    Keq["DPGM"] -> Infinity, Keq["vhbdpg"] -> Unit[1/4, "Liter"/"Millimole"], 
    Keq["vhbo1"] -> Unit[41.835169432436196, "Liter"/"Millimole"], 
    Keq["vhbo2"] -> Unit[73.21154650676336, "Liter"/"Millimole"], 
    Keq["vhbo3"] -> Unit[177.79947008785382, "Liter"/"Millimole"], 
    Keq["vhbo4"] -> Unit[1289.9177241667828, "Liter"/"Millimole"], 
    Keq["Sink_o2[c]"] -> 1, rateconst["DPGase", True] -> 
     Unit[0.14225806451612902, "Hour"^(-1)], rateconst["DPGM", True] -> 
     Unit[1814.8148148148148, "Hour"^(-1)], rateconst["vhbo1", True] -> 
     Unit[506935.270702259, "Liter"/("Hour"*"Millimole")], 
    rateconst["vhbo2", True] -> Unit[511077.050923776, 
      "Liter"/("Hour"*"Millimole")], rateconst["vhbo3", True] -> 
     Unit[509243.459567699, "Liter"/("Hour"*"Millimole")], 
    rateconst["vhbo4", True] -> Unit[501595.340624411, 
      "Liter"/("Hour"*"Millimole")], rateconst["vhbdpg", True] -> 
     Unit[519612.560391792, "Liter"/("Hour"*"Millimole")], 
    rateconst["Sink_o2[c]", True] -> Unit[509725.707725914, "Hour"^(-1)], 
    metabolite["o2", "Xt"] -> Unit[0.0200788, "Millimole"/"Liter"]}, 
  "Notes" -> "\nModel constructed on Tue 30 Apr 2013 16:15:51 by niko on \
staphylococcus.ucsd.edu using Mathematica 9.0 for Mac OS X x86 (64-bit) \
(November 20, 2012) at the following geodetic location: latitude 32.88; \
longitude -117.24\n This model is a translation of the hemoglobin model in \
'Simulation of dynamic network state' in terms of the iAB-RBC-238 \
reconstruction by Aarash Bordbar."}]
