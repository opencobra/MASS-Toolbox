(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
{"BIOMD0000000299" -> "Leloup1999_CircadianRhythms_Neurospora", 
 "BIOMD0000000298" -> "Leloup1999_CircadianRhythms_Drosophila", 
 "BIOMD0000000159" -> "Zatorsky2006_p53_Model1", 
 "BIOMD0000000156" -> "Zatorsky2006_p53_Model5", 
 "BIOMD0000000155" -> "Zatorsky2006_p53_Model6", 
 "BIOMD0000000158" -> "Zatorsky2006_p53_Model2", 
 "BIOMD0000000157" -> "Zatorsky2006_p53_Model4", 
 "BIOMD0000000162" -> "Hernjak2005_Calcium_Signaling", 
 "BIOMD0000000163" -> "Zi2007_TGFbeta_signaling", 
 "BIOMD0000000164" -> "SmithAE2002_RanTransport", 
 "BIOMD0000000165" -> "Saucerman2006_PKA", "BIOMD0000000160" -> 
  "Xie2007_CircClock", "BIOMD0000000161" -> "Eungdamrong2007_Ras_Activation", 
 "BIOMD0000000289" -> "Alexander2010_Tcell_Regulation_Sys1", 
 "BIOMD0000000288" -> "Wang2009 - PI3K Ras Crosstalk", 
 "BIOMD0000000287" -> "Passos2010_DNAdamage_CellularSenescence", 
 "BIOMD0000000149" -> "Kim2007 - Crosstalk between Wnt and ERK pathways", 
 "BIOMD0000000148" -> "Komarova2003_BoneRemodeling", 
 "BIOMD0000000147" -> "ODea2007_IkappaB", "BIOMD0000000146" -> 
  "Hatakeyama2003_MAPK", "BIOMD0000000145" -> 
  "Wang2007 - ATP induced intracellular Calcium Oscillation", 
 "BIOMD0000000144" -> "Calzone2007_CellCycle", 
 "BIOMD0000000153" -> "Fernandez2006_ModelB", 
 "BIOMD0000000154" -> "Zatorsky2006_p53_Model3", 
 "BIOMD0000000151" -> "Singh2006_IL6_Signal_Transduction", 
 "BIOMD0000000152" -> "Fernandez2006_ModelA", 
 "BIOMD0000000150" -> "Morris2002_CellCycle_CDK2Cyclin", 
 "BIOMD0000000292" -> "Rovers1995_Photsynthetic_Oscillations", 
 "BIOMD0000000293" -> "Proctor2010 - UCHL1 Protein Aggregation", 
 "BIOMD0000000290" -> "Alexander2010_Tcell_Regulation_Sys2", 
 "BIOMD0000000291" -> "Nikolaev2005_AlbuminBilirubinAdsorption", 
 "BIOMD0000000296" -> "Balagadd\[EAcute]2008_E_coli_Predator_Prey", 
 "BIOMD0000000297" -> "Ciliberto2003_Morphogenesis_Checkpoint", 
 "BIOMD0000000294" -> "Restif2007_Vaccination_Invasion", 
 "BIOMD0000000295" -> "Akman2008_Circadian_Clock_Model1", 
 "BIOMD0000000277" -> "Shrestha2010_HyperCalcemia_PTHresponse", 
 "BIOMD0000000276" -> "Shrestha2010_HypoCalcemia_PTHresponse", 
 "BIOMD0000000279" -> "Komarova2005_PTHaction_OsteoclastOsteoblastCoupling", 
 "BIOMD0000000278" -> 
  "Lemaire2004 - Role of RANK/RANKL/OPG pathway in bone remodelling process", 
 "BIOMD0000000178" -> "Lebeda2008_BoTN_Paralysis_4stepModel", 
 "BIOMD0000000177" -> "Conant2007_glycolysis_2C", 
 "BIOMD0000000179" -> "Kim2007_CellularMemory_AsymmetricModel", 
 "BIOMD0000000180" -> "Kim2007_CellularMemory_SymmetricModel", 
 "BIOMD0000000181" -> "Sriram2007_CellCycle", "BIOMD0000000182" -> "Neves2008 \
- Role of cell shape and size in controlling intracellular signalling", 
 "BIOMD0000000183" -> "Stefan2008 - calmodulin allostery", 
 "BIOMD0000000184" -> "Lavrentovich2008_Ca_Oscillations", 
 "BIOMD0000000185" -> "Locke2008_Circadian_Clock", 
 "BIOMD0000000186" -> 
  "Ibrahim2008 - Mitotic Spindle Assembly Checkpoint - Dissociation variant", 
 "BIOMD0000000187" -> 
  "Ibrahim2008 - Mitotic Spindle Assembly Checkpoint - Convey variant", 
 "BIOMD0000000283" -> "Chance1943_Peroxidase_ES_Kinetics", 
 "BIOMD0000000284" -> "Hofmeyer1986_SeqFb_Proc_AA_Synthesis", 
 "BIOMD0000000285" -> "Tang2010_PolyGlutamate", 
 "BIOMD0000000286" -> 
  "Proctor2010 - a link between GSK3 and p53 in Alzheimer's Disease", 
 "BIOMD0000000280" -> "Morris1981_MuscleFibre_Voltage_reduced", 
 "BIOMD0000000281" -> "Chance1960_Glycolysis_Respiration", 
 "BIOMD0000000282" -> "Chance1952_Catalase_Mechanism", 
 "BIOMD0000000269" -> "Liu2010_Hormonal_Crosstalk_Arabidopsis", 
 "BIOMD0000000268" -> "Reed2008_Glutathione_Metabolism", 
 "BIOMD0000000267" -> "Lebeda2008_BoNT_Paralysis_3stepModel", 
 "BIOMD0000000266" -> "Voit2003_Trehalose_Cycle", 
 "BIOMD0000000265" -> "Conradie2010_RPControl_CellCycle", 
 "BIOMD0000000169" -> "Aguda1999_CellCycle", 
 "BIOMD0000000168" -> "Obeyesekere1999_CellCycle", 
 "BIOMD0000000167" -> "Mayya2005_STATmodule", 
 "BIOMD0000000166" -> "Zhu2007_TF_modulated_by_Calcium", 
 "BIOMD0000000171" -> "Leloup1998_CircClock_LD", 
 "BIOMD0000000172" -> "Pritchard2002_glycolysis", 
 "BIOMD0000000170" -> "Weimann2004_CircadianOscillator", 
 "BIOMD0000000175" -> "Birtwistle2007_ErbB_Signalling", 
 "BIOMD0000000176" -> "Conant2007_WGD_glycolysis_2A3AB", 
 "BIOMD0000000173" -> "Schmierer_2008_Smad_Tgfb", 
 "BIOMD0000000174" -> "Del_Conte_Zerial2008_Rab5_Rab7_cut_out_switch", 
 "BIOMD0000000274" -> "Rattanakul2003_BoneFormationModel", 
 "BIOMD0000000275" -> "Goldbeter2007_Somitogenesis_Switch", 
 "BIOMD0000000272" -> "Becker2010_EpoR_AuxiliaryModel", 
 "BIOMD0000000273" -> "Pokhilko2010_CircClock", 
 "BIOMD0000000270" -> "Schilling2009 - ERK distributive", 
 "BIOMD0000000271" -> "Becker2010_EpoR_CoreModel", 
 "BIOMD0000000013" -> "Poolman2004_CalvinCycle", 
 "BIOMD0000000012" -> "Elowitz2000 - Repressilator", 
 "BIOMD0000000015" -> "Curto1998 - purine metabolism", 
 "BIOMD0000000014" -> "Levchenko2000_MAPK_Scaffold", 
 "BIOMD0000000017" -> "Hoefnagel2002_PyruvateBranches", 
 "BIOMD0000000199" -> "Santolini2001_nNOS_Mechanism_Regulation", 
 "BIOMD0000000016" -> "Goldbeter1995_CircClock", 
 "BIOMD0000000119" -> "Golomb2006_SomaticBursting_nonzero[Ca]", 
 "BIOMD0000000019" -> "Schoeberl2002 - EGF MAPK", 
 "BIOMD0000000018" -> "Morrison1989_FolateCycle", 
 "BIOMD0000000116" -> "McClean2007_CrossTalk", 
 "BIOMD0000000115" -> "Somogyi1990_CaOscillations_SingleCaSpike", 
 "BIOMD0000000118" -> "Golomb2006_SomaticBursting", 
 "BIOMD0000000117" -> "Dupont1991_CaOscillation", 
 "BIOMD0000000112" -> "Clarke2006_Smad_signalling", 
 "BIOMD0000000111" -> "Novak2001_FissionYeast_CellCycle", 
 "BIOMD0000000114" -> "Somogyi1990_CaOscillations", 
 "BIOMD0000000113" -> "Dupont1992_Ca_dpt_protein_phospho", 
 "BIOMD0000000120" -> "Chan2004_TCell_receptor_activation", 
 "BIOMD0000000121" -> "Clancy2001_Kchannel", 
 "BIOMD0000000398" -> 
  "Sivakumar2011_NeuralStemCellDifferentiation_Crosstalk", 
 "BIOMD0000000020" -> "Hodgkin-Huxley1952 squid-axon", 
 "BIOMD0000000397" -> "Sivakumar2011_WntSignalingPathway", 
 "BIOMD0000000021" -> "Leloup1999_CircClock", 
 "BIOMD0000000399" -> "Jenkinson2011_EGF_MAPK", 
 "BIOMD0000000022" -> "Ueda2001_CircClock", 
 "BIOMD0000000004" -> "Goldbeter1991 - Min Mit Oscil, Expl Inact", 
 "BIOMD0000000395" -> "Sivakumar2011 - Hedgehog Signaling Pathway", 
 "BIOMD0000000003" -> "Goldbeter1991 - Min Mit Oscil", 
 "BIOMD0000000396" -> "Sivakumar2011 - Notch Signaling Pathway", 
 "BIOMD0000000393" -> 
  "Arnold2011_Zhu2007_CalvinCycle_Starch_Sucrose_Photorespiration", 
 "BIOMD0000000002" -> "Edelstein1996 - EPSP ACh species", 
 "BIOMD0000000001" -> "Edelstein1996 - EPSP ACh event", 
 "BIOMD0000000394" -> "Sivakumar2011 - EGF Receptor Signaling Pathway", 
 "BIOMD0000000391" -> "Arnold2011_Poolman2000_CalvinCycle_Starch", 
 "BIOMD0000000008" -> "Gardner1998 - Cell Cycle Goldbeter", 
 "BIOMD0000000392" -> "Arnold2011_Laisk2006_CalvinCycle_Starch_Sucrose", 
 "BIOMD0000000007" -> "Novak1997 - Cell Cycle", 
 "BIOMD0000000006" -> "Tyson1991 - Cell Cycle 2 var", 
 "BIOMD0000000188" -> 
  "Proctor2008 - p53/Mdm2 circuit - p53 stabilisation by ATM", 
 "BIOMD0000000109" -> "Haberichter2007_cellcycle", 
 "BIOMD0000000390" -> "Arnold2011_Giersch1990_CalvinCycle", 
 "BIOMD0000000189" -> 
  "Proctor2008 - p53/Mdm2 circuit - p53 stablisation by p14ARF", 
 "BIOMD0000000005" -> "Tyson1991 - Cell Cycle 6 var", 
 "BIOMD0000000108" -> "Kowald2006_SOD", "BIOMD0000000107" -> 
  "Novak1993_M_phase_control", "BIOMD0000000106" -> 
  "Yang2007_ArachidonicAcid", "BIOMD0000000105" -> "Proctor2007 - Age related \
decline of proteolysis, ubiquitin-proteome system", 
 "BIOMD0000000009" -> "Huang1996 - Ultrasensitivity in MAPK cascade", 
 "BIOMD0000000104" -> "Klipp2002_MetabolicOptimization_linearPathway(n=2)", 
 "BIOMD0000000103" -> "Legewie2006_apoptosis_NC", 
 "BIOMD0000000102" -> "Legewie2006_apoptosis_WT", 
 "BIOMD0000000101" -> "Vilar2006_TGFbeta", "BIOMD0000000100" -> 
  "Rozi2003_GlycogenPhosphorylase_Activation", 
 "BIOMD0000000190" -> "Rodriguez-Caso2006_Polyamine_Metabolism", 
 "BIOMD0000000110" -> "Qu2003_CellCycle", "BIOMD0000000198" -> 
  "Stone1996_NOsGC", "BIOMD0000000197" -> "Bartholome2007_MDCKII", 
 "BIOMD0000000196" -> "Srividhya2006_CellCycle", 
 "BIOMD0000000195" -> "Tyson2001_Cell_Cycle_Regulation", 
 "BIOMD0000000389" -> "Arnold2011_Hahn1986_CalvinCycle_Starch_Sucrose", 
 "BIOMD0000000010" -> "Kholodenko2000 - Ultrasensitivity and negative \
feedback bring oscillations in MAPK cascade", 
 "BIOMD0000000194" -> "Ibrahim2008_Cdc20_Sequestring_Template_Model", 
 "BIOMD0000000388" -> "Arnold2011_Zhu2009_CalvinCycle", 
 "BIOMD0000000011" -> "Levchenko2000_MAPK_noScaffold", 
 "BIOMD0000000193" -> "Ibrahim2008_MCC_assembly_model_KDM", 
 "BIOMD0000000387" -> "Arnold2011_Damour2007_RuBisCO-CalvinCycle", 
 "BIOMD0000000192" -> "G\[ODoubleDot]rlich2003_RanGTP_gradient", 
 "BIOMD0000000386" -> "Arnold2011_Sharkey2007_RuBisCO-CalvinCycle", 
 "BIOMD0000000191" -> "Monta\[NTilde]ez2008_Arginine_catabolism", 
 "BIOMD0000000134" -> "Izhikevich2004_SpikingNeurons_SpikeLatency", 
 "BIOMD0000000133" -> "Izhikevich2004_SpikingNeurons_resonator", 
 "BIOMD0000000136" -> "Izhikevich2004_SpikingNeurons_thresholdVariability", 
 "BIOMD0000000135" -> 
  "Izhikevich2004_SpikingNeurons_subthresholdOscillations", 
 "BIOMD0000000138" -> "Tabak2007_dopamine", 
 "BIOMD0000000137" -> "Sedaghat2002_InsulinSignalling_noFeedback", 
 "BIOMD0000000139" -> "Hoffmann2002_KnockOut_IkBNFkB_Signaling", 
 "BIOMD0000000140" -> "Hoffmann2002_WT_IkBNFkB_Signaling", 
 "BIOMD0000000141" -> "Izhikevich2004_SpikingNeurons_Class1Excitable", 
 "BIOMD0000000142" -> "Izhikevich2004_SpikingNeurons_Class2Excitable", 
 "BIOMD0000000143" -> "Olsen2003_neutrophil_oscillatory_metabolism", 
 "BIOMD0000000125" -> "Komarova2005_TheoreticalFramework_BasicArchitecture", 
 "BIOMD0000000124" -> "Wu2006_K+Channel", "BIOMD0000000123" -> 
  "Fisher2006_NFAT_Activation", "BIOMD0000000122" -> 
  "Fisher2006_Ca_Oscillation_dpdnt_NFAT_dynamics", 
 "BIOMD0000000129" -> "Izhikevich2004_SpikingNeurons_inhibitionInducedSpiking\
", "BIOMD0000000128" -> "Bertram2006_Endothelin", 
 "BIOMD0000000127" -> "Izhikevich2003_SpikingNeuron", 
 "BIOMD0000000126" -> "Clancy2002_CardiacSodiumChannel_WT", 
 "BIOMD0000000131" -> "Izhikevich2004_SpikingNeurons_reboundBurst", 
 "BIOMD0000000132" -> "Izhikevich2004_SpikingNeurons_reboundSpike", 
 "BIOMD0000000130" -> "Izhikevich2004_SpikingNeurons_integrator", 
 "BIOMD0000000463" -> "Heldt2012 - Influenza Virus Replication", 
 "BIOMD0000000464" -> "Koo2013 - Shear stress induced calcium influx and eNOS \
activation - Model 1", "BIOMD0000000465" -> 
  "Koo2013 - Shear stress induced AKT and eNOS phosphorylation - Model 2", 
 "BIOMD0000000466" -> 
  "Koo2013 - Shear stress induced eNOS expression - Model 3", 
 "BIOMD0000000467" -> 
  "Koo2013 - Shear stress induced NO production - Model 4", 
 "BIOMD0000000468" -> 
  "Koo2013 - Integrated shear stress induced NO production model", 
 "BIOMD0000000469" -> 
  "Smallbone2013 - E.coli metabolic model with linlog rate law", 
 "BIOMD0000000330" -> "Larsen2004_CalciumSpiking", 
 "BIOMD0000000031" -> "Markevich2004_MAPK_orderedMM2kinases", 
 "BIOMD0000000030" -> "Markevich2004_MAPK_AllRandomElementary", 
 "BIOMD0000000033" -> "Brown2004 - NGF and EGF signaling", 
 "BIOMD0000000032" -> "Kofahl2004_PheromonePathway", 
 "BIOMD0000000023" -> "Rohwer2001_Sucrose", 
 "BIOMD0000000325" -> "Palini2011_Minimal_2_Feedback_Model", 
 "BIOMD0000000024" -> "Scheper1999_CircClock", 
 "BIOMD0000000324" -> "Morris1981_MuscleFibre_Voltage_full", 
 "BIOMD0000000025" -> "Smolen2002_CircClock", 
 "BIOMD0000000327" -> "Whitcomb2004_Bicarbonate_Pancreas", 
 "BIOMD0000000026" -> "Markevich2004_MAPK_orderedElementary", 
 "BIOMD0000000326" -> "DellOrco2009_phototransduction", 
 "BIOMD0000000027" -> 
  "Markevich2004 - MAPK double phosphorylation, ordered Michaelis-Menton", 
 "BIOMD0000000321" -> "Grange2001 - L Dopa PK model", 
 "BIOMD0000000028" -> "Markevich2004_MAPK_phosphoRandomElementary", 
 "BIOMD0000000320" -> 
  "Grange2001 - PK interaction of L-dopa and benserazide", 
 "BIOMD0000000029" -> "Markevich2004_MAPK_phosphoRandomMM", 
 "BIOMD0000000323" -> "Kim2011_Oscillator_SimpleIII", 
 "BIOMD0000000322" -> "Kim2011_Oscillator_SimpleI", 
 "BIOMD0000000471" -> 
  "Smallbone2013 - Yeast metabolic model with linlog rate law", 
 "BIOMD0000000329" -> "Kummer2000 - Oscillations in Calcium Signalling", 
 "BIOMD0000000470" -> 
  "Smallbone2013 - E.coli metabolic model with modular rate law", 
 "BIOMD0000000328" -> "Bucher2011_Atorvastatin_Metabolism", 
 "BIOMD0000000473" -> "Smallbone2013 - Yeast metabolic model with modular \
rate law, merged with Pritchard 2002", "BIOMD0000000472" -> 
  "Smallbone2013 - Yeast metabolic model with modular rate law", 
 "BIOMD0000000476" -> "Adams2012 - Locke2006 Circadian Rhythm model refined \
with Input Signal Light Function", "BIOMD0000000477" -> 
  "Mol2013 - Immune Signal Transduction in Leishmaniasis", 
 "BIOMD0000000474" -> 
  "Smith2013 - Regulation of Insulin Signalling by Oxidative Stress", 
 "BIOMD0000000475" -> 
  "Amara2013 - PCNA ubiquitylation in the activation of PRR pathway", 
 "BIOMD0000000478" -> "Besozzi2012 - Oscillatory regimes in the Ras/cAMP/PKA \
pathway in S.cerevisiae", "BIOMD0000000479" -> 
  "Croft2013 - GPCR-RGS interaction that compartmentalizes RGS activity", 
 "BIOMD0000000040" -> "Field1974_Oregonator", 
 "BIOMD0000000340" -> "Wajima2009_BloodCoagulation_warfarin_heparin", 
 "BIOMD0000000341" -> "Topp2000_BetaCellMass_Diabetes", 
 "BIOMD0000000044" -> "Borghans1997 - Calcium Oscillation - Model 2", 
 "BIOMD0000000043" -> "Borghans1997 - Calcium Oscillation - Model 1", 
 "BIOMD0000000042" -> "Nielsen1998_Glycolysis", 
 "BIOMD0000000041" -> 
  "Kongas2007 - Creatine Kinase in energy metabolic signaling in muscle", 
 "BIOMD0000000036" -> "Tyson1999_CircClock", 
 "BIOMD0000000338" -> "Wajima2009_BloodCoagulation_aPTTtest", 
 "BIOMD0000000037" -> 
  "Marwan2003 - Genetics, regulatory hierarchy between genes", 
 "BIOMD0000000337" -> 
  "Pfeiffer2001_ATP-ProducingPathways_CooperationCompetition", 
 "BIOMD0000000336" -> "Jones1994_BloodCoagulation", 
 "BIOMD0000000034" -> "Smolen2004_CircClock", 
 "BIOMD0000000335" -> "Hockin2002_BloodCoagulation", 
 "BIOMD0000000035" -> "Vilar2002_Oscillator", 
 "BIOMD0000000334" -> "Bungay2003_Thrombin_Generation", 
 "BIOMD0000000333" -> "Bungay2006_FollicularFluid", 
 "BIOMD0000000332" -> "Bungay2006_Plasma", "BIOMD0000000038" -> 
  "Rohwer2000_Phosphotransferase_System", "BIOMD0000000331" -> 
  "Larsen2004_CalciumSpiking_EnzymeBinding", 
 "BIOMD0000000039" -> "Marhl2000_CaOscillations", 
 "BIOMD0000000480" -> 
  "Carbo2013 - Mucosal Immune Response during H.pylori Infection", 
 "BIOMD0000000484" -> 
  "Cao2013 - Application of ABSIS method in birth-death process", 
 "BIOMD0000000483" -> "Cao2008 - Network of a toggle switch", 
 "BIOMD0000000482" -> "Noguchi2013 - Insulin dependent glucose metabolism", 
 "BIOMD0000000481" -> "St\[ODoubleDot]tzel2012 - Bovine estrous cycle, \
synchronization with prostaglandin F2\[Alpha]", 
 "BIOMD0000000339" -> "Wajima2009_BloodCoagulation_PTtest", 
 "BIOMD0000000489" -> 
  "Sharp2013 - Lipopolysaccharide induced NFkB activation", 
 "BIOMD0000000485" -> "Cao2013 - Application of ABSIS method in the bistable \
Schl\[ODoubleDot]gl model", "BIOMD0000000486" -> 
  "Cao2013 - Application of ABSIS method in the reversible isomerization \
model", "BIOMD0000000487" -> 
  "Cao2013 - Application of ABSIS in the the enzymatic futile cycle", 
 "BIOMD0000000488" -> 
  "Proctor2013 - Effect of A\[Beta] immunisation in Alzheimer's disease", 
 "BIOMD0000000053" -> "Ferreira2003_CML_generation2", 
 "BIOMD0000000052" -> "Brands2002 - Monosaccharide-casein systems", 
 "BIOMD0000000055" -> "Locke2005 - Circadian Clock", 
 "BIOMD0000000054" -> "Ataullahkhanov1996_Adenylate", 
 "BIOMD0000000051" -> "Chassagnole2002_Carbon_Metabolism", 
 "BIOMD0000000050" -> "Martins2003_AmadoriDegradation", 
 "BIOMD0000000049" -> "Sasagawa2005_MAPK", "BIOMD0000000301" -> 
  "Friedland2009_Ara_RTC3_counter", "BIOMD0000000300" -> 
  "Schmierer2010_FIH_Ankyrins", "BIOMD0000000045" -> 
  "Borghans1997 - Calcium Oscillation - Model 3", 
 "BIOMD0000000208" -> "Deineko2003_CellCycle", 
 "BIOMD0000000303" -> "Liu2011_Complement_System", 
 "BIOMD0000000046" -> "Olsen2003_peroxidase", 
 "BIOMD0000000207" -> "Romond1999_CellCycle", 
 "BIOMD0000000302" -> "Wang1996_Synaptic_Inhibition_Two_Neuron", 
 "BIOMD0000000305" -> "Kolomeisky2003_MyosinV_Processivity", 
 "BIOMD0000000047" -> "Oxhamre2005_Ca_oscillation", 
 "BIOMD0000000304" -> "Plant1981_BurstingNerveCells", 
 "BIOMD0000000048" -> "Kholodenko1999 - EGFR signaling", 
 "BIOMD0000000209" -> "Chickarmane2008 - Stem cell lineage determination", 
 "BIOMD0000000493" -> 
  "Schittler2010 - Cell fate of progenitor cells, osteoblasts or \
chondrocytes", "BIOMD0000000307" -> "Tyson2003_Substrate_Depletion_Osc", 
 "BIOMD0000000204" -> "Chickarmane2006 - Stem cell switch irreversible", 
 "BIOMD0000000492" -> 
  "Pathak2013 - MAPK activation in response to various biotic stresses", 
 "BIOMD0000000306" -> "Tyson2003_Activator_Inhibitor", 
 "BIOMD0000000203" -> "Chickarmane2006 - Stem cell switch reversible", 
 "BIOMD0000000495" -> "Sen2013 - Phospholipid Synthesis in P.knowlesi", 
 "BIOMD0000000309" -> "Tyson2003_NegFB_Homeostasis", 
 "BIOMD0000000206" -> "Wolf2000_Glycolytic_Oscillations", 
 "BIOMD0000000494" -> 
  "Roblitz2013 - Menstrual Cycle following GnRH analogue administration", 
 "BIOMD0000000308" -> "Tyson2003_NegFB_Oscillator", 
 "BIOMD0000000205" -> "Ung2008_EGFR_Endocytosis", 
 "BIOMD0000000200" -> "Bray1995_chemotaxis_receptorlinkedcomplex", 
 "BIOMD0000000491" -> 
  "Pathak2013 - MAPK activation in response to various abiotic stresses", 
 "BIOMD0000000202" -> "ChenXF2008_CICR", "BIOMD0000000490" -> 
  "Demin2013 - PKPD behaviour - 5-Lipoxygenase inhibitors", 
 "BIOMD0000000201" -> 
  "Goldbeter2008_Somite_Segmentation_Clock_Notch_Wnt_FGF", 
 "BIOMD0000000220" -> "Albeck2008_extrinsic_apoptosis", 
 "BIOMD0000000498" -> "Mitchell2013 - Liver Iron Metabolism", 
 "BIOMD0000000499" -> "Vizan2013 - TGF pathway long term signaling", 
 "BIOMD0000000496" -> 
  "Stanford2013 - Kinetic model of yeast metabolic network (standard)", 
 "BIOMD0000000497" -> 
  "Stanford2013 - Kinetic model of yeast metabolic network (regulation)", 
 "BIOMD0000000066" -> "Chassagnole2001_Threonine Synthesis", 
 "BIOMD0000000065" -> "Yildirim2003_Lac_Operon", 
 "BIOMD0000000064" -> "Teusink2000_Glycolysis", 
 "BIOMD0000000063" -> "Galazzo1990_FermentationPathwayKinetics", 
 "BIOMD0000000062" -> "Bhartiya2003_Tryptophan_operon", 
 "BIOMD0000000061" -> "Hynne2001_Glycolysis", 
 "BIOMD0000000060" -> "Keizer1996_Ryanodine_receptor_adaptation", 
 "BIOMD0000000312" -> "Tyson2003_Perfect_Adaption", 
 "BIOMD0000000311" -> "Tyson2003_Mutual_Activation", 
 "BIOMD0000000310" -> "Tyson2003_Mutual_Inhibition", 
 "BIOMD0000000058" -> "Bindschadler2001_coupled_Ca_oscillators", 
 "BIOMD0000000316" -> "Shen-Orr2002_FeedForward_AND_gate", 
 "BIOMD0000000059" -> "Fridlyand2003_Calcium_flux", 
 "BIOMD0000000315" -> "Montagne2011_Oligator_optimised", 
 "BIOMD0000000219" -> "Singh2006_TCA_mtu_model1", 
 "BIOMD0000000056" -> "Chen2004 - Cell Cycle Regulation", 
 "BIOMD0000000314" -> "Raia2011_IL13_L1236", 
 "BIOMD0000000057" -> "Sneyd2002_IP3_Receptor", 
 "BIOMD0000000218" -> "Singh2006_TCA_mtu_model2", 
 "BIOMD0000000313" -> "Raia2010_IL13_Signalling_MedB1", 
 "BIOMD0000000217" -> "Bruggeman2005_AmmoniumAssimilation", 
 "BIOMD0000000216" -> "Hong2009_CircadianClock", 
 "BIOMD0000000319" -> "Decroly1982_Enzymatic_Oscillator", 
 "BIOMD0000000215" -> "Schulz2009_Th1_differentiation", 
 "BIOMD0000000318" -> "Yao2008_Rb_E2F_Switch", 
 "BIOMD0000000214" -> "Akman2008_Circadian_Clock_Model2", 
 "BIOMD0000000317" -> "Shen-Orr2002_Single_Input_Module", 
 "BIOMD0000000213" -> "Nijhout2004_Folate_Cycle", 
 "BIOMD0000000212" -> "Curien2009_Aspartate_Metabolism", 
 "BIOMD0000000211" -> "Albert2005_Glycolysis", 
 "BIOMD0000000210" -> 
  "Chickarmane2008 - Stem cell lineage - NANOG GATA-6 switch", 
 "BIOMD0000000567" -> 
  "Morris2008 - Fitting protein aggregation data via F-W 2-step mechanism", 
 "BIOMD0000000428" -> 
  "Achcar2012 - Glycolysis in bloodstream form T. brucei", 
 "BIOMD0000000070" -> "Holzhutter2004_Erythrocyte_Metabolism", 
 "BIOMD0000000372" -> "Tolic2000_InsulinGlucoseFeedback", 
 "BIOMD0000000566" -> 
  "Morris2009 - \[Alpha]-Synuclein aggregation variable temperature and pH", 
 "BIOMD0000000427" -> "Bianconi2012 - EGFR and IGF1R pathway in lung cancer", 
 "BIOMD0000000071" -> "Bakker2001_Glycolysis", 
 "BIOMD0000000371" -> "DeVries2000_PancreaticBetaCells_InsulinSecretion", 
 "BIOMD0000000569" -> 
  "Dutta-Roy2015 - Opening of the multiple AMPA receptor conductance states", 
 "BIOMD0000000072" -> "Yi2003_GproteinCycle", 
 "BIOMD0000000374" -> "Bertram1995_PancreaticBetaCell_CRAC", 
 "BIOMD0000000568" -> 
  "Mueller2015 - Hepatocyte proliferation, T160 phosphorylation of CDK2", 
 "BIOMD0000000429" -> "Schaber2012 - Hog pathway in yeast", 
 "BIOMD0000000073" -> "Leloup2003_CircClock_DD", 
 "BIOMD0000000373" -> "Bertram2004_PancreaticBetaCell_modelB", 
 "BIOMD0000000563" -> "Pritchard2014 - plant-microbe interaction", 
 "BIOMD0000000074" -> "Leloup2003_CircClock_DD_REV-ERBalpha", 
 "BIOMD0000000562" -> 
  "Chaouiya2013 - EGF and TNFalpha mediated signalling pathway", 
 "BIOMD0000000075" -> "Xu2003 - Phosphoinositide turnover", 
 "BIOMD0000000565" -> 
  "Machado2014 - Curcumin production pathway in Escherichia coli", 
 "BIOMD0000000370" -> "Vinod2011_MitoticExit", 
 "BIOMD0000000076" -> "Cronwright2002_Glycerol_Synthesis", 
 "BIOMD0000000564" -> "Gould2013 - Temperature Sensitive Circadian Clock", 
 "BIOMD0000000077" -> "Blum2000_LHsecretion_1", 
 "BIOMD0000000420" -> "Ratushny2012_ASSURE_I", 
 "BIOMD0000000422" -> "Middleton2012_GibberellinSignalling", 
 "BIOMD0000000421" -> "Ratushny2012_ASSURE_II", 
 "BIOMD0000000424" -> 
  "Faratian2009 - Role of PTEN in Trastuzumab resistance", 
 "BIOMD0000000423" -> "Nyman2012_InsulinSignalling", 
 "BIOMD0000000426" -> "Mosca2012 - Central Carbon Metabolism Regulated by \
AKT", "BIOMD0000000231" -> "Valero2006_Adenine_TernaryCycle", 
 "BIOMD0000000425" -> "Tan2012 - Antibiotic Treatment, Inoculum Effect", 
 "BIOMD0000000230" -> "Ihekwaba2004_NFkB_Sensitivity", 
 "BIOMD0000000221" -> "Singh2006_TCA_Ecoli_acetate", 
 "BIOMD0000000222" -> "Singh2006_TCA_Ecoli_glucose", 
 "BIOMD0000000223" -> "Borisov2009_EGF_Insulin_Crosstalk", 
 "BIOMD0000000224" -> "Meyer1991_CalciumSpike_ICC", 
 "BIOMD0000000225" -> "Westermark2003_Pancreatic_GlycOsc_basic", 
 "BIOMD0000000226" -> "Radulescu2008_NFkB_hierarchy_M_14_25_28_Lipniacky", 
 "BIOMD0000000227" -> "Radulescu2008_NFkB_hierarchy_M_39_65_90", 
 "BIOMD0000000228" -> "Swat2004_Mammalian_G1_S_Transition", 
 "BIOMD0000000368" -> "Beltrami1995_ThrombinGeneration_C", 
 "BIOMD0000000068" -> "Curien2003_MetThr_synthesis", 
 "BIOMD0000000229" -> "Ma2002_cAMP_oscillations", 
 "BIOMD0000000570" -> "Aubert2002 - Coupling between Brain electrical \
activity, Metabolism and Hemodynamics", "BIOMD0000000369" -> 
  "Beltrami1995_ThrombinGeneration_D", "BIOMD0000000067" -> 
  "Fung2005_Metabolic_Oscillator", "BIOMD0000000571" -> "Nishio2008 - Design \
of the phosphotransferase system for enhanced glucose uptake in E. coli.", 
 "BIOMD0000000572" -> 
  "Costa2014 - Computational Model of L. lactis Metabolism", 
 "BIOMD0000000069" -> "Fuss2006_MitoticActivation", 
 "BIOMD0000000364" -> "Lee2010_ThrombinActivation_OneForm", 
 "BIOMD0000000365" -> "Hockin1999_BloodCoagulation_VaInactivation", 
 "BIOMD0000000366" -> "Orfao2008_ThrombinGeneration_AmidolyticActivity", 
 "BIOMD0000000367" -> "Mueller2008_ThrombinGeneration_minimal", 
 "BIOMD0000000385" -> "Arnold2011_Schultz2003_RuBisCO-CalvinCycle", 
 "BIOMD0000000083" -> "Leloup2003_CircClock_LD_REV-ERBalpha", 
 "BIOMD0000000384" -> "Arnold2011_Medlyn2002_RuBisCO-CalvinCycle", 
 "BIOMD0000000084" -> "Hornberg2005_ERKcascade", 
 "BIOMD0000000439" -> "Smith2009 - RGS mediated GTP hydrolysis", 
 "BIOMD0000000383" -> "Arnold2011_Farquhar1980_RuBisCO-CalvinCycle", 
 "BIOMD0000000081" -> "Suh2004_KCNQ_Regulation", 
 "BIOMD0000000577" -> 
  "Zhou2015 - Circadian clock with immune regulator NPR1", 
 "BIOMD0000000438" -> "Saeidi2012 - Quorum sensing device that produces GFP", 
 "BIOMD0000000382" -> "Sturis1991_InsulinGlucoseModel_UltradianOscillation", 
 "BIOMD0000000082" -> "Thomsen1988_AdenylateCyclase_Inhibition", 
 "BIOMD0000000576" -> 
  "Kolodkin2013 - Nuclear receptor-mediated cortisol signalling network", 
 "BIOMD0000000381" -> "Maree2006_DuCa_Type1DiabetesModel", 
 "BIOMD0000000087" -> "Proctor2006_telomere", "BIOMD0000000575" -> "Sass2009 \
- Approach to an \[Alpha]-synuclein-based BST model of Parkinson's disease", 
 "BIOMD0000000088" -> "Maeda2006_MyosinPhosphorylation", 
 "BIOMD0000000380" -> "Smallbone2011_TrehaloseBiosynthesis", 
 "BIOMD0000000574" -> 
  "Lai2014 - Hemiconcerted MWC model of intact calmodulin with two targets", 
 "BIOMD0000000085" -> "Maurya2005_GTPaseCycle_reducedOrder", 
 "BIOMD0000000573" -> "Aguilera 2014 - HIV latency. Interaction between HIV \
proteins and immune response", "BIOMD0000000086" -> 
  "Bornheimer2004_GTPaseCycle", "BIOMD0000000433" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_QSS_PSEQ)", 
 "BIOMD0000000432" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_QSS_USEQ)", 
 "BIOMD0000000431" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_PSEQ)", 
 "BIOMD0000000430" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_USEQ)", 
 "BIOMD0000000437" -> "Tseng2012 - Circadian clock of N.crassa", 
 "BIOMD0000000242" -> "Bai2003_G1phaseRegulation", 
 "BIOMD0000000436" -> "Gupta2009 - Eicosanoid Metabolism", 
 "BIOMD0000000080" -> "Thomsen1989_AdenylateCyclase", 
 "BIOMD0000000241" -> "Shi1993_Caffeine_pressor_tolerance", 
 "BIOMD0000000435" -> 
  "deBack2012 - Lineage Specification in Pancreas Development", 
 "BIOMD0000000240" -> "Veening2008_DegU_Regulation", 
 "BIOMD0000000434" -> "McAuley2012 - Whole-body Cholesterol Metabolism", 
 "BIOMD0000000234" -> 
  "Tham2008 - PDmodel, Tumour shrinkage by gemcitabine and carboplatin", 
 "BIOMD0000000235" -> "Kuhn2009_EndoMesodermNetwork", 
 "BIOMD0000000232" -> "Nazaret2009_TCA_RC_ATP", 
 "BIOMD0000000233" -> "Wilhelm2009_BistableReaction", 
 "BIOMD0000000238" -> "Overgaard2007_PDmodel_IL21", 
 "BIOMD0000000440" -> "Sarma2012 - Oscillations in MAPK cascade (S1)", 
 "BIOMD0000000239" -> "Jiang2007 - GSIS system, Pancreatic Beta Cells", 
 "BIOMD0000000236" -> "Westermark2003_Pancreatic_GlycOsc_extended", 
 "BIOMD0000000237" -> "Schaber2006_Pheromone_Starvation_Crosstalk", 
 "BIOMD0000000379" -> "DallaMan2007_MealModel_GlucoseInsulinSystem", 
 "BIOMD0000000079" -> "Goldbeter2006_weightCycling", 
 "BIOMD0000000078" -> "Leloup2003_CircClock_LD", 
 "BIOMD0000000377" -> "Bertram2000_PancreaticBetaCells_Oscillations", 
 "BIOMD0000000378" -> "Chay1997_CalciumConcentration", 
 "BIOMD0000000375" -> "Mears1997_CRAC_PancreaticBetaCells", 
 "BIOMD0000000376" -> "Bertram2007_IsletCell_Oscillations", 
 "BIOMD0000000541" -> 
  "Yugi2014 - Insulin induced signalling (PFKL phosphorylation) - model 2", 
 "BIOMD0000000096" -> "Zeilinger2006_PRR7-PRR9light-Y", 
 "BIOMD0000000540" -> 
  "Yugi2014 - Insulin induced signalling (PFKL phosphorylation) - model 1", 
 "BIOMD0000000097" -> "Zeilinger2006_PRR7-PRR9light-Yprime", 
 "BIOMD0000000543" -> 
  "Qi2013 - IL-6 and IFN crosstalk model (non-competitive)", 
 "BIOMD0000000098" -> "Goldbeter1990_CalciumSpike_CICR", 
 "BIOMD0000000542" -> 
  "Yuraszeck2010 - Vulnerabilities in the Tau Network in Tau Pathophysiology"\
, "BIOMD0000000099" -> "Laub1998_SpontaneousOscillations", 
 "BIOMD0000000545" -> 
  "Ouyang2014 - photomorphogenic UV-B signalling network", 
 "BIOMD0000000350" -> "Troein2011_ClockCircuit_OstreococcusTauri", 
 "BIOMD0000000092" -> "Fuentes2005_ZymogenActivation", 
 "BIOMD0000000544" -> "Qi2013 - IL-6 and IFN crosstalk model", 
 "BIOMD0000000449" -> "Br\[ADoubleDot]nnmark2013 - Insulin signalling in \
human adipocytes (diabetic condition)", "BIOMD0000000093" -> 
  "Yamada2003_JAK_STAT_pathway", "BIOMD0000000547" -> 
  "Talemi2014 - Arsenic toxicity and detoxification mechanisms in yeast", 
 "BIOMD0000000352" -> "Vernoux2011_AuxinSignaling_AuxinFluctuating", 
 "BIOMD0000000094" -> "Yamada2003_JAK_STAT_SOCS1_knockout", 
 "BIOMD0000000546" -> "Miao2010 - Innate and adaptive immune responses to \
primary Influenza A Virus infection", "BIOMD0000000351" -> 
  "Vernoux2011_AuxinSignaling_AuxinSingleStepInput", 
 "BIOMD0000000095" -> "Zeilinger2006_PRR7-PRR9-Y", 
 "BIOMD0000000549" -> "Baker2013 - Cytokine Mediated Inflammation in \
Rheumatoid Arthritis - Age Dependant", "BIOMD0000000446" -> 
  "Erguler2013 - Unfolded protein stress response", 
 "BIOMD0000000251" -> "Nakakuki2010_CellFateDecision_Core", 
 "BIOMD0000000548" -> 
  "Sneppen2009 - Modeling proteasome dynamics in Parkinson's disease", 
 "BIOMD0000000445" -> 
  "Pokhilko2013 - TOC1 signalling in Arabidopsis circadian clock", 
 "BIOMD0000000250" -> "Nakakuki2010_CellFateDecision_Mechanistic", 
 "BIOMD0000000448" -> "Br\[ADoubleDot]nnmark2013 - Insulin signalling in \
human adipocytes (normal condition)", "BIOMD0000000253" -> 
  "Teusink1998_Glycolysis_TurboDesign", "BIOMD0000000090" -> 
  "Wolf2001_Respiratory_Oscillations", "BIOMD0000000447" -> "Venkatraman2012 \
- Interplay between PLS and TSP1 in TGF-\[Beta]1 activation", 
 "BIOMD0000000252" -> "Hunziker2010_p53_StressSpecificResponse", 
 "BIOMD0000000091" -> 
  "Proctor2005 - Actions of chaperones and their role in ageing", 
 "BIOMD0000000442" -> "Sarma2012 - Oscillations in MAPK cascade (S2), \
inclusion of external signalling module", "BIOMD0000000441" -> 
  "Sarma2012 - Oscillations in MAPK cascade (S2)", 
 "BIOMD0000000444" -> "Sarma2012 - Oscillations in MAPK cascade (S2n)", 
 "BIOMD0000000443" -> "Sarma2012 - Oscillations in MAPK cascade (S1n)", 
 "BIOMD0000000247" -> "Ralser2007_Carbohydrate_Rerouting_ROS", 
 "BIOMD0000000248" -> "Lai2007_O2_Transport_Metabolism", 
 "BIOMD0000000450" -> "Reyes-Palomares2012 - a combined model hepatic \
polyamine and sulfur aminoacid metabolism - version2", 
 "BIOMD0000000249" -> "Restif2006_Whooping_Cough", 
 "BIOMD0000000451" -> "Carbo2013 - Cytokine driven CD4+ T Cell \
differentiation and phenotype plasticity", "BIOMD0000000243" -> 
  "Neumann2010_CD95Stimulation_NFkB_Apoptosis", 
 "BIOMD0000000244" -> "Kotte2010_Ecoli_Metabolic_Adaption", 
 "BIOMD0000000245" -> "Lei2001_Yeast_Aerobic_Metabolism", 
 "BIOMD0000000246" -> "Vasalou2010_Pacemaker_Neuron_SCN", 
 "BIOMD0000000342" -> "Zi2011_TGF-beta_Pathway", 
 "BIOMD0000000343" -> "Brannmark2010_InsulinSignalling_Mifamodel", 
 "BIOMD0000000344" -> "Proctor2011_ProteinHomeostasis_NormalCondition", 
 "BIOMD0000000345" -> "Koschorreck2008_InsulinClearance", 
 "BIOMD0000000346" -> "FitzHugh1961_NerveMembrane", 
 "BIOMD0000000347" -> "Bachmann2011_JAK2-STAT5_FeedbackControl", 
 "BIOMD0000000089" -> "Locke2006_CircClock_LL", 
 "BIOMD0000000348" -> "Fridlyand2010_GlucoseSensitivity_A", 
 "BIOMD0000000550" -> 
  "Baker2013 - Cytokine Mediated Inflammation in Rheumatoid Arthritis", 
 "BIOMD0000000349" -> "Fridlyand2010_GlucoseSensitivity_B", 
 "BIOMD0000000554" -> "Cloutier2009 - Brain Energy Metabolism", 
 "BIOMD0000000553" -> 
  "Ehrenstein1997 - The choline-leakage hypothesis in Alzheimer's disease", 
 "BIOMD0000000552" -> "Ehrenstein2000 - Positive-Feedback model for the loss \
of acetylcholine in Alzheimer's disease", "BIOMD0000000551" -> 
  "Das2010 - Effect of a gamma-secretase inhibitor on Amyloid-beta dynamics", 
 "BIOMD0000000558" -> 
  "Cloutier2012 - Feedback motif for Parkinson's disease", 
 "BIOMD0000000363" -> "Lee2010_ThrombinActivation_OneForm_minimal", 
 "BIOMD0000000557" -> 
  "Reiterer2013 - pseudophosphatase STYX role in ERK signalling", 
 "BIOMD0000000362" -> "Butenas2004_BloodCoagulation", 
 "BIOMD0000000556" -> "Ortega2013 - Interplay between secretases determines \
biphasic amyloid-beta level", "BIOMD0000000361" -> 
  "Panteleev2002_TFPImechanism_schmema1", "BIOMD0000000555" -> "Auer2010 - \
Correlation between lag time and aggregation rate in protein aggregation", 
 "BIOMD0000000360" -> "Panteleev2002_TFPImechanism_schmema2", 
 "BIOMD0000000459" -> 
  "Liebal2012 - B.subtilis post-transcriptional instability model", 
 "BIOMD0000000264" -> "Fujita2010_Akt_Signalling_EGFRinhib", 
 "BIOMD0000000458" -> "Smallbone2013 - Serine biosynthesis", 
 "BIOMD0000000263" -> "Fujita2010_Akt_Signalling_NGF", 
 "BIOMD0000000457" -> "Firczuk2013 - Eukaryotic mRNA translation machinery", 
 "BIOMD0000000262" -> "Fujita2010_Akt_Signalling_EGF", 
 "BIOMD0000000456" -> "Smallbone2013 - Metabolic Control Analysis - Example \
3", "BIOMD0000000559" -> "Ouzounoglou2014 - Modeling of alpha-synuclein \
effects on neuronal homeostasis", "BIOMD0000000261" -> 
  "Tiago2010_FeMetabolism_FeLoaded", "BIOMD0000000455" -> 
  "Smallbone2013 - Metabolic Control Analysis - Example 2", 
 "BIOMD0000000260" -> "Tiago2010_FeMetabolism_FeAdequate", 
 "BIOMD0000000454" -> 
  "Smallbone2013 - Metabolic Control Analysis - Example 1", 
 "BIOMD0000000453" -> "Bidkhori2012 - EGFR signalling in NSCLC", 
 "BIOMD0000000452" -> "Bidkhori2012 - normal EGFR signalling", 
 "BIOMD0000000461" -> 
  "Liebal2012 - B.subtilis transcription inhibition model", 
 "BIOMD0000000462" -> 
  "Proctor2012 - Role of Amyloid-beta dimers in aggregation formation", 
 "BIOMD0000000258" -> "Ortega2006 - bistability from double phosphorylation \
in signal transduction", "BIOMD0000000460" -> 
  "Liebal2012 - B.subtilis sigB proteolysis model", 
 "BIOMD0000000259" -> "Tiago2010_FeMetabolism_FeDeficient", 
 "BIOMD0000000256" -> "Rehm2006_Caspase", "BIOMD0000000257" -> 
  "Piedrafita2010_MR_System", "BIOMD0000000254" -> 
  "Bier2000_GlycolyticOscillation", "BIOMD0000000255" -> 
  "Chen2009 - ErbB Signaling", "BIOMD0000000355" -> 
  "Abell2011_CalciumSignaling_WithAdaptation", 
 "BIOMD0000000356" -> "Nyman2011_M3Hierarachical_InsulinGlucosedynamics", 
 "BIOMD0000000353" -> "Nag2011_ChloroplasticStarchDegradation", 
 "BIOMD0000000354" -> "Abell2011_CalciumSignaling_WithoutAdaptation", 
 "BIOMD0000000560" -> "Hui2014 - Age-related changes in articular cartilage", 
 "BIOMD0000000359" -> "Panteleev2002_TFPImechanism_schmema3", 
 "BIOMD0000000561" -> 
  "Martins2013 - True and apparent inhibition of amyloid fribril formation", 
 "BIOMD0000000357" -> "Lee2010_ThrombinActivation_OneForm_reduced", 
 "BIOMD0000000358" -> 
  "Stortelder1997 - Thrombin Generation Amidolytic Activity", 
 "BIOMD0000000528" -> "Fribourg2014 - Dynamics of viral antagonism and innate \
immune response (H1N1 influenza A virus - Cal/09)", 
 "BIOMD0000000529" -> "Fribourg2014 - Dynamics of viral antagonism and innate \
immune response (H1N1 influenza A virus - NC/99)", 
 "BIOMD0000000526" -> "Kallenberger2014 - CD95L induced apoptosis initiated \
by caspase-8, wild-type HeLa cells (cis/trans-cis/trans variant)", 
 "BIOMD0000000527" -> 
  "Kaiser2014 - Salmonella persistence after ciprofloxacin treatment", 
 "BIOMD0000000524" -> "Kallenberger2014 - CD95L induced apoptosis initiated \
by caspase-8, wild-type HeLa cells (cis/trans variant)", 
 "BIOMD0000000525" -> "Kallenberger2014 - CD95L induced apoptosis initiated \
by caspase-8, CD95 HeLa cells (cis/trans-cis/trans variant)", 
 "BIOMD0000000522" -> 
  "Muraro2014 - Vascular patterning in Arabidopsis roots", 
 "BIOMD0000000523" -> "Kallenberger2014 - CD95L induced apoptosis initiated \
by caspase-8, CD95 HeLa cells (cis/trans variant)", 
 "BIOMD0000000520" -> "Smallbone2013 - Colon Crypt cycle - Version 0", 
 "BIOMD0000000521" -> 
  "Ribba2012 - Low-grade gliomas, tumour growth inhibition model", 
 "BIOMD0000000537" -> 
  "Dwivedi2014 - Crohns IL6 Disease model - Anti-IL6R Antibody", 
 "BIOMD0000000538" -> 
  "Clarke2000 - One-hit model of cell death in neuronal degenerations", 
 "BIOMD0000000539" -> 
  "Fran\[CCedilla]ois2005 - Mixed Feedback Loop (two-gene network)", 
 "BIOMD0000000533" -> "Steckmann2012 - Amyloid beta-protein fibrillogenesis \
(kinetics of secondary structure conversion)", 
 "BIOMD0000000534" -> "Dwivedi2014 - Healthy Volunteer IL6 Model", 
 "BIOMD0000000535" -> 
  "Dwivedi2014 - Crohns IL6 Disease model - Anti-IL6 Antibody", 
 "BIOMD0000000536" -> 
  "Dwivedi2014 - Crohns IL6 Disease model - sgp130 activity", 
 "BIOMD0000000530" -> "Schmitz2014 - RNA triplex formation", 
 "BIOMD0000000531" -> "Crespo2012 - Kinetics of Amyloid Fibril Formation", 
 "BIOMD0000000532" -> "Vazquez2014 - Chemical inhibition from amyloid protein \
aggregation kinetics", "BIOMD0000000506" -> "vanEunen2013 - Network dynamics \
of fatty acid ?-oxidation (time-course model)", 
 "BIOMD0000000403" -> 
  "Ayati2010_BoneRemodelingDynamics_WithTumour+DrugTreatment", 
 "BIOMD0000000507" -> "Gardner2000 - genetic toggle switch in E.coli", 
 "BIOMD0000000404" -> "Bray1993_chemotaxis", "BIOMD0000000504" -> "Proctor201\
3 - Cartilage breakdown, interventions to reduce collagen release", 
 "BIOMD0000000401" -> "Ayati2010_BoneRemodelingDynamics_NormalCondition", 
 "BIOMD0000000505" -> "vanEunen2013 - Network dynamics of fatty acid \
?-oxidation (steady-state model)", "BIOMD0000000402" -> 
  "Ayati2010_BoneRemodelingDynamics_WithTumour", 
 "BIOMD0000000400" -> "Cooling2007_IP3transients_CardiacMyocyte", 
 "BIOMD0000000508" -> 
  "Barrack2014 - Calcium/cell cycle coupling - Cyclin D dependent ATP \
release", "BIOMD0000000509" -> 
  "Barrack2014 - Calcium/cell cycle coupling - Rs dependent ATP release", 
 "BIOMD0000000409" -> 
  "Queralt2006_MitoticExit_Cdc55DownregulationBySeparase", 
 "BIOMD0000000502" -> "Messiha2013 - Pentose phosphate pathway model", 
 "BIOMD0000000407" -> "Schliemann2011_TNF_ProAntiApoptosis", 
 "BIOMD0000000503" -> 
  "Messiha2013 - combined glycolysis and pentose phosphate pathway model", 
 "BIOMD0000000408" -> "Hettling2011_CreatineKinase", 
 "BIOMD0000000500" -> 
  "Begitt2014 - STAT1 cooperative DNA binding - single GAS polymer model", 
 "BIOMD0000000405" -> "Cookson2011_EnzymaticQueueingCoupling", 
 "BIOMD0000000406" -> "Moriya2011_CellCycle_FissionYeast", 
 "BIOMD0000000501" -> 
  "Begitt2014 - STAT1 cooperative DNA binding - double GAS polymer model", 
 "BIOMD0000000515" -> "Kerkhoven2013 - Glycolysis and Pentose Phosphate \
Pathway in T.brucei - MODEL C in fructose medium (with glucosomal \
ribokinase)", "BIOMD0000000412" -> 
  "Pokhilko2012_CircClock_RepressilatorFeedbackloop", 
 "BIOMD0000000516" -> "Kerkhoven2013 - Glycolysis and Pentose Phosphate \
Pathway in T.brucei - MODEL D in fructose medium (with ATP:ADP antiporter)", 
 "BIOMD0000000413" -> "Band2012_DII-Venus_FullModel", 
 "BIOMD0000000517" -> "Smallbone2013 - Colon Crypt cycle - Version 3", 
 "BIOMD0000000414" -> "Band2012_DII-Venus_ReducedModel", 
 "BIOMD0000000518" -> "Smallbone2013 - Colon Crypt cycle - Version 2", 
 "BIOMD0000000415" -> "Mellor2012_LipooxygenasePathway", 
 "BIOMD0000000519" -> "Smallbone2013 - Colon Crypt cycle - Version 1", 
 "BIOMD0000000410" -> "Wegner2012_TGFbetaSignalling_FeedbackLoops", 
 "BIOMD0000000411" -> "Heiland2012_CircadianClock_C.reinhardtii", 
 "BIOMD0000000510" -> "Kerkhoven2013 - Glycolysis and Pentose Phosphate \
Pathway in T.brucei - MODEL C (with glucosomal ribokinase)", 
 "BIOMD0000000511" -> "Kerkhoven2013 - Glycolysis and Pentose Phosphate \
Pathway in T.brucei - MODEL D (with ATP:ADP antiporter)", 
 "BIOMD0000000416" -> "Muraro2011_Cytokinin-Auxin_CrossRegulation", 
 "BIOMD0000000512" -> 
  "Benson2014 - FAAH inhibitors for the treatment of osteoarthritic pain", 
 "BIOMD0000000417" -> "Ratushny2012_NF", "BIOMD0000000513" -> 
  "Kerkhoven2013 - Glycolysis in T.brucei - MODEL A", 
 "BIOMD0000000418" -> "Ratushny2012_SPF", "BIOMD0000000514" -> "Kerkhoven2013 \
- Glycolysis and Pentose Phosphate Pathway in T.brucei - MODEL B", 
 "BIOMD0000000419" -> "Ratushny2012_SPF_I", 
 "MODEL1006230069" -> "Maltsev2009_PacemakerCellModel_nonSteadyState", 
 "MODEL1006230068" -> "Cloutier2009_EnergyMetabolism_ModelC", 
 "MODEL7743315447" -> "Radulescu2008_NFkB_hierarchy_M_6_10_15", 
 "MODEL9088294310" -> "Abu-Soud1999_NOHArginine", 
 "MODEL1409240004" -> "Larocque2014 - Metabolic reconstruction of Clostridium \
difficile pathogenic strain 630 (iMLTC806cdf)", 
 "MODEL1409240003" -> "Tiveci2005 - Calcium dynamics in brain energy \
metabolism and Alzheimer's disease", "MODEL1409240002" -> 
  "Qosa2014 - Mechanistic modeling that describes A? clearance across BBB", 
 "MODEL1409240001" -> "Puri2010 - Mathematical Modeling for the Pathogenesis \
of Alzheimer's Disease", "MODEL4780181279" -> "Kuroda2001_NO_cGMP_Pathway", 
 "MODEL1006230065" -> "Aslanidi2009_caninePVJ", 
 "MODEL1006230063" -> "Noble1998_VentricularCellModel_ModelC", 
 "MODEL1006230064" -> "Bagci2008_NO_Apoptosis_modelA", 
 "MODEL1006230061" -> "Wodarz2003_ImmunologicalMemory", 
 "MODEL1006230062" -> "Wodarz1999_CTLmemoryresponse_HIV", 
 "MODEL1006230060" -> "Liu1999_PulsatileSecretion", 
 "MODEL1006230057" -> "Moore2004_CML_TcellInteration", 
 "MODEL1006230056" -> "Bagci2006_ApoptoticStimuli", 
 "MODEL1006230059" -> "Cloutier2009_EnergyMetabolism_ModelE", 
 "MODEL1006230058" -> 
  "Matsuoka2003_VentricularCells_SinoatrialNodePacemaker", 
 "MODEL1506170000" -> "Capuani2015 - Human Core Catabolic Network", 
 "MODEL0403888565" -> "Nutsch2005_phototaxis_noncyc_spontaneous", 
 "MODEL1111070002" -> "Bordbar2011_TissueSpecific-Myocyte_MetablicNetwork", 
 "MODEL1111070003" -> "Bordbar2011_MultiTissueType_MetabolicNetwork", 
 "MODEL1111070000" -> 
  "Bordbar2011_TissueSpecific-Adipocyte_MetabolicNetwork", 
 "MODEL1401240000" -> 
  "Sertba\:015f2014 - Brain specific metabolic network (iMS570)", 
 "MODEL1111070001" -> 
  "Bordbar2011_TissueSpecific-Hepatocyte_MetabolicNetwork", 
 "MODEL1172200168" -> "Bingzheng1990_GlucocorticoidsSecretion", 
 "MODEL1006230052" -> "Wodarz2007_CTLinflation_ModelB", 
 "MODEL1006230053" -> "Vinnakota2006_MuscleGlycogenolysis_ModelB", 
 "MODEL1006230054" -> "Lockwood2006_PKPD_AlzheimersDisease", 
 "MODEL1006230055" -> "Mittler1998_HIV1_interactingTargetCells", 
 "MODEL1006230050" -> "Nowak1996_HostResponse_InfectiousAgents", 
 "MODEL0478895291" -> "Leloup2004_CircadianRhythms", 
 "MODEL1006230048" -> "Mahajan2008_CardiacActionPotential_Arrhythmias", 
 "MODEL1006230047" -> "Revilla2003_HIV1therapy", 
 "MODEL1006230046" -> "Webb2002_FasFasLsystem_Tumour", 
 "MODEL0848676877" -> "Haugh2004_hGH", "MODEL1006230045" -> 
  "Schlosser2000_GlucoseInsulinFeedback_BetaCells", 
 "MODEL1006230049" -> "Vinnakota2006_MuscleGlycogenolysis_ModelC", 
 "MODEL8459127548" -> "You2010_General_Yeast_mRNA_Translation", 
 "MODEL1101180000" -> "DiVentura2011_Min_System_E_coli", 
 "MODEL8478881246" -> "Basak_Cell_2007", "MODEL1006230040" -> 
  "Yang2006_Methadone_PKmodel", "MODEL9071122126" -> 
  "Bhalla1999_3d_fold_model", "MODEL1006230044" -> 
  "Ueda2001_typeBtrichothecenes", "MODEL1006230035" -> 
  "Perelson1993_HIVinfection_CD4Tcells_ModelD", 
 "MODEL1006230034" -> "Wu2006_ATPsynthesis_SkeletalMuscle", 
 "MODEL1006230037" -> "Weinstein2000_OMCD", 
 "MODEL1006230036" -> "Gupta2007_HypothalamicPituitaryAdrenal_ModelB", 
 "MODEL1105180000" -> "Smallbone2009 - FBA model-Geometric Perspective", 
 "MODEL1006230039" -> "Lemon2003_Ca2Dynamics", 
 "MODEL1006230038" -> "Kirschner1998_Immunotherapy_Tumour", 
 "MODEL1210260004" -> 
  "Viladomiu2012 - PPARgamma role in C.diff associated disease", 
 "MODEL8683876463" -> "Priebe1998_VentricularArrhythmias", 
 "MODEL1006230030" -> "Iyer2007_Arrhythmia_CardiacDeath", 
 "MODEL1006230031" -> "Sakmann2000_SodiumCurrent_ModelB", 
 "MODEL1006230032" -> "Yamaguchi1996_MyocardialCa2", 
 "MODEL1006230033" -> "Nelson1995_HIV1therapy_DIVadministraion_ModelB", 
 "MODEL1103210001" -> "Jamshidi01_RBC_MetabolicNetwork", 
 "MODEL1502230000" -> 
  "Best2009 - Homeostatic mechanisms in dopamine synthesis and release", 
 "MODEL1006230029" -> "Koivumaki2009_SERCAATPase_short", 
 "MODEL1006230027" -> "vanBeek2007_OxPhos_HeartMuscleCells", 
 "MODEL1006230028" -> "Tabak2010_NeuronalNetworks", 
 "MODEL1006230025" -> 
  "Phillips2007_AscendingArousalSystem_SleepWakeDynamics", 
 "MODEL8684444027" -> "Potter2006_AndrogenicRegulation", 
 "MODEL1006230026" -> "Bagci2008_NO_Apoptosis_modelB", 
 "MODEL1006230023" -> "Koivumaki2009_SERCAATPase_Standalone", 
 "MODEL1006230024" -> "Bertram2002_Gprotein_SynapticSignal", 
 "MODEL1006230022" -> "Wolf2000_AnaerobicGlycolysis", 
 "MODEL1006230021" -> "Sakmann2000_SodiumCurrent_ModelA", 
 "MODEL1006230020" -> "Sakmann2000_SodiumCurrent_ModelC", 
 "MODEL6185511733" -> "Qiao2007_MAPK_Signaling_Bistable", 
 "MODEL1012090005" -> "Kim2011_Oscillator_ExtendedI", 
 "MODEL1302010006" -> 
  "Pitkanen2014 - Metabolic reconstruction of Coprinus cinereus using CoReCo"\
, "MODEL1012090004" -> "Kim2011_Oscillator_DetailedIII", 
 "MODEL1302010007" -> "Pitkanen2014 - Metabolic reconstruction of \
Coccidioides immitis using CoReCo", "MODEL1012090003" -> 
  "Kim2011_Oscillator_DetailedII", "MODEL1302010008" -> "Pitkanen2014 - \
Metabolic reconstruction of Aspergillus oryzae using CoReCo", 
 "MODEL1012090002" -> "Kim2011_Oscillator_DetailedI", 
 "MODEL1302010009" -> 
  "Pitkanen2014 - Metabolic reconstruction of Magnaporthe grisea using \
CoReCo", "MODEL1302010002" -> 
  "Pitkanen2014 - Metabolic reconstruction of Chaetomium globosum using \
CoReCo", "MODEL1302010003" -> 
  "Pitkanen2014 - Metabolic reconstruction of Candida tropicalis using \
CoReCo", "MODEL1302010004" -> "Pitkanen2014 - Metabolic reconstruction of \
Pichia guilliermondii using CoReCo", "MODEL1302010005" -> "Pitkanen2014 - \
Metabolic reconstruction of Aspergillus nidulans using CoReCo", 
 "MODEL1006230016" -> "Cloutier2009_EnergyMetabolism_ModelB", 
 "MODEL1006230017" -> "Aslanidi2009_RightAtrialTissue_Arrhythmogenesis", 
 "MODEL1006230018" -> "Warren2009_CalciumWavePropagation", 
 "MODEL1006230019" -> "Brown1997_PlasmaMelatoninLevels", 
 "MODEL1006230012" -> "Stewart2009_ActionPotential_PurkinjeFibreCells", 
 "MODEL0912887467" -> "Demir1994_SinoatrialNode", 
 "MODEL1006230013" -> "Jelic2005_HypothalamicPituitaryAdrenal", 
 "MODEL1006230014" -> "Halloy2002_FollicularAutomaton", 
 "MODEL1012090006" -> "Kim2011_Oscillator_ExtendedIII", 
 "MODEL1006230015" -> "Lindblad1996_ActionPotential_AtrialMyocyte", 
 "MODEL1012140001" -> "Rattanakul2003_BoneFormation_Estrogenadministration", 
 "MODEL1006230011" -> 
  "Waugh2006_WoundHealingMacrophageDynamics_Diabetic_ModelC", 
 "MODEL0848507209" -> "Heinze1998_GnRH_LH", 
 "MODEL1012140000" -> "Rattanakul2003_BoneFormation_PTHadministration", 
 "MODEL1006230010" -> "Cloutier2009_EnergyMetabolism_ModelA", 
 "MODEL1007060000" -> "Plata2010_P_falciparum_iTH366", 
 "MODEL4780784080" -> "Hayashi1999_NOSynth_Phospho", 
 "MODEL7743212613" -> "Radulescu2008_NFkB_hierarchy_M_5_8_12", 
 "MODEL2427021978" -> "Conant2007_glycolysis_3A", 
 "MODEL1302010001" -> "Pitkanen2014 - Metabolic reconstruction of Fusarium \
verticillioides using CoReCo", "MODEL1302010000" -> "Pitkanen2014 - Metabolic \
reconstruction of Phaeosphaeria nodorum using CoReCo", 
 "MODEL1006230009" -> "Fink2008_VentricularActionPotential", 
 "MODEL1106200000" -> 
  "Chang2011_MetabolicNetworkReconstruction_ChlamydomonasReinhardtii", 
 "MODEL0911989198" -> "Fenton1998_MyocardiumVortexDynamics", 
 "MODEL1006230003" -> "Waugh2006_WoundHealing_Diabetic_ModelB", 
 "MODEL1006230004" -> "Chen2000_CellCycle", 
 "MODEL1006230001" -> "Fallon2000_IL2dynamics", 
 "MODEL1006230002" -> 
  "Waugh2006_WoundHealingMacrophageDynamics_Diabetic_ModelB", 
 "MODEL1006230007" -> "Holmes2006_MuscleContration", 
 "MODEL1006230008" -> "Inada2009_AtrioventricularNode_NodelHisCell", 
 "MODEL1006230005" -> "Chen2006_NitricOxideRelease", 
 "MODEL1006230006" -> "Wierschem2004_PancreaticIslets_ActionPotentials", 
 "MODEL4821294342" -> "Kierzek2001_LacZ", "MODEL1006230000" -> 
  "Smith2004_CVS_human", "MODEL5662425708" -> 
  "Feist2006_methanogenesis_OptiPyruvate", "MODEL1506260002" -> "Vaga2014 - \
Cross-modularity between high osmolarity and mating pathways - logical model"\
, "MODEL1208030000" -> 
  "Mandlik2013 - Synthetic circuit of IPC synthase in Leishmania", 
 "MODEL1506260000" -> 
  "Terfve2012 - Signalling in liver cancer - logical model", 
 "MODEL1106160000" -> "Smith2011_HumanHeartMitochondrian_MetabolicModel", 
 "MODEL0568648427" -> "Kervizic2008_Cholesterol_SREBP", 
 "MODEL5974712823" -> "FangeElf2006_MinSystem_MesoRD", 
 "MODEL6624199343" -> "Martins2001_glyoxalase", 
 "MODEL1411130000" -> "Miao2014 - Dynamics and migratory pathways of \
virus-specific antibody-secreting cell populations", 
 "MODEL9147975215" -> "Asthagiri2001_MAPK_Asthagiri_adapt_fb", 
 "MODEL1303260017" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 17", 
 "MODEL1303260018" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 18", 
 "MODEL1504080000" -> "Quek2014 - Metabolic flux analysis of HEK cell culture \
using Recon 2 (reduced version of Recon 2)", 
 "MODEL9086518048" -> "Hayer2005_AMPAR_traff_model1", 
 "MODEL0491251823" -> "Chen2007_NeuronalEndothelialNOS", 
 "MODEL1303260011" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 11", 
 "MODEL1303260012" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 12", 
 "MODEL1303260010" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 10", 
 "MODEL1303260015" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 15", 
 "MODEL1303260016" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 16", 
 "MODEL1303260013" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 13", 
 "MODEL1303260014" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 14", 
 "MODEL4151491057" -> "Beard2005_Mitochondrial_Respiration", 
 "MODEL1012080000" -> "Heitzler2012_GPCRsignalling", 
 "MODEL4132046015" -> "Calzone2008_Rb", "MODEL7814665196" -> 
  "Wang2008_Neonatal_heartfunction", "MODEL9086207764" -> 
  "Hayer2005_AMPAR_traff_model0", "MODEL1011300000" -> 
  "Kim2010_VvuMBEL943_GSMR", "MODEL6962035527" -> 
  "Zhang2000_Peripheral_Sinoatrial_Node", "MODEL1001200000" -> 
  "Smallbone2010_Genome_Scale_Yeast_Kinetics", 
 "MODEL1409050001" -> 
  "Rutkis2013 - Entner-Doudoroff pathway in Z.mobilis (cell-free)", 
 "MODEL9089491423" -> "Ajay_Bhalla_2004_PKM_Tuning", 
 "MODEL1409050000" -> "Rutkis2013 - Entner-Doudoroff pathway in Z.mobilis", 
 "MODEL1101100000" -> "Bakker1997_Glycolysis", 
 "MODEL2021729243" -> "Ma2007_HumanMetabol_woEnergy", 
 "MODEL1207300000" -> "Watterson2012_CholesterolBiosynthesisPathway", 
 "MODEL7743444866" -> "Radulescu2008_NFkB_hierarchy_M_14_25_33", 
 "MODEL7434234848" -> "Thomas2009_Buchnera_a_FBA", 
 "MODEL0848116681" -> "Hund2004_VentricularEpicardialAction", 
 "MODEL1006230099" -> "Waugh2006_WoundHealing_Diabetic_ModelC", 
 "MODEL1006230098" -> 
  "Waugh2006_WoundHealingMacrophageDynamics_Diabetic_ModelA", 
 "MODEL1006230097" -> "Wodarz2007_CTLinflation_ModelC", 
 "MODEL1006230096" -> "Cloutier2009_EnergyMetabolism_ModelF", 
 "MODEL0478740924" -> "Kyrylov2005_HPAaxis", 
 "MODEL1006230095" -> "Cloutier2009_EnergyMetabolism_ModelD", 
 "MODEL1006230094" -> "Wodarz2003_CTLcrosspriming", 
 "MODEL0911047946" -> "Guyton1972_PulmonaryOxygenIntake", 
 "MODEL1006230093" -> "Perelson1993_HIVinfection_CD4Tcells_ModelB", 
 "MODEL1006230092" -> "Grandi2009_VentricularMyocyte", 
 "MODEL1006230091" -> "Reed2004_MethionineCycle", 
 "MODEL1006230090" -> "Wu2007_MitochondrialTCAcycle", 
 "MODEL0910896131" -> "Guyton1972_StressRelaxation", 
 "MODEL1304190001" -> 
  "Mufudza2012 - Estrogen effect on the dynamics of breast cancer", 
 "MODEL1406230000" -> 
  "Lee2009 - Adaptive immune response to Influenza A Virus infection", 
 "MODEL3023641273" -> "Feist2007_EcMetabol_flux2", 
 "MODEL4992089662" -> "Banaji2005_Brain_Cell_Metabolism", 
 "MODEL1006230082" -> "Inada2009_AtrioventricularNode_AtrioNodalCell", 
 "MODEL1006230081" -> "Nelson1995_HIV1therapy_DIVadministraion_ModelA", 
 "MODEL1006230084" -> "Heldt2002_OrthostaticStress_circpbpk", 
 "MODEL1006230083" -> "Kroll2000_PTH_BoneFormationDesorption", 
 "MODEL1006230086" -> "Wodarz2007_CTLinflation_ModelA", 
 "MODEL1006230085" -> "Iribe2006_CaMKIIkineticsModel", 
 "MODEL7898438988" -> "Smith1980_HypothalamicRegulation", 
 "MODEL1006230088" -> "Inada2009_AtrioventricularNode_NodalCell", 
 "MODEL1006230087" -> "Benson2008_Arrhythmogenesis_Mcell", 
 "MODEL1006230080" -> "Noble1998_VentricularCellModel_ModelB", 
 "MODEL3023609334" -> "Feist2007_EcMetabol_flux1", 
 "MODEL0406793751" -> "Pasek2008_VentricularCardioMyocyte", 
 "MODEL1006230089" -> "Noble1998_VentricularCellModel_ModelA", 
 "MODEL7896869925" -> "Sobaleva2005_ProlactinRegulation", 
 "MODEL1150151512" -> "Bondarenko2004_Myocyte_AP_apical", 
 "MODEL1006230073" -> 
  "Noble1991_CardiacActionPotential_SodiumCalciumExchange", 
 "MODEL1006230072" -> "Yanagihara1980_PacemakerActivity", 
 "MODEL1006230071" -> "Bertram2004_PancreaticBetaCell_modelA", 
 "MODEL1006230070" -> "Earm1990_CalciumDynamics_Cardiac", 
 "MODEL1006230077" -> "Vinnakota2006_MuscleGlycogenolysis_ModelA", 
 "MODEL1006230076" -> "Mackenzie1996_NaGlucoseCotransporter_Kidney", 
 "MODEL1006230075" -> "Perelson1993_HIVinfection_CD4Tcells_ModelC", 
 "MODEL1303130001" -> "Venkatraman2011 - PLS-UPA behaviour in the presence of \
substrate competition", "MODEL1006230078" -> 
  "Benson2008_Arrhythmogenesis_Endocardial", 
 "MODEL1006230079" -> "Perelson1993_HIVinfection_CD4Tcells_ModelA", 
 "MODEL8568434338" -> "Raman2006_MycolicAcid", 
 "MODEL1303140000" -> 
  "Mazemondet2012 - beta-catenin dynamics in human neural progenitor cells", 
 "MODEL1303140001" -> 
  "Ray2013 - S.cerevisiae meiosis-specific metabolic network", 
 "MODEL3632127506" -> "Jablonsky2008_kinetic_model_of_dimeric_PSII", 
 "MODEL1407050000" -> 
  "Larocque2014 - Clostridium metabolic network reconstruction", 
 "MODEL1302180001" -> 
  "Sanjuan2013 - Evolution of HIV T-cell epitope, immune activation model", 
 "MODEL1201070001" -> "Gall1999_CalciumBursting_BetaCellModel_B", 
 "MODEL1201070000" -> "Gall1999_CalciumBursting_BetaCellModel_A", 
 "MODEL1302180002" -> 
  "Sanjuan2013 - Evolution of HIV T-cell epitope, control model", 
 "MODEL7910499126" -> "TenTusscher2006_VentricularCellModel", 
 "MODEL9808533471" -> "McAllister1975_CardiacPurkinjeFibres", 
 "MODEL2426780967" -> "Conant2007_glycolysis_2A", 
 "MODEL1209260000" -> "Koenig2012_HepaticGlucoseMetabolism", 
 "MODEL3883569319" -> "Aho2010_RefRec_S_cerevisiae", 
 "MODEL9080747936" -> "Bhalla2004_CaMKII_2003", 
 "MODEL5662377562" -> "Feist2006_methanogenesis_OptiAcetate", 
 "MODEL1008110000" -> "Werner2005_IkappaB_kinase", 
 "MODEL0995500644" -> "Rodriguez2005_denovo_pyrimidine_biosynthesis", 
 "MODEL0911601070" -> "Garny2003_SinoatrialNode", 
 "MODEL1201140001" -> "Keener2001_OscillatoryInsulinSecretionModel", 
 "MODEL1012300000" -> 
  "MacDonald2011_GeneticMetabolicDeterminants_BuchnereAphidicola", 
 "MODEL8938094216" -> "dAlcantara2003_SynapticPlasticity", 
 "MODEL1201140000" -> "Gall1999_CalciumBursting_BetaCellModel_C", 
 "MODEL1201140006" -> "Wanant2000_InsulinReceptorModel_B", 
 "MODEL1201140002" -> "Lenbury2001_InsulinKineticsModel_A", 
 "MODEL1201140003" -> "Lenbury2001_InsulinKineticsModel_B", 
 "MODEL1201140004" -> "Magnus1997_MitoCa_BetaCellMinimalModel", 
 "MODEL7743576806" -> 
  "Radulescu2008 - NF-\[Kappa]B hierarchy \[ScriptCapitalM](16,34,46)", 
 "MODEL1201140005" -> "Wanant2000_InsulinReceptorModel_A", 
 "MODEL8236441887" -> "Yang2008_AAnetwork_PMN", 
 "MODEL9089914876" -> "Ajay_Bhalla_2004_Feedback_Tuning", 
 "MODEL6963432821" -> "Zager2007_Genistein_Biliary_Excretion", 
 "MODEL1204120000" -> 
  "Bekaert2012 - Reconstruction of D.rerio Metabolic Network", 
 "MODEL1503180005" -> "Smallbone2015 - pathway feedback", 
 "MODEL1503180006" -> "Smallbone2015 - forced pathway feedback", 
 "MODEL7980735163" -> "Purvis2005_IonicCurrentModel", 
 "MODEL9086628127" -> "Hayer2005_simple_AMPAR_traff_model2", 
 "MODEL1503180002" -> "Smallbone2015 - Michaelis Menten", 
 "MODEL1503180003" -> "Smallbone2015 - pathway", 
 "MODEL1503180004" -> "Smallbone2015 - forced pathway", 
 "MODEL1012220004" -> "Caron2010_mTORsignalingNetwork_ActivityFlow", 
 "MODEL1012220003" -> "Caron2010_mTORC1_UpstreamRegulators", 
 "MODEL8686121468" -> "Noble1962_HodgkinHuxleyEquation", 
 "MODEL1012220002" -> "Caron2010_mTOR_SignalingNetwork", 
 "MODEL2463576061" -> "Oda2005_EGFR", "MODEL1308080003" -> 
  "Cao2010 - Epigenetic state of lysogeny in phage lambda", 
 "MODEL1308080002" -> "Koch2005 - sucrose breakdown pathway - petri net", 
 "MODEL9088169066" -> "Abu-Soud1999_NMArginine", 
 "MODEL1172425728" -> "Cui2008_CardiacMyocytes", 
 "MODEL7743528808" -> "Radulescu2008_NFkB_hierarchy_M_14_30_41", 
 "MODEL8236480549" -> "Yang2008_AAnetwork_EC", 
 "MODEL1302010040" -> 
  "Pitkanen2014 - Metabolic reconstruction of Neurospora crassa using CoReCo"\
, "MODEL1302010041" -> 
  "Pitkanen2014 - Metabolic reconstruction of Laccaria bicolor using CoReCo", 
 "MODEL0403988150" -> "Nutsch2005_phototaxis_noncyc_attractant_light", 
 "MODEL1302010044" -> "Pitkanen2014 - Metabolic reconstruction of \
Uncinocarpus reesii using CoReCo", "MODEL1302010045" -> 
  "Pitkanen2014 - Metabolic reconstruction of Puccinia graminis using CoReCo"\
, "MODEL1302010042" -> "Pitkanen2014 - Metabolic reconstruction of \
Batrachochytrium dendrobatidis using CoReCo", 
 "MODEL1302010043" -> 
  "Pitkanen2014 - Metabolic reconstruction of Pichia stipitis using CoReCo", 
 "MODEL1504280000" -> 
  "Tymoshenko2015 - Genome scale metabolic model - ToxoNet1", 
 "MODEL0909931851" -> "Guyton1972_volumeReceptors", 
 "MODEL1209060000" -> "Heavner2012 - Metabolic Network of S.cerevisiae", 
 "MODEL1108260010" -> "Jesty1993_ProteolyticPositiveFeedback", 
 "MODEL1302010048" -> 
  "Pitkanen2014 - Metabolic reconstruction of Pichia pastoris using CoReCo", 
 "MODEL0406151557" -> "Noble1984_SinoAtrialNode", 
 "MODEL1302010047" -> "Pitkanen2014 - Metabolic reconstruction of Neosartorya \
fischeri using CoReCo", "MODEL1407250000" -> "Taffi2014 - Extension of \
metabolic reconstruction of Pseudomonas putida KT2440 with aerobic pathway of \
PCBs degradation", "MODEL1302010046" -> 
  "Pitkanen2014 - Metabolic reconstruction of Candida albicans using CoReCo", 
 "MODEL1108260014" -> "Chatterjee2010_BloodCoagulation", 
 "MODEL1108260015" -> "Qiao2004_ThrombinGeneration", 
 "MODEL0911309080" -> "Guyton1972_AntidiureticHormone", 
 "MODEL1302010030" -> "Pitkanen2014 - Metabolic reconstruction of \
Encephalitozoon cuniculi using CoReCo", "MODEL1302010031" -> "Pitkanen2014 - \
Metabolic reconstruction of Mycosphaerella graminicola using CoReCo", 
 "MODEL1302010032" -> 
  "Pitkanen2014 - Metabolic reconstruction of Postia placenta using CoReCo", 
 "MODEL6399676120" -> "Duarte2007_Homo_sapiens_Metabol_Recon_1", 
 "MODEL0911120000" -> "Sorokina2009_PhyA_FHL_ON_OFF_9h", 
 "MODEL1302010033" -> "Pitkanen2014 - Metabolic reconstruction of \
Lodderomyces elongisporus using CoReCo", "MODEL1302010034" -> "Pitkanen2014 - \
Metabolic reconstruction of Sclerotinia sclerotiorum using CoReCo", 
 "MODEL7889395724" -> "Beeler1977_Ventricular_Myocardial_Fiber_AP", 
 "MODEL1112110000" -> "Alvehag2006_IVGTT_GlucoseModel_A", 
 "MODEL1112110001" -> "Alvehag2006_OGTT_GlucoseModel_B", 
 "MODEL1112110004" -> 
  "Silber2007_IntravenousGlucose_IntegratedGlucoseInsulinModel", 
 "MODEL1112110002" -> "Farhy2009_GlucagonCounterRegulationModel", 
 "MODEL1112110003" -> "Gaetano2008_DiabetesProgressionModel", 
 "MODEL1302010036" -> "Pitkanen2014 - Metabolic reconstruction of \
Sporobolomyces roseus using CoReCo", "MODEL1302010035" -> "Pitkanen2014 - \
Metabolic reconstruction of Schizosaccharomyces pombe using CoReCo", 
 "MODEL1302010038" -> 
  "Pitkanen2014 - Metabolic reconstruction of Ashbya gossypii using CoReCo", 
 "MODEL1302010037" -> 
  "Pitkanen2014 - Metabolic reconstruction of Candida lusitaniae using \
CoReCo", "MODEL1302010039" -> "Pitkanen2014 - Metabolic reconstruction of \
Cryptococcus neoformans using CoReCo", "MODEL1302010022" -> "Pitkanen2014 - \
Metabolic reconstruction of Histoplasma capsulatum using CoReCo", 
 "MODEL9079179924" -> "Bhalla2002_MAPK-bistability-fig1c", 
 "MODEL1302010023" -> "Pitkanen2014 - Metabolic reconstruction of \
Debaryomyces hansenii using CoReCo", "MODEL1302010020" -> "Pitkanen2014 - \
Metabolic reconstruction of Nectria haematococca using CoReCo", 
 "MODEL1302010021" -> "Pitkanen2014 - Metabolic reconstruction of \
Schizosaccharomyces japonicus using CoReCo", 
 "MODEL0847999575" -> "Iyer2004_VentricularMyocyte", 
 "MODEL0913095435" -> "Corrias2008_GastricSlowWaveActivity", 
 "MODEL1302010029" -> "Pitkanen2014 - Metabolic reconstruction of \
Saccharomyces cerevisiae using CoReCo", "MODEL1302010028" -> 
  "Pitkanen2014 - Metabolic reconstruction of Candida glabrata using CoReCo", 
 "MODEL1302010027" -> 
  "Pitkanen2014 - Metabolic reconstruction of Botrytis cinerea using CoReCo", 
 "MODEL1504010000" -> "Shestov2014 - aerobic glycolysis", 
 "MODEL1302010026" -> "Pitkanen2014 - Metabolic reconstruction of Fusarium \
graminearum using CoReCo", "MODEL1302010025" -> "Pitkanen2014 - Metabolic \
reconstruction of Phanerochaete chrysosporium using CoReCo", 
 "MODEL8687732743" -> "Muller2008_MAPKactivation_Dynamics", 
 "MODEL1302010024" -> "Pitkanen2014 - Metabolic reconstruction of Aspergillus \
fumigatus using CoReCo", "MODEL1302010010" -> "Pitkanen2014 - Metabolic \
reconstruction of Phycomyces blakesleeanus using CoReCo", 
 "MODEL1005050000" -> "Salazar2009_PhotoperiodicRegulation", 
 "MODEL1302010011" -> "Pitkanen2014 - Metabolic reconstruction of \
Kluyveromyces lactis using CoReCo", "MODEL1302010012" -> "Pitkanen2014 - \
Metabolic reconstruction of Aspergillus clavatus using CoReCo", 
 "MODEL0913285268" -> "Ciliberto2003_Swe1Network", 
 "MODEL0912452142" -> "Egli2004_ProlactinRhythmicSecretion", 
 "MODEL7907879432" -> "Schneider2006_CardiacContractionModel", 
 "MODEL1302010018" -> 
  "Pitkanen2014 - Metabolic reconstruction of Rhizopus oryzae using CoReCo", 
 "MODEL1302010017" -> 
  "Pitkanen2014 - Metabolic reconstruction of Aspergillus niger using CoReCo"\
, "MODEL1302010019" -> 
  "Pitkanen2014 - Metabolic reconstruction of Trichoderma reesei using \
CoReCo", "MODEL1302010014" -> 
  "Pitkanen2014 - Metabolic reconstruction of Fusarium oxysporum using \
CoReCo", "MODEL1302010013" -> 
  "Pitkanen2014 - Metabolic reconstruction of Yarrowia lipolytica using \
CoReCo", "MODEL1302010016" -> 
  "Pitkanen2014 - Metabolic reconstruction of Ustilago maydis using CoReCo", 
 "MODEL1302010015" -> "Pitkanen2014 - Metabolic reconstruction of Aspergillus \
terreus using CoReCo", "MODEL0911231713" -> "Guyton1972_HeartHypertrophy", 
 "MODEL1173105855" -> "Gilbert2008_ElectrochemicalBiosensor", 
 "MODEL1301290000" -> "Wodke2013 - Genome-scale constraint-based model of \
M.pneumoniae energy metabolism (iJW145)", "MODEL9079740062" -> 
  "Bhalla2004_PKA_2003", "MODEL0912940495" -> 
  "Demir1999_SinoatrialNodeActivity_Heart", 
 "MODEL5662324959" -> "Feist2006_methanogenesis_OptiMethanol", 
 "MODEL0913145131" -> "Corrias2007_GastricSMCellularActivation", 
 "MODEL0848062679" -> "Irvine1999_CardiacSodiumChannel", 
 "MODEL0912160003" -> "Luo1994_CardiacVentricularActionPotential", 
 "MODEL0912160000" -> "Guyton1972_CapillaryDynamics", 
 "MODEL0912153452" -> "Faber2000_LRmodel_CardiacMyocytes", 
 "MODEL5952308332" -> "Dan\[OSlash]2006_Glycolysis_Reduction", 
 "MODEL0912160001" -> "Guyton1972_Electrolytes", 
 "MODEL0912160004" -> "Shorten2007_SkeletalMuscleFatigue", 
 "MODEL0912160005" -> "Tomida2003_NFATfunctions_CalciumOscillation", 
 "MODEL0911342562" -> "Guyton1972_Angiotensin", 
 "MODEL2784700357" -> "Feala2007_dros_mel_central_metabolism", 
 "MODEL1004010002" -> "Kuwahara2010_Fimbriation_Switch_42C", 
 "MODEL1004010001" -> "Kuwahara2010_Fimbriation_Switch_37C", 
 "MODEL1004010000" -> "Kuwahara2010_Fimbriation_Switch_28C", 
 "MODEL9086953089" -> "Hayer2005_CaMKII_model3", 
 "MODEL9085850385" -> "Bhalla2004_EGFR_MAPK", "MODEL1305010000" -> "Chavez200\
9 - a core regulatory network of OCT4 in human embryonic stem cells", 
 "MODEL7914464799" -> "Shannon2004_VentricularMyocyte", 
 "MODEL0911169699" -> "Guyton1972_NonMuscleBloodFlowControl", 
 "MODEL1410310000" -> 
  "Masel2000 - Drugs to stop prion aggregates and other amyloids", 
 "MODEL0072364382" -> "Herrg\[ARing]rd2008_MetabolicNetwork_Yeast", 
 "MODEL1011010000" -> "Bruck2008_Glycolysis", 
 "MODEL1204190001" -> "Petelenz-kurdziel2013 - Osmo adaptation pfk2627D", 
 "MODEL1204190000" -> "Petelenz-kurdziel2013 - Osmo adaptation WT", 
 "MODEL1204190005" -> "Petelenz-Kurdziel2013 - Osmo adaptation fps1D1", 
 "MODEL1204190004" -> "Petelenz-kurdzeil2013 - Osmo adaptation gpd1D", 
 "MODEL1204190003" -> "Petelenz-kurdziel2013 - Osmo adaptation hog1D", 
 "MODEL1204190002" -> "Petelenz-kurdziel2013 - Osmo adaptation HOG1att", 
 "MODEL5662398146" -> "Feist2006_methanogenesis_OptiH2-CO2", 
 "MODEL1310110029" -> "Thiele2013 - Ovary ovarian stroma cells", 
 "MODEL1208060000" -> "Hoppe2012 - Predicting changes in metabolic function \
using transcript profiles (HepatoNet1b_mouse)", 
 "MODEL1310110028" -> "Thiele2013 - Parathyroid gland glandular cells", 
 "MODEL1107050000" -> "Bialik2010_Apoptosis_SPIKEmodel", 
 "MODEL1006230121" -> "Tran2009_CaDynamicsSERCA_Cardiac", 
 "MODEL1006230120" -> "Siebert2008_MuscleContraction_CCSEC", 
 "MODEL1310110020" -> "Thiele2013 - Small intestine glandular cells", 
 "MODEL1310110021" -> "Thiele2013 - Tonsil germinal center cells", 
 "MODEL1310110022" -> 
  "Thiele2013 - Uterus pre menopause cells in endometrial stroma", 
 "MODEL0911532520" -> "Goodwin1965_EnzymeControlProcess", 
 "MODEL1310110023" -> "Thiele2013 - Breast glandular cells", 
 "MODEL1310110024" -> "Thiele2013 - Pancreas exocrine glandular cells", 
 "MODEL1310110025" -> "Thiele2013 - Smooth muscle smooth muscle cells", 
 "MODEL1110130000" -> 
  "Gonz\[AAcute]lez-Domenech2012_MetabolicNetwork_iCG238", 
 "MODEL1310110026" -> "Thiele2013 - Cervix uterine glandular cells", 
 "MODEL1110130001" -> 
  "Gonz\[AAcute]lez-Domenech2012_MetabolicNetwork_iCG230", 
 "MODEL1310110027" -> "Thiele2013 - Oral mucosa squamous epithelial cells", 
 "MODEL1011090002" -> "Bordbar2010_M_tuberculosis_Macrophage", 
 "MODEL1011090001" -> "Bordbar2010_Macrophage_Metabolism", 
 "MODEL1011090000" -> "Goffin2010_L_plantarum_Metabolism", 
 "MODEL1310110019" -> "Thiele2013 - Vagina squamous epithelial cells", 
 "MODEL1310110018" -> "Thiele2013 - Prostate glandular cells", 
 "MODEL1310110017" -> 
  "Thiele2013 - Uterus post menopause cells in endometrial stroma", 
 "MODEL1006230110" -> "Phillips2008_AscendingArousalSystem_Baseline", 
 "MODEL1006230111" -> "Gupta2007_HypothalamicPituitaryAdrenal_ModelA", 
 "MODEL1204280032" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M4_K2_PSEQ_short_duration_signal)", "MODEL1310110011" -> 
  "Thiele2013 - Skeletal muscle myocytes", "MODEL1006230112" -> 
  "Vinnakotta2010_TranscientAnoxia_SOLmuscle", 
 "MODEL1204280031" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M3_K2_PSEQ_short_duration_signal)", "MODEL1310110012" -> 
  "Thiele2013 - Duodenum glandular cells", "MODEL1006230113" -> 
  "Heldt2002_OrthostaticStress_lpc", "MODEL1204280030" -> "Sarma2012 - \
Interaction topologies of MAPK cascade (M2_K2_PSEQ_short_duration_signal)", 
 "MODEL1006230114" -> "Bertram2006_ATPproduction_Mitochondrial", 
 "MODEL1310110010" -> "Thiele2013 - Lung pneumocytes", 
 "MODEL1006230115" -> "Phillips2008_AscendingArousalSystem_SleepDeprivation", 
 "MODEL1310110015" -> "Thiele2013 - Thyroid gland glandular cells", 
 "MODEL1006230116" -> "Tran2009_CardiacActiveForceGeneration", 
 "MODEL1204280035" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_QSS_USEQ)", 
 "MODEL1310110016" -> "Thiele2013 - Cerebellum cells in molecular layer", 
 "MODEL1006230117" -> "Iancu2007_CardiacMyoscytes_cAMPsignaling", 
 "MODEL1204280034" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_QSS_USEQ)", 
 "MODEL1310110013" -> "Thiele2013 - Pancreas islets of Langerhans", 
 "MODEL1006230118" -> "Saucerman2003_CardiacMyocyte_BetaAdrenergic", 
 "MODEL1204280033" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_QSS_USEQ)", 
 "MODEL1310110014" -> "Thiele2013 - Liver hepatocytes", 
 "MODEL1006230119" -> "Siebert2008_MuscleContraction_CC", 
 "MODEL1204280039" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_QSS_PSEQ)", 
 "MODEL1204280038" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_QSS_PSEQ)", 
 "MODEL1204280037" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_QSS_PSEQ)", 
 "MODEL1507180063" -> "Pastick2009 - Genome-scale metabolic network of \
Streptococcus thermophilus (iMP429)", "MODEL1507180064" -> 
  "Saha2011- Genome-scale metabolic network of Zea mays (iRS1563)", 
 "MODEL1507180065" -> 
  "Caspeta2012 - Genome-scale metabolic network of Pichia pastoris (iLC915)", 
 "MODEL1507180066" -> "Kuepfer2005 - Genome-scale metabolic network of \
Saccharomyces cerevisiae (iLL672)", "MODEL1507180067" -> 
  "Quek2008 - Genome-scale metabolic network of Mus musculus", 
 "MODEL0911202318" -> "Guyton1972_MuscleBloodFlowControl", 
 "MODEL1507180068" -> "Nogales2008 - Genome-scale metabolic network of \
Pseudomonas putida (iJN746)", "MODEL0975191032" -> "Chang2008 - ERK \
activation, hallucinogenic drugs mediated signalling through serotonin \
receptors", "MODEL8685104549" -> "Pandit2003_VentricularMyocytes", 
 "MODEL1507180069" -> "Baart2007 - Genome-scale metabolic network of \
Neisseria meningitidis (iGB555)", "MODEL1507180060" -> 
  "Reed2003 - Genome-scale metabolic network of Escherichia coli (iJR904)", 
 "MODEL0404023805" -> "Nutsch2005_phototaxis_noncyc_attractant_dark", 
 "MODEL1409230001" -> 
  "Hingant2014 - Micellar On-Pathway Intermediate in Prion Amyloid Formation"\
, "MODEL1507180061" -> "Sohn2012 - Genome-scale metabolic network of \
Schizosaccharomyces pombe (SpoMBEL1693)", "MODEL7891585309" -> 
  "Butera1999_Bursting_Pacemaker_Neuron_Model_1", 
 "MODEL1507180062" -> "Kim2007 - Genome-scale metabolic network of Mannheimia \
succiniciproducens (iTY425)", "MODEL1310110046" -> 
  "Thiele2013 - Stomach lower glandular cells", 
 "MODEL1310110047" -> "Thiele2013 - Kidney cells in tubules", 
 "MODEL1310110048" -> "Thiele2013 - Esophagus squamous epithelial cells", 
 "MODEL1310110049" -> "Thiele2013 - Placenta decidual cells", 
 "MODEL1310110042" -> "Thiele2013 - Gall bladder glandular cells", 
 "MODEL1310110043" -> "Thiele2013 - Colon glandular cells", 
 "MODEL1310110044" -> 
  "Thiele2013 - Cervix uterine squamous epithelial cells", 
 "MODEL1310110045" -> "Thiele2013 - Tonsil non germinal center cells", 
 "MODEL0848444339" -> "Hilgemann1987_CalciumTransients", 
 "MODEL1310110040" -> "Thiele2013 - Lateral ventricle neuronal cells", 
 "MODEL1310110041" -> "Thiele2013 - Liver bile duct cells", 
 "MODEL1502270000" -> "Weisse2015 - Cell Growth", 
 "MODEL8262229752" -> "Li2006_QuorumSensing", 
 "MODEL4816599063" -> "mahaney2000_SERCAregulation", 
 "MODEL1507180072" -> "Heinemann2005 - Genome-scale reconstruction of \
Staphylococcus aureus (iMH551)", "MODEL1507180070" -> "Becker2005 - \
Genome-scale metabolic network of Staphylococcus aureus (iSB619)", 
 "MODEL1112150000" -> "Tiemann2011_PhenotypeTransitions", 
 "MODEL1507180071" -> "Vanee2010 - Genome-scale metabolic model of \
Cryptosporidium hominis (iNV213)", "MODEL1310110039" -> 
  "Thiele2013 - Testis cells in seminiferus ducts", 
 "MODEL1310110037" -> "Thiele2013 - Lateral ventricle glial cells", 
 "MODEL1310110038" -> "Thiele2013 - Appendix glandular cells", 
 "MODEL1310110035" -> "Thiele2013 - Urinary bladder urothelial cells", 
 "MODEL1310110036" -> "Thiele2013 - Lymph node germinal center cells", 
 "MODEL1310110033" -> "Thiele2013 - Cerebral cortex neuronal cells", 
 "MODEL1310110034" -> "Thiele2013 - Hippocampus neuronal cells", 
 "MODEL1310110031" -> "Thiele2013 - Seminal vesicle glandular cells", 
 "MODEL1310110032" -> "Thiele2013 - Appendix lymphoid tissue", 
 "MODEL1310110030" -> "Thiele2013 - Bone marrow hematopoietic cells", 
 "MODEL1105100000" -> "Shlomi2011 - Warburg effect, metabolic model", 
 "MODEL6623617994" -> "Lambeth2002_Glycogenolysis", 
 "MODEL1203220000" -> "Mol2013 - Leishmania macrophage signaling network", 
 "MODEL1949107276" -> "Durot2008_A.Baylyi_ADP1Metabolism", 
 "MODEL1204280004" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M4_K1_USEQ)", 
 "MODEL1204280005" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M1_K1_PSEQ)", 
 "MODEL1204280006" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M2_K1_PSEQ)", 
 "MODEL1204280007" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M3_K1_PSEQ)", 
 "MODEL1208280000" -> 
  "Celli\[EGrave]re2011 - Plasticity of TGF-\[Beta] Signalling", 
 "MODEL1204280008" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M4_K1_PSEQ)", 
 "MODEL1310110061" -> "Thiele2013 - Vulva anal skin epidermal cells", 
 "MODEL1204280009" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M1_K1_USEQ_short_duration_signal)", "MODEL1310110060" -> 
  "Thiele2013 - Spleen cells in red pulp", "MODEL1208280001" -> 
  "Geier2011 - Integrin activation", "MODEL1310110063" -> 
  "Thiele2013 - Bronchus respiratory epithelial cells", 
 "MODEL1310110062" -> "Thiele2013 - Salivary gland glandular cells", 
 "MODEL1310110064" -> "Thiele2013 - Cerebral cortex glial cells", 
 "MODEL1204280001" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M1_K1_USEQ)", 
 "MODEL1204280002" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M2_K1_USEQ)", 
 "MODEL1204280003" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M3_K1_USEQ)", 
 "MODEL9081220742" -> "Bhalla2004_MAPK_network_2003", 
 "MODEL0912044015" -> "Faville2008_UPdepolarization", 
 "MODEL1310110052" -> 
  "Thiele2013 - Nasopharynx respiratory epithelial cells", 
 "MODEL0911091440" -> "Guyton1972_PulmonaryFluidDynamics", 
 "MODEL0913049417" -> "Courtemanche1998_AtrialActionPotential", 
 "MODEL1310110051" -> "Thiele2013 - Lung macrophages", 
 "MODEL1310110050" -> "Thiele2013 - Cerebellum Purkinje cells", 
 "MODEL0913003363" -> "Cui2006_CalciumHomeostasis", 
 "MODEL1310110056" -> "Thiele2013 - Heart muscle myocytes", 
 "MODEL1310110055" -> "Thiele2013 - Placenta trophoblastic cells", 
 "MODEL1310110054" -> "Thiele2013 - Epididymis glandular cells", 
 "MODEL7743631122" -> "Radulescu2008_NFkB_hierarchy_M_34_60_82", 
 "MODEL1310110053" -> "Thiele2013 - Kidney cells in glomeruli", 
 "MODEL0848279215" -> "Hornberg2005_MAPKsignalling", 
 "MODEL1310110059" -> "Thiele2013 - Stomach upper glandular cells", 
 "MODEL1310110058" -> "Thiele2013 - Tonsil squamous epithelial cells", 
 "MODEL1310110057" -> "Thiele2013 - Rectum glandular cells", 
 "MODEL6624091635" -> "Hoefnagel2002_Glycolysis", 
 "MODEL1008060002" -> "Munz2009 - Zombie SIZRQ", 
 "MODEL9089538076" -> "Ajay_Bhalla_2004_PKM_MKP3_Tuning", 
 "MODEL1008240001" -> 
  "\[CapitalCCedilla]akir2004 - Central Carbon Metabolism of S.cerevisiae", 
 "MODEL1008060001" -> "Munz2009 - Zombie SIZRC", 
 "MODEL1008060000" -> "Munz2009 - Zombi Impulsive Killing", 
 "MODEL1305060000" -> "Reyes-Palomares2012 - a combined model hepatic \
polyamine and sulfur aminoacid metabolism - version1", 
 "MODEL1204280026" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M2_K2_USEQ_short_duration_signal)", "MODEL9087255381" -> 
  "Hayer2005_AMPAR_CaMKII_strong_coupling", "MODEL1204280027" -> "Sarma2012 - \
Interaction topologies of MAPK cascade (M3_K2_USEQ_short_duration_signal)", 
 "MODEL1204280028" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M4_K2_USEQ_short_duration_signal)", "MODEL1204280029" -> "Sarma2012 - \
Interaction topologies of MAPK cascade (M1_K2_PSEQ_short_duration_signal)", 
 "MODEL1204280022" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_PSEQ)", 
 "MODEL1011020000" -> "Kaizu2010_BuddingYeastCellCycle_Map", 
 "MODEL1204280023" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_PSEQ)", 
 "MODEL0912388235" -> "Endresen1997_SinoatrialActionPotential", 
 "MODEL1204280025" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M1_K2_USEQ_short_duration_signal)", "MODEL1005200000" -> 
  "Twycross2010_Auxin_Transport", "MODEL1204280021" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_PSEQ)", 
 "MODEL1405070000" -> "Dolan2014 - calcium homeostasis (SOCE)", 
 "MODEL0910846879" -> "Guyton1972_ThirstDrinking_SaltAppetite", 
 "MODEL1411110000" -> "Rienksma2014 - Genome-scale constraint-based metabolic \
model of M.tuberculosis", "MODEL1310160000" -> 
  "Stavrum2013 - Tryptophan Metabolism in Liver", 
 "MODEL1204280019" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_USEQ)", 
 "MODEL1204280017" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_USEQ)", 
 "MODEL1204280018" -> 
  "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_USEQ)", 
 "MODEL1204280015" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M3_K1_PSEQ_short_duration_signal)", "MODEL1204280016" -> "Sarma2012 - \
Interaction topologies of MAPK cascade (M4_K1_PSEQ_short_duration_signal)", 
 "MODEL1204280013" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M1_K1_PSEQ_short_duration_signal)", "MODEL1204280014" -> "Sarma2012 - \
Interaction topologies of MAPK cascade (M2_K1_PSEQ_short_duration_signal)", 
 "MODEL1204280011" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M3_K1_USEQ_short_duration_signal)", "MODEL1204280012" -> "Sarma2012 - \
Interaction topologies of MAPK cascade (M4_K1_USEQ_short_duration_signal)", 
 "MODEL9077438479" -> "Bhalla2002_cAMP_pathway", 
 "MODEL1204280010" -> "Sarma2012 - Interaction topologies of MAPK cascade \
(M2_K1_USEQ_short_duration_signal)", "MODEL1411240029" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - heart"\
, "MODEL1411240028" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - prostate", "MODEL9071773985" -> 
  "Bhalla2001_MAPK_MKP1_oscillation", "MODEL1304120000" -> 
  "Goyal2014 - Genome-scale metabolic model of M.maripaludis S2", 
 "MODEL1411240025" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - pancreas", "MODEL1411240024" -> "Uhl\[EAcute]n2015 - \
Human tissue-based proteome metabolic network - small intestine", 
 "MODEL7817907010" -> "Wang2008_Rilusole_SkeletalMuscleCells", 
 "MODEL1411240027" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - duodenum", "MODEL1304300000" -> 
  "Hofmeyr1996 - metabolic control analysis", 
 "MODEL1411240026" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - gallbladder", "MODEL9080388197" -> "Bhalla2004_PKC_2003", 
 "MODEL0912096133" -> "Farhy2007_hGHregulation", 
 "MODEL1204270001" -> "Koenig2012_HepaticGlucoseMetabolism", 
 "MODEL1411240020" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - esophagus", "MODEL1411240021" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - ovary"\
, "MODEL1411240022" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - skin", 
 "MODEL1411240023" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
tonsil", "MODEL1112100000" -> 
  "J\[ODoubleDot]nsson2005_WUSCHELexpression_ShootApicalMeristem", 
 "MODEL1002240000" -> "Nookaew2008_Yeast_MetabolicNetwork_iIN800", 
 "MODEL0913242281" -> "Ciliberto2003_CyclinECdk2Timer", 
 "MODEL0912503622" -> "Dokos1996_SinoatrialNode", 
 "MODEL1102210000" -> "Wei2011_MLCactivationPathway_EndothelialPermeability", 
 "MODEL1411240031" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - urinary", "MODEL1407230001" -> 
  "Wollbold2014 - Effects of reactive oxygen species", 
 "MODEL1102210001" -> "Telesco2011_HER3-ErbB3-RTK_SignalingNetwork", 
 "MODEL0911665321" -> "Fox2002_IonicMechanism_CardiacMyocytes", 
 "MODEL1411240032" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - brain"\
, "MODEL1411240030" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - placenta", "MODEL7888000034" -> 
  "Vempati2007_MMP9_Regulation", "MODEL1004070000" -> 
  "Haut1974_Pentose_Cycle_Rat", "MODEL9200487367" -> 
  "LeBeau1999_IP3R_Phosphorylation", "MODEL1004070001" -> 
  "Vaseghi1999_Pentose_PP_yeast", "MODEL0911272039" -> 
  "Guyton1972_AtrialNatriureticPeptide", "MODEL0911270004" -> 
  "GonzalezHeydrich1994_HPAaxisRegulation_CortisolProduction", 
 "MODEL6960055446" -> "Aguda1999_G2_Damage_Checkpoint", 
 "MODEL0911270007" -> "Karagiannis2004_CollagenIproteolysis", 
 "MODEL0911270008" -> "Wodarz2007_CD4TcellsInfection_VirusSpread", 
 "MODEL0911270005" -> "Guyton1972_Autonomics", 
 "MODEL0911270006" -> "Guyton1972_HeartRateStrokeVolume", 
 "MODEL0912180000" -> "Calzone2010_Cellfate_Master_Model", 
 "MODEL7743358405" -> "Radulescu2008_NFkB_hierarchy_M_8_12_19", 
 "MODEL1107190000" -> 
  "Szappanos2011_GeneticInteractionNetwork_YeastMetabolism", 
 "MODEL0406553884" -> "Pasek2006_VentricularCardioMyocytes", 
 "MODEL1111240000" -> "Huthmacher2010_MetabolicNetwork_P.falciparum", 
 "MODEL3631586579" -> "Jablonsky2008_kinetic_model_of_monomeric_PSII", 
 "MODEL1111240001" -> "Huthmacher2010_HumanErythrocyte_MetabolicNetwork", 
 "MODEL1403120000" -> "Grunwald2008 - Gene regulation of the Duchenne \
muscular dystrophy (Petri-net model)", "MODEL1311110001" -> 
  "Smallbone2013 - Human metabolism global reconstruction (recon 2.1x)", 
 "MODEL9147091146" -> "Ajay_Bhalla_2007_Bistable", 
 "MODEL1311110000" -> 
  "Smallbone2013 - Human metabolism global reconstruction (recon 2.1)", 
 "MODEL3618487388" -> "Poolman2009_Metab_Arabidopsis_reduced", 
 "MODEL1401290000" -> "Thomas2014 - The effect of aspirin resistance on \
platelet metabolism (constraint-based modelling)", 
 "MODEL7914759868" -> "Sachse2008_FibroblastInteractingMyocytes", 
 "MODEL1112260002" -> "Smith2010_Foxo_PTMs_AgeingRelatedSignallingPathway_C", 
 "MODEL0848342500" -> "Hinch2004_VentricularMyocytes", 
 "MODEL1112260001" -> "Smith2010_Foxo_PTMs_AgeingRelatedSignallingPathway_B", 
 "MODEL1112260000" -> "Smith2010_Foxo_PTMs_AgeingRelatedSignallingPathway_A", 
 "MODEL1407310000" -> "Triana2014 - Genome-scale metabolic network of \
Synechococcus elongatus (iSyf715)", "MODEL4028801312" -> 
  "Yates2007_TcellHomeostasisProliferation", 
 "MODEL1310110005" -> "Thiele2013 - Hippocampus glial cells", 
 "MODEL1411240002" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - adrenal", "MODEL1310110004" -> 
  "Thiele2013 - Uterus post menopause glandular cells", 
 "MODEL1411240003" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - bone marrow", "MODEL1310110003" -> 
  "Thiele2013 - Skin epidermal cells", "MODEL1411240004" -> "Uhl\[EAcute]n201\
5 - Human tissue-based proteome metabolic network - appendix", 
 "MODEL1310110002" -> "Thiele2013 - Spleen cells in white pulp", 
 "MODEL1411240005" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - smooth muscle", "MODEL1310110001" -> 
  "Thiele2013 - Adrenal gland glandular cells", 
 "MODEL1411240006" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - fallopian", "MODEL1310110000" -> 
  "Thiele2013 - Cerebellum cells in granular layer", 
 "MODEL1411240007" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
rectum", "MODEL1411240008" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
thyroid", "MODEL1411240009" -> "Uhl\[EAcute]n2015 - Human tissue-based \
proteome metabolic network - skeletal", "MODEL1310110008" -> 
  "Thiele2013 - Testis Leydig cells", "MODEL1310110009" -> 
  "Thiele2013 - Fallopian tube glandular cells", 
 "MODEL1310110006" -> "Thiele2013 - Uterus pre menopause glandular cells", 
 "MODEL1411240001" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - adipose", "MODEL1310110007" -> 
  "Thiele2013 - Lymph node non germinal center cells", 
 "MODEL1212060001" -> 
  "Dreyfuss2013 - Genome-Scale Metabolic Model - N.crassa iJDZ836", 
 "MODEL0910928451" -> "Guyton1972_RedCells_Viscosity", 
 "MODEL1202170000" -> "Nazaret2008_Dynnik1980_CarbohydrateEnergyMetabolism", 
 "MODEL1411240015" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - colon"\
, "MODEL1411240016" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - lymph node", "MODEL1411240013" -> "Uhl\[EAcute]n2015 - \
Human tissue-based proteome metabolic network - salivary gland", 
 "MODEL1411240014" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
spleen", "MODEL1411240019" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
kidney", "MODEL1411240017" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
stomach", "MODEL1411240018" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
testis", "MODEL1411240012" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - liver"\
, "MODEL1411240011" -> 
  "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - lung", 
 "MODEL1411240010" -> "Uhl\[EAcute]n2015 - Human tissue-based proteome \
metabolic network - endometrium", "MODEL8268650277" -> 
  "Nelson2000_HIV-1_general_model", "MODEL4665428627" -> 
  "Schuetz2007_ecoli_FBA", "MODEL7519354389" -> 
  "Zou2007_MAPK_SignalingNetworks", "MODEL9147232940" -> 
  "Ajay_Bhalla_2007_PKM", "MODEL1212040000" -> 
  "Karlstaedt2012 - CardioNet, A Human Metabolic Network", 
 "MODEL1202090003" -> "Caydasi2012_SPOC_UbiquitousInactive", 
 "MODEL1303260009" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 09", 
 "MODEL1303260008" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 08", 
 "MODEL1303260007" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 07", 
 "MODEL1303260006" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 06", 
 "MODEL1403040000" -> 
  "Sackmann2006 - mating pheromone response pathway of S.cerevisiae", 
 "MODEL1172940336" -> "DePaor1986_CirculatoryAutoregulation", 
 "MODEL7743608569" -> "Radulescu2008_NFkB_hierarchy_M_24_45_62", 
 "MODEL1202270001" -> "Lee2012_GeneExpression_tTA-doxInteraction", 
 "MODEL1303260001" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 01", 
 "MODEL1303260000" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 00", 
 "MODEL1202270000" -> "Lee2012_GeneExpression_BasicDecoyModel", 
 "MODEL1002160000" -> "Gomez-Cabrero2011_Atherogenesis", 
 "MODEL1303260005" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 05", 
 "MODEL1303260004" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 04", 
 "MODEL1202090001" -> "Caydasi2012_SPOC_HotSpotAssociation", 
 "MODEL1303260003" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 03", 
 "MODEL1202090002" -> "Caydasi2012_SPOC_UbiquitousAssociation", 
 "MODEL1204040000" -> "Houser2012_pheromone_Ste12", 
 "MODEL1303260002" -> 
  "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 02", 
 "MODEL1203070000" -> "Radosavljevic2009_BioterroristAttack_PanicProtection", 
 "MODEL6655501972" -> "Nijhout2004_FolateCycle", 
 "MODEL9087988095" -> "Abu-Soud1999_HomoArginine", 
 "MODEL0912768548" -> "DiFrancesco1985_CardiacElectricalActivity", 
 "MODEL7909395757" -> "Razumova2000_MyofilamentContractileBehaviour", 
 "MODEL1172501439" -> "Cui2008_ZincHomeostasisSystem", 
 "MODEL9087766308" -> "Abu-Soud1999_L-Arginine", 
 "MODEL8102792069" -> "Nelson2000_HIV-1_intracellular_delay", 
 "MODEL1111190000" -> "Loira2012 - Metabolic Network of Y.lipolytica", 
 "MODEL1206070000" -> 
  "Bazzani2012 - Genome scale networks of P.falciparum and human hepatocyte", 
 "MODEL1302200000" -> 
  "B\[UDoubleDot]chel2013 - Dopaminergic Nerve Cell Model", 
 "MODEL1204240000" -> "Sorokina2011_StarchMetabolism_Ostreococcus", 
 "MODEL1403250001" -> "vanEunen2012 - Yeast Glycolysis (glucose upshift)", 
 "MODEL1204060000" -> "Kubota2012_InsulinAction_AKTpathway", 
 "MODEL1403250000" -> "Rao2014 - Fatty acid beta-oxidation (reduced model)", 
 "MODEL1403250002" -> "Rao2014 - Yeast glycolysis (reduced model)", 
 "MODEL1108160000" -> "Orth2011_E.coli_MetabolicNetwork", 
 "MODEL1012110001" -> "Li2010_YeastGlycolysis", 
 "MODEL1007200000" -> "Nijhout2006_Hepatic_Folate_Metab", 
 "MODEL4780441670" -> "Condorelli2001_GuanylateCyclase", 
 "MODEL1009230000" -> "Munz2009 - Zombie basic SZR", 
 "MODEL1009150002" -> "Jerby2010_Liver_Metabolism", 
 "MODEL1009150000" -> "Gille2010_HepatoNet1_Metabolic_Network", 
 "MODEL6185746832" -> "Qiao2007_MAPK_Signaling_Oscillatory", 
 "MODEL1101170000" -> "Nakano2010_Synaptic_Plasticity", 
 "MODEL1105030000" -> "Zhuang2011 - Ecoli FBA with membrane economics", 
 "MODEL9087474843" -> "Hayer2005_AMPAR_CaMKII_weak_coupling", 
 "MODEL1305240000" -> "MacNamara2012 - Signal transduction", 
 "MODEL1106080000" -> "Bordbar2011_HumanErythrocyte_MetabolicNetwork", 
 "MODEL0912835813" -> "Dempsher1984_ACTH_CortisolSecretion", 
 "MODEL1109130000" -> 
  "Thiele2013 - Human metabolism global reconstruction (Recon 2)", 
 "MODEL1411210000" -> "Aubert2005 - Interaction between astrocytes and \
neurons on energy metabolism", "MODEL1402200000" -> "Mardinoglu2013 - \
Genome-scale metabolic model (HMR version 1.0) - generic human cell", 
 "MODEL1402200001" -> "Mardinoglu2013 - Genome-scale metabolic model (HMR \
version 1.0) - human adipocytes (iAdipocytes1809)", 
 "MODEL1402200002" -> "Mardinoglu2014 - Genome-scale metabolic model (HMR \
version 2.0) - generic human cell", "MODEL1402200003" -> "Mardinoglu2014 - \
Genome-scale metabolic model (HMR verson 2.0) - human hepatocytes \
(iHepatocytes2322)", "MODEL1011080004" -> "Chang2010_Reduced_Kidney_FBA", 
 "MODEL1011080003" -> "Islam2010_Dehalococcoides_Metabolism", 
 "MODEL1011080002" -> "Cottret2010_B_cicadellinicola_Met_Net", 
 "MODEL1011080001" -> "Gonzalez2010_N_pharaonis_metabolism", 
 "MODEL1011080000" -> "Cottret2010_S_muelleri_Met_Net", 
 "MODEL9811206584" -> "MacGregor2005_HypothalamicSystems", 
 "MODEL1109150002" -> "Leipold1995_ThrombinFormation+inhibitors", 
 "MODEL1109150000" -> "Kuharsky2001_BloodCoagulation", 
 "MODEL1109150001" -> "Leipold1995_ThrombinFormation-inhibitors", 
 "MODEL0403954746" -> "Nutsch2005_phototaxis_noncyc_repellent_dark", 
 "MODEL1507180006" -> "Resendis-Antonio2007 - Genome-scale metabolic network \
of Rhizobium etli (iOR363)", "MODEL1507180005" -> 
  "Alam2010 - Genome-scale metabolic network of Streptomyces coelicolor", 
 "MODEL1507180008" -> "Montagud2010 - Genome-scale metabolic network of \
Synechocystis sp. PCC6803 (iSyn669)", "MODEL1507180007" -> 
  "Thiele2005 - Genome-scale metabolic network of Helicobacter pylori \
(iIT341)", "MODEL0393108880" -> "tenTusscher2004_CardiacArrhythmias", 
 "MODEL1507180009" -> "AbuOun2009 - Genome-scale metabolic network of \
Salmonella typhimurium (iMA945)", "MODEL1507180010" -> 
  "Archer2011 - Genome-scale metabolic model of Escherichia coli (iCA1273)", 
 "MODEL1109160001" -> "Kogan2001_aPTT_coagulation", 
 "MODEL1507180011" -> "Saha2011 - Genome-scale metabolic network of \
Arabidopsis thaliana (iRS1597)", "MODEL1507180012" -> "F\[ODoubleDot]rster200\
8 - Genome-scale metabolic network of Saccharamyces cerevisiae (iFF708)", 
 "MODEL1507180013" -> 
  "Oh2007 - Genome-scale metabolic network of Bacillus subtilis (iYO844)", 
 "MODEL1507180014" -> "Oliveira2005 - Genome-scale metabolic network of \
Lactococcus lactis (iAO358)", "MODEL1507180015" -> 
  "Henry2009 - Genome-scale metabolic network of Bacillus subtilis \
(iBsu1103)", "MODEL1109160000" -> "Kogan2001_aPTT_preincubation", 
 "MODEL1409170000" -> "Mazein2013 - Cholesterol biosynthesis pathway", 
 "MODEL1409170003" -> "Mazein2013 - Shunt pathway", 
 "MODEL1112050000" -> "Kiselyov2009_InsulinReceptorModel", 
 "MODEL1201230000" -> "Jol2012_YeastMetabolism_EFManalysis", 
 "MODEL1507180000" -> "Mahadevan2006 - Genome-scale metabolic network of \
Geobacter sulfurreducens (iRM588)", "MODEL0403928902" -> 
  "Nutsch2005_phototaxis_noncyc_repellent_light", 
 "MODEL1507180003" -> "Raghunathan2010 - Genome-scale metabolic network of \
Francisella tularensis (iRS605)", "MODEL1507180004" -> "Roberts2010 - \
Genome-scale metabolic network of Clostridium thermocellum (iSR432)", 
 "MODEL1507180001" -> "Jamshidi2007 - Genome-scale metabolic network of \
Mycobacterium tuberculosis (iNJ661)", "MODEL1507180002" -> "Sun2009 - \
Genome-scale metabolic network of Geobacter metallireducens (iJS747)", 
 "MODEL1112050001" -> "Liu2009_GlucoseMobilization_UptakeModel", 
 "MODEL9070467164" -> "Bhalla2002_mkp1_feedback_effects", 
 "MODEL1009220000" -> "Martins2004_Yeast_Glycolysis_GlycerolSynthesis", 
 "MODEL1408060000" -> 
  "Coggins2014 - CXCL12 dependent recruitment of beta arrestin", 
 "MODEL3618435756" -> "Poolman2009_GS_Metabolism_Arabidopsis", 
 "MODEL0479527919" -> "Luo1991_VentricularCardiacAction", 
 "MODEL1311070000" -> "Ponce-de-L\[EAcute]on2013 - Genome scale metabolic \
model for Blattabacterium cuenoti (iMP240)", 
 "MODEL1008120002" -> "Bekaert2010_mouse_inferred_metabolic_network", 
 "MODEL1008120001" -> "Bekaert2010_macaque_inferred_metabolic_network", 
 "MODEL1008120000" -> "Bekaert2010_chimpanzee_inferred_metabolic_network", 
 "MODEL0479926177" -> "Lenbury1991_CortisolSecretionSystem", 
 "MODEL1008120006" -> "Bekaert2010_dog_inferred_metabolic_network", 
 "MODEL1008120005" -> "Bekaert2010_horse_inferred_metabolic_network", 
 "MODEL1008120004" -> "Bekaert2010_cattle_inferred_metabolic_network", 
 "MODEL4968912141" -> "Phillips2003_RasGTPase", 
 "MODEL1008120003" -> "Bekaert2010_rat_inferred_metabolic_network", 
 "MODEL2463683119" -> "Oda2006_TollLikeR", "MODEL0406270966" -> 
  "Livshitz2007_CardiacMyocytes", "MODEL1303060000" -> 
  "Ray2013 - Meiotic initiation in S. cerevisiae", 
 "MODEL1507180049" -> "Borodina2005 - Genome-scale metabolic network of \
Streptomyces coelicolor (iIB711)", "MODEL5954483266" -> 
  "Koster1988_Histone_Expression", "MODEL0847712949" -> 
  "Kurata2002_SinoatrialNode", "MODEL8687196544" -> 
  "Niederer2006_CardiacMyocyteRelaxation", "MODEL1106220000" -> 
  "Imam2011_RhodobacterSphaeroides_MetabolicNetwork", 
 "MODEL0911376350" -> "Guyton1972_Aldosterone", 
 "MODEL1304240000" -> 
  "Imam2013 - Metabolic network in Rhodobacter sphaeroides (iRsp1140)", 
 "MODEL1507180051" -> "Fang2011 - Genome-scale metabolic network of \
Burkholderia cenocepacia (iKF1028)", "MODEL1507180050" -> 
  "Sohn2010 - Genome-scale metabolic network of Pichia pastoris \
(PpaMBEL1254)", "MODEL1507180053" -> "Schilling2000- Genome-scale metabolic \
network of Haemophilus influenzae (iCS400)", "MODEL1507180052" -> "Suthers200\
9 - Genome-scale metabolic network of Mycoplasma genitalium (iPS189)", 
 "MODEL1507180055" -> 
  "Sigurdsson2010 - Genome-scale metabolic model of Mus Musculus (iMM1415)", 
 "MODEL8236520494" -> "Yang2008_AAnetwork_PLT", 
 "MODEL1507180054" -> "Liao2011 - Genome-scale metabolic reconstruction of \
Klebsiella pneumoniae (iYL1228)", "MODEL1507180057" -> 
  "Widiastuti2010 - Genome-scale metabolic network Zymomonas mobilis \
(iZM363)", "MODEL1001150000" -> "Pepke2010_Full_Ca2/CaM_mCaMKII", 
 "MODEL1507180056" -> "Vongsangnak2008 - Genome-scale metabolic network of \
Aspergillus oryzae (iWV1314)", "MODEL1507180059" -> 
  "Chavali2008 - Genome-scale metabolic network of Leishmania major (iAC560)"\
, "MODEL9086926384" -> "Hayer2005_CaMKII_noPKA_model3", 
 "MODEL1507180058" -> "Raghunathan2009 - Genome-scale metabolic network of \
Salmonella typhimurium (iRR1083)", "MODEL1507180038" -> "Mazumdar2008 - \
Genome-scale metabolic network of Porphyromonas gingivalis (iVM679)", 
 "MODEL1507180039" -> "Zou2012 - Genome-scale metabolic network of \
Ketogulonicigenium vulgare (iWZ663)", "MODEL1504130000" -> 
  "Haraldsd\[OAcute]ttir2014 - Recon 2.03", 
 "MODEL1308180000" -> 
  "Rex2013 - Genome scale metabolic model of D.shibae (iDsh827)", 
 "MODEL2937159804" -> "Shimoni2009 - Escherichia Coli SOS", 
 "MODEL1507180040" -> "Benedict2011 - Genome-scale metoblic network of \
Methanosarcina acetivorans (iMB745)", "MODEL1507180044" -> "Puchalka2008 - \
Genome-scale metabolic network of Pseudomonas putida (iJP815)", 
 "MODEL0847869198" -> "Jafri1998_VentricularMyocyte", 
 "MODEL5950552398" -> "Mulquiney1999_BPG_metabolism", 
 "MODEL1507180043" -> "Sohn2010 - Genome-scale metabolic network of \
Pseudomonas putida (PpuMBEL1071)", "MODEL1507180042" -> 
  "Selvarasu2009 - Genome-scale metabolic network of Mus Musculus (iSS724)", 
 "MODEL1507180048" -> 
  "Zhang2009 - Genome-scale metabolic network of Thermotoga maritima", 
 "MODEL1507180047" -> "Andersen2009 - Genome-scale metabolic network of \
Aspergillus niger (iMA871)", "MODEL1507180046" -> "Nogales2012 - Genome-scale \
metabolic network of Synechocystis sp. PCC6803 (iJN678)", 
 "MODEL1507180045" -> "Teusink2006 - Genome-scale metabolic network of \
Lactobacillus plantarum (iBT721)", "MODEL1507180027" -> "Senger2008 - \
Genome-scale metabolic network of Clostridium acetobutylicum (iCac802)", 
 "MODEL1507180028" -> "deOliveiraDalMolin2010 - Genome-scale metabolic \
network of Arabidopsis thaliana (AraGEM)", "MODEL1507180029" -> "Kim2009 - \
Genome-scale metabolic network of Acinetobacter baumannii (AbyMBEL891)", 
 "MODEL1410060000" -> 
  "Poliquin2013 - Energy Deregulations in Parkinson's Disease", 
 "MODEL1501210000" -> "Invergo2014 - Mammalian Rod Phototransduction", 
 "MODEL1507180035" -> "Kumar2011 - Genome-scale metabolic network of \
Methanosarcina acetivorans (iVS941)", "MODEL1507180034" -> "Milne2011 - \
Genome-scale metabolic network of Clostridium beijerinckii (iCB925)", 
 "MODEL1507180037" -> "Schilling2002 - Genome-scale metabolic network of \
Helicobacter pylori (iCS291)", "MODEL1507180036" -> "Pinchuck2010 - \
Genome-scale metabolic network of Shewanella oneidensis (iSO783)", 
 "MODEL1507180031" -> "Lee2010 - Genome-scale metabolic network of Zymomonas \
mobilis (iZmobMBEL601)", "MODEL1507180030" -> "Lee2008 - Genome-scale \
metabolic network of Clostridium acetobutylicum (iJL432)", 
 "MODEL1507180033" -> "Mo2009 - Genome-scale metabolic network of \
Saccharomyces cerevisiae (iMM904)", "MODEL2021747594" -> 
  "Ma2007_HumanMetabol_wEnergy", "MODEL1006230108" -> 
  "Sarai2003_CardiacSAnodePacemaker", "MODEL3897771820" -> 
  "Csikasz-Nagy2006_Cell_Cycle", "MODEL1507180018" -> "Fang2010 - \
Genome-scale metabolic network of Mycobacterium tuberculosis (iNJ661m)", 
 "MODEL1507180019" -> "Duarte2004 - Genome-scale metabolic network of \
Saccharomyces cerevisiae (iND750)", "MODEL1310300000" -> 
  "Flahaut2013 - Genome-scale metabolic model of L.lactis (MG1363)", 
 "MODEL1507180016" -> "David2008 - Genome-scale metabolic network of \
Aspergillus nidulans (iHD666)", "MODEL9810152478" -> 
  "Maleckar2008_AtrialMyocyte", "MODEL1507180017" -> "Thiele2011 - \
Genome-scale metabolic network of Salmonella Typhimurium (STM_v1_0)", 
 "MODEL1006230101" -> "Benson2008_Arrhythmogenesis_Epicardial", 
 "MODEL1006230100" -> "Vinnakota2010_TranscientAnoia_EDLmuscle", 
 "MODEL1006230103" -> "Heldt2002_OrthostaticStress_heart", 
 "MODEL1006230102" -> "Waugh2006_WoundHealing_Diabetic_ModelD", 
 "MODEL7908934508" -> "Reidl2006_CalciumOscillationInCilia", 
 "MODEL1202030001" -> "Dupeux2011_ABAreceptor_Monomer", 
 "MODEL1006230105" -> "Koivumaki2009_SERCAATPase_long", 
 "MODEL1006230104" -> "Maltsev2009_PacemakerCellModel_SteadyState", 
 "MODEL1006230107" -> "Sneyd1995_CalciumWave_IP3diffusion", 
 "MODEL1006230106" -> "Waugh2006_WoundHealing_Diabetic_ModelA", 
 "MODEL7893871775" -> "Terkildsen2008_CardiomyocyteFunction", 
 "MODEL1202030000" -> "Dupeux2011_ABAreceptor_Dimer", 
 "MODEL1507180026" -> "Liu2012 - Genome-scale metabolic network of \
Scheffersomyces stipitis (iTL885)", "MODEL0318212660" -> 
  "Bhattacharya2011_UreaCycle", "MODEL1303010000" -> 
  "Lopez2013 - extrinsic apoptosis M1a embedded", 
 "MODEL1507180025" -> "Hong2004 - Genome-scale metabolic network of \
Mannheimia succiniciproducens (iSH335)", "MODEL1507180024" -> "Risso2009 - \
Genome-scale metabolic network of Rhodoferax ferrireducens (iCR744)", 
 "MODEL1507180023" -> 
  "Chung2010 - Genome-scale metabolic network of Pichia pastoris (iPP668)", 
 "MODEL1507180022" -> 
  "Caspeta2012 - Genome-scale metabolic network of Pichia stipitis (iSS884)", 
 "MODEL1507180021" -> "Beste2007 - Genome-scale metabolic network of \
Mycobacterium tuberculosis (GSMN_TB)", "MODEL1507180020" -> "Oberhardt2008 - \
Genome-scale metabolic network of Pseudomonas aeruginosa (iMO1056)"}
