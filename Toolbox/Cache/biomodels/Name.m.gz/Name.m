(* Created with the Wolfram Language for Students - Personal Use Only : www.wolfram.com *)
{"Leloup1999_CircadianRhythms_Neurospora", 
 "Leloup1999_CircadianRhythms_Drosophila", "Zatorsky2006_p53_Model1", 
 "Zatorsky2006_p53_Model5", "Zatorsky2006_p53_Model6", 
 "Zatorsky2006_p53_Model2", "Zatorsky2006_p53_Model4", 
 "Hernjak2005_Calcium_Signaling", "Zi2007_TGFbeta_signaling", 
 "SmithAE2002_RanTransport", "Saucerman2006_PKA", "Xie2007_CircClock", 
 "Eungdamrong2007_Ras_Activation", "Alexander2010_Tcell_Regulation_Sys1", 
 "Wang2009 - PI3K Ras Crosstalk", "Passos2010_DNAdamage_CellularSenescence", 
 "Kim2007 - Crosstalk between Wnt and ERK pathways", 
 "Komarova2003_BoneRemodeling", "ODea2007_IkappaB", "Hatakeyama2003_MAPK", 
 "Wang2007 - ATP induced intracellular Calcium Oscillation", 
 "Calzone2007_CellCycle", "Fernandez2006_ModelB", "Zatorsky2006_p53_Model3", 
 "Singh2006_IL6_Signal_Transduction", "Fernandez2006_ModelA", 
 "Morris2002_CellCycle_CDK2Cyclin", "Rovers1995_Photsynthetic_Oscillations", 
 "Proctor2010 - UCHL1 Protein Aggregation", 
 "Alexander2010_Tcell_Regulation_Sys2", 
 "Nikolaev2005_AlbuminBilirubinAdsorption", 
 "Balagadd\[EAcute]2008_E_coli_Predator_Prey", 
 "Ciliberto2003_Morphogenesis_Checkpoint", "Restif2007_Vaccination_Invasion", 
 "Akman2008_Circadian_Clock_Model1", 
 "Shrestha2010_HyperCalcemia_PTHresponse", 
 "Shrestha2010_HypoCalcemia_PTHresponse", 
 "Komarova2005_PTHaction_OsteoclastOsteoblastCoupling", 
 "Lemaire2004 - Role of RANK/RANKL/OPG pathway in bone remodelling process", 
 "Lebeda2008_BoTN_Paralysis_4stepModel", "Conant2007_glycolysis_2C", 
 "Kim2007_CellularMemory_AsymmetricModel", 
 "Kim2007_CellularMemory_SymmetricModel", "Sriram2007_CellCycle", "Neves2008 \
- Role of cell shape and size in controlling intracellular signalling", 
 "Stefan2008 - calmodulin allostery", "Lavrentovich2008_Ca_Oscillations", 
 "Locke2008_Circadian_Clock", 
 "Ibrahim2008 - Mitotic Spindle Assembly Checkpoint - Dissociation variant", 
 "Ibrahim2008 - Mitotic Spindle Assembly Checkpoint - Convey variant", 
 "Chance1943_Peroxidase_ES_Kinetics", "Hofmeyer1986_SeqFb_Proc_AA_Synthesis", 
 "Tang2010_PolyGlutamate", 
 "Proctor2010 - a link between GSK3 and p53 in Alzheimer's Disease", 
 "Morris1981_MuscleFibre_Voltage_reduced", 
 "Chance1960_Glycolysis_Respiration", "Chance1952_Catalase_Mechanism", 
 "Liu2010_Hormonal_Crosstalk_Arabidopsis", "Reed2008_Glutathione_Metabolism", 
 "Lebeda2008_BoNT_Paralysis_3stepModel", "Voit2003_Trehalose_Cycle", 
 "Conradie2010_RPControl_CellCycle", "Aguda1999_CellCycle", 
 "Obeyesekere1999_CellCycle", "Mayya2005_STATmodule", 
 "Zhu2007_TF_modulated_by_Calcium", "Leloup1998_CircClock_LD", 
 "Pritchard2002_glycolysis", "Weimann2004_CircadianOscillator", 
 "Birtwistle2007_ErbB_Signalling", "Conant2007_WGD_glycolysis_2A3AB", 
 "Schmierer_2008_Smad_Tgfb", "Del_Conte_Zerial2008_Rab5_Rab7_cut_out_switch", 
 "Rattanakul2003_BoneFormationModel", "Goldbeter2007_Somitogenesis_Switch", 
 "Becker2010_EpoR_AuxiliaryModel", "Pokhilko2010_CircClock", 
 "Schilling2009 - ERK distributive", "Becker2010_EpoR_CoreModel", 
 "Poolman2004_CalvinCycle", "Elowitz2000 - Repressilator", 
 "Curto1998 - purine metabolism", "Levchenko2000_MAPK_Scaffold", 
 "Hoefnagel2002_PyruvateBranches", "Santolini2001_nNOS_Mechanism_Regulation", 
 "Goldbeter1995_CircClock", "Golomb2006_SomaticBursting_nonzero[Ca]", 
 "Schoeberl2002 - EGF MAPK", "Morrison1989_FolateCycle", 
 "McClean2007_CrossTalk", "Somogyi1990_CaOscillations_SingleCaSpike", 
 "Golomb2006_SomaticBursting", "Dupont1991_CaOscillation", 
 "Clarke2006_Smad_signalling", "Novak2001_FissionYeast_CellCycle", 
 "Somogyi1990_CaOscillations", "Dupont1992_Ca_dpt_protein_phospho", 
 "Chan2004_TCell_receptor_activation", "Clancy2001_Kchannel", 
 "Sivakumar2011_NeuralStemCellDifferentiation_Crosstalk", 
 "Hodgkin-Huxley1952 squid-axon", "Sivakumar2011_WntSignalingPathway", 
 "Leloup1999_CircClock", "Jenkinson2011_EGF_MAPK", "Ueda2001_CircClock", 
 "Goldbeter1991 - Min Mit Oscil, Expl Inact", 
 "Sivakumar2011 - Hedgehog Signaling Pathway", 
 "Goldbeter1991 - Min Mit Oscil", "Sivakumar2011 - Notch Signaling Pathway", 
 "Arnold2011_Zhu2007_CalvinCycle_Starch_Sucrose_Photorespiration", 
 "Edelstein1996 - EPSP ACh species", "Edelstein1996 - EPSP ACh event", 
 "Sivakumar2011 - EGF Receptor Signaling Pathway", 
 "Arnold2011_Poolman2000_CalvinCycle_Starch", 
 "Gardner1998 - Cell Cycle Goldbeter", 
 "Arnold2011_Laisk2006_CalvinCycle_Starch_Sucrose", "Novak1997 - Cell Cycle", 
 "Tyson1991 - Cell Cycle 2 var", 
 "Proctor2008 - p53/Mdm2 circuit - p53 stabilisation by ATM", 
 "Haberichter2007_cellcycle", "Arnold2011_Giersch1990_CalvinCycle", 
 "Proctor2008 - p53/Mdm2 circuit - p53 stablisation by p14ARF", 
 "Tyson1991 - Cell Cycle 6 var", "Kowald2006_SOD", 
 "Novak1993_M_phase_control", "Yang2007_ArachidonicAcid", "Proctor2007 - Age \
related decline of proteolysis, ubiquitin-proteome system", 
 "Huang1996 - Ultrasensitivity in MAPK cascade", 
 "Klipp2002_MetabolicOptimization_linearPathway(n=2)", 
 "Legewie2006_apoptosis_NC", "Legewie2006_apoptosis_WT", "Vilar2006_TGFbeta", 
 "Rozi2003_GlycogenPhosphorylase_Activation", 
 "Rodriguez-Caso2006_Polyamine_Metabolism", "Qu2003_CellCycle", 
 "Stone1996_NOsGC", "Bartholome2007_MDCKII", "Srividhya2006_CellCycle", 
 "Tyson2001_Cell_Cycle_Regulation", 
 "Arnold2011_Hahn1986_CalvinCycle_Starch_Sucrose", "Kholodenko2000 - \
Ultrasensitivity and negative feedback bring oscillations in MAPK cascade", 
 "Ibrahim2008_Cdc20_Sequestring_Template_Model", 
 "Arnold2011_Zhu2009_CalvinCycle", "Levchenko2000_MAPK_noScaffold", 
 "Ibrahim2008_MCC_assembly_model_KDM", 
 "Arnold2011_Damour2007_RuBisCO-CalvinCycle", 
 "G\[ODoubleDot]rlich2003_RanGTP_gradient", 
 "Arnold2011_Sharkey2007_RuBisCO-CalvinCycle", 
 "Monta\[NTilde]ez2008_Arginine_catabolism", 
 "Izhikevich2004_SpikingNeurons_SpikeLatency", 
 "Izhikevich2004_SpikingNeurons_resonator", 
 "Izhikevich2004_SpikingNeurons_thresholdVariability", 
 "Izhikevich2004_SpikingNeurons_subthresholdOscillations", 
 "Tabak2007_dopamine", "Sedaghat2002_InsulinSignalling_noFeedback", 
 "Hoffmann2002_KnockOut_IkBNFkB_Signaling", 
 "Hoffmann2002_WT_IkBNFkB_Signaling", 
 "Izhikevich2004_SpikingNeurons_Class1Excitable", 
 "Izhikevich2004_SpikingNeurons_Class2Excitable", 
 "Olsen2003_neutrophil_oscillatory_metabolism", 
 "Komarova2005_TheoreticalFramework_BasicArchitecture", "Wu2006_K+Channel", 
 "Fisher2006_NFAT_Activation", 
 "Fisher2006_Ca_Oscillation_dpdnt_NFAT_dynamics", 
 "Izhikevich2004_SpikingNeurons_inhibitionInducedSpiking", 
 "Bertram2006_Endothelin", "Izhikevich2003_SpikingNeuron", 
 "Clancy2002_CardiacSodiumChannel_WT", 
 "Izhikevich2004_SpikingNeurons_reboundBurst", 
 "Izhikevich2004_SpikingNeurons_reboundSpike", 
 "Izhikevich2004_SpikingNeurons_integrator", 
 "Heldt2012 - Influenza Virus Replication", "Koo2013 - Shear stress induced \
calcium influx and eNOS activation - Model 1", 
 "Koo2013 - Shear stress induced AKT and eNOS phosphorylation - Model 2", 
 "Koo2013 - Shear stress induced eNOS expression - Model 3", 
 "Koo2013 - Shear stress induced NO production - Model 4", 
 "Koo2013 - Integrated shear stress induced NO production model", 
 "Smallbone2013 - E.coli metabolic model with linlog rate law", 
 "Larsen2004_CalciumSpiking", "Markevich2004_MAPK_orderedMM2kinases", 
 "Markevich2004_MAPK_AllRandomElementary", 
 "Brown2004 - NGF and EGF signaling", "Kofahl2004_PheromonePathway", 
 "Rohwer2001_Sucrose", "Palini2011_Minimal_2_Feedback_Model", 
 "Scheper1999_CircClock", "Morris1981_MuscleFibre_Voltage_full", 
 "Smolen2002_CircClock", "Whitcomb2004_Bicarbonate_Pancreas", 
 "Markevich2004_MAPK_orderedElementary", "DellOrco2009_phototransduction", 
 "Markevich2004 - MAPK double phosphorylation, ordered Michaelis-Menton", 
 "Grange2001 - L Dopa PK model", 
 "Markevich2004_MAPK_phosphoRandomElementary", 
 "Grange2001 - PK interaction of L-dopa and benserazide", 
 "Markevich2004_MAPK_phosphoRandomMM", "Kim2011_Oscillator_SimpleIII", 
 "Kim2011_Oscillator_SimpleI", 
 "Smallbone2013 - Yeast metabolic model with linlog rate law", 
 "Kummer2000 - Oscillations in Calcium Signalling", 
 "Smallbone2013 - E.coli metabolic model with modular rate law", 
 "Bucher2011_Atorvastatin_Metabolism", "Smallbone2013 - Yeast metabolic model \
with modular rate law, merged with Pritchard 2002", 
 "Smallbone2013 - Yeast metabolic model with modular rate law", "Adams2012 - \
Locke2006 Circadian Rhythm model refined with Input Signal Light Function", 
 "Mol2013 - Immune Signal Transduction in Leishmaniasis", 
 "Smith2013 - Regulation of Insulin Signalling by Oxidative Stress", 
 "Amara2013 - PCNA ubiquitylation in the activation of PRR pathway", "Besozzi\
2012 - Oscillatory regimes in the Ras/cAMP/PKA pathway in S.cerevisiae", 
 "Croft2013 - GPCR-RGS interaction that compartmentalizes RGS activity", 
 "Field1974_Oregonator", "Wajima2009_BloodCoagulation_warfarin_heparin", 
 "Topp2000_BetaCellMass_Diabetes", 
 "Borghans1997 - Calcium Oscillation - Model 2", 
 "Borghans1997 - Calcium Oscillation - Model 1", "Nielsen1998_Glycolysis", 
 "Kongas2007 - Creatine Kinase in energy metabolic signaling in muscle", 
 "Tyson1999_CircClock", "Wajima2009_BloodCoagulation_aPTTtest", 
 "Marwan2003 - Genetics, regulatory hierarchy between genes", 
 "Pfeiffer2001_ATP-ProducingPathways_CooperationCompetition", 
 "Jones1994_BloodCoagulation", "Smolen2004_CircClock", 
 "Hockin2002_BloodCoagulation", "Vilar2002_Oscillator", 
 "Bungay2003_Thrombin_Generation", "Bungay2006_FollicularFluid", 
 "Bungay2006_Plasma", "Rohwer2000_Phosphotransferase_System", 
 "Larsen2004_CalciumSpiking_EnzymeBinding", "Marhl2000_CaOscillations", 
 "Carbo2013 - Mucosal Immune Response during H.pylori Infection", 
 "Cao2013 - Application of ABSIS method in birth-death process", 
 "Cao2008 - Network of a toggle switch", 
 "Noguchi2013 - Insulin dependent glucose metabolism", "St\[ODoubleDot]tzel20\
12 - Bovine estrous cycle, synchronization with prostaglandin F2\[Alpha]", 
 "Wajima2009_BloodCoagulation_PTtest", 
 "Sharp2013 - Lipopolysaccharide induced NFkB activation", "Cao2013 - \
Application of ABSIS method in the bistable Schl\[ODoubleDot]gl model", 
 "Cao2013 - Application of ABSIS method in the reversible isomerization \
model", "Cao2013 - Application of ABSIS in the the enzymatic futile cycle", 
 "Proctor2013 - Effect of A\[Beta] immunisation in Alzheimer's disease", 
 "Ferreira2003_CML_generation2", 
 "Brands2002 - Monosaccharide-casein systems", "Locke2005 - Circadian Clock", 
 "Ataullahkhanov1996_Adenylate", "Chassagnole2002_Carbon_Metabolism", 
 "Martins2003_AmadoriDegradation", "Sasagawa2005_MAPK", 
 "Friedland2009_Ara_RTC3_counter", "Schmierer2010_FIH_Ankyrins", 
 "Borghans1997 - Calcium Oscillation - Model 3", "Deineko2003_CellCycle", 
 "Liu2011_Complement_System", "Olsen2003_peroxidase", "Romond1999_CellCycle", 
 "Wang1996_Synaptic_Inhibition_Two_Neuron", 
 "Kolomeisky2003_MyosinV_Processivity", "Oxhamre2005_Ca_oscillation", 
 "Plant1981_BurstingNerveCells", "Kholodenko1999 - EGFR signaling", 
 "Chickarmane2008 - Stem cell lineage determination", 
 "Schittler2010 - Cell fate of progenitor cells, osteoblasts or chondrocytes"\
, "Tyson2003_Substrate_Depletion_Osc", 
 "Chickarmane2006 - Stem cell switch irreversible", 
 "Pathak2013 - MAPK activation in response to various biotic stresses", 
 "Tyson2003_Activator_Inhibitor", 
 "Chickarmane2006 - Stem cell switch reversible", 
 "Sen2013 - Phospholipid Synthesis in P.knowlesi", 
 "Tyson2003_NegFB_Homeostasis", "Wolf2000_Glycolytic_Oscillations", 
 "Roblitz2013 - Menstrual Cycle following GnRH analogue administration", 
 "Tyson2003_NegFB_Oscillator", "Ung2008_EGFR_Endocytosis", 
 "Bray1995_chemotaxis_receptorlinkedcomplex", 
 "Pathak2013 - MAPK activation in response to various abiotic stresses", 
 "ChenXF2008_CICR", "Demin2013 - PKPD behaviour - 5-Lipoxygenase inhibitors", 
 "Goldbeter2008_Somite_Segmentation_Clock_Notch_Wnt_FGF", 
 "Albeck2008_extrinsic_apoptosis", "Mitchell2013 - Liver Iron Metabolism", 
 "Vizan2013 - TGF pathway long term signaling", 
 "Stanford2013 - Kinetic model of yeast metabolic network (standard)", 
 "Stanford2013 - Kinetic model of yeast metabolic network (regulation)", 
 "Chassagnole2001_Threonine Synthesis", "Yildirim2003_Lac_Operon", 
 "Teusink2000_Glycolysis", "Galazzo1990_FermentationPathwayKinetics", 
 "Bhartiya2003_Tryptophan_operon", "Hynne2001_Glycolysis", 
 "Keizer1996_Ryanodine_receptor_adaptation", "Tyson2003_Perfect_Adaption", 
 "Tyson2003_Mutual_Activation", "Tyson2003_Mutual_Inhibition", 
 "Bindschadler2001_coupled_Ca_oscillators", 
 "Shen-Orr2002_FeedForward_AND_gate", "Fridlyand2003_Calcium_flux", 
 "Montagne2011_Oligator_optimised", "Singh2006_TCA_mtu_model1", 
 "Chen2004 - Cell Cycle Regulation", "Raia2011_IL13_L1236", 
 "Sneyd2002_IP3_Receptor", "Singh2006_TCA_mtu_model2", 
 "Raia2010_IL13_Signalling_MedB1", "Bruggeman2005_AmmoniumAssimilation", 
 "Hong2009_CircadianClock", "Decroly1982_Enzymatic_Oscillator", 
 "Schulz2009_Th1_differentiation", "Yao2008_Rb_E2F_Switch", 
 "Akman2008_Circadian_Clock_Model2", "Shen-Orr2002_Single_Input_Module", 
 "Nijhout2004_Folate_Cycle", "Curien2009_Aspartate_Metabolism", 
 "Albert2005_Glycolysis", 
 "Chickarmane2008 - Stem cell lineage - NANOG GATA-6 switch", 
 "Morris2008 - Fitting protein aggregation data via F-W 2-step mechanism", 
 "Achcar2012 - Glycolysis in bloodstream form T. brucei", 
 "Holzhutter2004_Erythrocyte_Metabolism", "Tolic2000_InsulinGlucoseFeedback", 
 "Morris2009 - \[Alpha]-Synuclein aggregation variable temperature and pH", 
 "Bianconi2012 - EGFR and IGF1R pathway in lung cancer", 
 "Bakker2001_Glycolysis", "DeVries2000_PancreaticBetaCells_InsulinSecretion", 
 "Dutta-Roy2015 - Opening of the multiple AMPA receptor conductance states", 
 "Yi2003_GproteinCycle", "Bertram1995_PancreaticBetaCell_CRAC", 
 "Mueller2015 - Hepatocyte proliferation, T160 phosphorylation of CDK2", 
 "Schaber2012 - Hog pathway in yeast", "Leloup2003_CircClock_DD", 
 "Bertram2004_PancreaticBetaCell_modelB", 
 "Pritchard2014 - plant-microbe interaction", 
 "Leloup2003_CircClock_DD_REV-ERBalpha", 
 "Chaouiya2013 - EGF and TNFalpha mediated signalling pathway", 
 "Xu2003 - Phosphoinositide turnover", 
 "Machado2014 - Curcumin production pathway in Escherichia coli", 
 "Vinod2011_MitoticExit", "Cronwright2002_Glycerol_Synthesis", 
 "Gould2013 - Temperature Sensitive Circadian Clock", 
 "Blum2000_LHsecretion_1", "Ratushny2012_ASSURE_I", 
 "Middleton2012_GibberellinSignalling", "Ratushny2012_ASSURE_II", 
 "Faratian2009 - Role of PTEN in Trastuzumab resistance", 
 "Nyman2012_InsulinSignalling", 
 "Mosca2012 - Central Carbon Metabolism Regulated by AKT", 
 "Valero2006_Adenine_TernaryCycle", 
 "Tan2012 - Antibiotic Treatment, Inoculum Effect", 
 "Ihekwaba2004_NFkB_Sensitivity", "Singh2006_TCA_Ecoli_acetate", 
 "Singh2006_TCA_Ecoli_glucose", "Borisov2009_EGF_Insulin_Crosstalk", 
 "Meyer1991_CalciumSpike_ICC", "Westermark2003_Pancreatic_GlycOsc_basic", 
 "Radulescu2008_NFkB_hierarchy_M_14_25_28_Lipniacky", 
 "Radulescu2008_NFkB_hierarchy_M_39_65_90", 
 "Swat2004_Mammalian_G1_S_Transition", "Beltrami1995_ThrombinGeneration_C", 
 "Curien2003_MetThr_synthesis", "Ma2002_cAMP_oscillations", "Aubert2002 - \
Coupling between Brain electrical activity, Metabolism and Hemodynamics", 
 "Beltrami1995_ThrombinGeneration_D", "Fung2005_Metabolic_Oscillator", "Nishi\
o2008 - Design of the phosphotransferase system for enhanced glucose uptake \
in E. coli.", "Costa2014 - Computational Model of L. lactis Metabolism", 
 "Fuss2006_MitoticActivation", "Lee2010_ThrombinActivation_OneForm", 
 "Hockin1999_BloodCoagulation_VaInactivation", 
 "Orfao2008_ThrombinGeneration_AmidolyticActivity", 
 "Mueller2008_ThrombinGeneration_minimal", 
 "Arnold2011_Schultz2003_RuBisCO-CalvinCycle", 
 "Leloup2003_CircClock_LD_REV-ERBalpha", 
 "Arnold2011_Medlyn2002_RuBisCO-CalvinCycle", "Hornberg2005_ERKcascade", 
 "Smith2009 - RGS mediated GTP hydrolysis", 
 "Arnold2011_Farquhar1980_RuBisCO-CalvinCycle", "Suh2004_KCNQ_Regulation", 
 "Zhou2015 - Circadian clock with immune regulator NPR1", 
 "Saeidi2012 - Quorum sensing device that produces GFP", 
 "Sturis1991_InsulinGlucoseModel_UltradianOscillation", 
 "Thomsen1988_AdenylateCyclase_Inhibition", 
 "Kolodkin2013 - Nuclear receptor-mediated cortisol signalling network", 
 "Maree2006_DuCa_Type1DiabetesModel", "Proctor2006_telomere", "Sass2009 - \
Approach to an \[Alpha]-synuclein-based BST model of Parkinson's disease", 
 "Maeda2006_MyosinPhosphorylation", "Smallbone2011_TrehaloseBiosynthesis", 
 "Lai2014 - Hemiconcerted MWC model of intact calmodulin with two targets", 
 "Maurya2005_GTPaseCycle_reducedOrder", "Aguilera 2014 - HIV latency. \
Interaction between HIV proteins and immune response", 
 "Bornheimer2004_GTPaseCycle", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_QSS_PSEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_QSS_USEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_PSEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M4_K2_USEQ)", 
 "Tseng2012 - Circadian clock of N.crassa", "Bai2003_G1phaseRegulation", 
 "Gupta2009 - Eicosanoid Metabolism", "Thomsen1989_AdenylateCyclase", 
 "Shi1993_Caffeine_pressor_tolerance", 
 "deBack2012 - Lineage Specification in Pancreas Development", 
 "Veening2008_DegU_Regulation", 
 "McAuley2012 - Whole-body Cholesterol Metabolism", 
 "Tham2008 - PDmodel, Tumour shrinkage by gemcitabine and carboplatin", 
 "Kuhn2009_EndoMesodermNetwork", "Nazaret2009_TCA_RC_ATP", 
 "Wilhelm2009_BistableReaction", "Overgaard2007_PDmodel_IL21", 
 "Sarma2012 - Oscillations in MAPK cascade (S1)", 
 "Jiang2007 - GSIS system, Pancreatic Beta Cells", 
 "Westermark2003_Pancreatic_GlycOsc_extended", 
 "Schaber2006_Pheromone_Starvation_Crosstalk", 
 "DallaMan2007_MealModel_GlucoseInsulinSystem", 
 "Goldbeter2006_weightCycling", "Leloup2003_CircClock_LD", 
 "Bertram2000_PancreaticBetaCells_Oscillations", 
 "Chay1997_CalciumConcentration", "Mears1997_CRAC_PancreaticBetaCells", 
 "Bertram2007_IsletCell_Oscillations", 
 "Yugi2014 - Insulin induced signalling (PFKL phosphorylation) - model 2", 
 "Zeilinger2006_PRR7-PRR9light-Y", 
 "Yugi2014 - Insulin induced signalling (PFKL phosphorylation) - model 1", 
 "Zeilinger2006_PRR7-PRR9light-Yprime", 
 "Qi2013 - IL-6 and IFN crosstalk model (non-competitive)", 
 "Goldbeter1990_CalciumSpike_CICR", 
 "Yuraszeck2010 - Vulnerabilities in the Tau Network in Tau Pathophysiology", 
 "Laub1998_SpontaneousOscillations", 
 "Ouyang2014 - photomorphogenic UV-B signalling network", 
 "Troein2011_ClockCircuit_OstreococcusTauri", 
 "Fuentes2005_ZymogenActivation", "Qi2013 - IL-6 and IFN crosstalk model", "B\
r\[ADoubleDot]nnmark2013 - Insulin signalling in human adipocytes (diabetic \
condition)", "Yamada2003_JAK_STAT_pathway", 
 "Talemi2014 - Arsenic toxicity and detoxification mechanisms in yeast", 
 "Vernoux2011_AuxinSignaling_AuxinFluctuating", 
 "Yamada2003_JAK_STAT_SOCS1_knockout", "Miao2010 - Innate and adaptive immune \
responses to primary Influenza A Virus infection", 
 "Vernoux2011_AuxinSignaling_AuxinSingleStepInput", 
 "Zeilinger2006_PRR7-PRR9-Y", "Baker2013 - Cytokine Mediated Inflammation in \
Rheumatoid Arthritis - Age Dependant", 
 "Erguler2013 - Unfolded protein stress response", 
 "Nakakuki2010_CellFateDecision_Core", 
 "Sneppen2009 - Modeling proteasome dynamics in Parkinson's disease", 
 "Pokhilko2013 - TOC1 signalling in Arabidopsis circadian clock", 
 "Nakakuki2010_CellFateDecision_Mechanistic", "Br\[ADoubleDot]nnmark2013 - \
Insulin signalling in human adipocytes (normal condition)", 
 "Teusink1998_Glycolysis_TurboDesign", "Wolf2001_Respiratory_Oscillations", "\
Venkatraman2012 - Interplay between PLS and TSP1 in TGF-\[Beta]1 activation", 
 "Hunziker2010_p53_StressSpecificResponse", 
 "Proctor2005 - Actions of chaperones and their role in ageing", "Sarma2012 - \
Oscillations in MAPK cascade (S2), inclusion of external signalling module", 
 "Sarma2012 - Oscillations in MAPK cascade (S2)", 
 "Sarma2012 - Oscillations in MAPK cascade (S2n)", 
 "Sarma2012 - Oscillations in MAPK cascade (S1n)", 
 "Ralser2007_Carbohydrate_Rerouting_ROS", "Lai2007_O2_Transport_Metabolism", 
 "Reyes-Palomares2012 - a combined model hepatic polyamine and sulfur \
aminoacid metabolism - version2", "Restif2006_Whooping_Cough", "Carbo2013 - \
Cytokine driven CD4+ T Cell differentiation and phenotype plasticity", 
 "Neumann2010_CD95Stimulation_NFkB_Apoptosis", 
 "Kotte2010_Ecoli_Metabolic_Adaption", "Lei2001_Yeast_Aerobic_Metabolism", 
 "Vasalou2010_Pacemaker_Neuron_SCN", "Zi2011_TGF-beta_Pathway", 
 "Brannmark2010_InsulinSignalling_Mifamodel", 
 "Proctor2011_ProteinHomeostasis_NormalCondition", 
 "Koschorreck2008_InsulinClearance", "FitzHugh1961_NerveMembrane", 
 "Bachmann2011_JAK2-STAT5_FeedbackControl", "Locke2006_CircClock_LL", 
 "Fridlyand2010_GlucoseSensitivity_A", 
 "Baker2013 - Cytokine Mediated Inflammation in Rheumatoid Arthritis", 
 "Fridlyand2010_GlucoseSensitivity_B", 
 "Cloutier2009 - Brain Energy Metabolism", 
 "Ehrenstein1997 - The choline-leakage hypothesis in Alzheimer's disease", "E\
hrenstein2000 - Positive-Feedback model for the loss of acetylcholine in \
Alzheimer's disease", 
 "Das2010 - Effect of a gamma-secretase inhibitor on Amyloid-beta dynamics", 
 "Cloutier2012 - Feedback motif for Parkinson's disease", 
 "Lee2010_ThrombinActivation_OneForm_minimal", 
 "Reiterer2013 - pseudophosphatase STYX role in ERK signalling", 
 "Butenas2004_BloodCoagulation", "Ortega2013 - Interplay between secretases \
determines biphasic amyloid-beta level", 
 "Panteleev2002_TFPImechanism_schmema1", "Auer2010 - Correlation between lag \
time and aggregation rate in protein aggregation", 
 "Panteleev2002_TFPImechanism_schmema2", 
 "Liebal2012 - B.subtilis post-transcriptional instability model", 
 "Fujita2010_Akt_Signalling_EGFRinhib", 
 "Smallbone2013 - Serine biosynthesis", "Fujita2010_Akt_Signalling_NGF", 
 "Firczuk2013 - Eukaryotic mRNA translation machinery", 
 "Fujita2010_Akt_Signalling_EGF", 
 "Smallbone2013 - Metabolic Control Analysis - Example 3", "Ouzounoglou2014 - \
Modeling of alpha-synuclein effects on neuronal homeostasis", 
 "Tiago2010_FeMetabolism_FeLoaded", 
 "Smallbone2013 - Metabolic Control Analysis - Example 2", 
 "Tiago2010_FeMetabolism_FeAdequate", 
 "Smallbone2013 - Metabolic Control Analysis - Example 1", 
 "Bidkhori2012 - EGFR signalling in NSCLC", 
 "Bidkhori2012 - normal EGFR signalling", 
 "Liebal2012 - B.subtilis transcription inhibition model", 
 "Proctor2012 - Role of Amyloid-beta dimers in aggregation formation", "Orteg\
a2006 - bistability from double phosphorylation in signal transduction", 
 "Liebal2012 - B.subtilis sigB proteolysis model", 
 "Tiago2010_FeMetabolism_FeDeficient", "Rehm2006_Caspase", 
 "Piedrafita2010_MR_System", "Bier2000_GlycolyticOscillation", 
 "Chen2009 - ErbB Signaling", "Abell2011_CalciumSignaling_WithAdaptation", 
 "Nyman2011_M3Hierarachical_InsulinGlucosedynamics", 
 "Nag2011_ChloroplasticStarchDegradation", 
 "Abell2011_CalciumSignaling_WithoutAdaptation", 
 "Hui2014 - Age-related changes in articular cartilage", 
 "Panteleev2002_TFPImechanism_schmema3", 
 "Martins2013 - True and apparent inhibition of amyloid fribril formation", 
 "Lee2010_ThrombinActivation_OneForm_reduced", 
 "Stortelder1997 - Thrombin Generation Amidolytic Activity", "Fribourg2014 - \
Dynamics of viral antagonism and innate immune response (H1N1 influenza A \
virus - Cal/09)", "Fribourg2014 - Dynamics of viral antagonism and innate \
immune response (H1N1 influenza A virus - NC/99)", "Kallenberger2014 - CD95L \
induced apoptosis initiated by caspase-8, wild-type HeLa cells \
(cis/trans-cis/trans variant)", 
 "Kaiser2014 - Salmonella persistence after ciprofloxacin treatment", "Kallen\
berger2014 - CD95L induced apoptosis initiated by caspase-8, wild-type HeLa \
cells (cis/trans variant)", "Kallenberger2014 - CD95L induced apoptosis \
initiated by caspase-8, CD95 HeLa cells (cis/trans-cis/trans variant)", 
 "Muraro2014 - Vascular patterning in Arabidopsis roots", "Kallenberger2014 - \
CD95L induced apoptosis initiated by caspase-8, CD95 HeLa cells (cis/trans \
variant)", "Smallbone2013 - Colon Crypt cycle - Version 0", 
 "Ribba2012 - Low-grade gliomas, tumour growth inhibition model", 
 "Dwivedi2014 - Crohns IL6 Disease model - Anti-IL6R Antibody", 
 "Clarke2000 - One-hit model of cell death in neuronal degenerations", 
 "Fran\[CCedilla]ois2005 - Mixed Feedback Loop (two-gene network)", "Steckman\
n2012 - Amyloid beta-protein fibrillogenesis (kinetics of secondary structure \
conversion)", "Dwivedi2014 - Healthy Volunteer IL6 Model", 
 "Dwivedi2014 - Crohns IL6 Disease model - Anti-IL6 Antibody", 
 "Dwivedi2014 - Crohns IL6 Disease model - sgp130 activity", 
 "Schmitz2014 - RNA triplex formation", 
 "Crespo2012 - Kinetics of Amyloid Fibril Formation", "Vazquez2014 - Chemical \
inhibition from amyloid protein aggregation kinetics", "vanEunen2013 - \
Network dynamics of fatty acid ?-oxidation (time-course model)", 
 "Ayati2010_BoneRemodelingDynamics_WithTumour+DrugTreatment", 
 "Gardner2000 - genetic toggle switch in E.coli", "Bray1993_chemotaxis", "Pro\
ctor2013 - Cartilage breakdown, interventions to reduce collagen release", 
 "Ayati2010_BoneRemodelingDynamics_NormalCondition", "vanEunen2013 - Network \
dynamics of fatty acid ?-oxidation (steady-state model)", 
 "Ayati2010_BoneRemodelingDynamics_WithTumour", 
 "Cooling2007_IP3transients_CardiacMyocyte", 
 "Barrack2014 - Calcium/cell cycle coupling - Cyclin D dependent ATP release"\
, "Barrack2014 - Calcium/cell cycle coupling - Rs dependent ATP release", 
 "Queralt2006_MitoticExit_Cdc55DownregulationBySeparase", 
 "Messiha2013 - Pentose phosphate pathway model", 
 "Schliemann2011_TNF_ProAntiApoptosis", 
 "Messiha2013 - combined glycolysis and pentose phosphate pathway model", 
 "Hettling2011_CreatineKinase", 
 "Begitt2014 - STAT1 cooperative DNA binding - single GAS polymer model", 
 "Cookson2011_EnzymaticQueueingCoupling", 
 "Moriya2011_CellCycle_FissionYeast", 
 "Begitt2014 - STAT1 cooperative DNA binding - double GAS polymer model", "Ke\
rkhoven2013 - Glycolysis and Pentose Phosphate Pathway in T.brucei - MODEL C \
in fructose medium (with glucosomal ribokinase)", 
 "Pokhilko2012_CircClock_RepressilatorFeedbackloop", "Kerkhoven2013 - \
Glycolysis and Pentose Phosphate Pathway in T.brucei - MODEL D in fructose \
medium (with ATP:ADP antiporter)", "Band2012_DII-Venus_FullModel", 
 "Smallbone2013 - Colon Crypt cycle - Version 3", 
 "Band2012_DII-Venus_ReducedModel", 
 "Smallbone2013 - Colon Crypt cycle - Version 2", 
 "Mellor2012_LipooxygenasePathway", 
 "Smallbone2013 - Colon Crypt cycle - Version 1", 
 "Wegner2012_TGFbetaSignalling_FeedbackLoops", 
 "Heiland2012_CircadianClock_C.reinhardtii", "Kerkhoven2013 - Glycolysis and \
Pentose Phosphate Pathway in T.brucei - MODEL C (with glucosomal ribokinase)"\
, "Kerkhoven2013 - Glycolysis and Pentose Phosphate Pathway in T.brucei - \
MODEL D (with ATP:ADP antiporter)", 
 "Muraro2011_Cytokinin-Auxin_CrossRegulation", 
 "Benson2014 - FAAH inhibitors for the treatment of osteoarthritic pain", 
 "Ratushny2012_NF", "Kerkhoven2013 - Glycolysis in T.brucei - MODEL A", 
 "Ratushny2012_SPF", "Kerkhoven2013 - Glycolysis and Pentose Phosphate \
Pathway in T.brucei - MODEL B", "Ratushny2012_SPF_I", 
 "Maltsev2009_PacemakerCellModel_nonSteadyState", 
 "Cloutier2009_EnergyMetabolism_ModelC", 
 "Radulescu2008_NFkB_hierarchy_M_6_10_15", "Abu-Soud1999_NOHArginine", "Laroc\
que2014 - Metabolic reconstruction of Clostridium difficile pathogenic strain \
630 (iMLTC806cdf)", "Tiveci2005 - Calcium dynamics in brain energy metabolism \
and Alzheimer's disease", 
 "Qosa2014 - Mechanistic modeling that describes A? clearance across BBB", "P\
uri2010 - Mathematical Modeling for the Pathogenesis of Alzheimer's Disease", 
 "Kuroda2001_NO_cGMP_Pathway", "Aslanidi2009_caninePVJ", 
 "Noble1998_VentricularCellModel_ModelC", "Bagci2008_NO_Apoptosis_modelA", 
 "Wodarz2003_ImmunologicalMemory", "Wodarz1999_CTLmemoryresponse_HIV", 
 "Liu1999_PulsatileSecretion", "Moore2004_CML_TcellInteration", 
 "Bagci2006_ApoptoticStimuli", "Cloutier2009_EnergyMetabolism_ModelE", 
 "Matsuoka2003_VentricularCells_SinoatrialNodePacemaker", 
 "Capuani2015 - Human Core Catabolic Network", 
 "Nutsch2005_phototaxis_noncyc_spontaneous", 
 "Bordbar2011_TissueSpecific-Myocyte_MetablicNetwork", 
 "Bordbar2011_MultiTissueType_MetabolicNetwork", 
 "Bordbar2011_TissueSpecific-Adipocyte_MetabolicNetwork", 
 "Sertba\:015f2014 - Brain specific metabolic network (iMS570)", 
 "Bordbar2011_TissueSpecific-Hepatocyte_MetabolicNetwork", 
 "Bingzheng1990_GlucocorticoidsSecretion", "Wodarz2007_CTLinflation_ModelB", 
 "Vinnakota2006_MuscleGlycogenolysis_ModelB", 
 "Lockwood2006_PKPD_AlzheimersDisease", 
 "Mittler1998_HIV1_interactingTargetCells", 
 "Nowak1996_HostResponse_InfectiousAgents", "Leloup2004_CircadianRhythms", 
 "Mahajan2008_CardiacActionPotential_Arrhythmias", "Revilla2003_HIV1therapy", 
 "Webb2002_FasFasLsystem_Tumour", "Haugh2004_hGH", 
 "Schlosser2000_GlucoseInsulinFeedback_BetaCells", 
 "Vinnakota2006_MuscleGlycogenolysis_ModelC", 
 "You2010_General_Yeast_mRNA_Translation", "DiVentura2011_Min_System_E_coli", 
 "Basak_Cell_2007", "Yang2006_Methadone_PKmodel", "Bhalla1999_3d_fold_model", 
 "Ueda2001_typeBtrichothecenes", 
 "Perelson1993_HIVinfection_CD4Tcells_ModelD", 
 "Wu2006_ATPsynthesis_SkeletalMuscle", "Weinstein2000_OMCD", 
 "Gupta2007_HypothalamicPituitaryAdrenal_ModelB", 
 "Smallbone2009 - FBA model-Geometric Perspective", "Lemon2003_Ca2Dynamics", 
 "Kirschner1998_Immunotherapy_Tumour", 
 "Viladomiu2012 - PPARgamma role in C.diff associated disease", 
 "Priebe1998_VentricularArrhythmias", "Iyer2007_Arrhythmia_CardiacDeath", 
 "Sakmann2000_SodiumCurrent_ModelB", "Yamaguchi1996_MyocardialCa2", 
 "Nelson1995_HIV1therapy_DIVadministraion_ModelB", 
 "Jamshidi01_RBC_MetabolicNetwork", 
 "Best2009 - Homeostatic mechanisms in dopamine synthesis and release", 
 "Koivumaki2009_SERCAATPase_short", "vanBeek2007_OxPhos_HeartMuscleCells", 
 "Tabak2010_NeuronalNetworks", 
 "Phillips2007_AscendingArousalSystem_SleepWakeDynamics", 
 "Potter2006_AndrogenicRegulation", "Bagci2008_NO_Apoptosis_modelB", 
 "Koivumaki2009_SERCAATPase_Standalone", 
 "Bertram2002_Gprotein_SynapticSignal", "Wolf2000_AnaerobicGlycolysis", 
 "Sakmann2000_SodiumCurrent_ModelA", "Sakmann2000_SodiumCurrent_ModelC", 
 "Qiao2007_MAPK_Signaling_Bistable", "Kim2011_Oscillator_ExtendedI", 
 "Pitkanen2014 - Metabolic reconstruction of Coprinus cinereus using CoReCo", 
 "Kim2011_Oscillator_DetailedIII", "Pitkanen2014 - Metabolic reconstruction \
of Coccidioides immitis using CoReCo", "Kim2011_Oscillator_DetailedII", 
 "Pitkanen2014 - Metabolic reconstruction of Aspergillus oryzae using CoReCo"\
, "Kim2011_Oscillator_DetailedI", 
 "Pitkanen2014 - Metabolic reconstruction of Magnaporthe grisea using CoReCo"\
, 
 "Pitkanen2014 - Metabolic reconstruction of Chaetomium globosum using \
CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Candida tropicalis using CoReCo"\
, "Pitkanen2014 - Metabolic reconstruction of Pichia guilliermondii using \
CoReCo", "Pitkanen2014 - Metabolic reconstruction of Aspergillus nidulans \
using CoReCo", "Cloutier2009_EnergyMetabolism_ModelB", 
 "Aslanidi2009_RightAtrialTissue_Arrhythmogenesis", 
 "Warren2009_CalciumWavePropagation", "Brown1997_PlasmaMelatoninLevels", 
 "Stewart2009_ActionPotential_PurkinjeFibreCells", 
 "Demir1994_SinoatrialNode", "Jelic2005_HypothalamicPituitaryAdrenal", 
 "Halloy2002_FollicularAutomaton", "Kim2011_Oscillator_ExtendedIII", 
 "Lindblad1996_ActionPotential_AtrialMyocyte", 
 "Rattanakul2003_BoneFormation_Estrogenadministration", 
 "Waugh2006_WoundHealingMacrophageDynamics_Diabetic_ModelC", 
 "Heinze1998_GnRH_LH", "Rattanakul2003_BoneFormation_PTHadministration", 
 "Cloutier2009_EnergyMetabolism_ModelA", "Plata2010_P_falciparum_iTH366", 
 "Hayashi1999_NOSynth_Phospho", "Radulescu2008_NFkB_hierarchy_M_5_8_12", 
 "Conant2007_glycolysis_3A", "Pitkanen2014 - Metabolic reconstruction of \
Fusarium verticillioides using CoReCo", "Pitkanen2014 - Metabolic \
reconstruction of Phaeosphaeria nodorum using CoReCo", 
 "Fink2008_VentricularActionPotential", 
 "Chang2011_MetabolicNetworkReconstruction_ChlamydomonasReinhardtii", 
 "Fenton1998_MyocardiumVortexDynamics", 
 "Waugh2006_WoundHealing_Diabetic_ModelB", "Chen2000_CellCycle", 
 "Fallon2000_IL2dynamics", 
 "Waugh2006_WoundHealingMacrophageDynamics_Diabetic_ModelB", 
 "Holmes2006_MuscleContration", 
 "Inada2009_AtrioventricularNode_NodelHisCell", 
 "Chen2006_NitricOxideRelease", 
 "Wierschem2004_PancreaticIslets_ActionPotentials", "Kierzek2001_LacZ", 
 "Smith2004_CVS_human", "Feist2006_methanogenesis_OptiPyruvate", "Vaga2014 - \
Cross-modularity between high osmolarity and mating pathways - logical model"\
, "Mandlik2013 - Synthetic circuit of IPC synthase in Leishmania", 
 "Terfve2012 - Signalling in liver cancer - logical model", 
 "Smith2011_HumanHeartMitochondrian_MetabolicModel", 
 "Kervizic2008_Cholesterol_SREBP", "FangeElf2006_MinSystem_MesoRD", 
 "Martins2001_glyoxalase", "Miao2014 - Dynamics and migratory pathways of \
virus-specific antibody-secreting cell populations", 
 "Asthagiri2001_MAPK_Asthagiri_adapt_fb", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 17", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 18", "Quek2014 - \
Metabolic flux analysis of HEK cell culture using Recon 2 (reduced version of \
Recon 2)", "Hayer2005_AMPAR_traff_model1", "Chen2007_NeuronalEndothelialNOS", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 11", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 12", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 10", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 15", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 16", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 13", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 14", 
 "Beard2005_Mitochondrial_Respiration", "Heitzler2012_GPCRsignalling", 
 "Calzone2008_Rb", "Wang2008_Neonatal_heartfunction", 
 "Hayer2005_AMPAR_traff_model0", "Kim2010_VvuMBEL943_GSMR", 
 "Zhang2000_Peripheral_Sinoatrial_Node", 
 "Smallbone2010_Genome_Scale_Yeast_Kinetics", 
 "Rutkis2013 - Entner-Doudoroff pathway in Z.mobilis (cell-free)", 
 "Ajay_Bhalla_2004_PKM_Tuning", 
 "Rutkis2013 - Entner-Doudoroff pathway in Z.mobilis", 
 "Bakker1997_Glycolysis", "Ma2007_HumanMetabol_woEnergy", 
 "Watterson2012_CholesterolBiosynthesisPathway", 
 "Radulescu2008_NFkB_hierarchy_M_14_25_33", "Thomas2009_Buchnera_a_FBA", 
 "Hund2004_VentricularEpicardialAction", 
 "Waugh2006_WoundHealing_Diabetic_ModelC", 
 "Waugh2006_WoundHealingMacrophageDynamics_Diabetic_ModelA", 
 "Wodarz2007_CTLinflation_ModelC", "Cloutier2009_EnergyMetabolism_ModelF", 
 "Kyrylov2005_HPAaxis", "Cloutier2009_EnergyMetabolism_ModelD", 
 "Wodarz2003_CTLcrosspriming", "Guyton1972_PulmonaryOxygenIntake", 
 "Perelson1993_HIVinfection_CD4Tcells_ModelB", 
 "Grandi2009_VentricularMyocyte", "Reed2004_MethionineCycle", 
 "Wu2007_MitochondrialTCAcycle", "Guyton1972_StressRelaxation", 
 "Mufudza2012 - Estrogen effect on the dynamics of breast cancer", 
 "Lee2009 - Adaptive immune response to Influenza A Virus infection", 
 "Feist2007_EcMetabol_flux2", "Banaji2005_Brain_Cell_Metabolism", 
 "Inada2009_AtrioventricularNode_AtrioNodalCell", 
 "Nelson1995_HIV1therapy_DIVadministraion_ModelA", 
 "Heldt2002_OrthostaticStress_circpbpk", 
 "Kroll2000_PTH_BoneFormationDesorption", "Wodarz2007_CTLinflation_ModelA", 
 "Iribe2006_CaMKIIkineticsModel", "Smith1980_HypothalamicRegulation", 
 "Inada2009_AtrioventricularNode_NodalCell", 
 "Benson2008_Arrhythmogenesis_Mcell", 
 "Noble1998_VentricularCellModel_ModelB", "Feist2007_EcMetabol_flux1", 
 "Pasek2008_VentricularCardioMyocyte", 
 "Noble1998_VentricularCellModel_ModelA", "Sobaleva2005_ProlactinRegulation", 
 "Bondarenko2004_Myocyte_AP_apical", 
 "Noble1991_CardiacActionPotential_SodiumCalciumExchange", 
 "Yanagihara1980_PacemakerActivity", "Bertram2004_PancreaticBetaCell_modelA", 
 "Earm1990_CalciumDynamics_Cardiac", 
 "Vinnakota2006_MuscleGlycogenolysis_ModelA", 
 "Mackenzie1996_NaGlucoseCotransporter_Kidney", 
 "Perelson1993_HIVinfection_CD4Tcells_ModelC", "Venkatraman2011 - PLS-UPA \
behaviour in the presence of substrate competition", 
 "Benson2008_Arrhythmogenesis_Endocardial", 
 "Perelson1993_HIVinfection_CD4Tcells_ModelA", "Raman2006_MycolicAcid", 
 "Mazemondet2012 - beta-catenin dynamics in human neural progenitor cells", 
 "Ray2013 - S.cerevisiae meiosis-specific metabolic network", 
 "Jablonsky2008_kinetic_model_of_dimeric_PSII", 
 "Larocque2014 - Clostridium metabolic network reconstruction", 
 "Sanjuan2013 - Evolution of HIV T-cell epitope, immune activation model", 
 "Gall1999_CalciumBursting_BetaCellModel_B", 
 "Gall1999_CalciumBursting_BetaCellModel_A", 
 "Sanjuan2013 - Evolution of HIV T-cell epitope, control model", 
 "TenTusscher2006_VentricularCellModel", 
 "McAllister1975_CardiacPurkinjeFibres", "Conant2007_glycolysis_2A", 
 "Koenig2012_HepaticGlucoseMetabolism", "Aho2010_RefRec_S_cerevisiae", 
 "Bhalla2004_CaMKII_2003", "Feist2006_methanogenesis_OptiAcetate", 
 "Werner2005_IkappaB_kinase", "Rodriguez2005_denovo_pyrimidine_biosynthesis", 
 "Garny2003_SinoatrialNode", "Keener2001_OscillatoryInsulinSecretionModel", 
 "MacDonald2011_GeneticMetabolicDeterminants_BuchnereAphidicola", 
 "dAlcantara2003_SynapticPlasticity", 
 "Gall1999_CalciumBursting_BetaCellModel_C", 
 "Wanant2000_InsulinReceptorModel_B", "Lenbury2001_InsulinKineticsModel_A", 
 "Lenbury2001_InsulinKineticsModel_B", 
 "Magnus1997_MitoCa_BetaCellMinimalModel", 
 "Radulescu2008 - NF-\[Kappa]B hierarchy \[ScriptCapitalM](16,34,46)", 
 "Wanant2000_InsulinReceptorModel_A", "Yang2008_AAnetwork_PMN", 
 "Ajay_Bhalla_2004_Feedback_Tuning", "Zager2007_Genistein_Biliary_Excretion", 
 "Bekaert2012 - Reconstruction of D.rerio Metabolic Network", 
 "Smallbone2015 - pathway feedback", 
 "Smallbone2015 - forced pathway feedback", "Purvis2005_IonicCurrentModel", 
 "Hayer2005_simple_AMPAR_traff_model2", "Smallbone2015 - Michaelis Menten", 
 "Smallbone2015 - pathway", "Smallbone2015 - forced pathway", 
 "Caron2010_mTORsignalingNetwork_ActivityFlow", 
 "Caron2010_mTORC1_UpstreamRegulators", "Noble1962_HodgkinHuxleyEquation", 
 "Caron2010_mTOR_SignalingNetwork", "Oda2005_EGFR", 
 "Cao2010 - Epigenetic state of lysogeny in phage lambda", 
 "Koch2005 - sucrose breakdown pathway - petri net", 
 "Abu-Soud1999_NMArginine", "Cui2008_CardiacMyocytes", 
 "Radulescu2008_NFkB_hierarchy_M_14_30_41", "Yang2008_AAnetwork_EC", 
 "Pitkanen2014 - Metabolic reconstruction of Neurospora crassa using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Laccaria bicolor using CoReCo", 
 "Nutsch2005_phototaxis_noncyc_attractant_light", "Pitkanen2014 - Metabolic \
reconstruction of Uncinocarpus reesii using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Puccinia graminis using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Batrachochytrium dendrobatidis \
using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Pichia stipitis using CoReCo", 
 "Tymoshenko2015 - Genome scale metabolic model - ToxoNet1", 
 "Guyton1972_volumeReceptors", 
 "Heavner2012 - Metabolic Network of S.cerevisiae", 
 "Jesty1993_ProteolyticPositiveFeedback", 
 "Pitkanen2014 - Metabolic reconstruction of Pichia pastoris using CoReCo", 
 "Noble1984_SinoAtrialNode", "Pitkanen2014 - Metabolic reconstruction of \
Neosartorya fischeri using CoReCo", "Taffi2014 - Extension of metabolic \
reconstruction of Pseudomonas putida KT2440 with aerobic pathway of PCBs \
degradation", 
 "Pitkanen2014 - Metabolic reconstruction of Candida albicans using CoReCo", 
 "Chatterjee2010_BloodCoagulation", "Qiao2004_ThrombinGeneration", 
 "Guyton1972_AntidiureticHormone", "Pitkanen2014 - Metabolic reconstruction \
of Encephalitozoon cuniculi using CoReCo", "Pitkanen2014 - Metabolic \
reconstruction of Mycosphaerella graminicola using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Postia placenta using CoReCo", 
 "Duarte2007_Homo_sapiens_Metabol_Recon_1", 
 "Sorokina2009_PhyA_FHL_ON_OFF_9h", "Pitkanen2014 - Metabolic reconstruction \
of Lodderomyces elongisporus using CoReCo", "Pitkanen2014 - Metabolic \
reconstruction of Sclerotinia sclerotiorum using CoReCo", 
 "Beeler1977_Ventricular_Myocardial_Fiber_AP", 
 "Alvehag2006_IVGTT_GlucoseModel_A", "Alvehag2006_OGTT_GlucoseModel_B", 
 "Silber2007_IntravenousGlucose_IntegratedGlucoseInsulinModel", 
 "Farhy2009_GlucagonCounterRegulationModel", 
 "Gaetano2008_DiabetesProgressionModel", "Pitkanen2014 - Metabolic \
reconstruction of Sporobolomyces roseus using CoReCo", "Pitkanen2014 - \
Metabolic reconstruction of Schizosaccharomyces pombe using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Ashbya gossypii using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Candida lusitaniae using CoReCo"\
, "Pitkanen2014 - Metabolic reconstruction of Cryptococcus neoformans using \
CoReCo", "Pitkanen2014 - Metabolic reconstruction of Histoplasma capsulatum \
using CoReCo", "Bhalla2002_MAPK-bistability-fig1c", "Pitkanen2014 - Metabolic \
reconstruction of Debaryomyces hansenii using CoReCo", "Pitkanen2014 - \
Metabolic reconstruction of Nectria haematococca using CoReCo", "Pitkanen2014 \
- Metabolic reconstruction of Schizosaccharomyces japonicus using CoReCo", 
 "Iyer2004_VentricularMyocyte", "Corrias2008_GastricSlowWaveActivity", "Pitka\
nen2014 - Metabolic reconstruction of Saccharomyces cerevisiae using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Candida glabrata using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Botrytis cinerea using CoReCo", 
 "Shestov2014 - aerobic glycolysis", "Pitkanen2014 - Metabolic reconstruction \
of Fusarium graminearum using CoReCo", "Pitkanen2014 - Metabolic \
reconstruction of Phanerochaete chrysosporium using CoReCo", 
 "Muller2008_MAPKactivation_Dynamics", "Pitkanen2014 - Metabolic \
reconstruction of Aspergillus fumigatus using CoReCo", "Pitkanen2014 - \
Metabolic reconstruction of Phycomyces blakesleeanus using CoReCo", 
 "Salazar2009_PhotoperiodicRegulation", "Pitkanen2014 - Metabolic \
reconstruction of Kluyveromyces lactis using CoReCo", "Pitkanen2014 - \
Metabolic reconstruction of Aspergillus clavatus using CoReCo", 
 "Ciliberto2003_Swe1Network", "Egli2004_ProlactinRhythmicSecretion", 
 "Schneider2006_CardiacContractionModel", 
 "Pitkanen2014 - Metabolic reconstruction of Rhizopus oryzae using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Aspergillus niger using CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Trichoderma reesei using CoReCo"\
, 
 "Pitkanen2014 - Metabolic reconstruction of Fusarium oxysporum using CoReCo"\
, 
 "Pitkanen2014 - Metabolic reconstruction of Yarrowia lipolytica using \
CoReCo", 
 "Pitkanen2014 - Metabolic reconstruction of Ustilago maydis using CoReCo", "\
Pitkanen2014 - Metabolic reconstruction of Aspergillus terreus using CoReCo", 
 "Guyton1972_HeartHypertrophy", "Gilbert2008_ElectrochemicalBiosensor", "Wodk\
e2013 - Genome-scale constraint-based model of M.pneumoniae energy metabolism \
(iJW145)", "Bhalla2004_PKA_2003", "Demir1999_SinoatrialNodeActivity_Heart", 
 "Feist2006_methanogenesis_OptiMethanol", 
 "Corrias2007_GastricSMCellularActivation", 
 "Irvine1999_CardiacSodiumChannel", 
 "Luo1994_CardiacVentricularActionPotential", "Guyton1972_CapillaryDynamics", 
 "Faber2000_LRmodel_CardiacMyocytes", 
 "Dan\[OSlash]2006_Glycolysis_Reduction", "Guyton1972_Electrolytes", 
 "Shorten2007_SkeletalMuscleFatigue", 
 "Tomida2003_NFATfunctions_CalciumOscillation", "Guyton1972_Angiotensin", 
 "Feala2007_dros_mel_central_metabolism", 
 "Kuwahara2010_Fimbriation_Switch_42C", 
 "Kuwahara2010_Fimbriation_Switch_37C", 
 "Kuwahara2010_Fimbriation_Switch_28C", "Hayer2005_CaMKII_model3", 
 "Bhalla2004_EGFR_MAPK", "Chavez2009 - a core regulatory network of OCT4 in \
human embryonic stem cells", "Shannon2004_VentricularMyocyte", 
 "Guyton1972_NonMuscleBloodFlowControl", 
 "Masel2000 - Drugs to stop prion aggregates and other amyloids", 
 "Herrg\[ARing]rd2008_MetabolicNetwork_Yeast", "Bruck2008_Glycolysis", 
 "Petelenz-kurdziel2013 - Osmo adaptation pfk2627D", 
 "Petelenz-kurdziel2013 - Osmo adaptation WT", 
 "Petelenz-Kurdziel2013 - Osmo adaptation fps1D1", 
 "Petelenz-kurdzeil2013 - Osmo adaptation gpd1D", 
 "Petelenz-kurdziel2013 - Osmo adaptation hog1D", 
 "Petelenz-kurdziel2013 - Osmo adaptation HOG1att", 
 "Feist2006_methanogenesis_OptiH2-CO2", 
 "Thiele2013 - Ovary ovarian stroma cells", "Hoppe2012 - Predicting changes \
in metabolic function using transcript profiles (HepatoNet1b_mouse)", 
 "Thiele2013 - Parathyroid gland glandular cells", 
 "Bialik2010_Apoptosis_SPIKEmodel", "Tran2009_CaDynamicsSERCA_Cardiac", 
 "Siebert2008_MuscleContraction_CCSEC", 
 "Thiele2013 - Small intestine glandular cells", 
 "Thiele2013 - Tonsil germinal center cells", 
 "Thiele2013 - Uterus pre menopause cells in endometrial stroma", 
 "Goodwin1965_EnzymeControlProcess", "Thiele2013 - Breast glandular cells", 
 "Thiele2013 - Pancreas exocrine glandular cells", 
 "Thiele2013 - Smooth muscle smooth muscle cells", 
 "Gonz\[AAcute]lez-Domenech2012_MetabolicNetwork_iCG238", 
 "Thiele2013 - Cervix uterine glandular cells", 
 "Gonz\[AAcute]lez-Domenech2012_MetabolicNetwork_iCG230", 
 "Thiele2013 - Oral mucosa squamous epithelial cells", 
 "Bordbar2010_M_tuberculosis_Macrophage", 
 "Bordbar2010_Macrophage_Metabolism", "Goffin2010_L_plantarum_Metabolism", 
 "Thiele2013 - Vagina squamous epithelial cells", 
 "Thiele2013 - Prostate glandular cells", 
 "Thiele2013 - Uterus post menopause cells in endometrial stroma", 
 "Phillips2008_AscendingArousalSystem_Baseline", 
 "Gupta2007_HypothalamicPituitaryAdrenal_ModelA", "Sarma2012 - Interaction \
topologies of MAPK cascade (M4_K2_PSEQ_short_duration_signal)", 
 "Thiele2013 - Skeletal muscle myocytes", 
 "Vinnakotta2010_TranscientAnoxia_SOLmuscle", "Sarma2012 - Interaction \
topologies of MAPK cascade (M3_K2_PSEQ_short_duration_signal)", 
 "Thiele2013 - Duodenum glandular cells", "Heldt2002_OrthostaticStress_lpc", 
 "Sarma2012 - Interaction topologies of MAPK cascade \
(M2_K2_PSEQ_short_duration_signal)", 
 "Bertram2006_ATPproduction_Mitochondrial", "Thiele2013 - Lung pneumocytes", 
 "Phillips2008_AscendingArousalSystem_SleepDeprivation", 
 "Thiele2013 - Thyroid gland glandular cells", 
 "Tran2009_CardiacActiveForceGeneration", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_QSS_USEQ)", 
 "Thiele2013 - Cerebellum cells in molecular layer", 
 "Iancu2007_CardiacMyoscytes_cAMPsignaling", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_QSS_USEQ)", 
 "Thiele2013 - Pancreas islets of Langerhans", 
 "Saucerman2003_CardiacMyocyte_BetaAdrenergic", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_QSS_USEQ)", 
 "Thiele2013 - Liver hepatocytes", "Siebert2008_MuscleContraction_CC", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_QSS_PSEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_QSS_PSEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_QSS_PSEQ)", "Past\
ick2009 - Genome-scale metabolic network of Streptococcus thermophilus \
(iMP429)", "Saha2011- Genome-scale metabolic network of Zea mays (iRS1563)", 
 "Caspeta2012 - Genome-scale metabolic network of Pichia pastoris (iLC915)", 
 "Kuepfer2005 - Genome-scale metabolic network of Saccharomyces cerevisiae \
(iLL672)", "Quek2008 - Genome-scale metabolic network of Mus musculus", 
 "Guyton1972_MuscleBloodFlowControl", "Nogales2008 - Genome-scale metabolic \
network of Pseudomonas putida (iJN746)", "Chang2008 - ERK activation, \
hallucinogenic drugs mediated signalling through serotonin receptors", 
 "Pandit2003_VentricularMyocytes", "Baart2007 - Genome-scale metabolic \
network of Neisseria meningitidis (iGB555)", 
 "Reed2003 - Genome-scale metabolic network of Escherichia coli (iJR904)", 
 "Nutsch2005_phototaxis_noncyc_attractant_dark", 
 "Hingant2014 - Micellar On-Pathway Intermediate in Prion Amyloid Formation", 
 "Sohn2012 - Genome-scale metabolic network of Schizosaccharomyces pombe \
(SpoMBEL1693)", "Butera1999_Bursting_Pacemaker_Neuron_Model_1", "Kim2007 - \
Genome-scale metabolic network of Mannheimia succiniciproducens (iTY425)", 
 "Thiele2013 - Stomach lower glandular cells", 
 "Thiele2013 - Kidney cells in tubules", 
 "Thiele2013 - Esophagus squamous epithelial cells", 
 "Thiele2013 - Placenta decidual cells", 
 "Thiele2013 - Gall bladder glandular cells", 
 "Thiele2013 - Colon glandular cells", 
 "Thiele2013 - Cervix uterine squamous epithelial cells", 
 "Thiele2013 - Tonsil non germinal center cells", 
 "Hilgemann1987_CalciumTransients", 
 "Thiele2013 - Lateral ventricle neuronal cells", 
 "Thiele2013 - Liver bile duct cells", "Weisse2015 - Cell Growth", 
 "Li2006_QuorumSensing", "mahaney2000_SERCAregulation", "Heinemann2005 - \
Genome-scale reconstruction of Staphylococcus aureus (iMH551)", "Becker2005 - \
Genome-scale metabolic network of Staphylococcus aureus (iSB619)", 
 "Tiemann2011_PhenotypeTransitions", "Vanee2010 - Genome-scale metabolic \
model of Cryptosporidium hominis (iNV213)", 
 "Thiele2013 - Testis cells in seminiferus ducts", 
 "Thiele2013 - Lateral ventricle glial cells", 
 "Thiele2013 - Appendix glandular cells", 
 "Thiele2013 - Urinary bladder urothelial cells", 
 "Thiele2013 - Lymph node germinal center cells", 
 "Thiele2013 - Cerebral cortex neuronal cells", 
 "Thiele2013 - Hippocampus neuronal cells", 
 "Thiele2013 - Seminal vesicle glandular cells", 
 "Thiele2013 - Appendix lymphoid tissue", 
 "Thiele2013 - Bone marrow hematopoietic cells", 
 "Shlomi2011 - Warburg effect, metabolic model", 
 "Lambeth2002_Glycogenolysis", 
 "Mol2013 - Leishmania macrophage signaling network", 
 "Durot2008_A.Baylyi_ADP1Metabolism", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M4_K1_USEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M1_K1_PSEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M2_K1_PSEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M3_K1_PSEQ)", 
 "Celli\[EGrave]re2011 - Plasticity of TGF-\[Beta] Signalling", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M4_K1_PSEQ)", 
 "Thiele2013 - Vulva anal skin epidermal cells", "Sarma2012 - Interaction \
topologies of MAPK cascade (M1_K1_USEQ_short_duration_signal)", 
 "Thiele2013 - Spleen cells in red pulp", "Geier2011 - Integrin activation", 
 "Thiele2013 - Bronchus respiratory epithelial cells", 
 "Thiele2013 - Salivary gland glandular cells", 
 "Thiele2013 - Cerebral cortex glial cells", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M1_K1_USEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M2_K1_USEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M3_K1_USEQ)", 
 "Bhalla2004_MAPK_network_2003", "Faville2008_UPdepolarization", 
 "Thiele2013 - Nasopharynx respiratory epithelial cells", 
 "Guyton1972_PulmonaryFluidDynamics", 
 "Courtemanche1998_AtrialActionPotential", "Thiele2013 - Lung macrophages", 
 "Thiele2013 - Cerebellum Purkinje cells", "Cui2006_CalciumHomeostasis", 
 "Thiele2013 - Heart muscle myocytes", 
 "Thiele2013 - Placenta trophoblastic cells", 
 "Thiele2013 - Epididymis glandular cells", 
 "Radulescu2008_NFkB_hierarchy_M_34_60_82", 
 "Thiele2013 - Kidney cells in glomeruli", "Hornberg2005_MAPKsignalling", 
 "Thiele2013 - Stomach upper glandular cells", 
 "Thiele2013 - Tonsil squamous epithelial cells", 
 "Thiele2013 - Rectum glandular cells", "Hoefnagel2002_Glycolysis", 
 "Munz2009 - Zombie SIZRQ", "Ajay_Bhalla_2004_PKM_MKP3_Tuning", 
 "\[CapitalCCedilla]akir2004 - Central Carbon Metabolism of S.cerevisiae", 
 "Munz2009 - Zombie SIZRC", "Munz2009 - Zombi Impulsive Killing", "Reyes-Palo\
mares2012 - a combined model hepatic polyamine and sulfur aminoacid \
metabolism - version1", "Sarma2012 - Interaction topologies of MAPK cascade \
(M2_K2_USEQ_short_duration_signal)", 
 "Hayer2005_AMPAR_CaMKII_strong_coupling", "Sarma2012 - Interaction \
topologies of MAPK cascade (M3_K2_USEQ_short_duration_signal)", "Sarma2012 - \
Interaction topologies of MAPK cascade (M4_K2_USEQ_short_duration_signal)", "\
Sarma2012 - Interaction topologies of MAPK cascade \
(M1_K2_PSEQ_short_duration_signal)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_PSEQ)", 
 "Kaizu2010_BuddingYeastCellCycle_Map", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_PSEQ)", 
 "Endresen1997_SinoatrialActionPotential", "Sarma2012 - Interaction \
topologies of MAPK cascade (M1_K2_USEQ_short_duration_signal)", 
 "Twycross2010_Auxin_Transport", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_PSEQ)", 
 "Dolan2014 - calcium homeostasis (SOCE)", 
 "Guyton1972_ThirstDrinking_SaltAppetite", "Rienksma2014 - Genome-scale \
constraint-based metabolic model of M.tuberculosis", 
 "Stavrum2013 - Tryptophan Metabolism in Liver", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M3_K2_USEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M1_K2_USEQ)", 
 "Sarma2012 - Interaction topologies of MAPK cascade (M2_K2_USEQ)", "Sarma201\
2 - Interaction topologies of MAPK cascade \
(M3_K1_PSEQ_short_duration_signal)", "Sarma2012 - Interaction topologies of \
MAPK cascade (M4_K1_PSEQ_short_duration_signal)", "Sarma2012 - Interaction \
topologies of MAPK cascade (M1_K1_PSEQ_short_duration_signal)", "Sarma2012 - \
Interaction topologies of MAPK cascade (M2_K1_PSEQ_short_duration_signal)", "\
Sarma2012 - Interaction topologies of MAPK cascade \
(M3_K1_USEQ_short_duration_signal)", "Sarma2012 - Interaction topologies of \
MAPK cascade (M4_K1_USEQ_short_duration_signal)", "Bhalla2002_cAMP_pathway", 
 "Sarma2012 - Interaction topologies of MAPK cascade \
(M2_K1_USEQ_short_duration_signal)", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - heart", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
prostate", "Bhalla2001_MAPK_MKP1_oscillation", 
 "Goyal2014 - Genome-scale metabolic model of M.maripaludis S2", "Uhl\
\[EAcute]n2015 - Human tissue-based proteome metabolic network - pancreas", "\
Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - small \
intestine", "Wang2008_Rilusole_SkeletalMuscleCells", "Uhl\[EAcute]n2015 - \
Human tissue-based proteome metabolic network - duodenum", 
 "Hofmeyr1996 - metabolic control analysis", "Uhl\[EAcute]n2015 - Human \
tissue-based proteome metabolic network - gallbladder", 
 "Bhalla2004_PKC_2003", "Farhy2007_hGHregulation", 
 "Koenig2012_HepaticGlucoseMetabolism", "Uhl\[EAcute]n2015 - Human \
tissue-based proteome metabolic network - esophagus", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - ovary", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - skin", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - tonsil"\
, "J\[ODoubleDot]nsson2005_WUSCHELexpression_ShootApicalMeristem", 
 "Nookaew2008_Yeast_MetabolicNetwork_iIN800", 
 "Ciliberto2003_CyclinECdk2Timer", "Dokos1996_SinoatrialNode", 
 "Wei2011_MLCactivationPathway_EndothelialPermeability", "Uhl\[EAcute]n2015 - \
Human tissue-based proteome metabolic network - urinary", 
 "Wollbold2014 - Effects of reactive oxygen species", 
 "Telesco2011_HER3-ErbB3-RTK_SignalingNetwork", 
 "Fox2002_IonicMechanism_CardiacMyocytes", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - brain", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
placenta", "Vempati2007_MMP9_Regulation", "Haut1974_Pentose_Cycle_Rat", 
 "LeBeau1999_IP3R_Phosphorylation", "Vaseghi1999_Pentose_PP_yeast", 
 "Guyton1972_AtrialNatriureticPeptide", 
 "GonzalezHeydrich1994_HPAaxisRegulation_CortisolProduction", 
 "Aguda1999_G2_Damage_Checkpoint", "Karagiannis2004_CollagenIproteolysis", 
 "Wodarz2007_CD4TcellsInfection_VirusSpread", "Guyton1972_Autonomics", 
 "Guyton1972_HeartRateStrokeVolume", "Calzone2010_Cellfate_Master_Model", 
 "Radulescu2008_NFkB_hierarchy_M_8_12_19", 
 "Szappanos2011_GeneticInteractionNetwork_YeastMetabolism", 
 "Pasek2006_VentricularCardioMyocytes", 
 "Huthmacher2010_MetabolicNetwork_P.falciparum", 
 "Jablonsky2008_kinetic_model_of_monomeric_PSII", 
 "Huthmacher2010_HumanErythrocyte_MetabolicNetwork", "Grunwald2008 - Gene \
regulation of the Duchenne muscular dystrophy (Petri-net model)", 
 "Smallbone2013 - Human metabolism global reconstruction (recon 2.1x)", 
 "Ajay_Bhalla_2007_Bistable", 
 "Smallbone2013 - Human metabolism global reconstruction (recon 2.1)", 
 "Poolman2009_Metab_Arabidopsis_reduced", "Thomas2014 - The effect of aspirin \
resistance on platelet metabolism (constraint-based modelling)", 
 "Sachse2008_FibroblastInteractingMyocytes", 
 "Smith2010_Foxo_PTMs_AgeingRelatedSignallingPathway_C", 
 "Hinch2004_VentricularMyocytes", 
 "Smith2010_Foxo_PTMs_AgeingRelatedSignallingPathway_B", 
 "Smith2010_Foxo_PTMs_AgeingRelatedSignallingPathway_A", "Triana2014 - \
Genome-scale metabolic network of Synechococcus elongatus (iSyf715)", 
 "Yates2007_TcellHomeostasisProliferation", 
 "Thiele2013 - Hippocampus glial cells", "Uhl\[EAcute]n2015 - Human \
tissue-based proteome metabolic network - adrenal", 
 "Thiele2013 - Uterus post menopause glandular cells", "Uhl\[EAcute]n2015 - \
Human tissue-based proteome metabolic network - bone marrow", 
 "Thiele2013 - Skin epidermal cells", "Uhl\[EAcute]n2015 - Human tissue-based \
proteome metabolic network - appendix", 
 "Thiele2013 - Spleen cells in white pulp", "Uhl\[EAcute]n2015 - Human \
tissue-based proteome metabolic network - smooth muscle", 
 "Thiele2013 - Adrenal gland glandular cells", "Uhl\[EAcute]n2015 - Human \
tissue-based proteome metabolic network - fallopian", 
 "Thiele2013 - Cerebellum cells in granular layer", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - rectum"\
, 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
thyroid", "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network \
- skeletal", "Thiele2013 - Testis Leydig cells", 
 "Thiele2013 - Fallopian tube glandular cells", 
 "Thiele2013 - Uterus pre menopause glandular cells", "Uhl\[EAcute]n2015 - \
Human tissue-based proteome metabolic network - adipose", 
 "Thiele2013 - Lymph node non germinal center cells", 
 "Dreyfuss2013 - Genome-Scale Metabolic Model - N.crassa iJDZ836", 
 "Guyton1972_RedCells_Viscosity", 
 "Nazaret2008_Dynnik1980_CarbohydrateEnergyMetabolism", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - colon", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - lymph \
node", "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
salivary gland", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - spleen"\
, 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - kidney"\
, 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
stomach", 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - testis"\
, 
 "Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - liver", \
"Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - lung", "\
Uhl\[EAcute]n2015 - Human tissue-based proteome metabolic network - \
endometrium", "Nelson2000_HIV-1_general_model", "Schuetz2007_ecoli_FBA", 
 "Zou2007_MAPK_SignalingNetworks", "Ajay_Bhalla_2007_PKM", 
 "Karlstaedt2012 - CardioNet, A Human Metabolic Network", 
 "Caydasi2012_SPOC_UbiquitousInactive", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 09", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 08", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 07", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 06", 
 "Sackmann2006 - mating pheromone response pathway of S.cerevisiae", 
 "DePaor1986_CirculatoryAutoregulation", 
 "Radulescu2008_NFkB_hierarchy_M_24_45_62", 
 "Lee2012_GeneExpression_tTA-doxInteraction", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 01", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 00", 
 "Lee2012_GeneExpression_BasicDecoyModel", "Gomez-Cabrero2011_Atherogenesis", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 05", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 04", 
 "Caydasi2012_SPOC_HotSpotAssociation", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 03", 
 "Caydasi2012_SPOC_UbiquitousAssociation", "Houser2012_pheromone_Ste12", 
 "Smallbone2013 - Glycolysis in S.cerevisiae - Iteration 02", 
 "Radosavljevic2009_BioterroristAttack_PanicProtection", 
 "Nijhout2004_FolateCycle", "Abu-Soud1999_HomoArginine", 
 "DiFrancesco1985_CardiacElectricalActivity", 
 "Razumova2000_MyofilamentContractileBehaviour", 
 "Cui2008_ZincHomeostasisSystem", "Abu-Soud1999_L-Arginine", 
 "Nelson2000_HIV-1_intracellular_delay", 
 "Loira2012 - Metabolic Network of Y.lipolytica", 
 "Bazzani2012 - Genome scale networks of P.falciparum and human hepatocyte", 
 "B\[UDoubleDot]chel2013 - Dopaminergic Nerve Cell Model", 
 "Sorokina2011_StarchMetabolism_Ostreococcus", 
 "vanEunen2012 - Yeast Glycolysis (glucose upshift)", 
 "Kubota2012_InsulinAction_AKTpathway", 
 "Rao2014 - Fatty acid beta-oxidation (reduced model)", 
 "Rao2014 - Yeast glycolysis (reduced model)", 
 "Orth2011_E.coli_MetabolicNetwork", "Li2010_YeastGlycolysis", 
 "Nijhout2006_Hepatic_Folate_Metab", "Condorelli2001_GuanylateCyclase", 
 "Munz2009 - Zombie basic SZR", "Jerby2010_Liver_Metabolism", 
 "Gille2010_HepatoNet1_Metabolic_Network", 
 "Qiao2007_MAPK_Signaling_Oscillatory", "Nakano2010_Synaptic_Plasticity", 
 "Zhuang2011 - Ecoli FBA with membrane economics", 
 "Hayer2005_AMPAR_CaMKII_weak_coupling", 
 "MacNamara2012 - Signal transduction", 
 "Bordbar2011_HumanErythrocyte_MetabolicNetwork", 
 "Dempsher1984_ACTH_CortisolSecretion", 
 "Thiele2013 - Human metabolism global reconstruction (Recon 2)", "Aubert2005 \
- Interaction between astrocytes and neurons on energy metabolism", "Mardinog\
lu2013 - Genome-scale metabolic model (HMR version 1.0) - generic human cell"\
, "Mardinoglu2013 - Genome-scale metabolic model (HMR version 1.0) - human \
adipocytes (iAdipocytes1809)", "Mardinoglu2014 - Genome-scale metabolic model \
(HMR version 2.0) - generic human cell", "Mardinoglu2014 - Genome-scale \
metabolic model (HMR verson 2.0) - human hepatocytes (iHepatocytes2322)", 
 "Chang2010_Reduced_Kidney_FBA", "Islam2010_Dehalococcoides_Metabolism", 
 "Cottret2010_B_cicadellinicola_Met_Net", 
 "Gonzalez2010_N_pharaonis_metabolism", "Cottret2010_S_muelleri_Met_Net", 
 "MacGregor2005_HypothalamicSystems", 
 "Leipold1995_ThrombinFormation+inhibitors", "Kuharsky2001_BloodCoagulation", 
 "Leipold1995_ThrombinFormation-inhibitors", 
 "Nutsch2005_phototaxis_noncyc_repellent_dark", "Resendis-Antonio2007 - \
Genome-scale metabolic network of Rhizobium etli (iOR363)", 
 "Alam2010 - Genome-scale metabolic network of Streptomyces coelicolor", "Mon\
tagud2010 - Genome-scale metabolic network of Synechocystis sp. PCC6803 \
(iSyn669)", 
 "Thiele2005 - Genome-scale metabolic network of Helicobacter pylori \
(iIT341)", "tenTusscher2004_CardiacArrhythmias", "AbuOun2009 - Genome-scale \
metabolic network of Salmonella typhimurium (iMA945)", 
 "Archer2011 - Genome-scale metabolic model of Escherichia coli (iCA1273)", 
 "Kogan2001_aPTT_coagulation", "Saha2011 - Genome-scale metabolic network of \
Arabidopsis thaliana (iRS1597)", "F\[ODoubleDot]rster2008 - Genome-scale \
metabolic network of Saccharamyces cerevisiae (iFF708)", 
 "Oh2007 - Genome-scale metabolic network of Bacillus subtilis (iYO844)", "Ol\
iveira2005 - Genome-scale metabolic network of Lactococcus lactis (iAO358)", 
 "Henry2009 - Genome-scale metabolic network of Bacillus subtilis (iBsu1103)"\
, "Kogan2001_aPTT_preincubation", 
 "Mazein2013 - Cholesterol biosynthesis pathway", 
 "Mazein2013 - Shunt pathway", "Kiselyov2009_InsulinReceptorModel", 
 "Jol2012_YeastMetabolism_EFManalysis", "Mahadevan2006 - Genome-scale \
metabolic network of Geobacter sulfurreducens (iRM588)", 
 "Nutsch2005_phototaxis_noncyc_repellent_light", "Raghunathan2010 - \
Genome-scale metabolic network of Francisella tularensis (iRS605)", "Roberts2\
010 - Genome-scale metabolic network of Clostridium thermocellum (iSR432)", "\
Jamshidi2007 - Genome-scale metabolic network of Mycobacterium tuberculosis \
(iNJ661)", "Sun2009 - Genome-scale metabolic network of Geobacter \
metallireducens (iJS747)", "Liu2009_GlucoseMobilization_UptakeModel", 
 "Bhalla2002_mkp1_feedback_effects", 
 "Martins2004_Yeast_Glycolysis_GlycerolSynthesis", 
 "Coggins2014 - CXCL12 dependent recruitment of beta arrestin", 
 "Poolman2009_GS_Metabolism_Arabidopsis", "Luo1991_VentricularCardiacAction", 
 "Ponce-de-L\[EAcute]on2013 - Genome scale metabolic model for \
Blattabacterium cuenoti (iMP240)", 
 "Bekaert2010_mouse_inferred_metabolic_network", 
 "Bekaert2010_macaque_inferred_metabolic_network", 
 "Bekaert2010_chimpanzee_inferred_metabolic_network", 
 "Lenbury1991_CortisolSecretionSystem", 
 "Bekaert2010_dog_inferred_metabolic_network", 
 "Bekaert2010_horse_inferred_metabolic_network", 
 "Bekaert2010_cattle_inferred_metabolic_network", "Phillips2003_RasGTPase", 
 "Bekaert2010_rat_inferred_metabolic_network", "Oda2006_TollLikeR", 
 "Livshitz2007_CardiacMyocytes", 
 "Ray2013 - Meiotic initiation in S. cerevisiae", "Borodina2005 - \
Genome-scale metabolic network of Streptomyces coelicolor (iIB711)", 
 "Koster1988_Histone_Expression", "Kurata2002_SinoatrialNode", 
 "Niederer2006_CardiacMyocyteRelaxation", 
 "Imam2011_RhodobacterSphaeroides_MetabolicNetwork", 
 "Guyton1972_Aldosterone", 
 "Imam2013 - Metabolic network in Rhodobacter sphaeroides (iRsp1140)", "Fang2\
011 - Genome-scale metabolic network of Burkholderia cenocepacia (iKF1028)", 
 "Sohn2010 - Genome-scale metabolic network of Pichia pastoris (PpaMBEL1254)"\
, "Schilling2000- Genome-scale metabolic network of Haemophilus influenzae \
(iCS400)", "Suthers2009 - Genome-scale metabolic network of Mycoplasma \
genitalium (iPS189)", 
 "Sigurdsson2010 - Genome-scale metabolic model of Mus Musculus (iMM1415)", 
 "Yang2008_AAnetwork_PLT", "Liao2011 - Genome-scale metabolic reconstruction \
of Klebsiella pneumoniae (iYL1228)", 
 "Widiastuti2010 - Genome-scale metabolic network Zymomonas mobilis (iZM363)"\
, "Pepke2010_Full_Ca2/CaM_mCaMKII", "Vongsangnak2008 - Genome-scale metabolic \
network of Aspergillus oryzae (iWV1314)", 
 "Chavali2008 - Genome-scale metabolic network of Leishmania major (iAC560)", 
 "Hayer2005_CaMKII_noPKA_model3", "Raghunathan2009 - Genome-scale metabolic \
network of Salmonella typhimurium (iRR1083)", "Mazumdar2008 - Genome-scale \
metabolic network of Porphyromonas gingivalis (iVM679)", "Zou2012 - \
Genome-scale metabolic network of Ketogulonicigenium vulgare (iWZ663)", 
 "Haraldsd\[OAcute]ttir2014 - Recon 2.03", 
 "Rex2013 - Genome scale metabolic model of D.shibae (iDsh827)", 
 "Shimoni2009 - Escherichia Coli SOS", "Benedict2011 - Genome-scale metoblic \
network of Methanosarcina acetivorans (iMB745)", "Puchalka2008 - Genome-scale \
metabolic network of Pseudomonas putida (iJP815)", 
 "Jafri1998_VentricularMyocyte", "Mulquiney1999_BPG_metabolism", "Sohn2010 - \
Genome-scale metabolic network of Pseudomonas putida (PpuMBEL1071)", 
 "Selvarasu2009 - Genome-scale metabolic network of Mus Musculus (iSS724)", 
 "Zhang2009 - Genome-scale metabolic network of Thermotoga maritima", "Anders\
en2009 - Genome-scale metabolic network of Aspergillus niger (iMA871)", "Noga\
les2012 - Genome-scale metabolic network of Synechocystis sp. PCC6803 \
(iJN678)", "Teusink2006 - Genome-scale metabolic network of Lactobacillus \
plantarum (iBT721)", "Senger2008 - Genome-scale metabolic network of \
Clostridium acetobutylicum (iCac802)", "deOliveiraDalMolin2010 - Genome-scale \
metabolic network of Arabidopsis thaliana (AraGEM)", "Kim2009 - Genome-scale \
metabolic network of Acinetobacter baumannii (AbyMBEL891)", 
 "Poliquin2013 - Energy Deregulations in Parkinson's Disease", 
 "Invergo2014 - Mammalian Rod Phototransduction", "Kumar2011 - Genome-scale \
metabolic network of Methanosarcina acetivorans (iVS941)", "Milne2011 - \
Genome-scale metabolic network of Clostridium beijerinckii (iCB925)", "Schill\
ing2002 - Genome-scale metabolic network of Helicobacter pylori (iCS291)", "P\
inchuck2010 - Genome-scale metabolic network of Shewanella oneidensis \
(iSO783)", "Lee2010 - Genome-scale metabolic network of Zymomonas mobilis \
(iZmobMBEL601)", "Lee2008 - Genome-scale metabolic network of Clostridium \
acetobutylicum (iJL432)", "Mo2009 - Genome-scale metabolic network of \
Saccharomyces cerevisiae (iMM904)", "Ma2007_HumanMetabol_wEnergy", 
 "Sarai2003_CardiacSAnodePacemaker", "Csikasz-Nagy2006_Cell_Cycle", "Fang2010 \
- Genome-scale metabolic network of Mycobacterium tuberculosis (iNJ661m)", "D\
uarte2004 - Genome-scale metabolic network of Saccharomyces cerevisiae \
(iND750)", "Flahaut2013 - Genome-scale metabolic model of L.lactis (MG1363)", 
 "David2008 - Genome-scale metabolic network of Aspergillus nidulans \
(iHD666)", "Maleckar2008_AtrialMyocyte", "Thiele2011 - Genome-scale metabolic \
network of Salmonella Typhimurium (STM_v1_0)", 
 "Benson2008_Arrhythmogenesis_Epicardial", 
 "Vinnakota2010_TranscientAnoia_EDLmuscle", 
 "Heldt2002_OrthostaticStress_heart", 
 "Waugh2006_WoundHealing_Diabetic_ModelD", 
 "Reidl2006_CalciumOscillationInCilia", "Dupeux2011_ABAreceptor_Monomer", 
 "Koivumaki2009_SERCAATPase_long", 
 "Maltsev2009_PacemakerCellModel_SteadyState", 
 "Sneyd1995_CalciumWave_IP3diffusion", 
 "Waugh2006_WoundHealing_Diabetic_ModelA", 
 "Terkildsen2008_CardiomyocyteFunction", "Dupeux2011_ABAreceptor_Dimer", "Liu\
2012 - Genome-scale metabolic network of Scheffersomyces stipitis (iTL885)", 
 "Bhattacharya2011_UreaCycle", 
 "Lopez2013 - extrinsic apoptosis M1a embedded", "Hong2004 - Genome-scale \
metabolic network of Mannheimia succiniciproducens (iSH335)", "Risso2009 - \
Genome-scale metabolic network of Rhodoferax ferrireducens (iCR744)", 
 "Chung2010 - Genome-scale metabolic network of Pichia pastoris (iPP668)", 
 "Caspeta2012 - Genome-scale metabolic network of Pichia stipitis (iSS884)", 
 "Beste2007 - Genome-scale metabolic network of Mycobacterium tuberculosis \
(GSMN_TB)", "Oberhardt2008 - Genome-scale metabolic network of Pseudomonas \
aeruginosa (iMO1056)"}
