(* Mathematica Init File *)

BeginPackage["Toolbox`ThirdParty`"]
EndPackage[]

Get["Toolbox`ThirdParty`BiochemThermo`BasicBiochemData2modified`"]
(* Get["Toolbox`ThirdParty`BiochemThermo`BasicBiochemData3modified`"] *)
