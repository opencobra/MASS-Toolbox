UnitSet["Troy"]={
	DeclareUnit["Grain", Unit[1/7000, "Pound"],  UsageMessage->"Grain is a unit of weight.",TraditionalLabel->"gr"], 
	DeclareUnit["TroyOunce", Unit[480, "Grain"], UsageMessage->"TroyOunce is a unit of weight.",TraditionalLabel->"oz t"],
	DeclareUnit["TroyPound", Unit[5760, "Grain"], UsageMessage->"TroyOunce is a unit of weight.",TraditionalLabel->"lb t"],
	DeclareUnit["Pennyweight", Unit[24, "Grain"], UsageMessage->"Pennyweight is a unit of weight.",TraditionalLabel->"dwt"]}; 

