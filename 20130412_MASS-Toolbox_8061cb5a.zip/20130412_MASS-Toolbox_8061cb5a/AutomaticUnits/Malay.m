UnitSet["Malay"]={
	DeclareUnit["Kati",Unit[4/3, "Pound"],UsageMessage->"Kati is a Malay unit of mass."],
	DeclareUnit["Pikul",Unit[100, "Kati"],UsageMessage->"Pikul is a Malay unit of mass."],
	DeclareUnit["Gantang",Unit["ImperialGallon"],UsageMessage->"Gentang is a Malay unit of volume."],
	DeclareUnit["Chupak",1/4Unit["Gantang"],UsageMessage->"Chupak is a Malay unit of volume."],
	DeclareUnit["Chentong",1/4 Unit["Chupak"],UsageMessage->"Chentong is a Malay unit of volume."],
	DeclareUnit["Leng",2Unit["Chentong"],UsageMessage->"Leng is a Malay unit of volume."]
};