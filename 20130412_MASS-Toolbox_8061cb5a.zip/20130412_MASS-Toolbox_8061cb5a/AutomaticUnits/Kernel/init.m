(* Mathematica Init File *)
Get[ "AutomaticUnits`AutomaticUnits`"]