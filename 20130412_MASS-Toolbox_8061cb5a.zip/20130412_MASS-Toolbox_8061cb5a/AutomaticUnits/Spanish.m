UnitSet["Spanish"]={
	DeclareUnit["Pie",Unit[0.2786,"Meter"],UsageMessage->"Pie is an old Spanish unit of length."],			
	DeclareUnit["Vara",Unit[3,"Pie"],UsageMessage->"Pie is an old Spanish unit of length."],	
	DeclareUnit["Paso",Unit[5,"Pie"],UsageMessage->"Pie is an old Spanish unit of length."],	
	DeclareUnit["Legua",Unit[15000,"Pie"],UsageMessage->"Pie is an old Spanish unit of length."],			
	DeclareUnit["Punto",Unit[1/1728,"Pie"],UsageMessage->"Pie is an old Spanish unit of length."],	
	DeclareUnit["Linea",Unit[1/144,"Pie"],UsageMessage->"Pie is an old Spanish unit of length."],	
	DeclareUnit["Pulgada",Unit[1/12,"Pie"],UsageMessage->"Pie is an old Spanish unit of length."],
			
	DeclareUnit["Palmo",Unit[0.20873,"Meter"],UsageMessage->"Palmo is an old Spanish unit of length."],	
	DeclareUnit["Coto",Unit[1/2,"Palmo"],UsageMessage->"Coto is an old Spanish unit of length."],	
		
	DeclareUnit["Labor",1000000Unit["Vara"],UsageMessage->"Pie is an old Spanish unit of area."]	
};